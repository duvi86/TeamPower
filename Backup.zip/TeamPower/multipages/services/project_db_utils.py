"""Database functions for project management in transactions page"""

from db_management.project_db import (
    get_projects as get_all_projects, 
    add_project as add_project_to_db, 
    update_project as update_project_in_db,
    delete_project as delete_project_from_db
)
from datetime import datetime

def add_project(name, description, start_date, end_date, ongoing, status, maturity, budget, currency, 
                potential_value, realized_value, refresh_date, program_id, spadm_id):
    """Add a new project to the database"""
    try:
        # Handle ongoing projects (set end_date to None if ongoing)
        end_date_final = None if ongoing else end_date
        
        # Convert empty strings to None for optional fields
        program_id_final = program_id if program_id else None
        spadm_id_final = spadm_id if spadm_id else None
        
        add_project_to_db(
            name=name,
            description=description,
            start_date=start_date,
            end_date=end_date_final,
            ongoing=bool(ongoing),
            status=status,
            budget=float(budget) if budget else 0.0,
            currency=currency,
            maturity=maturity,
            potential_value=float(potential_value) if potential_value else 0.0,
            realized_value=float(realized_value) if realized_value else 0.0,
            refresh_date=refresh_date,
            program_id=program_id_final,
            spadm_id=spadm_id_final
        )
        return True, "Project added successfully"
    except Exception as e:
        return False, f"Error adding project: {str(e)}"

def get_projects():
    """Get all projects from the database"""
    try:
        return get_all_projects()
    except Exception as e:
        print(f"Error getting projects: {e}")
        return []

def update_project(project_id, name, description, start_date, end_date, ongoing, status, maturity, 
                  budget, currency, potential_value, realized_value, refresh_date, program_id, spadm_id):
    """Update an existing project in the database"""
    try:
        # Handle ongoing projects (set end_date to None if ongoing)
        end_date_final = None if ongoing else end_date
        
        # Convert empty strings to None for optional fields
        program_id_final = program_id if program_id else None
        spadm_id_final = spadm_id if spadm_id else None
        
        update_project_in_db(
            project_id=project_id,
            name=name,
            description=description,
            start_date=start_date,
            end_date=end_date_final,
            ongoing=bool(ongoing),
            status=status,
            budget=float(budget) if budget else 0.0,
            currency=currency,
            maturity=maturity,
            potential_value=float(potential_value) if potential_value else 0.0,
            realized_value=float(realized_value) if realized_value else 0.0,
            refresh_date=refresh_date,
            program_id=program_id_final,
            spadm_id=spadm_id_final
        )
        return True, "Project updated successfully"
    except Exception as e:
        return False, f"Error updating project: {str(e)}"

def delete_project(project_id):
    """Delete a project from the database"""
    try:
        delete_project_from_db(project_id)
        return True, "Project deleted successfully"
    except Exception as e:
        return False, f"Error deleting project: {str(e)}"
