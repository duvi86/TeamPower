
import pandas as pd
from dash import dash_table, dcc, html, Input, Output
from Dash_template.multipages.utils.create_card import create_card
from ..utils.create_dropdown import create_dropdown
from dash import callback, ctx

def key_wins_table(df):
    columns = [
        {"name": "Key Win", "id": "key_win"},
        {"name": "Owner", "id": "owner_name"},
        {"name": "Status", "id": "status"},
        {"name": "Value Realized", "id": "value_realized"},
        {"name": "Value Potential", "id": "value_potential"},
        {"name": "Date Completed", "id": "date_completed"}
    ]
    for col in [c["id"] for c in columns]:
        if col not in df.columns:
            df[col] = ""
    df["value_realized"] = df["value_realized"].apply(lambda x: f"£{x:,.0f}" if pd.notnull(x) and x != "" else "")
    df["value_potential"] = df["value_potential"].apply(lambda x: f"£{x:,.0f}" if pd.notnull(x) and x != "" else "")

    # Row-per-page selector
    page_size_selector = html.Div([
        html.Label("Rows per page:", className="table-page-size-label"),
        create_dropdown(
            id="key-wins-table-page-size",
            options=[
                {"label": str(n), "value": n} for n in [5, 10, 20, 50, 100]
            ],
            default_value=10,
            class_name="table-page-size-dropdown"
        )
    ], className="table-page-size-container")

    table = dash_table.DataTable(
        id="key-wins-table",
        columns=columns,
        data=df.to_dict("records"),
        style_table={"overflowX": "auto"},
        style_cell={"textAlign": "left", "padding": "6px"},
        style_header={"backgroundColor": "#f8f9fa", "fontWeight": "bold"},
        page_size=10,
        filter_action="native",
        sort_action="native",
        row_selectable="single"
    )

    return create_card(
        title="Key Wins Table",
        content=[
            html.Div([
                page_size_selector,
                table
            ])
        ],
        color="info",
        class_name="key-wins-table-card"
    )

# Dash callback to update page_size
@callback(
    Output("key-wins-table", "page_size"),
    Input("key-wins-table-page-size", "value")
)
def update_key_wins_table_page_size(page_size):
    return page_size
