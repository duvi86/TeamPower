import dash_bootstrap_components as dbc
from dash import html
from Dash_template.multipages.utils.create_stats_card import create_stats_card

def metrics_row(total_wins, completed_wins, value_realized, value_potential, realization_rate):
    """
    Returns a row of modular stats cards using the dash_template's create_stats_card utility.
    """
    return dbc.Row([
        dbc.Col(create_stats_card(
            title="Total Key Wins",
            value=str(total_wins),
            icon="fas fa-trophy",
            color="primary"
        ), width=2),
        dbc.Col(create_stats_card(
            title="Completed Wins",
            value=str(completed_wins),
            icon="fas fa-check-circle",
            color="success"
        ), width=2),
        dbc.Col(create_stats_card(
            title="Value Realized",
            value=f"£{value_realized:,.0f}",
            icon="fas fa-coins",
            color="success"
        ), width=2),
        dbc.Col(create_stats_card(
            title="Value Potential",
            value=f"£{value_potential:,.0f}",
            icon="fas fa-bullseye",
            color="info"
        ), width=2),
        dbc.Col(create_stats_card(
            title="Realization Rate",
            value=f"{realization_rate:.1f}%",
            icon="fas fa-percentage",
            color="tertiary"
        ), width=2)
    ], className="mb-4")
