from dash import html, register_page, dcc, callback, Input, Output
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from db_management.team_member_db import get_team_members
from utils.create_navbar import create_navbar
from utils.create_feedback_button import create_feedback_button
from utils.create_graph_card import create_graph_card
from utils.create_badge import create_badge, create_status_badge, create_count_badge
from utils.create_sunburst_chart import create_sunburst_chart, prepare_org_chart_data
from utils.create_stacked_bar_chart import create_stacked_bar_chart, prepare_department_status_data

register_page(__name__, path="/team-hierarchy", title="Team Hierarchy", name="Team Hierarchy")

def create_org_chart():
    """Create an interactive organizational chart using generic sunburst component"""
    team_members = get_team_members()
    
    if not team_members:
        fig = go.Figure()
        fig.add_annotation(
            text="No team member data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font=dict(size=16)
        )
        fig.update_layout(title="Team Organizational Chart", height=600)
        return fig
    
    # Prepare data using generic function, but show only active employees in the center node
    active_count = sum(1 for m in team_members if m.get('status', '').lower() != 'inactive')
    chart_data = prepare_org_chart_data(team_members)
    # Overwrite root label and value to show only active employees
    if chart_data['labels']:
        chart_data['labels'][0] = f"Active Employees\n{active_count}"
    if chart_data['values']:
        chart_data['values'][0] = active_count
    # Configure chart appearance (no title, consistent style)
    chart_config = {
        'title': '',
        'height': 600,
        'maxdepth': 3,
        'margin': {'t': 20, 'b': 20, 'l': 20, 'r': 20},
        'font_family': 'GSK Precision',
        'font_size': 12,
        'hover_template': '<b>%{label}</b><br>Count: %{value}<extra></extra>',
        'line_color': 'white',
        'line_width': 2
    }
    return create_sunburst_chart(chart_data, chart_config)

def create_role_distribution_chart():
    """Create a role distribution chart using generic stacked bar component"""
    team_members = get_team_members()
    
    if not team_members:
        fig = go.Figure()
        fig.add_annotation(
            text="No team member data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font=dict(size=16, color='#464646')  # GSK text subtle
        )
        fig.update_layout(
            title="Team Members by Role",
            height=400,
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        return fig
    
    # Transform team data for role-based grouping
    role_counts = {}
    for member in team_members:
        role = member.get('role', 'Unknown')
        status = member.get('status', 'Active')
        
        if role not in role_counts:
            role_counts[role] = {'Active': 0, 'On Leave': 0, 'Inactive': 0}
        role_counts[role][status] += 1
    
    # Sort roles by total count (descending)
    sorted_roles = sorted(role_counts.items(), key=lambda x: sum(x[1].values()), reverse=True)
    
    # Prepare data for generic stacked bar chart
    roles = [role for role, _ in sorted_roles]
    
    # GSK Design System color palette
    colors = {
        'Active': '#448422',      # GSK Success Strong
        'On Leave': '#FFC709',    # GSK Warning Strong  
        'Inactive': '#C83629'     # GSK Error Strong
    }
    
    series_data = []
    for status in ['Active', 'On Leave', 'Inactive']:
        values = [role_counts[role][status] for role in roles]
        series_data.append({
            'name': status,
            'values': values,
            'color': colors[status]
        })
    
    chart_data = {
        'categories': roles,
        'series': series_data
    }
    
    # Configure chart appearance
    chart_config = {
        'title': 'Team Distribution by Role & Status',
        'height': 450,
        'x_title': 'Roles',
        'y_title': 'Number of Team Members',
        'margin': {'t': 80, 'b': 80, 'l': 60, 'r': 40},
        'font_family': 'GSK Precision',
        'font_size': 12,
        'title_font_size': 20,
        'title_font_family': 'GSK Precision Bold',
        'title_color': '#151515',
        'axis_title_size': 14,
        'show_legend': True,
        'legend_orientation': 'h',
        'legend_y': 1.1,
        'bar_gap': 0.1,
        'hover_template': '<b>%{y}</b> %{fullData.name}<br>%{x}<extra></extra>'
    }
    
    # Create chart using generic component
    return create_stacked_bar_chart(chart_data, chart_config)

def create_department_cards():
    """Create enhanced cards showing team structure by department"""
    team_members = get_team_members()
    
    if not team_members:
        return [html.P("No team member data available", className="text-center text-muted")]
    
    # Group by department
    departments = {}
    member_map = {m['id']: m for m in team_members}
    
    for member in team_members:
        dept = member.get('department', 'Unassigned')
        if dept not in departments:
            departments[dept] = []
        departments[dept].append(member)
    
    cards = []
    
    for dept, members in departments.items():
        # Count by status
        active_count = len([m for m in members if m.get('status') == 'Active'])
        on_leave_count = len([m for m in members if m.get('status') == 'On Leave'])
        inactive_count = len([m for m in members if m.get('status') == 'Inactive'])
        
        # Create simple member list without duplicate status indicators
        member_list = []
        for member in sorted(members, key=lambda x: x['name']):
            manager = member_map.get(member.get('manager_id'))
            manager_name = manager['name'] if manager else 'No Manager'
            
            member_list.append(
                dbc.ListGroupItem([
                    html.Div([
                        html.Div([
                            html.Strong(member['name'], className="me-3"),
                            create_status_badge(member.get('status', 'Active'))
                        ], className="d-flex align-items-center justify-content-between mb-2"),
                        html.P(f"{member.get('role', 'N/A')}", className="mb-1 text-muted small"),
                        html.Small(f"Reports to: {manager_name}", className="text-secondary")
                    ])
                ], className="member-list-item")
            )
        
        # Create metrics row with GSK colors
        metrics = dbc.Row([
            dbc.Col([
                html.Div([
                    html.H3(str(active_count), className="status-active mb-0"),
                    html.Small("Active", className="text-muted")
                ], className="text-center")
            ], width=4),
            dbc.Col([
                html.Div([
                    html.H3(str(on_leave_count), className="status-on-leave mb-0"),
                    html.Small("On Leave", className="text-muted")
                ], className="text-center")
            ], width=4),
            dbc.Col([
                html.Div([
                    html.H3(str(inactive_count), className="status-inactive mb-0"),
                    html.Small("Inactive", className="text-muted")
                ], className="text-center")
            ], width=4)
        ], className="mb-3")
        
        # Remove department icons for cleaner design
        card = dbc.Card([
            dbc.CardHeader([
                html.Div([
                    html.H5(f"{dept}", className="mb-0 d-inline"),
                    create_count_badge(len(members), "members")
                ], className="d-flex align-items-center justify-content-between")
            ]),
            dbc.CardBody([
                metrics,
                html.Hr(className="custom-divider"),
                dbc.ListGroup(member_list, flush=True) if member_list else html.P("No members", className="text-muted text-center")
            ], className="custom-card-body")
        ], className="mb-4 shadow-sm custom-hover-card")
        
        cards.append(dbc.Col(card, width=12, lg=6, xl=4))
    
    return cards

def create_hierarchy_tree():
    """Create an enhanced tree-like view of the management hierarchy"""
    team_members = get_team_members()
    
    if not team_members:
        return html.P("No team member data available", className="text-center text-muted")
    
    member_map = {m['id']: m for m in team_members}
    
    def build_tree_level(manager_id=None, level=0):
        """Recursively build enhanced tree structure"""
        direct_reports = [m for m in team_members if m.get('manager_id') == manager_id]
        direct_reports.sort(key=lambda x: (x.get('role', ''), x['name']))
        
        if not direct_reports:
            return []
        
        tree_items = []
        colors = ['primary', 'success', 'info', 'warning', 'error', 'secondary']
        accent_color = colors[level % len(colors)]
        
        for i, member in enumerate(direct_reports):
            # Count direct reports
            subordinates = [m for m in team_members if m.get('manager_id') == member['id']]
            subordinate_count = len(subordinates)
            
            # Status styling using GSK design system classes
            status_config = {
                'Active': {'bg_class': 'hierarchy-card-active', 'color': 'success'},
                'On Leave': {'bg_class': 'hierarchy-card-on-leave', 'color': 'warning'},
                'Inactive': {'bg_class': 'hierarchy-card-inactive', 'color': 'error'}
            }
            status_info = status_config.get(member.get('status', 'Active'), {
                'bg_class': 'hierarchy-card-active', 'color': 'secondary'
            })
            
            # Remove department icons for cleaner design
            
            # Member card with enhanced design using CSS classes
            member_card = dbc.Card([
                dbc.CardBody([
                    html.Div([
                        html.Div([
                            html.Strong(member['name'], className="me-3"),
                            create_status_badge(member.get('status', 'Active')),
                            create_badge(member.get('department', 'N/A'), color="secondary")
                        ], className="d-flex align-items-center mb-2 flex-wrap gap-2"),
                        
                        html.Div([
                            html.P([
                                html.Strong("Role: "), 
                                html.Span(member.get('role', 'N/A'), className="text-muted")
                            ], className="mb-1 small"),
                            html.P([
                                html.Strong("Email: "), 
                                html.Code(member.get('email', 'N/A'), className="small text-muted")
                            ], className="mb-1 small"),
                            
                            # Team size indicator
                            html.Div([
                                html.Span(f"{subordinate_count} direct reports" if subordinate_count > 0 else "Individual contributor", 
                                         className="small text-muted")
                            ], className="mt-2") if level < 3 else None
                        ])
                    ])
                ], className="p-3 custom-card-body")
            ], 
            className=f"mb-3 border-start border-{accent_color} border-4 shadow-sm custom-hover-card hierarchy-level-{level} {status_info['bg_class']}")
            
            tree_items.append(member_card)
            
            # Add subordinates with connection lines
            if subordinates and level < 4:  # Limit depth to prevent overflow
                # Add connection indicator using CSS classes
                if level < 3:
                    connection = html.Div([
                        html.Hr(className=f"border-{accent_color} border-2 hierarchy-connection"),
                        html.Div(f"👥 {subordinate_count} Direct Reports", 
                                className=f"hierarchy-connection-label small fw-bold text-center mb-2 hierarchy-level-{level + 1}")
                    ])
                    tree_items.append(connection)
                
                subordinate_items = build_tree_level(member['id'], level + 1)
                tree_items.extend(subordinate_items)
        
        return tree_items
    
    # Build tree starting from root (no manager)
    tree_content = build_tree_level()
    
    if not tree_content:
        return html.Div([
            html.I(className="fas fa-info-circle text-muted me-2"),
            html.Span("No hierarchy data available", className="text-muted")
        ], className="text-center p-4")
    
    return html.Div([
        html.Div(tree_content, className="hierarchy-tree")
    ])

layout = html.Div([
    create_navbar(active_tab='Team', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0"),
    html.Div(
        className="page-container",
        children=[
            # Page header
            html.Div(
                id='main-content',
                children=[
                    html.H1('Team'),
                    create_feedback_button(id_prefix="team-hierarchy-feedback")
                ],
                className='centered-content section-spacing'
            ),
            
            # Tab selection
            dbc.Tabs([
                dbc.Tab(label="Organizational Chart", tab_id="org-chart"),
                dbc.Tab(label="Department Teams", tab_id="dept-teams"), 
                dbc.Tab(label="Management Tree", tab_id="mgmt-tree"),
            ], id="hierarchy-tabs", active_tab="org-chart", className="mb-4"),
            
            # Content area
            html.Div(id="hierarchy-content")
        ]
    ),
    html.Span("TwinOps AI Powered | 2.0.0", className="bottom-section b1")
], className="main-layout")

@callback(
    Output('hierarchy-content', 'children'),
    Input('hierarchy-tabs', 'active_tab')
)
def update_hierarchy_content(active_tab):
    """Update content based on selected tab"""
    if active_tab == "org-chart":
        org_chart_figure = create_org_chart()
        role_chart_figure = create_role_distribution_chart()
        
        return html.Div([
            dbc.Row([
                dbc.Col([
                    create_graph_card(
                        id='org-chart-card',
                        figure=org_chart_figure,
                        title='Organization',
                        height=600,
                        actions=False
                    )
                ], width=12, lg=8),
                dbc.Col([
                    create_graph_card(
                        id='role-chart-card',
                        figure=role_chart_figure,
                        title='People by Role',
                        height=600,
                        actions=False
                    )
                ], width=12, lg=4)
            ])
        ])
    
    elif active_tab == "dept-teams":
        cards = create_department_cards()
        return html.Div([
            dbc.Row(cards) if cards else html.P("No team data available", className="text-center text-muted")
        ])
    
    elif active_tab == "mgmt-tree":
        tree = create_hierarchy_tree()
        return html.Div([
            tree
        ])
    
    return html.Div("Select a tab to view team hierarchy", className="text-center text-muted")
