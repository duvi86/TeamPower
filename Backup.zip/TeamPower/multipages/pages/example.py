"""
Example usage of the generic components

This file shows how to use all the generic components together
to create a fully functional dashboard page.
"""

import dash_bootstrap_components as dbc
from dash import html, dcc, register_page, callback, Input, Output, ctx
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

# Import utility functions
from utils.create_page_layout import create_page_layout
from utils.create_filters import create_filters
from utils.create_dashboard_grid import create_dashboard_grid
from utils.create_stats_card import create_stats_card
from utils.create_feedback_button import create_feedback_button
from utils.create_line_chart import create_line_chart, prepare_time_series_data, prepare_metrics_data
from utils.create_gauge_chart import create_performance_gauge, create_kpi_gauge, create_score_gauge
from utils.create_bar_chart import create_bar_chart, prepare_category_data

# Register this page in the app
register_page(__name__, path="/example", name="Example Page", order=5)

# Generate some sample data
def generate_sample_data():
    # Time series data for metrics
    dates = pd.date_range(start=datetime.now() - timedelta(days=30), end=datetime.now(), freq='D')
    metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
    
    data = []
    for metric in metrics:
        for date in dates:
            # Generate random value between 0.7 and 0.98
            value = 0.7 + (0.28 * np.random.random())
            data.append({
                'Date': date,
                'Metric': metric,
                'Value': value
            })
    
    return pd.DataFrame(data)

# Sample dataframe
df = generate_sample_data()

# Create sample figures using generic components
def create_metrics_chart():
    """Create metrics line chart using generic component"""
    # Prepare data for line chart
    metrics_data = {}
    for metric in df['Metric'].unique():
        metric_df = df[df['Metric'] == metric].sort_values('Date')
        metrics_data[metric] = metric_df['Value'].tolist()
    
    # Get sorted dates
    dates = df['Date'].dt.strftime('%Y-%m-%d').unique()
    dates = sorted(dates)
    
    chart_data = prepare_metrics_data(metrics_data, dates)
    
    chart_config = {
        'title': 'Model Performance Metrics Over Time',
        'height': 400,
        'x_title': 'Date',
        'y_title': 'Score',
        'show_markers': True,
        'line_width': 3
    }
    
    return create_line_chart(chart_data, chart_config)

def create_distribution_chart():
    """Create distribution bar chart using generic component"""
    # Get latest day data
    latest_data = df[df['Date'] == df['Date'].max()]
    
    chart_data = {
        'categories': latest_data['Metric'].tolist(),
        'values': latest_data['Value'].tolist()
    }
    
    chart_config = {
        'title': 'Metrics Distribution (Latest Day)',
        'height': 400,
        'x_title': 'Metrics',
        'y_title': 'Score',
        'color': '#21837E',  # GSK viz teal
        'show_values_on_bars': True
    }
    
    return create_bar_chart(chart_data, chart_config)

# Create sample gauges using generic components
def create_gauge(value, title):
    """Create performance gauge using generic component"""
    return create_performance_gauge(value, title)

# Define filter options
metrics = [{'label': metric, 'value': metric} for metric in df['Metric'].unique()]
date_range = [
    {'label': 'Last 7 days', 'value': '7d'},
    {'label': 'Last 14 days', 'value': '14d'},
    {'label': 'Last 30 days', 'value': '30d'},
]

# Define page layout
def layout():
    # Define filters for the page
    filter_row = create_filters([
        {
            'label': 'Metric',
            'id': 'metric-filter',
            'options': metrics,
            'default_value': 'Accuracy',
            'width': 4
        },
        {
            'label': 'Time Period',
            'id': 'time-filter',
            'options': date_range,
            'default_value': '7d',
            'width': 4
        }
    ])
    
    # Calculate latest metrics for stats cards
    latest_metrics = df[df['Date'] == df['Date'].max()].groupby('Metric')['Value'].mean().to_dict()
    
    # Create stats cards
    stats_items = [
        {
            'type': 'card',
            'title': 'Accuracy',
            'content': create_stats_card(
                title='Accuracy',
                value=f"{latest_metrics['Accuracy']:.2%}",
                subtitle='Current model accuracy',
                icon='fas fa-bullseye',
                color='primary',
                trend={'value': '+2.3%', 'direction': 'up'}
            ),
            'width': 3
        },
        {
            'type': 'card',
            'title': 'Precision',
            'content': create_stats_card(
                title='Precision',
                value=f"{latest_metrics['Precision']:.2%}",
                subtitle='Positive prediction precision',
                icon='fas fa-check-circle',
                color='success',
                trend={'value': '+1.5%', 'direction': 'up'}
            ),
            'width': 3
        },
        {
            'type': 'card',
            'title': 'Recall',
            'content': create_stats_card(
                title='Recall',
                value=f"{latest_metrics['Recall']:.2%}",
                subtitle='True positive rate',
                icon='fas fa-search',
                color='info',
                trend={'value': '-0.8%', 'direction': 'down', 'color': 'danger'}
            ),
            'width': 3
        },
        {
            'type': 'card',
            'title': 'F1 Score',
            'content': create_stats_card(
                title='F1 Score',
                value=f"{latest_metrics['F1 Score']:.2%}",
                subtitle='Harmonic mean of precision and recall',
                icon='fas fa-balance-scale',
                color='warning',
                trend={'value': '+0.5%', 'direction': 'up'}
            ),
            'width': 3
        },
    ]
    
    # Create visualization items
    chart_items = [
        {
            'type': 'graph',
            'title': 'Performance Metrics Over Time',
            'id': 'metrics-chart',
            'figure': create_metrics_chart(),
            'width': 8,
            'height': 400
        },
        {
            'type': 'graph',
            'title': 'Metrics Distribution',
            'id': 'distribution-chart',
            'figure': create_distribution_chart(),
            'width': 4,
            'height': 400
        },
        {
            'type': 'graph',
            'title': 'Accuracy Gauge',
            'id': 'accuracy-gauge',
            'figure': create_gauge(latest_metrics['Accuracy'], 'Accuracy'),
            'width': 3
        },
        {
            'type': 'graph',
            'title': 'Precision Gauge',
            'id': 'precision-gauge',
            'figure': create_gauge(latest_metrics['Precision'], 'Precision'),
            'width': 3
        },
        {
            'type': 'graph',
            'title': 'Recall Gauge',
            'id': 'recall-gauge',
            'figure': create_gauge(latest_metrics['Recall'], 'Recall'),
            'width': 3
        },
        {
            'type': 'graph',
            'title': 'F1 Score Gauge',
            'id': 'f1-gauge',
            'figure': create_gauge(latest_metrics['F1 Score'], 'F1 Score'),
            'width': 3
        }
    ]
    
    # Create dashboard components
    stats_grid = create_dashboard_grid(stats_items)
    charts_grid = create_dashboard_grid(chart_items)
    
    # Add feedback button
    feedback = create_feedback_button(id_prefix="example-feedback")
    
    # Create page content
    content = html.Div([
        html.H2("Dashboard Example"),
        html.Hr(),
        filter_row,
        html.Div(stats_grid, className="mb-4"),
        html.Div(charts_grid),
        feedback
    ])
    
    # Return the page layout with standardized structure
    return create_page_layout(
        title="Example Dashboard", 
        content=content,
        description="An example of using all the generic components together"
    )

# Define callbacks
@callback(
    [
        Output("metrics-chart", "figure"),
        Output("distribution-chart", "figure")
    ],
    [
        Input("metric-filter", "value"),
        Input("time-filter", "value")
    ]
)
def update_charts(selected_metric, time_period):
    # Filter data based on selected time period
    days = int(time_period.replace('d', ''))
    filtered_df = df[df['Date'] >= (datetime.now() - timedelta(days=days))]
    
    # Update line chart using generic component
    metrics_data = {}
    for metric in filtered_df['Metric'].unique():
        metric_df = filtered_df[filtered_df['Metric'] == metric].sort_values('Date')
        metrics_data[metric] = metric_df['Value'].tolist()
    
    dates = filtered_df['Date'].dt.strftime('%Y-%m-%d').unique()
    dates = sorted(dates)
    
    line_chart_data = prepare_metrics_data(metrics_data, dates)
    line_config = {
        'title': f'Model Performance Metrics - Last {days} days',
        'height': 400,
        'x_title': 'Date',
        'y_title': 'Score',
        'show_markers': True,
        'line_width': 3
    }
    line_fig = create_line_chart(line_chart_data, line_config)
    
    # Update bar chart using generic component
    latest_data = filtered_df[filtered_df['Date'] == filtered_df['Date'].max()]
    
    bar_chart_data = {
        'categories': latest_data['Metric'].tolist(),
        'values': latest_data['Value'].tolist()
    }
    
    bar_config = {
        'title': 'Metrics Distribution (Latest Day)',
        'height': 400,
        'x_title': 'Metrics',
        'y_title': 'Score',
        'color': '#21837E',  # GSK viz teal
        'show_values_on_bars': True
    }
    hist_fig = create_bar_chart(bar_chart_data, bar_config)
    
    return line_fig, hist_fig

# Feedback modal callback
@callback(
    Output("example-feedback-modal", "is_open"),
    [
        Input("example-feedback-button", "n_clicks"),
        Input("example-feedback-close", "n_clicks"),
        Input("example-feedback-submit", "n_clicks"),
    ],
    prevent_initial_call=True
)
def toggle_feedback_modal(open_clicks, close_clicks, submit_clicks, is_open):
    if not ctx.triggered:
        return is_open
    trigger_id = ctx.triggered[0]["prop_id"].split(".")[0]
    if trigger_id == "example-feedback-button":
        return True
    return False

@callback(
    Output("example-feedback-toast", "is_open"),
    [Input("example-feedback-submit", "n_clicks")],
)
def show_toast(submit_clicks):
    if not ctx.triggered:
        return False
    if submit_clicks:
        return True
    return False
