# """
# Example: OKR Management page using the generic page pattern
# This demonstrates how to create a new page type with the reusable template.
# TEMPORARILY DISABLED TO AVOID CALLBACK CONFLICTS
# """

from dash import html

# Layout for disabled page
layout = html.Div([
    html.H2("OKR Example Page"),
    html.P("This page is temporarily disabled to avoid callback conflicts."),
    html.P("To enable it, uncomment the code in pages/okr_example.py")
])
