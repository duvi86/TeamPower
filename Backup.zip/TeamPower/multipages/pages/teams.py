from dash import html, register_page, dcc, callback, Input, Output
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.create_navbar import create_navbar
from utils.create_feedback_button import create_feedback_button
from utils.create_card import create_card
from components.forms.team_form import create_team_form
from components.tables.team_table import create_team_table
import logging

logger = logging.getLogger(__name__)

register_page(__name__, path="/teams", title="Team Management", name="Teams")

layout = html.Div([
    create_navbar(active_tab='Teams', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0"),
    html.Div(
        style={
            'margin-left': '20px', 
            'margin-right': '20px',
            'margin-bottom': '0px',
            'margin-top': '10px',
            'height': 'calc(100vh - 120px)',
            'overflowY': 'auto',
            'overflowX': 'hidden'
        },
        children=[
            # Page Header
            html.Div([
                html.H1("Team Management", 
                       style={
                           'fontSize': '1.8rem', 
                           'color': 'var(--color-text-default)',
                           'marginBottom': '0.5rem',
                           'fontWeight': '600'
                       }),
                html.P("Manage team members, roles, and assignments", 
                      style={
                          'fontSize': 'var(--font-size-body)', 
                          'color': 'var(--color-text-subtle)',
                          'margin': '0'
                      }),
                create_feedback_button(id_prefix="teams-feedback")
            ], style={
                'marginBottom': '2rem',
                'padding': '1rem 0',
                'borderBottom': '1px solid var(--color-stroke-primary)'
            }),
            
            # Main Content Grid
            html.Div([
                # Left Column - Form
                html.Div([
                    create_card(
                        title="Add New Team Member",
                        content=create_team_form(),
                        id="team-form-card"
                    )
                ], style={
                    'flex': '0 0 400px',
                    'marginRight': '1.5rem'
                }),
                
                # Right Column - Table
                html.Div([
                    create_card(
                        title="Team Members",
                        content=create_team_table(),
                        id="team-table-card"
                    )
                ], style={
                    'flex': '1',
                    'minWidth': '0'
                })
            ], style={
                'display': 'flex',
                'gap': '1.5rem',
                'height': 'calc(100vh - 300px)',
                'overflow': 'hidden'
            })
        ]
    )
])
