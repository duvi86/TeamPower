from dash import html, register_page
import dash_bootstrap_components as dbc
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_navbar import create_navbar
from utils.create_dropdown import create_dropdown
from utils.create_card import create_card
from utils.create_graph_card import create_graph_card
from utils.create_filters import create_filters
from utils.create_page_layout import create_page_layout
from utils.create_feedback_button import create_feedback_button
import pandas as pd
import numpy as np

# Register this page in the app
register_page(__name__, path="/home", name="Home", order=1)

# Sample data for the graph
np.random.seed(42)
date_range = pd.date_range(start='1/1/2022', periods=100)
sinusoid = np.sin(2 * np.pi * 50 * np.arange(100) / 100)
noise = 0.5 * np.random.randn(100)
values = sinusoid + noise

df = pd.DataFrame({
    'date': date_range,
    'value': values
})

# Create filters
filters = create_filters([
    {
        'label': 'Zone',
        'id': 'zone-dropdown',
        'options': [
            {'label': 'Barner Castle', 'value': 'Barner Castle'},
            {'label': 'Parme', 'value': 'Parme'}
        ],
        'default_value': 'Barner Castle',
        'width': 4
    },
    {
        'label': 'Product',
        'id': 'product-dropdown',
        'options': [{'label': 'CABO_LAI', 'value': 'CABO_LAI'}],
        'default_value': 'CABO_LAI',
        'width': 4
    }
])

layout = html.Div([
    create_navbar(active_tab='Home', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="2.0.0"),
    html.Div(
        style={
            'margin-left': '20px', 
            'margin-right': '20px',
            'margin-bottom': '40px',
            'margin-top': '10px',
            'height': 'calc(100vh - 120px)',
            'display': 'flex',
            'flex-direction': 'column'
        },
        children=[
            # Page header
            html.Div(
                id='main-content',
                children=[
                    html.H1('Welcome to the GSK Cabo Digital Twin'),
                    # Using standardized feedback button component
                    create_feedback_button(id_prefix="home-feedback")
                ],
                className='centered-content',
                style={'margin-bottom': '10px'}
            ),
            
            # Filters
            filters,
            
            # Content row with cards
            dbc.Row(
                [
                    dbc.Col(
                        [
                            create_card(title="Batch ID", body_id="batch-id"),
                            create_card(title="Line 2: WBM2_Projected Mill Time", body_id="projected-mill-time", class_name='b1')
                        ],
                        width=4
                    ),
                    dbc.Col(
                        create_graph_card(
                            df=df, 
                            graph_id='wbm2-sensors',
                            title="Wet Bead Mill (WBM2) Process",
                            height=400
                        ),
                        width=8
                    )
                ],
                style={'flex-grow': '1', 'min-height': '0'}
            ),
        ]
    ),
    html.Span("TwinOps AI Powered | 2.0.0", className="bottom-section b1")
], style={'height': '100vh', 'overflow': 'hidden'})
