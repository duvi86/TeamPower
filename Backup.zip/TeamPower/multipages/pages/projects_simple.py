"""
Projects page using the generic page pattern
This demonstrates how to create a simple CRUD page with the reusable template.
"""

from dash import html, register_page
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_generic_page import create_generic_page_layout
from utils.page_config import get_projects_page_config

# Register the page  
register_page(__name__, path="/ai-projects-simple", title="AI Projects", name="AI Projects Simple")

# Get the page configuration
page_config = get_projects_page_config()

# Create the layout using the generic template
layout = create_generic_page_layout(page_config)
