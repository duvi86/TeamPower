from dash import html, register_page
import dash_bootstrap_components as dbc
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_navbar import create_navbar
from utils.create_card import create_card
from utils.create_feedback_button import create_feedback_button

register_page(__name__, path="/ai-governance", title="AI Governance", name="AI Governance")

layout = html.Div([
    create_navbar(active_tab='AI Governance', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0"),
    html.Div(
        style={
            'margin-left': '20px',
            'margin-right': '20px',
            'margin-bottom': '40px',
            'margin-top': '10px',
            'height': 'calc(100vh - 120px)',
            'display': 'flex',
            'flex-direction': 'column'
        },
        children=[
            html.Div(
                id='main-content',
                children=[
                    html.H1('AI Governance'),
                    # Using standardized feedback button component
                    create_feedback_button(id_prefix="ai-governance-feedback")
                ],
                className='centered-content',
                style={'margin-bottom': '10px'}
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            create_card(title="Policy Management", body_id="policy-management"),
                            create_card(title="Compliance Status", body_id="compliance-status", class_name='b1')
                        ],
                        width=4
                    ),
                    dbc.Col(
                        [
                            create_card(title="AI Model Audit", body_id="ai-model-audit"),
                            create_card(title="Risk Assessment", body_id="risk-assessment", class_name='b1')
                        ],
                        width=4
                    ),
                    dbc.Col(
                        [
                            create_card(title="Governance Dashboard", body_id="governance-dashboard")
                        ],
                        width=4
                    )
                ],
                className="mb-2 b1",
                style={'margin-bottom': '10px'}
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            create_card(
                                title="Additional Information",
                                body_id="additional-info",
                                class_name='b1'
                            )
                        ],
                        width=12
                    )
                ],
                style={'flex-grow': '1', 'min-height': '0'}
            ),
        ]
    ),
    html.Span("TwinOps AI Powered | 1.0.0", className="bottom-section b1")
], style={'height': '100vh', 'overflow': 'hidden'})
