from dash import html, register_page, dcc, dash_table
import dash
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from db_management.db import get_transactions_df, get_year_filtered_kpis, get_value_evolution_data
from db_management.project_db import get_projects
from db_management.program_db import get_programs
from db_management.team_member_db import get_team_members
from utils.create_kpi_card import create_kpi_card, create_kpi_row
from utils.create_generic_graph import create_generic_graph, create_generic_bar_plot
from utils.create_dropdown import create_dropdown
from utils.create_navbar import create_navbar
from utils.create_feedback_button import create_feedback_button
from utils.gsk_colors import get_department_color_sequence
from dashboard.analytics import budget_financial_analytics
from dash.dependencies import Input, Output
import logging

logger = logging.getLogger(__name__)

register_page(__name__, path="/ai-monitoring")

def create_year_and_category_selector():
    """
    Create a styled year and category selection dropdowns in the same row
    
    Returns:
    --------
    html.Div
        Container with year and category dropdown selectors in the same row
    """
    try:
        # Get all available years from the database
        df = get_transactions_df()
        available_years = []
        if not df.empty:
            df['Date'] = pd.to_datetime(df['Date'])
            available_years = sorted(df['Date'].dt.year.unique().tolist(), reverse=True)
        
        # Use the most recent year available in the data, or current system year as fallback
        current_year = available_years[0] if available_years else pd.Timestamp.now().year
        
        # Create options for dropdown
        year_options = [{'label': str(year), 'value': year} for year in available_years]
        
        # If no data available, add current system year as option
        if not available_years:
            system_year = pd.Timestamp.now().year
            year_options = [{'label': str(system_year), 'value': system_year}]
            available_years = [system_year]
            current_year = system_year
        
        return html.Div([
            # Year selector
            html.Div([
                
                create_dropdown(
                    id='year-selector',
                    options=year_options,
                    default_value=current_year,
                    class_name="year-dropdown",
                    style={
                        'width': '150px',
                        'minWidth': '120px'
                    }
                )
            ], className="selector-item"),
            
            # Category selector
            html.Div([
                html.Label(
                    "Select Category:",
                    className="dropdown-label"
                ),
                create_dropdown(
                    id='monthly-category-selector',
                    options=[
                        {'label': 'Budget', 'value': 'Budget'},
                        {'label': 'Consumed', 'value': 'Consumed'},
                        {'label': 'Planned', 'value': 'Planned'}
                    ],
                    default_value='Consumed',
                    class_name="category-dropdown",
                    style={
                        'width': '150px',
                        'minWidth': '120px'
                    }
                )
            ], className="selector-item")
        ], className="selectors-row")
        
    except Exception as e:
        logger.error(f"Error creating selectors: {str(e)}")
        # Return a default selector with current system year
        fallback_year = pd.Timestamp.now().year
        return html.Div([
            html.Div([
                html.Label(
                    "Select Year:",
                    className="dropdown-label"
                ),
                create_dropdown(
                    id='year-selector',
                    options=[{'label': str(fallback_year), 'value': fallback_year}],
                    default_value=fallback_year,
                    class_name="year-dropdown",
                    style={
                        'width': '150px',
                        'minWidth': '120px'
                    }
                )
            ], className="selector-item"),
            html.Div([
                html.Label(
                    "Select Category:",
                    className="dropdown-label"
                ),
                create_dropdown(
                    id='monthly-category-selector',
                    options=[
                        {'label': 'Consumed', 'value': 'Consumed'}
                    ],
                    default_value='Consumed',
                    class_name="category-dropdown",
                    style={
                        'width': '150px',
                        'minWidth': '120px'
                    }
                )
            ], className="selector-item")
        ], className="selectors-row")

def get_filtered_transactions_data(selected_year):
    """
    Get filtered transaction data based on selected year
    
    Parameters:
    -----------
    selected_year : int
        The year to filter the data by
        
    Returns:
    --------
    pd.DataFrame
        Filtered dataframe for the selected year
    """
    try:
        # Get all transactions data
        df = get_transactions_df()
        
        if df.empty:
            logger.warning(f"No transaction data available for filtering")
            return pd.DataFrame()
        
        # Convert Date to datetime and filter by selected year
        df['Date'] = pd.to_datetime(df['Date'])
        df_filtered = df[df['Date'].dt.year == selected_year]
        
        # Create full year date range for selected year
        year_start = pd.Timestamp(f'{selected_year}-01-01')
        year_end = pd.Timestamp(f'{selected_year}-12-31')
        
        logger.info(f"Filtered {len(df_filtered)} transactions for year {selected_year}")
        return df_filtered
        
    except Exception as e:
        logger.error(f"Error filtering transaction data for year {selected_year}: {str(e)}")
        return pd.DataFrame()

def generate_dashboard_content(selected_year):
    """
    Generate dashboard content for the selected year
    
    Parameters:
    -----------
    selected_year : int
        The year to generate content for
        
    Returns:
    --------
    list
        List of dashboard components
    """
    try:
        # Get filtered data
        filtered_df = get_filtered_transactions_data(selected_year)
        
        # Get year-filtered KPIs that will change based on selected year
        kpi_data = get_year_filtered_kpis(selected_year)
        
        # Calculate attrition breakdown for display (organizational data - doesn't change by year)
        inactive_members = kpi_data.get('inactive_team_members', 0)
        total_members = kpi_data.get('total_team_members', 0)
        attrition_rate = kpi_data.get('attrition_rate', 0)
        attrition_breakdown = f"({inactive_members}/{total_members})" if total_members > 0 else "(0/0)"
        
        # Create year-aware KPI cards that will show different values for different years
        kpi_cards = [
            create_kpi_card(
                f'Total Budget ({selected_year})', 
                f"${kpi_data.get('budget_amount', 0):,.0f}", 
                value_class='budget'
            ),
            create_kpi_card(
                f'Total Planned ({selected_year})', 
                f"${kpi_data.get('planned_amount', 0):,.0f}", 
                value_class='planned'
            ),
            create_kpi_card(
                f'Total Consumed ({selected_year})', 
                f"${kpi_data.get('consumed_amount', 0):,.0f}", 
                value_class='consumed'
            ),
            create_kpi_card(
                f'Budget Gap ({selected_year})', 
                f"${kpi_data.get('budget_amount', 0) - kpi_data.get('consumed_amount', 0):,.0f}",
                subtitle=f"Budget vs Consumed",
                value_class='gap-positive' if (kpi_data.get('budget_amount', 0) - kpi_data.get('consumed_amount', 0)) >= 0 else 'gap-negative'
            ),
            create_kpi_card(
                'Active Team Members', 
                str(kpi_data.get('active_team_members', 0)), 
                value_class='team-members'
            ),
            create_kpi_card(
                'Attrition Rate', 
                f"{attrition_rate}%", 
                subtitle=attrition_breakdown, 
                value_class='attrition-rate'
            )
        ]
        
        # Create enhanced visualizations
        project_budget_chart = create_project_budget_bar_chart()
        program_budget_chart = create_program_budget_comparison()
        team_distribution_chart = create_team_distribution_chart()
        value_analysis_chart = create_project_value_analysis()
        
        # Get organizational evolution data for selected year
        # org_data = get_organizational_evolution_data(selected_year)
        # org_df = pd.DataFrame(org_data)
        # Create empty dataframe for now
        org_df = pd.DataFrame({"Month": [], "Active": [], "On Leave": [], "Inactive": []})
        
        org_evolution_fig = px.line(
            org_df,
            x='Month',
            y=['Active', 'On Leave', 'Inactive'],
            title=f'Organizational Evolution - {selected_year}',
            labels={'value': 'Number of People', 'Month': 'Month', 'variable': 'Status'},
            color_discrete_map={
                'Active': '#66BB6A',
                'On Leave': '#FFA726',
                'Inactive': '#EF5350'
            }
        )
        
        # Get value evolution data for selected year
        value_data = get_value_evolution_data(selected_year)
        value_df = pd.DataFrame(value_data)
        
        value_evolution_fig = px.area(
            value_df,
            x='Month',
            y=['Value Promised', 'Value Realized'],
            title=f'Value Evolution - {selected_year}',
            labels={'value': 'Value ($)', 'Month': 'Month', 'variable': 'Value Type'},
            color_discrete_map={
                'Value Promised': '#42A5F5',
                'Value Realized': '#66BB6A'
            }
        )
        
        # Return dashboard content components
        return [
            # KPI Row
            create_kpi_row(kpi_cards),
            
            # Budget Financial Analytics Section
            budget_financial_analytics(selected_year),
            
            # First row of charts
            html.Div([
                create_generic_bar_plot('Project Budget by Status', project_budget_chart, 
                                      graph_id='project-budget-chart', width=6, height=400),
                create_generic_bar_plot('Program Budget Comparison', program_budget_chart, 
                                      graph_id='program-budget-chart', width=6, height=400)
            ], className='dashboard-graphs-row'),
            
            # Second row of charts
            html.Div([
                create_generic_graph('Team Distribution', team_distribution_chart, 
                                   graph_id='team-distribution-chart', width=6, height=400),
                create_generic_graph('Project Value Analysis', value_analysis_chart, 
                                   graph_id='value-analysis-chart', width=6, height=400)
            ], className='dashboard-graphs-row'),
            
            # Third row - Evolution charts
            html.Div([
                create_generic_graph('Organizational Evolution', org_evolution_fig, 
                                   graph_id='org-evolution-chart', width=6, height=400),
                create_generic_graph('Value Evolution', value_evolution_fig, 
                                   graph_id='value-evolution-chart', width=6, height=400)
            ], className='dashboard-graphs-row'),
        ]
        
    except Exception as e:
        logger.error(f"Error generating dashboard content for year {selected_year}: {str(e)}")
        return [html.Div(f"Error loading dashboard content for {selected_year}", 
                        style={'text-align': 'center', 'margin': '50px', 'color': 'red'})]

def create_project_budget_bar_chart():
    """Create a bar chart showing project budgets by status"""
    try:
        projects = get_projects()
        if not projects:
            logger.warning("No projects found for budget chart")
            # Create empty chart
            fig = go.Figure()
            fig.add_annotation(
                text="No project data available",
                xref="paper", yref="paper",
                x=0.5, y=0.5, xanchor='center', yanchor='middle',
                showarrow=False, font=dict(size=16)
            )
            fig.update_layout(title="Project Budget Distribution by Status")
            return fig
        
        # Convert to DataFrame for easier manipulation
        df = pd.DataFrame(projects)
        
        # Group by status and sum budgets
        budget_by_status = df.groupby('status')['budget'].sum().reset_index()
        
        # Color mapping for different project statuses
        color_map = {
            'Planning': '#FFA726',      # Orange
            'Active': '#66BB6A',        # Green  
            'On Hold': '#EF5350',       # Red
            'Completed': '#42A5F5',     # Blue
            'Cancelled': '#BDBDBD'      # Gray
        }
        
        fig = px.bar(
            budget_by_status,
            x='status',
            y='budget',
            title='Project Budget Distribution by Status',
            labels={'budget': 'Budget ($)', 'status': 'Project Status'},
            color='status',
            color_discrete_map=color_map,
            text='budget'
        )
        
        # Format text on bars
        fig.update_traces(texttemplate='$%{text:,.0f}', textposition='outside')
        
        # Update layout for better readability
        fig.update_layout(
            showlegend=False,
            xaxis_title="Project Status",
            yaxis_title="Total Budget ($)",
            template="plotly_white"
        )
        
        return fig
        
    except Exception as e:
        logger.error(f"Error creating project budget bar chart: {e}")
        # Return empty chart on error
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error loading project data: {str(e)[:50]}...",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font=dict(size=14)
        )
        fig.update_layout(title="Project Budget Distribution by Status")
        return fig


def create_program_budget_comparison():
    """Create a horizontal bar chart comparing program budgets"""
    try:
        programs = get_programs()
        if not programs:
            logger.warning("No programs found for budget comparison")
            # Create empty chart
            fig = go.Figure()
            fig.add_annotation(
                text="No program data available",
                xref="paper", yref="paper",
                x=0.5, y=0.5, xanchor='center', yanchor='middle',
                showarrow=False, font=dict(size=16)
            )
            fig.update_layout(title="Program Budget Comparison")
            return fig
        
        # Convert to DataFrame and sort by budget
        df = pd.DataFrame(programs)
        df = df.sort_values('budget', ascending=True)
        
        # Create horizontal bar chart
        fig = px.bar(
            df,
            x='budget',
            y='name',
            orientation='h',
            title='Program Budget Comparison',
            labels={'budget': 'Budget ($)', 'name': 'Program'},
            color='budget',
            color_continuous_scale='viridis',
            text='budget'
        )
        
        # Format text on bars
        fig.update_traces(texttemplate='$%{text:,.0f}', textposition='outside')
        
        # Update layout
        fig.update_layout(
            showlegend=False,
            xaxis_title="Budget ($)",
            yaxis_title="Programs",
            template="plotly_white",
            coloraxis_colorbar=dict(title="Budget Level")
        )
        
        return fig
        
    except Exception as e:
        logger.error(f"Error creating program budget comparison: {e}")
        # Return empty chart on error
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error loading program data: {str(e)[:50]}...",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font=dict(size=14)
        )
        fig.update_layout(title="Program Budget Comparison")
        return fig


def create_team_distribution_chart():
    """Create a pie chart showing team member distribution by department"""
    try:
        team_members = get_team_members()
        if not team_members:
            logger.warning("No team members found for distribution chart")
            # Create empty chart
            fig = go.Figure()
            fig.add_annotation(
                text="No team member data available",
                xref="paper", yref="paper",
                x=0.5, y=0.5, xanchor='center', yanchor='middle',
                showarrow=False, font=dict(size=16)
            )
            fig.update_layout(title="Team Distribution by Department")
            return fig
        
        # Convert to DataFrame
        df = pd.DataFrame(team_members)
        
        # Count team members by department
        dept_counts = df.groupby('department').size().reset_index(name='count')
        
        # Use standardized GSK visualization colors
        color_sequence = get_department_color_sequence(dept_counts['department'].tolist())
        
        fig = px.pie(
            dept_counts,
            values='count',
            names='department',
            title='Team Distribution by Department',
            color_discrete_sequence=color_sequence
        )
        
        # Update traces for better display
        fig.update_traces(textposition='inside', textinfo='percent+label')
        
        fig.update_layout(
            template="plotly_white",
            showlegend=True
        )
        
        return fig
        
    except Exception as e:
        logger.error(f"Error creating team distribution chart: {e}")
        # Return empty chart on error
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error loading team data: {str(e)[:50]}...",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font=dict(size=14)
        )
        fig.update_layout(title="Team Distribution by Department")
        return fig


def create_project_value_analysis():
    """Create a scatter plot comparing potential vs realized value"""
    try:
        projects = get_projects()
        if not projects:
            logger.warning("No projects found for value analysis")
            # Create empty chart
            fig = go.Figure()
            fig.add_annotation(
                text="No project data available",
                xref="paper", yref="paper",
                x=0.5, y=0.5, xanchor='center', yanchor='middle',
                showarrow=False, font=dict(size=16)
            )
            fig.update_layout(title="Project Value Analysis: Potential vs Realized")
            return fig
        
        # Convert to DataFrame
        df = pd.DataFrame(projects)
        
        # Filter out projects with no value data
        df_filtered = df[(df['potential_value'] > 0) | (df['realized_value'] > 0)]
        
        if df_filtered.empty:
            fig = go.Figure()
            fig.add_annotation(
                text="No value data available for projects",
                xref="paper", yref="paper",
                x=0.5, y=0.5, xanchor='center', yanchor='middle',
                showarrow=False, font=dict(size=14)
            )
            fig.update_layout(title="Project Value Analysis: Potential vs Realized")
            return fig
        
        # Create scatter plot
        fig = px.scatter(
            df_filtered,
            x='potential_value',
            y='realized_value',
            size='budget',
            color='status',
            hover_name='name',
            title='Project Value Analysis: Potential vs Realized',
            labels={
                'potential_value': 'Potential Value ($)',
                'realized_value': 'Realized Value ($)',
                'status': 'Project Status'
            }
        )
        
        # Add diagonal line for reference (perfect realization)
        max_value = max(df_filtered['potential_value'].max(), df_filtered['realized_value'].max())
        fig.add_trace(
            go.Scatter(
                x=[0, max_value],
                y=[0, max_value],
                mode='lines',
                line=dict(dash='dash', color='gray'),
                name='Perfect Realization',
                showlegend=True
            )
        )
        
        fig.update_layout(
            template="plotly_white",
            showlegend=True
        )
        
        return fig
        
    except Exception as e:
        logger.error(f"Error creating project value analysis: {e}")
        # Return empty chart on error
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error loading project data: {str(e)[:50]}...",
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font=dict(size=14)
        )
        fig.update_layout(title="Project Value Analysis: Potential vs Realized")
        return fig


def dashboard_page(selected_year=None):
    """Enhanced dashboard page with comprehensive visualizations"""
    try:
        # Use current year if no year is selected
        if selected_year is None:
            selected_year = pd.Timestamp.now().year
        
        # Generate dashboard content for selected year
        dashboard_content = generate_dashboard_content(selected_year)
        
        # Create enhanced layout
        layout = html.Div([
            # Year and Category Selector
            create_year_and_category_selector(),
            
            # Dashboard content that will be updated based on year selection
            html.Div(id='dashboard-content', children=dashboard_content)
        ], className='dashboard-main')
        
        return layout
        
    except Exception as e:
        logger.error(f"Error creating dashboard page: {e}")
        # Return error message
        return html.Div([
            create_year_and_category_selector(),
            html.Div([
                html.H2("Error Loading Dashboard", style={'color': 'red', 'text-align': 'center'}),
                html.P(f"An error occurred while loading the dashboard: {str(e)}", 
                      style={'text-align': 'center', 'margin': '20px'})
            ])
        ], className='dashboard-main')

layout = html.Div([
    create_navbar(active_tab='AI Financials', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0"),
    html.Div(
        style={
            'margin-left': '20px', 
            'margin-right': '20px',
            'margin-bottom': '40px',
            'margin-top': '10px',
            'height': 'calc(100vh - 120px)',
           
        },
        children=[
            # Page header
            html.Div(
                id='main-content',
                children=[
                    html.H1('AI Financials'),
                    # Using standardized feedback button component
                    create_feedback_button(id_prefix="ai-monitoring-feedback")
                ],
                className='centered-content',
                style={'margin-bottom': '10px'}
            ),
            dashboard_page(),
        ]
    ),
    html.Span("TwinOps AI Powered | 2.0.0", className="bottom-section b1")
], style={'height': '100vh', 'overflow': 'hidden'})
