from dash import State
from db_management.db import add_value_tracking_record, get_value_tracking_records, update_value_tracking_record, delete_value_tracking_record, get_value_tracking_record_by_id
# --- Value Tracking CRUD Callbacks ---
from dash import html, register_page, dcc, callback, Input, Output
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.create_navbar import create_navbar
from utils.create_feedback_button import create_feedback_button
from utils.create_card import create_card
from utils.create_page_layout import create_page_layout
from components.forms.transaction_form import create_transaction_form
from components.forms.team_form import create_team_form
from components.tables.team_table import create_team_table
import logging

# Helper to get the form (import inside to avoid circular)
def __get_value_tracking_form(selected=False, value_tracking_data=None):
    from components.forms.value_tracking_form import create_value_tracking_form
    return create_value_tracking_form(selected=selected, value_tracking_data=value_tracking_data)


logger = logging.getLogger(__name__)

register_page(__name__, path="/config", title="Config", name="Config")

def create_transaction_tabs():
    """Create tab navigation similar to navbar style"""
    return html.Div([
        html.Div([
            html.A(
                "Transactions",
                href="#",
                className="tab tab-active tab-item",
                id="transactions-tab",
                style={
                    'padding': '10px 20px',
                    'marginRight': '10px',
                    'display': 'inline-block',
                    'borderRadius': '4px 4px 0 0'
                }
            ),
            html.A(
                "Teams",
                href="#",
                className="tab tab-item",
                id="teams-tab",
                style={
                    'padding': '10px 20px',
                    'marginRight': '10px',
                    'display': 'inline-block',
                    'borderRadius': '4px 4px 0 0'
                }
            ),
            html.A(
                "Programs",
                href="#",
                className="tab tab-item",
                id="programs-tab",
                style={
                    'padding': '10px 20px',
                    'marginRight': '10px',
                    'display': 'inline-block',
                    'borderRadius': '4px 4px 0 0'
                }
            ),
            html.A(
                "Projects",
                href="#",
                className="tab tab-item",
                id="projects-tab",
                style={
                    'padding': '10px 20px',
                    'marginRight': '10px',
                    'display': 'inline-block',
                    'borderRadius': '4px 4px 0 0'
                }
            ),
            html.A(
                "Value Tracker",
                href="#",
                className="tab tab-item",
                id="value-tracker-tab",
                style={
                    'padding': '10px 20px',
                    'marginRight': '10px',
                    'display': 'inline-block',
                    'borderRadius': '4px 4px 0 0'
                }
            )
        ], style={
            'borderBottom': '1px solid var(--color-stroke-primary)',
            'marginBottom': '20px',
            'display': 'flex',
            'alignItems': 'flex-end'
        })
    ], style={
        'marginBottom': '20px'
    })
def get_value_tracker_content():
    """Create Value Tracker tab content (form + table)"""
    try:
        from components.forms.value_tracking_form import create_value_tracking_form
        from components.tables.value_tracking_table import create_value_tracking_table
    except ImportError:
        # If not implemented, show a placeholder
        return html.Div([
            html.H3("Value Tracker components not implemented yet.")
        ])
    return html.Div([
        html.Div([
            create_card(
                title="Add Value Record",
                content=html.Div(
                    id="value-tracker-form-container",
                    children=create_value_tracking_form(selected=False)
                ),
                id="value-tracker-form-card"
            )
        ], style={
            'flex': '0 0 400px',
            'marginRight': '24px',
            'display': 'flex',
            'flexDirection': 'column'
        }),
        html.Div([
            create_card(
                title="Value Tracking Table",
                content=create_value_tracking_table(),
                id="value-tracker-table-card"
            )
        ], style={
            'flex': '1',
            'minWidth': '800px',
            'display': 'flex',
            'flexDirection': 'column'
        })
    ], style={
        'display': 'flex',
        'gap': '24px',
        'alignItems': 'stretch',
        'width': '100%',
        'maxWidth': '1600px',
        'margin': '0 auto',
        'minHeight': '600px'
    })

def get_teams_content():
    """Create teams tab content"""
    return html.Div([
        # Form and Table layout - responsive with synchronized flexible heights
        html.Div([
            # Team Form Card
            html.Div([
                create_card(
                    title="Add New Team Member",
                    content=html.Div(
                        id="team-form-container",
                        children=create_team_form(selected=False)  # Initial form without delete button
                    ),
                    id="team-form-card"
                )
            ], style={
                'flex': '0 0 400px',  # Fixed width for form
                'marginRight': '24px',
                'display': 'flex',  # Make this a flex container
                'flexDirection': 'column'  # Stack content vertically
            }),
            
            # Team Table - takes remaining space with matching height
            html.Div([
                create_card(
                    title="Team Members",
                    content=create_team_table(),
                    id="team-table-card"
                )
            ], style={
                'flex': '1',  # Takes remaining space
                'minWidth': '800px',  # Minimum width for table readability
                'display': 'flex',  # Make this a flex container
                'flexDirection': 'column'  # Stack content vertically
            })
        ], style={
            'display': 'flex', 
            'gap': '24px', 
            'alignItems': 'stretch',  # Equal heights
            'width': '100%',
            'maxWidth': '1600px',
            'margin': '0 auto',
            'minHeight': '600px'
        })
    ])

def get_transactions_content():
    """Create transactions tab content"""
    from components.tables.transactions_table import create_transactions_table
    from db_management.db import get_transactions
    # Fetch latest transactions for initial table data
    data = get_transactions()
    return html.Div([
        # Form and Table layout - responsive with synchronized flexible heights
        html.Div([
            # Transaction Form Card
            html.Div([
                create_card(
                    title="Add New Transaction",
                    content=html.Div(
                        id="transaction-form-container",
                        children=create_transaction_form(selected=False)  # Initial form without delete button
                    ),
                    id="transaction-form-card"
                )
            ], style={
                'flex': '0 0 400px',  # Fixed width for form
                'marginRight': '24px',
                'display': 'flex',
                'flexDirection': 'column'
            }),
            # Managed Transactions Table - takes remaining space with matching height
            html.Div([
                create_card(
                    title="Transaction History",
                    content=create_transactions_table(data),
                    id="transactions-table-card"
                )
            ], style={
                'flex': '1',
                'minWidth': '800px',
                'display': 'flex',
                'flexDirection': 'column'
            })
        ], style={
            'display': 'flex',
            'gap': '24px',
            'alignItems': 'stretch',  # Match other tabs for equal heights
            'width': '100%',
            'maxWidth': '1600px',
            'margin': '0 auto',
            'minHeight': '600px'  # Match other tabs for consistent height
        })
    ])

def transactions_page():
    """Simple transactions page with tab switching between transactions and teams"""
    return html.Div([
        # Tab Navigation
        create_transaction_tabs(),
        
        # Tab Content Container - will be populated by callback
        html.Div(id="tab-content", children=[
            get_transactions_content()  # Default to transactions tab
        ])
    ], className="dashboard-main", style={
        'padding': '0px',
        'overflowY': 'auto',
        'maxHeight': 'calc(100vh - 140px)'  # Reduced from 200px to 140px (navbar 120px + bottom 30px - 10px margin)
    })

layout = html.Div([
    create_navbar(active_tab='Config', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0"),
    html.Div(
        style={
            'margin-left': '20px', 
            'margin-right': '20px',
            'margin-bottom': '0px',
            'margin-top': '10px',
            'height': 'calc(100vh - 120px)',
            'overflowY': 'auto',  # Make the main content area scrollable
            'overflowX': 'hidden',
            'paddingBottom': '0px'  # Ensure no bottom padding
        },
        children=[
            # Page header using existing styles
            html.Div(
                id='main-content',
                children=[
                    html.H1('Config'),
                    create_feedback_button(id_prefix="config-feedback")
                ],
                className='centered-content',
                style={'margin-bottom': '0px'}
            ),
            transactions_page(),
        ]
    ),
    html.Span("TwinOps AI Powered | 2.0.0", className="bottom-section b1")
], style={'height': '100vh', 'overflow': 'hidden'})

# Callback to handle tab switching

@callback(
    [Output('transactions-tab', 'className'),
     Output('projects-tab', 'className'),
     Output('programs-tab', 'className'),
     Output('teams-tab', 'className'),
     Output('value-tracker-tab', 'className'),
     Output('tab-content', 'children')],
    [Input('transactions-tab', 'n_clicks'),
     Input('projects-tab', 'n_clicks'),
     Input('programs-tab', 'n_clicks'),
     Input('teams-tab', 'n_clicks'),
     Input('value-tracker-tab', 'n_clicks')]
)
def update_tab_content(transactions_clicks, projects_clicks, programs_clicks, teams_clicks, value_tracker_clicks):
    """Handle tab switching between Transactions, Projects, Programs, Teams, and Value Tracker"""
    from dash import ctx

    # Default to transactions tab
    active_tab = 'transactions'

    # Determine which tab was clicked
    if ctx.triggered:
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]
        if button_id == 'projects-tab':
            active_tab = 'projects'
        elif button_id == 'programs-tab':
            active_tab = 'programs'
        elif button_id == 'teams-tab':
            active_tab = 'teams'
        elif button_id == 'value-tracker-tab':
            active_tab = 'value-tracker'

    # Set tab classes based on active tab
    transactions_class = "tab tab-active tab-item" if active_tab == 'transactions' else "tab tab-item"
    projects_class = "tab tab-active tab-item" if active_tab == 'projects' else "tab tab-item"
    programs_class = "tab tab-active tab-item" if active_tab == 'programs' else "tab tab-item"
    teams_class = "tab tab-active tab-item" if active_tab == 'teams' else "tab tab-item"
    value_tracker_class = "tab tab-active tab-item" if active_tab == 'value-tracker' else "tab tab-item"

    # Return content based on active tab
    if active_tab == 'projects':
        from components.forms.project_form import create_project_form
        from components.tables.projects_table import create_projects_table
        content = html.Div([
            html.Div([
                create_card(
                    title="Add New Project",
                    content=html.Div(
                        id="project-form-container",
                        children=create_project_form(selected=False, id_prefix="projects-table")
                    ),
                    id="project-form-card"
                )
            ], style={
                'flex': '0 0 400px',
                'marginRight': '24px',
                'display': 'flex',
                'flexDirection': 'column'
            }),
            html.Div([
                create_card(
                    title="Project Portfolio",
                    content=create_projects_table(),
                    id="projects-table-card"
                )
            ], style={
                'flex': '1',
                'minWidth': '800px',
                'display': 'flex',
                'flexDirection': 'column'
            })
        ], style={
            'display': 'flex',
            'gap': '24px',
            'alignItems': 'stretch',
            'width': '100%',
            'maxWidth': '1600px',
            'margin': '0 auto',
            'minHeight': '600px'
        }, id="projects-content")
    elif active_tab == 'programs':
        from components.forms.program_form import create_program_form
        from components.tables.programs_table import create_programs_table
        content = html.Div([
            html.Div([
                create_card(
                    title="Add New Program",
                    content=html.Div(
                        id="program-form-container",
                        children=create_program_form(selected=False)
                    ),
                    id="program-form-card"
                )
            ], style={
                'flex': '0 0 400px',
                'marginRight': '24px',
                'display': 'flex',
                'flexDirection': 'column'
            }),
            html.Div([
                create_card(
                    title="Program Portfolio",
                    content=create_programs_table(),
                    id="programs-table-card"
                )
            ], style={
                'flex': '1',
                'minWidth': '800px',
                'display': 'flex',
                'flexDirection': 'column'
            })
        ], style={
            'display': 'flex',
            'gap': '24px',
            'alignItems': 'stretch',
            'width': '100%',
            'maxWidth': '1600px',
            'margin': '0 auto',
            'minHeight': '600px'
        }, id="programs-content")
    elif active_tab == 'teams':
        content = get_teams_content()
    elif active_tab == 'value-tracker':
        content = get_value_tracker_content()
    else:
        content = get_transactions_content()

    return transactions_class, projects_class, programs_class, teams_class, value_tracker_class, content


