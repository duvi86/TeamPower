from dash import html, register_page, dcc, callback, Input, Output, State
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from utils.create_navbar import create_navbar
from utils.create_feedback_button import create_feedback_button
from utils.create_card import create_card
from utils.create_page_layout import create_page_layout
from components.forms.project_form import create_project_form
from components.tables.projects_table import create_projects_table
from db_management.program_db import (get_programs, add_program, update_program, 
                                        delete_program, get_program_by_id)
import logging

logger = logging.getLogger(__name__)

register_page(__name__, path="/programs", title="Programs", name="Programs")

def create_program_tabs():
    """Create tab navigation for Programs and Projects"""
    return html.Div([
        html.Div([
            html.A(
                "Projects",
                href="#",
                className="tab tab-active tab-item",
                id="projects-tab",
                style={
                    'padding': '10px 20px',
                    'marginRight': '10px',
                    'display': 'inline-block',
                    'borderRadius': '4px 4px 0 0',
                    'backgroundColor': 'var(--gsk-primary)',
                    'color': 'white',
                    'textDecoration': 'none'
                }
            )
        ], className="tab-navigation", style={'marginBottom': '0'})
    ], className="tab-container", style={'marginBottom': '20px'})

def programs_page():
    """Programs page with Projects content"""
    from components.forms.program_form import create_program_form
    from components.tables.programs_table import create_programs_table
    return html.Div([
        html.Div([
            html.Div([
                create_card(
                    title="Add New Program",
                    content=html.Div(
                        id="program-form-container",
                        children=create_program_form(selected=False, id_prefix="programs-table")
                    ),
                    id="program-form-card"
                )
            ], className="form-card-container"),
            html.Div([
                create_card(
                    title="Program Portfolio",
                    content=html.Div([
                        create_programs_table(id_prefix="programs-table"),
                        dcc.Download(id="programs-table-download-csv")
                    ]),
                    id="programs-table-card"
                )
            ], className="table-card-container")
        ], className="page-content-layout", id="programs-content")
    ], className="dashboard-main compact-page")

layout = html.Div([
    create_navbar(active_tab='Programs', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0"),
    html.Div(
        className="main-content-container",
        children=[
            # Page header using existing styles
            html.Div(
                id='main-content',
                children=[
                    html.H1('Projects'),
                    create_feedback_button(id_prefix="projects-feedback")
                ],
                className='centered-content section-spacing'
            ),
            programs_page(),
        ]
    ),
    html.Span("TwinOps AI Powered | 2.0.0", className="bottom-section b1")
], className="full-height-container")
