"""
Refactored transactions page using the generic page pattern
This demonstrates how to use the reusable page template system.
"""

from dash import html, register_page
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_generic_page import create_generic_page_layout, create_tab_callback_factory
from utils.page_config import get_combined_transactions_projects_config

# Register the page with a different path to avoid conflicts
register_page(__name__, path="/transactions-refactored", title="Transactions (Refactored)", name="Transactions (Refactored)")

# Get the page configuration
page_config = get_combined_transactions_projects_config()

# Create the layout using the generic template
layout = create_generic_page_layout(page_config)

# Create tab switching callback if this is a tabbed page
if 'tabs' in page_config:
    create_tab_callback_factory(page_config)
