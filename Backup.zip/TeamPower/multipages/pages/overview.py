from dash import html, register_page, dcc, dash_table
import dash
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from db_management.db import get_transactions_df, get_year_filtered_kpis
from db_management.project_db import get_projects
from db_management.program_db import get_programs
from db_management.value_tracking_db import get_value_tracking_for_year
from utils.create_kpi_card import create_kpi_card, create_kpi_row
from utils.create_graph_card import create_graph_card
from utils.create_dropdown import create_dropdown
from utils.create_sunburst_chart import create_sunburst_chart, prepare_programs_data
from utils.create_navbar import create_navbar
from utils.create_feedback_button import create_feedback_button
from utils.gsk_colors import GSK_VIZ_COLORS, get_department_color_sequence
from dash.dependencies import Input, Output
import logging

logger = logging.getLogger(__name__)

register_page(__name__, path="/", title="Overview", name="Overview")

def create_year_selector():
    """
    Create styled year and value type selection dropdowns
    
    Returns:
    --------
    html.Div
        Container with year and value type dropdown selectors
    """
    try:
        # Get all available years from the database
        df = get_transactions_df()
        available_years = []
        if not df.empty:
            df['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d', errors='coerce')
            years = df['Date'].dt.year.dropna().astype(int).unique()
            available_years = sorted(years, reverse=True)
        
        # Use the most recent year available in the data, or current system year as fallback
        current_year = available_years[0] if available_years else pd.Timestamp.now().year
        
        # Create options for year dropdown, filter out any None/NaN, ensure int
        year_options = [
            {'label': str(int(year)), 'value': int(year)}
            for year in available_years if pd.notnull(year)
        ]
        
        # If no data available, add current system year as option
        if not available_years:
            system_year = pd.Timestamp.now().year
            year_options = [{'label': str(system_year), 'value': system_year}]
            available_years = [system_year]
            current_year = system_year
        
        # Create options for value type dropdown
        value_type_options = [
            {'label': 'Potential', 'value': 'potential'},
            {'label': 'Realized', 'value': 'realized'}
        ]
        
        return html.Div([
            html.Div([
                create_dropdown(
                    id='overview-year-selector',
                    options=year_options,
                    default_value=current_year,
                    class_name="year-dropdown",
                )
            ], className="selector-item", style={'marginBottom': '20px', 'marginRight': '12px'}),
            html.Div([
                create_dropdown(
                    id='overview-value-type-selector',
                    options=value_type_options,
                    default_value='potential',
                    class_name="year-dropdown",  # Use same styling as year dropdown
                )
            ], className="selector-item", style={'marginBottom': '20px'})
        ], className="selectors-row", style={'marginBottom': '20px', 'display': 'flex', 'alignItems': 'center'})
        
    except Exception as e:
        logger.error(f"Error creating year selector: {str(e)}")
        # Return a default selector with current system year and value type
        fallback_year = pd.Timestamp.now().year
        value_type_options = [
            {'label': 'Potential Value', 'value': 'potential'},
            {'label': 'Realized Value', 'value': 'realized'}
        ]
        return html.Div([
            html.Div([
                create_dropdown(
                    id='overview-year-selector',
                    options=[{'label': str(fallback_year), 'value': fallback_year}],
                    default_value=fallback_year,
                    class_name="year-dropdown",
                )
            ], className="selector-item", style={'marginBottom': '20px', 'marginRight': '12px'}),
            html.Div([
                create_dropdown(
                    id='overview-value-type-selector',
                    options=value_type_options,
                    default_value='potential',
                    class_name="year-dropdown",  # Use same styling as year dropdown
                )
            ], className="selector-item", style={'marginBottom': '20px'})
        ], className="selectors-row", style={'marginBottom': '20px', 'display': 'flex', 'alignItems': 'center'})

def get_filtered_transactions_data(selected_year):
    """
    Get filtered transaction data based on selected year
    
    Parameters:
    -----------
    selected_year : int
        The year to filter the data by
        
    Returns:
    --------
    pd.DataFrame
        Filtered dataframe for the selected year
    """
    try:
        # Get all transactions data
        df = get_transactions_df()
        
        if df.empty:
            logger.warning(f"No transaction data available for filtering")
            return pd.DataFrame()
        
        # Convert Date to datetime and filter by selected year
        df['Date'] = pd.to_datetime(df['Date'])
        df_filtered = df[df['Date'].dt.year == selected_year]
        
        # # Create full year date range for selected year
        # year_start = pd.Timestamp(f'{selected_year}-01-01')
        # year_end = pd.Timestamp(f'{selected_year}-12-31')
        
        logger.info(f"Filtered {len(df_filtered)} transactions for year {selected_year}")
        return df_filtered
        
    except Exception as e:
        logger.error(f"Error filtering transaction data for year {selected_year}: {str(e)}")
        return pd.DataFrame()


# def create_value_per_program_chart(selected_year):
#     """Create a bar chart of value promised & realized per program for the selected year."""
#     try:
#         import pandas as pd
#         import plotly.express as px
#         from utils.create_graph_card import create_graph_card
#         programs = get_programs()
#         projects = get_projects()
#         # Build a mapping of program_id to program name
#         program_id_to_name = {p['id']: p['name'] for p in programs}
#         # Aggregate promised value per program for projects with end_date in selected year
#         from datetime import datetime
#         data = {}
#         for proj in projects:
#             end_date = proj.get('end_date')
#             if not end_date:
#                 continue
#             try:
#                 end_year = datetime.strptime(end_date, "%Y-%m-%d").year
#             except Exception:
#                 continue
#             if end_year != selected_year:
#                 continue
#             prog_id = proj.get('program_id')
#             prog_name = program_id_to_name.get(prog_id, f"Program {prog_id}")
#             if prog_name not in data:
#                 data[prog_name] = 0
#             data[prog_name] += (proj.get('potential_value', 0) or 0)
#         # Prepare DataFrame
#         df = pd.DataFrame([
#             {'Program': k, 'Value Promised': v}
#             for k, v in data.items()
#         ])
#         if df.empty:
#             import plotly.graph_objects as go
#             fig = go.Figure()
#             fig.add_annotation(
#                 text="No program value data available",
#                 xref="paper", yref="paper",
#                 x=0.5, y=0.5, xanchor='center', yanchor='middle',
#                 showarrow=False, font=dict(size=16)
#             )
#             fig.update_layout(
#                 title=f'Value Promised per Program - {selected_year}',
#                 template='plotly_white',
#                 height=400,
#                 margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
#             )
#             return create_graph_card(
#                 id='program-value-chart',
#                 figure=fig,
#                 title='Value Promised per Program',
#                 height=500,
#                 actions=False
#             )
#         fig = px.bar(
#             df,
#             x='Program',
#             y='Value Promised',
#             color='Program',
#             title=f'Value Promised per Program - {selected_year}',
#             labels={'Value Promised': 'Value Promised ($)', 'Program': 'Program'},
#             color_discrete_sequence=px.colors.qualitative.Plotly
#         )
#         fig.update_layout(
#             template="plotly_white",
#             title={'x': 0.5, 'xanchor': 'center'},
#             yaxis={'tickformat': '$,.0f'},
#             height=400,
#             margin={'t': 60, 'b': 40, 'l': 60, 'r': 20},
#             showlegend=False
#         )
#         return create_graph_card(
#             id='program-value-chart',
#             figure=fig,
#             title='Value Promised per Program',
#             height=500,
#             actions=False
#         )
#     except Exception as e:
#         import plotly.graph_objects as go
#         from utils.create_graph_card import create_graph_card
#         fig = go.Figure()
#         fig.add_annotation(
#             text=f"Error loading program value data: {str(e)[:50]}...",
#             xref="paper", yref="paper",
#             x=0.5, y=0.5, xanchor='center', yanchor='middle',
#             showarrow=False, font=dict(size=14)
#         )
#         fig.update_layout(
#             title=f'Value Promised & Realized per Program - {selected_year}',
#             template='plotly_white',
#             height=400,
#             margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
#         )
#         return create_graph_card(
#             id='program-value-chart',
#             figure=fig,
#             title='Value Promised & Realized per Program',
#             height=500,
#             actions=False
#         )

# def create_value_promised_realized_chart(selected_year):
#     """Create value promised vs realized chart with card styling"""
#     try:
#         # Get value evolution data for selected year
        
        
#         value_evolution_fig = px.area(
#             x='Month',
#             y=['Value Promised', 'Value Realized'],
#             title=f'Value Promised vs Realized - {selected_year}',
#             labels={'value': 'Value ($)', 'Month': 'Month', 'variable': 'Value Type'},
#             color_discrete_map={
#                 'Value Promised': '#42A5F5',
#                 'Value Realized': '#66BB6A'
#             }
#         )
        
#         value_evolution_fig.update_layout(
#             template="plotly_white",
#             title={'x': 0.5, 'xanchor': 'center'},
#             yaxis={'tickformat': '$,.0f'},
#             height=400,
#             margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
#         )
        
#         return create_graph_card(
#             id='value-chart',
#             figure=value_evolution_fig,
#             title='Value Promised vs Realized',
#             height=500,
#             actions=False
#         )
        
#     except Exception as e:
#         logger.error(f"Error creating value promised vs realized chart: {e}")
#         fig = go.Figure()
#         fig.add_annotation(
#             text=f"Error loading value data: {str(e)[:50]}...",
#             xref="paper", yref="paper",
#             x=0.5, y=0.5, xanchor='center', yanchor='middle',
#             showarrow=False, font=dict(size=14)
#         )
#         fig.update_layout(
#             title=f'Value Promised vs Realized - {selected_year}',
#             template='plotly_white',
#             height=400,
#             margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
#         )
#         return create_graph_card(
#             id='value-chart',
#             figure=fig,
#             title='Value Promised vs Realized',
#             height=500,
#             actions=False
#         )

# Filter programs and projects to those active in the selected year (start_date <= year <= end_date)
def is_active_in_year(item, selected_year):
    start = pd.to_datetime(item.get('start_date'), errors='coerce')
    end = pd.to_datetime(item.get('end_date'), errors='coerce')
    if pd.isnull(start) or pd.isnull(end):
        return False
    return start.year <= selected_year <= end.year

def create_programs_sunburst_chart(selected_year=None, selected_value_type='potential'):
    """Create the updated sunburst chart with value potential hierarchy using central component."""
    try:
        from datetime import datetime
        
        # Use current year if no year is selected
        if selected_year is None:
            selected_year = datetime.now().year
            
        programs = get_programs()
        projects = get_projects()
        
        # Prepare data using central utility with selected year and value type for filtering
        config = {
            'selected_year': selected_year,
            'value_type': selected_value_type
        }
        sunburst_data = prepare_programs_data(programs, projects, config)
        
        # Configure the chart
        chart_config = {
            'title': '',  # No title since it's handled by the card wrapper
            'height': 900,
            'maxdepth': 3,
            'hover_template': '<b>%{label}</b><br>Value: %{value:.2f} M$<br>Share: %{percentParent}<br><extra></extra>',
            'margin': {'t': 0, 'l': 0, 'r': 0, 'b': 0}
        }
        
        # Create sunburst using central component
        fig = create_sunburst_chart(sunburst_data, chart_config)
        
        # Ensure branchvalues is set to total for correct rendering
        if fig.data:
            fig.data[0].branchvalues = 'total'
            
        return fig
        
    except Exception as e:
        logger.error(f"Error creating programs sunburst chart: {e}")
        # Return empty figure with error message
        fig = go.Figure()
        fig.add_annotation(
            text='Error loading programs data',
            xref='paper', yref='paper',
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font=dict(size=16)
        )
        fig.update_layout(
            height=450,
            paper_bgcolor='white',
            plot_bgcolor='white',
            margin={'t': 0, 'l': 0, 'r': 0, 'b': 0}
        )
        return fig

def create_program_status_summary(get_items, selected_year):
    """Create a simple status summary card to complement the sunburst chart"""
    try:
        programs = [prog for prog in get_items() if is_active_in_year(prog, selected_year)]

        if not programs:
            return html.Div("No program data", className="text-center text-muted")
        
        # Count by status
        status_counts = {}
        for program in programs:
            status = program.get('status', 'Unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
        
        # Create status badges
        import dash_bootstrap_components as dbc
        status_items = []
        status_colors = {
            'Active': 'success',
            'Completed': 'primary', 
            'On Hold': 'warning',
            'Cancelled': 'danger',
            'Planning': 'info',
            'In Progress': 'success',
            'Paused': 'secondary'
        }
        
        for status, count in sorted(status_counts.items(), key=lambda x: x[1], reverse=True):
            color = status_colors.get(status, 'secondary')
            status_items.append(
                dbc.ListGroupItem([
                    html.Div([
                        html.Span(status, className="fw-bold me-2"),
                        dbc.Badge(str(count), color=color, pill=True)
                    ], className="d-flex align-items-center justify-content-between")
                ])
            )
        
        from utils.create_card import create_card
        return create_card(
            title="Project Pipeline Status",
            content=[
                dbc.ListGroup(status_items, flush=True),
                html.Hr(),
                html.P(f"Total: {len(programs)} programs", className="text-center text-muted mb-0")
            ],
            id="program-status-summary-card",
            class_name="d-flex flex-column card-body",
            style={
                "height": "520px",  # match card_height in create_graph_card (500+20)
                "minHeight": "520px",
                "maxHeight": "520px",
                "overflow": "hidden"
            }
        )
        
    except Exception as e:
        return html.Div(f"Error: {e}", className="text-danger")

def generate_overview_content(selected_year, selected_value_type='potential'):
    """
    Generate overview dashboard content for the selected year and value type
    
    Parameters:
    -----------
    selected_year : int
        The year to generate content for
    selected_value_type : str
        The value type to display ('potential' or 'realized')
        
    Returns:
    --------
    list
        List of dashboard components
    """
    try:
        # Get filtered data
        filtered_df = get_filtered_transactions_data(selected_year)
        
        # Get year-filtered KPIs that will change based on selected year
        kpi_data = get_year_filtered_kpis(selected_year)
        
        # Get actual database projects for value calculations
        all_projects = get_projects()
        # Only include projects whose start or end year matches the selected year
        projects = [p for p in all_projects if (
            (p.get('start_date') and pd.to_datetime(p.get('start_date'), errors='coerce').year == selected_year) or
            (p.get('end_date') and pd.to_datetime(p.get('end_date'), errors='coerce').year == selected_year)
        )]
        
        # Get actual program counts, filtered by selected year
        all_programs = get_programs()
        programs = [prog for prog in all_programs if (
            (prog.get('start_date') and pd.to_datetime(prog.get('start_date'), errors='coerce').year == selected_year) or
            (prog.get('end_date') and pd.to_datetime(prog.get('end_date'), errors='coerce').year == selected_year)
        )]
        

        programs = [prog for prog in get_programs() if is_active_in_year(prog, selected_year)]
        projects = [proj for proj in get_projects() if is_active_in_year(proj, selected_year)]

        # Calculate actual counts from database
        total_programs = len(programs)
        active_projects = len([p for p in projects if p.get('status') == 'Active'])

        value_list = get_value_tracking_for_year(selected_year)


        # Calculate values based on selected value type
        total_value_realized_ytd = sum(item.get('amount', 0) for item in value_list)
        total_value_potential = sum(p.get('potential_value', 0) for p in projects)
        
        # Use the year-filtered team metrics from database (keep these as they are team-related)
        active_team_members = kpi_data.get('active_team_members', 0)
        attrition_rate = kpi_data.get('attrition_rate', 0)
        leavers = kpi_data.get('leavers', 0)
        base_population = kpi_data.get('base_population', 0)

        # Create overview KPI cards with consistent ordering (always potential first, then realized)
        kpi_cards = [
            create_kpi_card(
                f'Total Value Potential', 
                f"${total_value_potential:,.0f}", 
                value_class='value-potential'
            ),
            create_kpi_card(
                f'Total Value Realized YTD', 
                f"${total_value_realized_ytd:,.0f}", 
                value_class='value-realized'
            ),
            create_kpi_card(
                f'Total Programs', 
                str(total_programs), 
                value_class='programs'
            ),
            create_kpi_card(
                f'Active Projects', 
                str(active_projects), 
                value_class='projects'
            ),
            create_kpi_card(
                'Active Team Members', 
                str(active_team_members), 
                value_class='team-members'
            ),
            create_kpi_card(
                'Attrition Rate', 
                f"{attrition_rate}%", 
                subtitle=f"({leavers}/{base_population:.1f})", 
                value_class='attrition-rate'
            )
        ]

        # Create the enhanced programs sunburst chart with value type selection
        programs_chart = create_programs_sunburst_chart(selected_year, selected_value_type)
        status_summary = create_program_status_summary(get_projects, selected_year)

        # Return overview dashboard content
        return [
            # KPI Row
            create_kpi_row(kpi_cards),
            # Enhanced Chart row: programs sunburst chart and status summary
            html.Div([
                html.Div([
                    html.Div([
                        create_graph_card(
                            id='programs-overview-chart',
                            figure=programs_chart,
                            title='Interactive Programs Overview',
                            height=500,
                            actions=True  # Enable download/fullscreen
                        )
                    ], className='chart-column', style={'width': '65%'}),
                    html.Div([
                        status_summary
                    ], className='chart-column', style={'width': '35%', 'padding-left': '15px'}),
                ], className='charts-container', style={'display': 'flex', 'width': '100%'}),
            ], className='budget-analytics-section'),
        ]
        
    except Exception as e:
        logger.error(f"Error generating overview content for year {selected_year}: {str(e)}")
        return [html.Div(f"Error loading overview content for {selected_year}", 
                        style={'text-align': 'center', 'margin': '50px', 'color': 'red'})]

def overview_dashboard_page(selected_year=None, selected_value_type='potential'):
    """Overview dashboard page with comprehensive visualizations"""
    try:
        # Use current year if no year is selected
        if selected_year is None:
            selected_year = pd.Timestamp.now().year
        
        # Generate overview content for selected year and value type
        overview_content = generate_overview_content(selected_year, selected_value_type)
        
        # Create overview layout
        layout = html.Div([
            # Year and Value Type Selector
            create_year_selector(),
            
            # Overview content that will be updated based on year and value type selection
            html.Div(id='overview-content', children=overview_content)
        ], className='dashboard-main')
        
        return layout
        
    except Exception as e:
        logger.error(f"Error creating overview page: {e}")
        # Return error message
        return html.Div([
            create_year_selector(),
            html.Div([
                html.H2("Error Loading Overview", style={'color': 'red', 'text-align': 'center'}),
                html.P(f"An error occurred while loading the overview: {str(e)}", 
                      style={'text-align': 'center', 'margin': '20px'})
            ])
        ], className='dashboard-main')

# Add callback to update overview content based on year selector
@dash.callback(
    Output('overview-content', 'children', allow_duplicate=True),
    [Input('overview-year-selector', 'value'),
     Input('overview-value-type-selector', 'value')],
    prevent_initial_call=True
)
def update_overview_content(selected_year, selected_value_type):
    """
    Callback to update the overview content based on year and value type selection
    
    Parameters:
    -----------
    selected_year : int
        The selected year from the dropdown
    selected_value_type : str
        The selected value type ('potential' or 'realized')
    
    Returns:
    --------
    list
        Updated overview content
    """
    try:
        if not selected_year:
            selected_year = pd.Timestamp.now().year
        if not selected_value_type:
            selected_value_type = 'potential'
            
        return generate_overview_content(selected_year, selected_value_type)
    except Exception as e:
        logger.error(f"Error updating overview content: {str(e)}")
        return [html.Div(
            f"Error updating overview content: {str(e)}", 
            style={'text-align': 'center', 'color': 'red', 'margin': '30px'}
        )]

def layout():
    """Create the overview page layout"""
    try:
        return html.Div([
            create_navbar(active_tab='Overview', logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0"),
            html.Div(
                style={
                    'margin-left': '20px', 
                    'margin-right': '20px',
                    'margin-bottom': '40px',
                    'margin-top': '10px',
                    'height': 'calc(100vh - 120px)',
                },
                children=[
                    # Page header
                    html.Div(
                        id='main-content',
                        children=[
                            html.H1('Overview'),
                            # Using standardized feedback button component
                            create_feedback_button(id_prefix="overview-feedback")
                        ],
                        className='centered-content',
                        style={'margin-bottom': '10px'}
                    ),
                    overview_dashboard_page(),
                ]
            ),
            html.Span("TwinOps AI Powered | 2.0.0", className="bottom-section b1")
        ], style={'height': '100vh', 'overflow': 'hidden'})
    except Exception as e:
        logger.error(f"Error creating overview layout: {e}")
        return html.Div([
            html.H1("Error Loading Overview", style={'color': 'red', 'text-align': 'center'}),
            html.P(f"Error: {str(e)}", style={'text-align': 'center'})
        ])
