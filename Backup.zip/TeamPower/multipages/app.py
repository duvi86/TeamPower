
import dash
import dash_bootstrap_components as dbc
from dash import html, dcc
from utils.create_navbar import create_navbar

# Initialize the Dash app with external CSS and enable pages
app = dash.Dash(
    __name__,
    use_pages=True,
    pages_folder="pages",
    external_stylesheets=[
        dbc.themes.BOOTSTRAP,
        "/assets/bootstrap-overrides.css",
        "/assets/styles.css",
        "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    ],
    suppress_callback_exceptions=True
)


# Import all pages to ensure they're registered (after app initialization)
from pages import overview, configuration, ai_financials, ai_governance, transactions, team_hierarchy


# Import callbacks (must be after app initialization)
import callbacks

# Set up the app layout
app.layout = html.Div([
    dash.page_container
], style={'height': '100vh', 'overflow': 'hidden'})

if __name__ == '__main__':
    app.run(debug=True, port=8112)
