# from multipages.callbacks.program_callbacks import *
# from multipages.callbacks.project_callbacks import *
# from dash import callback, Input, Output, State, html, dcc, ctx, MATCH, ALL, no_update
# from dash.exceptions import PreventUpdate
# import dash_bootstrap_components as dbc
# import dash
# import math
# import sys
# import os
# from datetime import datetime, date
# from db_management.db import get_transactions, delete_transaction, get_transactions_df, update_transaction
# import plotly.express as px
# from db_management.db import add_value_tracking_record, update_value_tracking_record, delete_value_tracking_record, get_value_tracking_records, get_value_tracking_record_by_id

# # === Value Tracking Table Row Selection Callback (using active_cell for proper toggle, fully aligned with team logic) ===

# # === Value Tracking Table Row Selection Callback (EXACT team logic) ===

# # === Value Tracking Table Row Selection Callback (EXACT team logic, no selected_rows output) ===

# # === Value Tracking Table Row Selection Callback (Teams tab logic: toggle, update button, delete button) ===
# @callback(
#     [Output('value-tracking-description', 'value', allow_duplicate=True),
#      Output('value-tracking-amount', 'value', allow_duplicate=True),
#      Output('value-tracking-start-date', 'date', allow_duplicate=True),
#      Output('value-tracking-end-date', 'date', allow_duplicate=True),
#      Output('value-tracking-project', 'value', allow_duplicate=True),
#      Output('value-tracking-business-sponsor', 'value', allow_duplicate=True),
#      Output('selected-value-tracking-store', 'data', allow_duplicate=True),
#      Output('add-value-tracking-btn', 'children', allow_duplicate=True),
#      Output('value-tracking-table-datatable', 'selected_rows', allow_duplicate=True),
#      Output('delete-value-tracking-btn-wrapper', 'style', allow_duplicate=True)],
#     [Input('value-tracking-table-datatable', 'active_cell')],
#     [State('value-tracking-table-datatable', 'data'),
#      State('selected-value-tracking-store', 'data')],
#     prevent_initial_call=True
# )
# def value_tracking_table_row_selected(active_cell, table_data, current_selected_id):
#     from datetime import datetime, date
#     # Clear form if active_cell is cleared (e.g., by deselecting)
#     if not active_cell:
#         return ('', None, None, None, None, '', None, 'Add Value Record', [], {'opacity': '0', 'pointerEvents': 'none'})

#     row_index = active_cell['row']
#     selected_row = table_data[row_index]
#     record_id = selected_row['id']

#     # If the same row is clicked again, deselect and clear the form
#     if record_id == current_selected_id:
#         return ('', None, None, None, None, '', None, 'Add Value Record', [], {'opacity': '0', 'pointerEvents': 'none'})

#     # Get value tracking record details from database
#     record_data = get_value_tracking_record_by_id(record_id)
#     if record_data:
#         # Convert start_date string to date object if needed
#         start_date_value = record_data.get('start_date', date.today())
#         if isinstance(start_date_value, str) and start_date_value:
#             try:
#                 start_date_value = datetime.strptime(start_date_value, '%Y-%m-%d').date()
#             except (ValueError, TypeError):
#                 start_date_value = date.today()

#         # Convert end_date string to date object, handling empty or invalid values
#         end_date_value = record_data.get('end_date', None)
#         if isinstance(end_date_value, str) and end_date_value.strip():
#             try:
#                 end_date_value = datetime.strptime(end_date_value, '%Y-%m-%d').date()
#             except (ValueError, TypeError):
#                 end_date_value = None
#         else:
#             end_date_value = None

#         return (
#             record_data.get('description', ''),
#             record_data.get('amount', None),
#             start_date_value,
#             end_date_value,
#             record_data.get('project_id', None),
#             record_data.get('business_sponsor', ''),
#             record_id,
#             'Update Value Record',
#             [row_index],
#             {'opacity': '1', 'pointerEvents': 'auto'}
#         )

#     # Fallback to clear the form if something goes wrong
#     return ('', None, None, None, None, '', None, 'Add Value Record', [], {'opacity': '0', 'pointerEvents': 'none'})

# # Callback to change clear button text to "Duplicate" when a value tracking record is selected
# @callback(
#     Output('clear-value-tracking-form-btn', 'children'),
#     [Input('selected-value-tracking-store', 'data')],
#     prevent_initial_call=False
# )
# def update_clear_value_tracking_button_text(selected_record_id):
#     """Change button text to 'Duplicate' when a row is selected, otherwise 'Clear'."""
#     if selected_record_id is not None:
#         return 'Duplicate'
#     else:
#         return 'Clear'

# # Clear Value Tracking Form Callback - handles both clear and duplicate functionality
# @callback(
#     [Output('value-tracking-description', 'value', allow_duplicate=True),
#      Output('value-tracking-amount', 'value', allow_duplicate=True),
#      Output('value-tracking-start-date', 'date', allow_duplicate=True),
#      Output('value-tracking-end-date', 'date', allow_duplicate=True),
#      Output('value-tracking-project', 'value', allow_duplicate=True),
#      Output('value-tracking-business-sponsor', 'value', allow_duplicate=True),
#      Output('value-tracking-message', 'children', allow_duplicate=True),
#      Output('selected-value-tracking-store', 'data', allow_duplicate=True),
#      Output('add-value-tracking-btn', 'children', allow_duplicate=True),
#      Output('value-tracking-table-datatable', 'selected_rows', allow_duplicate=True),
#      Output('delete-value-tracking-btn-wrapper', 'style', allow_duplicate=True)],
#     [Input('clear-value-tracking-form-btn', 'n_clicks')],
#     [State('selected-value-tracking-store', 'data'),
#      # Add current form values as State inputs for duplicate functionality
#      State('value-tracking-description', 'value'),
#      State('value-tracking-amount', 'value'),
#      State('value-tracking-start-date', 'date'),
#      State('value-tracking-end-date', 'date'),
#      State('value-tracking-project', 'value'),
#      State('value-tracking-business-sponsor', 'value')],
#     prevent_initial_call=True
# )
# def clear_value_tracking_form(n_clicks, selected_record_id, current_description, current_amount, 
#                              current_start_date, current_end_date, current_project, current_business_sponsor):
#     """Handle both clear and duplicate functionality for value tracking form."""
#     if not n_clicks:
#         return ('', None, None, None, None, '', '', None, 'Add Value Record', [], {'opacity': '0', 'pointerEvents': 'none'})
    
#     if selected_record_id is not None:
#         # Duplicate mode: keep current form values but clear selection to allow adding as new record
#         return (current_description, current_amount, current_start_date, current_end_date, 
#                 current_project, current_business_sponsor, '', None, 'Add Value Record', [], {'opacity': '0', 'pointerEvents': 'none'})
#     else:
#         # Clear mode: clear all form fields
#         return ('', None, None, None, None, '', '', None, 'Add Value Record', [], {'opacity': '0', 'pointerEvents': 'none'})

# # === VALUE TRACKING DELETE CONFIRM CALLBACK ===
# @callback(
#     [Output('value-tracking-table-datatable', 'data', allow_duplicate=True),
#      Output('value-tracking-table-delete-modal', 'is_open', allow_duplicate=True),
#      Output('value-tracking-table-delete-info', 'children', allow_duplicate=True),
#      Output('value-tracking-table-delete-store', 'data', allow_duplicate=True),
#      Output('value-tracking-message', 'children', allow_duplicate=True)],
#     [Input('value-tracking-table-confirm-delete', 'n_clicks')],
#     [State('value-tracking-table-delete-store', 'data')],
#     prevent_initial_call=True
# )
# def confirm_delete_value_tracking(confirm_clicks, delete_store):
#     if confirm_clicks and delete_store:
#         try:
#             record_id = delete_store.get('id') if isinstance(delete_store, dict) else delete_store
#             delete_value_tracking_record(record_id)
#             updated_data = get_value_tracking_records()
#             message = html.Div("✅ Value record deleted successfully!", style={'color': 'green'})
#             return updated_data, False, [], None, message
#         except Exception as e:
#             message = html.Div(f"❌ Error deleting value record: {str(e)}", style={'color': 'red'})
#             return dash.no_update, False, [], None, message
#     return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

# # === VALUE TRACKING DELETE MODAL CALLBACK ===
# @callback(
#     [Output('value-tracking-table-delete-modal', 'is_open'),
#      Output('value-tracking-table-delete-info', 'children'),
#      Output('value-tracking-table-delete-store', 'data')],
#     [Input('delete-value-tracking-btn', 'n_clicks'),
#      Input('value-tracking-table-cancel-delete', 'n_clicks'),
#      Input('value-tracking-table-confirm-delete', 'n_clicks')],
#     [State('value-tracking-table-datatable', 'selected_rows'),
#      State('value-tracking-table-datatable', 'data'),
#      State('value-tracking-table-delete-store', 'data')],
#     prevent_initial_call=True
# )
# def handle_value_tracking_delete_modal(delete_clicks, cancel_clicks, confirm_clicks, selected_rows, table_data, delete_store):
#     ctx_id = ctx.triggered_id if hasattr(ctx, 'triggered_id') else None
#     # Only open modal if delete button is clicked and a row is selected
#     if ctx_id == 'delete-value-tracking-btn' and delete_clicks and selected_rows and table_data:
#         idx = selected_rows[0]
#         record = table_data[idx]
#         info = f"Are you sure you want to delete value record: {record.get('description', '')}?"
#         return True, info, {'id': record.get('id')}
#     elif ctx_id == 'value-tracking-table-cancel-delete' and cancel_clicks:
#         return False, '', None
#     elif ctx_id == 'value-tracking-table-confirm-delete' and confirm_clicks and delete_store:
#         return False, '', None
#     # If triggered by row selection or anything else, do nothing
#     return dash.no_update, dash.no_update, dash.no_update

# # === VALUE TRACKING ADD/UPDATE CALLBACK ===
# @callback(
#     [Output('value-tracking-description', 'value'),
#      Output('value-tracking-amount', 'value'),
#      Output('value-tracking-start-date', 'date'),
#      Output('value-tracking-end-date', 'date'),
#      Output('value-tracking-project', 'value'),
#      Output('value-tracking-business-sponsor', 'value'),
#      Output('value-tracking-message', 'children', allow_duplicate=True),
#      Output('value-tracking-table-datatable', 'data', allow_duplicate=True),
#      Output('selected-value-tracking-store', 'data', allow_duplicate=True),
#      Output('value-tracking-table-datatable', 'selected_rows', allow_duplicate=True),
#      Output('add-value-tracking-btn', 'children', allow_duplicate=True)],
#     [Input('add-value-tracking-btn', 'n_clicks')],
#     [State('value-tracking-description', 'value'),
#      State('value-tracking-amount', 'value'),
#      State('value-tracking-start-date', 'date'),
#      State('value-tracking-end-date', 'date'),
#      State('value-tracking-project', 'value'),
#      State('value-tracking-business-sponsor', 'value'),
#      State('selected-value-tracking-store', 'data')],
#     prevent_initial_call=True
# )
# def handle_add_value_tracking(n_clicks, description, amount, start_date, end_date, project_id, business_sponsor, selected_record_id):
#     if not n_clicks:
#         return ('', None, None, None, None, '', '', dash.no_update, dash.no_update, dash.no_update, 'Add Value Record')
#     required_fields = [description, amount, start_date, end_date, project_id, business_sponsor]
#     if not all(required_fields):
#         return (description, amount, start_date, end_date, project_id, business_sponsor,
#                 html.Div("Please fill in all required fields", style={'color': 'red'}),
#                 dash.no_update, dash.no_update, [], 'Add Value Record'
#         )
#     try:
#         if selected_record_id:
#             update_value_tracking_record(selected_record_id, description, amount, start_date, end_date, project_id, business_sponsor)
#             msg = "Value record updated successfully!"
#             updated_data = get_value_tracking_records()
#             # Find the updated row index
#             idx = None
#             for i, row in enumerate(updated_data):
#                 if str(row.get('id')) == str(selected_record_id):
#                     idx = i
#                     break
#             # After update, keep the form and selection as-is (do not clear anything)
#             return (
#                 description, amount, start_date, end_date, project_id, business_sponsor,
#                 html.Div(msg, style={'color': 'green'}),
#                 updated_data, selected_record_id, [idx] if idx is not None else [], 'Update Value Record'
#             )
#         else:
#             add_value_tracking_record(description, amount, start_date, end_date, project_id, business_sponsor)
#             msg = "Value record added successfully!"
#             updated_data = get_value_tracking_records()
#             # After add, clear the form and selection
#             return ('', None, None, None, None, '', html.Div(msg, style={'color': 'green'}), updated_data, None, [], 'Add Value Record')
#     except Exception as e:
#         return (description, amount, start_date, end_date, project_id, business_sponsor,
#                 html.Div(f"Error: {str(e)}", style={'color': 'red'}), dash.no_update, dash.no_update, dash.no_update, 'Add Value Record')
# import pandas as pd
# import io

# @callback(
#     [Output('transactions-table-delete-modal', 'is_open'),
#      Output('transactions-table-delete-info', 'children'),
#      Output('transactions-table-delete-store', 'data')],
#     [Input('delete-form-btn', 'n_clicks'),
#      Input('transactions-table-cancel-delete', 'n_clicks'),
#      Input('transactions-table-confirm-delete', 'n_clicks')],
#     [State('transactions-table-datatable', 'selected_rows'),
#      State('transactions-table-datatable', 'data'),
#      State('transactions-table-delete-store', 'data')],
#     prevent_initial_call=True
# )
# def handle_transaction_delete_modal(delete_clicks, cancel_clicks, confirm_clicks, selected_rows, table_data, delete_store):
#     """Handle delete modal for transactions"""
    
#     # Determine which input triggered the callback
#     triggered_id = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else None
    
#     if triggered_id == 'delete-form-btn' and delete_clicks and selected_rows and table_data:
#         # Open delete modal
#         transaction = table_data[selected_rows[0]]
#         delete_info = html.Div([
#             html.P(f"Transaction: {transaction.get('description', 'Unknown')}"),
#             html.P(f"Amount: ${transaction.get('amount', 'N/A')}"),
#             html.P(f"Date: {transaction.get('date', 'N/A')}")
#         ])
#         return True, delete_info, transaction
    
#     elif triggered_id == 'transactions-table-cancel-delete' and cancel_clicks:
#         # Close delete modal without deleting
#         return False, [], None
    
#     elif triggered_id == 'transactions-table-confirm-delete' and confirm_clicks and delete_store:
#         # Modal closing is handled by the actual delete callback
#         return False, [], None
    
#     return no_update, no_update, no_update
# ## === TEAM MEMBER DELETE MODAL CALLBACK ===



# @callback(
#     Output('transactions-table-datatable', 'selected_rows', allow_duplicate=True),
#     [Input('transactions-table-datatable', 'active_cell')],
#     [State('transactions-table-datatable', 'selected_rows')],
#     prevent_initial_call=True
# )
# def toggle_selected_row(active_cell, selected_rows):
#     """Allow toggling selection of a row by clicking it again to unselect."""
#     if not active_cell:
#         return selected_rows or []
#     row = active_cell.get('row')
#     if selected_rows and row in selected_rows:
#         # Deselect if already selected
#         return []
#     else:
#         return [row]

# # === Export CSV callback for transactions table ===
# @callback(
#     Output('transactions-table-download-csv', 'data'),
#     [Input('transactions-table-export-csv', 'n_clicks')],
#     [State('transactions-table-datatable', 'data')],
#     prevent_initial_call=True
# )
# def export_transactions_table_csv(n_clicks, table_data):
#     if not n_clicks or not table_data:
#         return no_update
#     df = pd.DataFrame(table_data)
#     csv_string = df.to_csv(index=False)
#     return dict(content=csv_string, filename="transactions_export.csv")

# # === Page size selector callback for transactions table ===
# @callback(
#     Output('transactions-table-datatable', 'page_size'),
#     [Input('transactions-table-page-size-dropdown', 'value')],
#     prevent_initial_call=False
# )
# def update_transactions_table_page_size(page_size):
#     """Update the DataTable's page_size property when the dropdown changes"""
#     return page_size

# def create_edit_form(transaction):
#     """Create edit form components for the modal"""
#     return html.Div([
#         html.Div([
#             html.Label("Date:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.DatePickerSingle(
#                 id='edit-date-input',
#                 date=transaction.get('date'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Description:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-description-input',
#                 type='text',
#                 value=transaction.get('description'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Amount:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-amount-input',
#                 type='number',
#                 value=transaction.get('amount'),
#                 style={'width': '100px', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Cost Center Project:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-cost-center-project-input',
#                 type='text',
#                 value=transaction.get('cost_center_project'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Cost Center SOW:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-cost-center-sow-input',
#                 type='text',
#                 value=transaction.get('cost_center_sow'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("SOW Number:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-sow-number-input',
#                 type='text',
#                 value=transaction.get('sow_number'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("PO Number:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-po-number-input',
#                 type='text',
#                 value=transaction.get('po'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Category:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Dropdown(
#                 id='edit-category-input',
#                 options=[
#                     {'label': 'Budget', 'value': 'Budget'},
#                     {'label': 'Planned', 'value': 'Planned'},
#                     {'label': 'Consumed', 'value': 'Consumed'}
#                 ],
#                 value=transaction.get('category'),
#                 style={'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Type:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Dropdown(
#                 id='edit-type-input',
#                 options=[
#                     {'label': 'OPEX', 'value': 'OPEX'},
#                     {'label': 'CAPEX', 'value': 'CAPEX'}
#                 ],
#                 value=transaction.get('type'),
#                 style={'marginBottom': '15px'}
#             )
#         ])
#     ])

# def create_table_row(row, is_editing=False):
#     """Create a single table row with edit mode support"""
#     if is_editing:
#         # Edit mode row with inputs
#         return html.Tr([
#             html.Td([
#                 dcc.DatePickerSingle(
#                     id={'type': 'edit-date', 'index': row.get('id')},
#                     date=row.get('date'),
#                     style={'width': '120px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 dcc.Input(
#                     id={'type': 'edit-amount', 'index': row.get('id')},
#                     type='number',
#                     value=row.get('amount'),
#                     style={'width': '100px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 dcc.Input(
#                     id={'type': 'edit-ccp', 'index': row.get('id')},
#                     type='text',
#                     value=row.get('cost_center_project', ''),
#                     style={'width': '150px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 dcc.Input(
#                     id={'type': 'edit-ccs', 'index': row.get('id')},
#                     type='text',
#                     value=row.get('cost_center_sow', ''),
#                     style={'width': '150px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 dcc.Input(
#                     id={'type': 'edit-sow', 'index': row.get('id')},
#                     type='text',
#                     value=row.get('sow_number', ''),
#                     style={'width': '120px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 dcc.Input(
#                     id={'type': 'edit-po', 'index': row.get('id')},
#                     type='text',
#                     value=row.get('po', ''),
#                     style={'width': '120px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 dcc.Dropdown(
#                     id={'type': 'edit-category', 'index': row.get('id')},
#                     options=[{'label': c, 'value': c} for c in ['Budget', 'X-charged', 'Consumed']],
#                     value=row.get('category'),
#                     style={'width': '120px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 dcc.Dropdown(
#                     id={'type': 'edit-type', 'index': row.get('id')},
#                     options=[{'label': t, 'value': t} for t in ['OPEX', 'CAPEX']],
#                     value=row.get('type'),
#                     style={'width': '100px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6'}),
#             html.Td([
#                 html.Button(
#                     "💾",
#                     id={'type': 'save-btn', 'index': row.get('id')},
#                     title="Save changes",
#                     className="btn_bottom",
#                     style={'marginRight': '4px', 'padding': '4px 8px', 'fontSize': '12px'}
#                 ),
#                 html.Button(
#                     "❌",
#                     id={'type': 'cancel-btn', 'index': row.get('id')},
#                     title="Cancel edit",
#                     className="btn-bottom-sec",
#                     style={'padding': '4px 8px', 'fontSize': '12px'}
#                 )
#             ], style={'padding': '8px', 'borderBottom': '1px solid #dee2e6', 'textAlign': 'center'})
#         ])
#     else:
#         # Display mode row
#         return html.Tr([
#             html.Td(row.get('date', ''), style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'fontSize': '14px'}),
#             html.Td(f"${float(row.get('amount', 0)):.2f}", style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'textAlign': 'right', 'fontWeight': 'bold', 'fontSize': '14px'}),
#             html.Td(row.get('cost_center_project', ''), style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'fontSize': '14px'}),
#             html.Td(row.get('cost_center_sow', ''), style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'fontSize': '14px'}),
#             html.Td(row.get('sow_number', ''), style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'fontSize': '14px'}),
#             html.Td(row.get('po', ''), style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'fontSize': '14px'}),
#             html.Td([
#                 html.Span(
#                     row.get('category', ''),
#                     style={
#                         'backgroundColor': '#007bff' if row.get('category') == 'Budget' 
#                                         else '#ffc107' if row.get('category') == 'Planned' 
#                                         else '#dc3545',
#                         'color': 'white' if row.get('category') in ['Budget', 'Consumed'] else '#212529',
#                         'padding': '4px 8px',
#                         'borderRadius': '12px',
#                         'fontSize': '12px',
#                         'fontWeight': '600'
#                     }
#                 )
#             ], style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'fontSize': '14px'}),
#             html.Td([
#                 html.Span(
#                     row.get('type', ''),
#                     style={
#                         'backgroundColor': '#28a745' if row.get('type') == 'OPEX' else '#6f42c1',
#                         'color': 'white',
#                         'padding': '4px 8px',
#                         'borderRadius': '12px',
#                         'fontSize': '12px',
#                         'fontWeight': '600'
#                     }
#                 )
#             ], style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'fontSize': '14px'}),
#             html.Td([
#                 html.Button(
#                     "✏️",
#                     id={'type': 'edit-btn', 'index': row.get('id')},
#                     title="Edit transaction",
#                     className="btn_bottom",
#                     style={
#                         'marginRight': '4px',
#                         'padding': '6px 8px',
#                         'fontSize': '12px',
#                         'minWidth': 'auto'
#                     }
#                 ),
#                 html.Button(
#                     "🗑️",
#                     id={'type': 'delete-btn', 'index': row.get('id')},
#                     title="Delete transaction",
#                     className="btn-bottom-sec",
#                     style={
#                         'padding': '6px 8px',
#                         'fontSize': '12px',
#                         'minWidth': 'auto',
#                         'backgroundColor': '#dc3545',
#                         'borderColor': '#dc3545'
#                     }
#                 )
#             ], style={'padding': '8px 12px', 'borderBottom': '1px solid #dee2e6', 'textAlign': 'center'})
#         ])

# # Refresh DataTable data with search
# @callback(
#     [Output('transactions-table-datatable', 'data'),
#      Output('transactions-table-filtered-data', 'data')],
#     [Input('transactions-table-datatable', 'id'),  # Trigger on component load
#      Input('add-transaction-btn', 'n_clicks'),
#      Input('transactions-table-confirm-delete', 'n_clicks'),
#      Input('transactions-table-search', 'value')],
#     [State('transactions-table-delete-store', 'data')],
#     prevent_initial_call=False
# )
# def refresh_transactions_datatable(datatable_id, add_clicks, delete_clicks, search_value, delete_store):
#     """Refresh DataTable data with search support"""
    
#     # Get all transactions
#     all_transactions = get_transactions()
#     filtered_transactions = []
#     if all_transactions:
#         # Format date to only show YYYY-MM-DD
#         for transaction in all_transactions:
#             date_val = transaction.get('date')
#             if isinstance(date_val, str) and 'T' in date_val:
#                 transaction['date'] = date_val.split('T')[0]
#         # Apply search filter if provided
#         if search_value and search_value.strip():
#             search_term = search_value.lower().strip()
#             for transaction in all_transactions:
#                 # Search across all string fields
#                 search_fields = [
#                     str(transaction.get('date', '')).lower(),
#                     str(transaction.get('description', '')).lower(),
#                     str(transaction.get('amount', '')).lower(),
#                     str(transaction.get('cost_center_project', '')).lower(),
#                     str(transaction.get('cost_center_sow', '')).lower(),
#                     str(transaction.get('sow_number', '')).lower(),
#                     str(transaction.get('po', '')).lower(),
#                     str(transaction.get('category', '')).lower(),
#                     str(transaction.get('type', '')).lower()
#                 ]
#                 if any(search_term in field for field in search_fields):
#                     filtered_transactions.append(transaction)
#         else:
#             filtered_transactions = all_transactions
#     return filtered_transactions, filtered_transactions

# # Handle edit button click for selected row
# @callback(
#     [Output('transactions-table-edit-modal', 'is_open'),
#      Output('transactions-table-edit-form', 'children'),
#      Output('transactions-table-edit-store', 'data')],
#     [Input('✏️ Edit Transaction', 'n_clicks'),
#      Input('transactions-table-cancel-edit', 'n_clicks'),
#      Input('transactions-table-save-edit', 'n_clicks')],
#     [State('transactions-table-datatable', 'selected_rows'),
#      State('transactions-table-datatable', 'data'),
#      State('transactions-table-edit-store', 'data'),
#      State('transactions-table-edit-modal', 'is_open')],
#     prevent_initial_call=True
# )
# def handle_edit_modal(edit_clicks, cancel_clicks, save_clicks, selected_rows, table_data, edit_store, is_open):
#     """Handle edit modal for selected transaction"""
    
#     trigger_id = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else ""
    
#     # Open edit modal
#     if trigger_id == '✏️ Edit Transaction' and selected_rows and len(selected_rows) > 0:
#         selected_idx = selected_rows[0]
#         if selected_idx < len(table_data):
#             transaction = table_data[selected_idx]
#             edit_form = create_edit_form(transaction)
#             return True, edit_form, transaction
    
#     # Close modal (cancel or save)
#     elif trigger_id in ['transactions-table-cancel-edit', 'transactions-table-save-edit']:
#         if trigger_id == 'transactions-table-save-edit' and edit_store:
#             # Save logic is handled by separate callback below
#             pass
#         return False, [], None
    
#     return is_open, [], edit_store

# # Handle saving edited transaction data
# @callback(
#     Output('transaction-message', 'children', allow_duplicate=True),  # Show save status message
#     [Input('transactions-table-save-edit', 'n_clicks')],
#     [State('edit-date-input', 'date'),
#      State('edit-description-input', 'value'),
#      State('edit-amount-input', 'value'),
#      State('edit-cost-center-project-input', 'value'),
#      State('edit-cost-center-sow-input', 'value'),
#      State('edit-sow-number-input', 'value'),
#      State('edit-po-number-input', 'value'),
#      State('edit-category-input', 'value'),
#      State('edit-type-input', 'value'),
#      State('transactions-table-edit-store', 'data')],
#     prevent_initial_call=True
# )
# def save_edited_transaction(save_clicks, date, description, amount, cost_center_project, 
#                           cost_center_sow, sow_number, po_number, category, type_val, edit_store):
#     """Save the edited transaction to database"""
    
#     if not save_clicks or not edit_store:
#         raise PreventUpdate
    
#     try:
#         # Get the original transaction ID
#         transaction_id = edit_store.get('id')
        
#         if not transaction_id:
#             return html.Div("❌ Error: No transaction ID found", 
#                           style={'color': 'red', 'marginTop': '10px'})
        
#         # Update the transaction in the database
#         from db_management.db import update_transaction
        
#         # Update in database using individual parameters
#         update_transaction(
#             transaction_id,
#             date,
#             description,
#             cost_center_project,
#             cost_center_sow,
#             sow_number,
#             po_number,
#             float(amount) if amount else 0.0,
#             category,
#             type_val
#         )
        
#         return html.Div("✅ Transaction updated successfully!", 
#                       style={'color': 'green', 'marginTop': '10px'})
            
#     except Exception as e:
#         print(f"Error saving edited transaction: {e}")
#         return html.Div(f"❌ Error: {str(e)}", 
#                       style={'color': 'red', 'marginTop': '10px'})

#     if 'edit-btn' in prop_id and any(edit_clicks):
#         import json
#         button_data = json.loads(prop_id.split('.')[0])
#         transaction_id = str(button_data['index'])
        
#         if transaction_id not in edit_rows:
#             edit_rows.append(transaction_id)
    
#     # Handle cancel button clicks
#     elif 'cancel-btn' in prop_id and any(cancel_clicks):
#         import json
#         button_data = json.loads(prop_id.split('.')[0])
#         transaction_id = str(button_data['index'])
        
#         if transaction_id in edit_rows:
#             edit_rows.remove(transaction_id)
    
#     # Regenerate table rows with updated edit state
#     if page_size is None:
#         page_size = 25
#     if page_size == -1:
#         page_size = len(filtered_data) if filtered_data else 1
#         current_page = 0
#     if current_page is None:
#         current_page = 0
    
#     start_idx = current_page * page_size
#     end_idx = start_idx + page_size
#     page_transactions = filtered_data[start_idx:end_idx] if filtered_data else []
    
#     table_rows = []
#     for row in page_transactions:
#         is_editing = str(row.get('id')) in edit_rows
#         table_rows.append(create_table_row(row, is_editing=is_editing))
    
#     return edit_rows, table_rows

# # Handle save button clicks (save inline edits)
# @callback(
#     [Output('transactions-table-edit-store', 'data', allow_duplicate=True),
#      Output('transaction-message', 'children', allow_duplicate=True)],
#     [Input({'type': 'save-btn', 'index': dash.ALL}, 'n_clicks')],
#     [State({'type': 'edit-date', 'index': dash.ALL}, 'date'),
#      State({'type': 'edit-amount', 'index': dash.ALL}, 'value'),
#      State({'type': 'edit-ccp', 'index': dash.ALL}, 'value'),
#      State({'type': 'edit-ccs', 'index': dash.ALL}, 'value'),
#      State({'type': 'edit-sow', 'index': dash.ALL}, 'value'),
#      State({'type': 'edit-po', 'index': dash.ALL}, 'value'),
#      State({'type': 'edit-category', 'index': dash.ALL}, 'value'),
#      State({'type': 'edit-type', 'index': dash.ALL}, 'value'),
#      State('transactions-table-edit-store', 'data')],
#     prevent_initial_call=True
# )
# def save_inline_edit(save_clicks, dates, amounts, ccps, ccss, sows, pos, categories, types, edit_store):
#     """Save inline edits to database"""
#     if not ctx.triggered or not any(save_clicks):
#         return edit_store or [], ""
    
#     # Find which save button was clicked
#     for i, clicks in enumerate(save_clicks):
#         if clicks:
#             import json
#             prop_id = ctx.triggered[0]['prop_id']
#             button_data = json.loads(prop_id.split('.')[0])
#             transaction_id = str(button_data['index'])
            
#             try:
#                 # Get values for this transaction
#                 date = dates[i] if i < len(dates) else None
#                 amount = amounts[i] if i < len(amounts) else None
#                 ccp = ccps[i] if i < len(ccps) else None
#                 ccs = ccss[i] if i < len(ccss) else None
#                 sow = sows[i] if i < len(sows) else None
#                 po = pos[i] if i < len(pos) else None
#                 category = categories[i] if i < len(categories) else None
#                 type_ = types[i] if i < len(types) else None
                
#                 # Validate required fields
#                 if not all([date, amount, ccp, ccs, sow, po, category, type_]):
#                     return edit_store, html.Div("Please fill all fields", style={'color': 'var(--color-text-error)'})
                
#                 # Update in database
#                 update_transaction(int(transaction_id), date, ccp, ccs, sow, po, float(amount), category, type_)
                
#                 # Remove from edit mode
#                 edit_rows = edit_store or []
#                 if transaction_id in edit_rows:
#                     edit_rows.remove(transaction_id)
                
#                 return edit_rows, html.Div("Transaction updated successfully!", style={'color': 'var(--color-text-success)'})
                
#             except Exception as e:
#                 return edit_store, html.Div(f"Error updating transaction: {str(e)}", style={'color': 'var(--color-text-error)'})
    
#     return edit_store or [], ""


# @callback(
#     Output("navbar-collapse", "is_open"),
#     [Input("navbar-toggler", "n_clicks")],
#     [State("navbar-collapse", "is_open")]
# )
# def toggle_navbar_collapse(n, is_open):
#     if n:
#         return not is_open
#     return is_open

# @callback(
#     Output('dashboard-content', 'children'),
#     [Input('year-selector', 'value'),
#      Input('view-type-selector', 'value')]
# )
# def update_dashboard_content(selected_year, selected_view_type):
#     """Update dashboard content when year selection or view type changes"""
#     if selected_year is None:
#         # Use current year as default
#         import pandas as pd
#         selected_year = pd.Timestamp.now().year
    
#     if selected_view_type is None:
#         selected_view_type = 'cumulative'
    
#     # Import here to avoid circular import and app instantiation issues
#     from pages.ai_financials import generate_dashboard_content
    
#     # Generate dashboard content for selected year and view type
#     return generate_dashboard_content(selected_year, selected_view_type)

# # Callback for year dropdown with transaction filters
# @callback(
#     Output('financial-bar-chart', 'figure'),
#     [Input('year-selector', 'value')]
# )
# def update_financial_chart(selected_year):
#     """Update financial bar chart with year selection"""
#     if selected_year is None:
#         selected_year = pd.Timestamp.now().year
    
#     # Get transaction data for the selected year
#     transactions_df = get_transactions_df()
    
#     if transactions_df.empty:
#         # Create empty figure
#         figure = px.bar(title=f"No transaction data available for {selected_year}")
#         return figure
    
#     # Ensure Date column is datetime
#     transactions_df['Date'] = pd.to_datetime(transactions_df['Date'])
    
#     # Filter by year
#     year_data = transactions_df[transactions_df['Date'].dt.year == selected_year]
    
#     if year_data.empty:
#         # Create empty figure for the selected year
#         figure = px.bar(title=f"No transaction data available for {selected_year}")
#         return figure
    
#     # Group by category and sum amounts
#     category_totals = year_data.groupby('Category')['Amount'].sum().reset_index()
    
#     # Create bar chart
#     figure = px.bar(category_totals, 
#                    x='Category', 
#                    y='Amount',
#                    title=f'Transaction Categories - {selected_year}',
#                    labels={'Amount': 'Total Amount ($)', 'Category': 'Transaction Category'})
    
#     figure.update_layout(
#         showlegend=False,
#         height=400,
#         margin=dict(t=50, b=50, l=50, r=50)
#     )
    
#     return figure

# # Callback for monthly analysis chart
# @callback(
#     Output('monthly-analysis-chart-graph', 'figure'),
#     [Input('year-selector', 'value')]
# )
# def update_monthly_chart(selected_year):
#     """Update monthly chart based on selected year"""
#     if selected_year is None:
#         selected_year = pd.Timestamp.now().year
    
#     # Get filtered transaction data
#     df = get_transactions_df()
#     if df.empty:
#         return px.bar(title='No transaction data available')
    
#     # Convert Date to datetime and filter by selected year
#     df['Date'] = pd.to_datetime(df['Date'])
#     df_filtered = df[df['Date'].dt.year == selected_year]
    
#     if df_filtered.empty:
#         return px.bar(title=f'No transaction data available for {selected_year}')
    
#     # Create year date range
#     year_start = pd.Timestamp(f'{selected_year}-01-01')
#     all_months = pd.date_range(start=year_start, end=pd.Timestamp(f'{selected_year}-12-01'), freq='MS')
#     month_index = [d.strftime('%Y-%m') for d in all_months]
#     month_labels = [d.strftime('%b') for d in all_months]
    
#     # Group by month and transaction type (Budget, X-charged, Consumed)
#     monthly_data = df_filtered.groupby([df_filtered['Date'].dt.strftime('%Y-%m'), 'Type'])['Amount'].sum().unstack(fill_value=0)
#     monthly_df = pd.DataFrame(index=month_index, columns=['Budget', 'X-charged', 'Consumed'], dtype=float).fillna(0.0)
    
#     if not monthly_data.empty:
#         for col in monthly_data.columns:
#             if col in monthly_df.columns:
#                 monthly_df[col] = monthly_data[col].reindex(month_index, fill_value=0.0)
    
#     # Ensure all values are numeric and fill any remaining NaN with 0
#     monthly_df = monthly_df.fillna(0.0)
    
#     # Create the figure
#     figure = px.bar(
#         monthly_df,
#         x=month_labels,
#         y=['Budget', 'X-charged', 'Consumed'],
#         title=f'Monthly Financial Analysis - {selected_year}',
#         labels={'value': 'Amount ($)', 'x': 'Month', 'variable': 'Type'},
#         barmode='group',
#         color_discrete_map={'Budget': '#2E86AB', 'X-charged': '#A23B72', 'Consumed': '#F18F01'}
#     )
    
#     figure.update_layout(
#         template='plotly_white',
#         title={'x': 0.5, 'xanchor': 'center'},
#         xaxis={'tickangle': 0},
#         yaxis={'tickformat': '$,.0f'},
#         height=400,  # Fixed height to match card
#         margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
#     )
    
#     return figure

# # === Overview Page Callbacks ===

# @callback(
#     Output('overview-content', 'children'),
#     [Input('overview-year-selector', 'value')]
# )
# def update_overview_content(selected_year):
#     """Update overview content when year selection changes"""
#     if selected_year is None:
#         # Use current year as default
#         import pandas as pd
#         selected_year = pd.Timestamp.now().year
    
#     # Import here to avoid circular import and app instantiation issues
#     from pages.overview import generate_overview_content
    
#     # Generate overview content for selected year
#     return generate_overview_content(selected_year)

# # All transaction management callbacks have been removed for the simplified form-only page
# # They can be re-added when full transaction management functionality is needed

# # === Transaction Form Callbacks ===
# from db_management.db import add_transaction

# # Add transaction callback
# @callback(
#     [Output('transaction-description', 'value'),
#      Output('transaction-amount', 'value'),
#      Output('transaction-cost-center-project', 'value'),
#      Output('transaction-cost-center-sow', 'value'),
#      Output('transaction-sow-number', 'value'),
#      Output('transaction-po-number', 'value'),
#      Output('transaction-category', 'value'),
#      Output('transaction-type', 'value'),
#      Output('transaction-project-bottom', 'value'),
#      Output('transaction-date', 'date'),
#      Output('transaction-message', 'children', allow_duplicate=True),
#      Output('transactions-table-datatable', 'data', allow_duplicate=True),
#      Output('selected-transaction-store', 'data', allow_duplicate=True),
#      Output('transactions-table-datatable', 'selected_rows', allow_duplicate=True),
#      Output('add-transaction-btn', 'children', allow_duplicate=True)],
#     [Input('add-transaction-btn', 'n_clicks')],
#     [State('transaction-description', 'value'),
#      State('transaction-amount', 'value'),
#      State('transaction-cost-center-project', 'value'),
#      State('transaction-cost-center-sow', 'value'),
#      State('transaction-sow-number', 'value'),
#      State('transaction-po-number', 'value'),
#      State('transaction-category', 'value'),
#      State('transaction-type', 'value'),
#      State('transaction-project-bottom', 'value'),
#      State('transaction-date', 'date'),
#      State('selected-transaction-store', 'data')],
#     prevent_initial_call=True
# )
# def handle_add_transaction(n_clicks, description, amount, cc_project, cc_sow, sow_number, po_number, category, type_, project_id, date, selected_transaction_id):
#     """Handle adding a new transaction or updating an existing one"""
#     if not n_clicks:
#         return ('', None, '', '', '', '', None, None, None, datetime.today().date(), "", 
#                 dash.no_update, dash.no_update, dash.no_update, 'Add Transaction')
#     # Check required fields (only description, amount, and date are truly required)
#     required_fields = [description, amount, date]
#     if not all(field for field in required_fields):
#         return (description, amount, cc_project, cc_sow, sow_number, po_number, category, type_, project_id, date,
#                 html.Div("Please fill in required fields: Description, Amount, and Date", 
#                        style={'color': 'var(--color-text-error)', 
#                               'backgroundColor': 'var(--color-surface-error-primary)',
#                               'padding': 'var(--spacing-8)',
#                               'borderRadius': 'var(--border-radius-small)',
#                               'border': '1px solid var(--color-stroke-error-primary)',
#                               'fontSize': 'var(--font-size-small)'}),
#                 dash.no_update, dash.no_update, [], 'Add Transaction'
#         )
#     try:
#         if selected_transaction_id:
#             update_transaction(selected_transaction_id, date, description, cc_project or '', cc_sow or '', sow_number or '', po_number or '', float(amount), category or '', type_ or '', project_id)
#             success_message = "Transaction updated successfully!"
#             updated_data = get_transactions()
#             # Find the updated row index
#             idx = None
#             for i, row in enumerate(updated_data):
#                 if str(row.get('id')) == str(selected_transaction_id):
#                     idx = i
#                     break
#             # After update, keep the form and selection as-is (do not clear anything)
#             return (
#                 description, amount, start_date, end_date, project_id, business_sponsor,
#                 html.Div(success_message, style={'color': 'green'}),
#                 updated_data, selected_transaction_id, [idx] if idx is not None else [], 'Update Transaction'
#             )
#         else:
#             add_transaction(date, description, cc_project or '', cc_sow or '', sow_number or '', po_number or '', float(amount), category or '', type_ or '', project_id)
#             success_message = "Transaction added successfully!"
#             updated_data = get_transactions()
#             # After add, clear the form and selection
#             return ('', None, '', '', '', '', html.Div(success_message, style={'color': 'green'}), updated_data, None, [], 'Add Transaction')
#     except Exception as e:
#         return (description, amount, cc_project, cc_sow, sow_number, po_number, category, type_, project_id, date,
#                 html.Div(f"Error: {str(e)}", style={'color': 'red'}), dash.no_update, dash.no_update, dash.no_update, 'Add Transaction'
#         )

# # Callback to change clear button text to "Duplicate" when a row is selected
# @callback(
#     Output('clear-form-btn', 'children'),
#     [Input('selected-transaction-store', 'data')],
#     prevent_initial_call=False
# )
# def update_clear_button_text(selected_transaction_id):
#     """Change button text to 'Duplicate' when a row is selected, otherwise 'Clear'."""
#     if selected_transaction_id is not None:
#         return 'Duplicate'
#     else:
#         return 'Clear'

# # Clear form callback - now handles duplicate functionality
# @callback(
#     [Output('transaction-description', 'value', allow_duplicate=True),
#      Output('transaction-amount', 'value', allow_duplicate=True),
#      Output('transaction-cost-center-project', 'value', allow_duplicate=True),
#      Output('transaction-cost-center-sow', 'value', allow_duplicate=True),
#      Output('transaction-sow-number', 'value', allow_duplicate=True),
#      Output('transaction-po-number', 'value', allow_duplicate=True),
#      Output('transaction-category', 'value', allow_duplicate=True),
#      Output('transaction-type', 'value', allow_duplicate=True),
#      Output('transaction-date', 'date', allow_duplicate=True),
#      Output('selected-transaction-store', 'data', allow_duplicate=True),
#      Output('add-transaction-btn', 'children', allow_duplicate=True)],
#     [Input('clear-form-btn', 'n_clicks')],
#     [State('selected-transaction-store', 'data'),
#      # Add current form values as State inputs for duplicate functionality
#      State('transaction-description', 'value'),
#      State('transaction-amount', 'value'),
#      State('transaction-cost-center-project', 'value'),
#      State('transaction-cost-center-sow', 'value'),
#      State('transaction-sow-number', 'value'),
#      State('transaction-po-number', 'value'),
#      State('transaction-category', 'value'),
#      State('transaction-type', 'value'),
#      State('transaction-date', 'date')],
#     prevent_initial_call=True
# )
# def clear_or_duplicate_transaction_form(n_clicks, selected_transaction_id, table_data, selected_rows,
#                                       current_description, current_amount,
#                                       current_ccp, current_ccs, current_sow, current_po,
#                                       current_category, current_type, current_date):
#     """Clear the form or preserve current form data for duplicating when clear/duplicate button is clicked."""
#     if n_clicks:
#      if selected_transaction_id is not None and selected_rows:
#          # In duplicate mode - preserve all current form data and completely reset for new transaction
#          # This ensures the form is ready to submit as a NEW transaction, not an update
#          return (
#           current_description or '',  # Keep current description
#           current_amount,             # Keep current amount
#           current_ccp or '',          # Keep current cost center project
#           current_ccs or '',          # Keep current cost center SOW
#           current_sow or '',          # Keep current SOW number
#           current_po or '',           # Keep current PO
#           current_category,           # Keep current category
#           current_type,               # Keep current type
#           current_date or datetime.today().date(),  # Keep current date
#           None,                       # IMPORTANT: Clear selection - this makes it a NEW transaction
#           'Add Transaction',          # Reset button text for new entry
#           [],                         # Clear table selection
#           dash.no_update,            # Don't update table data
#           html.Div("Form data preserved for new transaction", 
#               style={'color': 'var(--color-text-info)', 
#                   'backgroundColor': 'var(--color-surface-info-primary)',
#                   'padding': 'var(--spacing-8)',
#                   'borderRadius': 'var(--border-radius-small)',
#                   'border': '1px solid var(--color-stroke-info-primary)',
#                   'fontSize': 'var(--font-size-small)'}),  # Show info message
#          )
#      # In clear mode - clear the form completely
#      return ('', None, '', '', '', '', None, None, datetime.today().date(), 
#           None, 'Add Transaction', [], dash.no_update, 
#           html.Div("Form cleared", 
#               style={'color': 'var(--color-text-info)', 
#                   'backgroundColor': 'var(--color-surface-info-primary)',
#                   'padding': 'var(--spacing-8)',
#                   'borderRadius': 'var(--border-radius-small)',
#                   'border': '1px solid var(--color-stroke-info-primary)',
#                   'fontSize': 'var(--font-size-small)'}))
    
#     return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update


# # Callback to populate form when a table row is selected (with toggle functionality)
# @callback(
#     [Output('transaction-description', 'value', allow_duplicate=True),
#      Output('transaction-amount', 'value', allow_duplicate=True),
#      Output('transaction-cost-center-project', 'value', allow_duplicate=True),
#      Output('transaction-cost-center-sow', 'value', allow_duplicate=True),
#      Output('transaction-sow-number', 'value', allow_duplicate=True),
#      Output('transaction-po-number', 'value', allow_duplicate=True),
#      Output('transaction-category', 'value', allow_duplicate=True),
#      Output('transaction-type', 'value', allow_duplicate=True),
#      Output('transaction-date', 'date', allow_duplicate=True),
#      Output('selected-transaction-store', 'data', allow_duplicate=True),
#      Output('add-transaction-btn', 'children', allow_duplicate=True)],
#     [Input('transactions-table-datatable', 'selected_rows')],
#     [State('transactions-table-datatable', 'data'),
#      State('selected-transaction-store', 'data'),
#      State('clear-form-btn', 'n_clicks')],  # Add clear button clicks as state to detect duplicate action
#     prevent_initial_call=True
# )
# def populate_form_from_selected_row(selected_rows, table_data, current_selected_id, clear_btn_clicks):
#     """Populate the form when a table row is selected, with toggle deselection"""
    
#     # Only clear form if user explicitly deselected rows by clicking on the table
#     # Don't clear if rows were cleared programmatically (e.g., by duplicate function)
#     if not selected_rows or not table_data:
#         # Only return no_update to prevent clearing form data that was just set by duplicate
#         # Return 13 values to match the 13 outputs
#         return (dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, 
#                 dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, 
#                 'Add Transaction', [], dash.no_update)
    
#     # Get the selected row data
#     selected_idx = selected_rows[0]
#     if selected_idx >= len(table_data):
#         return (dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, 
#                 dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, 
#                 'Add Transaction', [], dash.no_update)
        
#     row_data = table_data[selected_idx]
#     selected_transaction_id = row_data.get('id', None)
    
#     # Check if clicking the same row again (toggle deselection)
#     if current_selected_id == selected_transaction_id:
#         # Deselect: clear form and reset button
#         return ('', None, '', '', '', '', None, None, datetime.today().date(), 
#                 None, 'Add Transaction', [], dash.no_update)
    
#     # Convert date string to date object if needed
#     date_value = row_data.get('date', datetime.today().date())
#     if isinstance(date_value, str):
#         try:
#             date_value = datetime.strptime(date_value, '%Y-%m-%d').date()
#         except:
#             date_value = datetime.today().date()
    
#     # Return the row data to populate the form
#     return (
#         row_data.get('description', ''),
#         row_data.get('amount', None),
#         row_data.get('cost_center_project', ''),
#         row_data.get('cost_center_sow', ''),
#         row_data.get('sow_number', ''),
#         row_data.get('po', ''),
#         row_data.get('category', None),
#         row_data.get('type', None),
#         date_value,
#         selected_transaction_id,  # Store the transaction ID for editing
#         'Update Transaction',  # Change button text
#         selected_rows,  # Keep the selection
#         dash.no_update  # Don't update table data
#     )


# # Callback to toggle delete button visibility without recreating the form
# @callback(
#     Output('delete-btn-wrapper', 'style'),
#     [Input('selected-transaction-store', 'data')],
#     prevent_initial_call=False
# )
# def toggle_delete_button_visibility(selected_transaction_id):
#     """Show/hide delete button based on selection state."""
#     if selected_transaction_id is not None:
#         return {'opacity': '1', 'pointerEvents': 'auto'}
#     else:
#         return {'opacity': '0', 'pointerEvents': 'none'}


# # ====================================================
# # Handle transaction deletion confirmation
# # ====================================================
# @callback(
#     [Output('transaction-description', 'value', allow_duplicate=True),
#      Output('transaction-amount', 'value', allow_duplicate=True),
#      Output('transaction-cost-center-project', 'value', allow_duplicate=True),
#      Output('transaction-cost-center-sow', 'value', allow_duplicate=True),
#      Output('transaction-sow-number', 'value', allow_duplicate=True),
#      Output('transaction-po-number', 'value', allow_duplicate=True),
#      Output('transaction-category', 'value', allow_duplicate=True),
#      Output('transaction-type', 'value', allow_duplicate=True),
#      Output('transaction-date', 'date', allow_duplicate=True),
#      Output('selected-transaction-store', 'data', allow_duplicate=True),
#      Output('add-transaction-btn', 'children', allow_duplicate=True),
#      Output('transactions-table-datatable', 'selected_rows', allow_duplicate=True),
#      Output('transactions-table-datatable', 'data', allow_duplicate=True),
#      Output('transaction-message', 'children', allow_duplicate=True)],
#     [Input('transactions-table-confirm-delete', 'n_clicks')],
#     [State('transactions-table-delete-store', 'data')],
#     prevent_initial_call=True
# )
# def confirm_delete_transaction(confirm_clicks, delete_store):
#     """Delete the transaction when confirmed in modal"""
#     if confirm_clicks and delete_store:
#         try:
#             # Extract transaction ID from delete_store
#             transaction_id = delete_store['id'] if isinstance(delete_store, dict) and 'id' in delete_store else delete_store
#             delete_transaction(transaction_id)
#             # Refresh transaction data
#             updated_transactions = get_transactions()
#             # Create display copies with formatted dates
#             display_transactions = []
#             for transaction in updated_transactions:
#                 display_transaction = transaction.copy()
#                 date_val = display_transaction.get('date')
#                 if isinstance(date_val, str) and 'T' in date_val:
#                     display_transaction['date'] = date_val.split('T')[0]
#                 display_transactions.append(display_transaction)
            
#             message = dbc.Alert(
#                 f"✅ Transaction deleted successfully!",
#                 color="success",
#                 duration=3000,
#                 dismissable=True
#             )
#             # Clear form and reset state
#             return ('', None, '', '', '', '', None, None, datetime.today().date(), 
#                     None, 'Add Transaction', [], display_transactions, message)
#         except Exception as e:
#             message = dbc.Alert(
#                 f"❌ Error deleting transaction: {str(e)}",
#                 color="danger",
#                 duration=5000,
#                 dismissable=True
#             )
#             # Return current state with error message
#             return (dash.no_update, dash.no_update, dash.no_update, dash.no_update, 
#                     dash.no_update, dash.no_update, dash.no_update, dash.no_update, 
#                     dash.no_update, dash.no_update, dash.no_update, dash.no_update, 
#                     dash.no_update, message)
#     return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

# # ====================================================
# # PROJECTS CALLBACKS (mirroring transaction logic)
# # ====================================================



# # Refresh DataTable data with search for projects
# @callback(
#     [Output('projects-table-datatable', 'data'),
#      Output('projects-table-filtered-data', 'data')],
#     [Input('projects-table-datatable', 'id'),  # Trigger on component load
#      Input('add-project-btn', 'n_clicks'),
#      Input('projects-table-confirm-delete', 'n_clicks'),
#      Input('projects-table-search', 'value')],
#     [State('projects-table-delete-store', 'data')],
#     prevent_initial_call=False
# )

# # Handle edit button click for selected project row
# @callback(
#     [Output('projects-table-edit-modal', 'is_open'),
#      Output('projects-table-edit-form', 'children'),
#      Output('projects-table-edit-store', 'data')],
#     [Input('edit-project-btn', 'n_clicks'),
#      Input('projects-table-cancel-edit', 'n_clicks'),
#      Input('projects-table-save-edit', 'n_clicks')],
#     [State('projects-table-datatable', 'selected_rows'),
#      State('projects-table-datatable', 'data'),
#      State('projects-table-edit-store', 'data')],
#     prevent_initial_call=True
# )

# def create_project_edit_form(project):
#     """Create edit form components for the project modal"""
#     return html.Div([
#         html.Div([
#             html.Label("Title:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-project-title-input',
#                 type='text',
#                 value=project.get('title'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Description:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             html.Textarea(
#                 id='edit-project-description-input',
#                 value=project.get('description'),
#                 style={'width': '100%', 'height': '80px', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Potential Value:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-project-potential-value-input',
#                 type='number',
#                 value=project.get('potential_value'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Realized Value YTD:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-project-realized-value-input',
#                 type='number',
#                 value=project.get('realized_value'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Start Date:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.DatePickerSingle(
#                 id='edit-project-start-date-input',
#                 date=project.get('start_date'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("End Date:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.DatePickerSingle(
#                 id='edit-project-end-date-input',
#                 date=project.get('end_date'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Program:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-project-program-input',
#                 type='text',
#                 value=project.get('program'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Owner:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-project-owner-input',
#                 type='text',
#                 value=project.get('owner'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ]),
#         html.Div([
#             html.Label("Maturity:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
#             dcc.Input(
#                 id='edit-project-maturity-input',
#                 type='text',
#                 value=project.get('maturity'),
#                 style={'width': '100%', 'marginBottom': '15px'}
#             )
#         ])
#     ])

# # Handle delete button click for selected project row
# @callback(
#     [Output('programs-table-delete-modal', 'is_open'),
#      Output('programs-table-delete-info', 'children'),
#      Output('programs-table-delete-store', 'data')],
#     [Input('delete-program-btn', 'n_clicks'),
#      Input('programs-table-cancel-delete', 'n_clicks'),
#      Input('programs-table-confirm-delete', 'n_clicks')],
#     [State('programs-table-datatable', 'selected_rows'),
#      State('programs-table-datatable', 'data'),
#      State('programs-table-delete-store', 'data')],
#     prevent_initial_call=True
# )
# def handle_program_delete_modal(delete_clicks, cancel_clicks, confirm_clicks, selected_rows, table_data, delete_store):
#     """Handle delete modal for projects"""
    
#     # Determine which input triggered the callback
#     triggered_id = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else None
    
#     if triggered_id == 'delete-program-btn' and delete_clicks and selected_rows and table_data:
#         # Open delete modal
#         program = table_data[selected_rows[0]]
#         delete_info = html.Div([
#             html.P(f"Program: {program.get('name', 'Unknown')}"),
#             html.P(f"Description: {program.get('description', 'N/A')}")
#         ])
#         return True, delete_info, program
    
#     elif triggered_id == 'programs-table-cancel-delete' and cancel_clicks:
#         # Close delete modal without deleting
#         return False, [], None
    

#     elif triggered_id == 'programs-table-confirm-delete' and confirm_clicks and delete_store:
#         # Actually delete the program and close modal
#         try:
#             from db_management.project_db import delete_program
#             delete_program(delete_store['id'] if isinstance(delete_store, dict) and 'id' in delete_store else delete_store)
#             return False, [], None
#         except Exception as e:
#             return False, [html.Div(f"Error deleting program: {str(e)}")], None
    
#     return no_update, no_update, no_update

# # ============ ADDITIONAL TEAM TABLE CALLBACKS ============

# # Team Table Export CSV
# @callback(
#     Output('team-table-download-csv', 'data'),
#     [Input('team-table-export-csv', 'n_clicks')],
#     [State('team-table-datatable', 'data')],
#     prevent_initial_call=True
# )
# def export_team_table_csv(n_clicks, table_data):
#     """Export team table data to CSV"""
#     if not n_clicks or not table_data:
#         return no_update
#     import pandas as pd
#     df = pd.DataFrame(table_data)
#     csv_string = df.to_csv(index=False)
#     return dict(content=csv_string, filename="team_members_export.csv")

# # Team Table Search Callback
# @callback(
#     [Output('team-table-datatable', 'data', allow_duplicate=True)],
#     [Input('team-table-search', 'value')],
#     prevent_initial_call=True
# )
# def search_team_members(search_value):
#     """Filter team members based on search input"""
    
#     # Get all team members
#     from components.tables.team_table import get_team_members_data
#     all_team_members = get_team_members_data()
    
#     if not all_team_members:
#         return [[]]
    
#     if search_value and search_value.strip():
#         # Filter team members based on search
#         search_term = search_value.lower().strip()
#         filtered_team_members = []
#         for member in all_team_members:
#             # Search in name, email, role, department, status
#             searchable_text = f"{member.get('full_name', '')} {member.get('email', '')} {member.get('role', '')} {member.get('department', '')} {member.get('status', '')}".lower()
#             if search_term in searchable_text:
#                 filtered_team_members.append(member)
#         return [filtered_team_members]
#     else:
#         return [all_team_members]

# # Transactions Table Search Callback
# @callback(
#     [Output('transactions-table-datatable', 'data', allow_duplicate=True)],
#     [Input('transactions-table-search', 'value')],
#     prevent_initial_call=True
# )
# def search_transactions(search_value):
#     """Filter transactions based on search input"""
    
#     # Get all transactions
#     all_transactions = get_transactions()
    
#     if not all_transactions:
#         return [[]]
    
#     if search_value and search_value.strip():
#         # Filter transactions based on search
#         search_term = search_value.lower().strip()
#         filtered_transactions = []
#         for transaction in all_transactions:
#             # Search across all string fields
#             searchable_text = f"{transaction.get('date', '')} {transaction.get('description', '')} {transaction.get('amount', '')} {transaction.get('cost_center_project', '')} {transaction.get('cost_center_sow', '')} {transaction.get('sow_number', '')} {transaction.get('po', '')} {transaction.get('category', '')} {transaction.get('type', '')}".lower()
#             if search_term in searchable_text:
#                 filtered_transactions.append(transaction)
#         return [filtered_transactions]
#     else:
#         return [all_transactions]

# # Projects Table Search Callback

# # Programs Table Search Callback
# @callback(
#     [Output('programs-table-datatable', 'data', allow_duplicate=True)],
#     [Input('programs-table-search', 'value')],
#     prevent_initial_call=True
# )
# def search_programs(search_value):
#     """Filter programs based on search input"""
    
#     # Get all programs
#     from components.tables.programs_table import get_programs_data
#     all_programs = get_programs_data()
    
#     if not all_programs:
#         return [[]]
    
#     if search_value and search_value.strip():
#         # Filter programs based on search
#         search_term = search_value.lower().strip()
#         filtered_programs = []
#         for program in all_programs:
#             # Search across all string fields
#             searchable_text = f"{program.get('name', '')} {program.get('description', '')} {program.get('status', '')} {program.get('owner', '')}".lower()
#             if search_term in searchable_text:
#                 filtered_programs.append(program)
#         return [filtered_programs]
#     else:
#         return [all_programs]

# # Team Table Page Size Callback
# @callback(
#     Output('team-table-datatable', 'page_size'),
#     [Input('team-table-page-size-dropdown', 'value')]
# )
# def update_team_table_page_size(page_size):
#     """Update team table page size"""
#     return page_size or 15