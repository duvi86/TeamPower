"""
Program analytics component for dashboard visualizations
"""

import plotly.graph_objects as go
import plotly.express as px
from dash import html, dcc
import pandas as pd
import logging
from datetime import datetime, timedelta
from db_management.program_db import get_programs

logger = logging.getLogger(__name__)

def create_program_analytics(programs_data=None):
    """
    Create program analytics dashboard with charts and metrics
    
    Parameters:
    -----------
    programs_data : list, optional
        Programs data for analytics
        
    Returns:
    --------
    html.Div
        Complete analytics dashboard
    """
    try:
        # Get programs data if not provided
        if programs_data is None:
            programs_data = get_programs()
        
        if not programs_data:
            return html.Div([
                html.P("No programs data available for analytics", className="no-data-message")
            ], className="analytics-empty-state")
        
        # Create individual charts
        status_chart = create_status_distribution_chart(programs_data)
        budget_chart = create_budget_analysis_chart(programs_data)
        timeline_chart = create_timeline_chart(programs_data)
        owner_chart = create_owner_distribution_chart(programs_data)
        
        # Analytics grid
        analytics_grid = html.Div([
            html.Div([
                html.H4("Program Status Distribution", className="chart-title"),
                status_chart
            ], className="analytics-card"),
            
            html.Div([
                html.H4("Budget Analysis", className="chart-title"),
                budget_chart
            ], className="analytics-card"),
            
            html.Div([
                html.H4("Program Timeline", className="chart-title"),
                timeline_chart
            ], className="analytics-card"),
            
            html.Div([
                html.H4("Programs by Owner", className="chart-title"),
                owner_chart
            ], className="analytics-card")
        ], className="analytics-grid")
        
        return html.Div([
            html.H3("Program Analytics Dashboard", className="analytics-title"),
            analytics_grid
        ], className="program-analytics-container")
        
    except Exception as e:
        logger.error(f"Error creating program analytics: {e}")
        return html.Div([
            html.P("Error loading program analytics", className="error-message"),
            html.P(f"Details: {str(e)}", className="error-details")
        ], className="analytics-error")

def create_status_distribution_chart(programs_data):
    """Create program status distribution pie chart"""
    try:
        # Count programs by status
        status_counts = {}
        for program in programs_data:
            status = program.get('status', 'Unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
        
        if not status_counts:
            return html.P("No status data available", className="chart-no-data")
        
        # Create pie chart
        fig = px.pie(
            values=list(status_counts.values()),
            names=list(status_counts.keys()),
            title="",
            color_discrete_map={
                'Active': '#28a745',
                'Completed': '#17a2b8',
                'Planning': '#ffc107',
                'On Hold': '#6c757d',
                'Cancelled': '#dc3545'
            }
        )
        
        fig.update_layout(
            height=160,
            margin=dict(t=0, b=0, l=0, r=0),
            font=dict(size=10),
            showlegend=True,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=-0.2,
                xanchor="center",
                x=0.5,
                font=dict(size=9)
            )
        )
        
        return dcc.Graph(figure=fig, className="analytics-chart")
        
    except Exception as e:
        logger.error(f"Error creating status chart: {e}")
        return html.P("Error loading status chart", className="chart-error")

def create_budget_analysis_chart(programs_data):
    """Create budget analysis bar chart"""
    try:
        # Prepare budget data
        budget_data = []
        for program in programs_data:
            name = program.get('name', 'Unknown')[:15] + '...' if len(program.get('name', '')) > 15 else program.get('name', 'Unknown')
            budget = float(program.get('budget', 0))
            status = program.get('status', 'Unknown')
            budget_data.append({'name': name, 'budget': budget, 'status': status})
        
        if not budget_data:
            return html.P("No budget data available", className="chart-no-data")
        
        # Sort by budget descending
        budget_data.sort(key=lambda x: x['budget'], reverse=True)
        
        # Take top 10
        budget_data = budget_data[:10]
        
        df = pd.DataFrame(budget_data)
        
        # Create bar chart
        fig = px.bar(
            df,
            x='name',
            y='budget',
            color='status',
            title="",
            color_discrete_map={
                'Active': '#28a745',
                'Completed': '#17a2b8',
                'Planning': '#ffc107',
                'On Hold': '#6c757d',
                'Cancelled': '#dc3545'
            }
        )
        
        fig.update_layout(
            height=160,
            margin=dict(t=0, b=40, l=40, r=0),
            xaxis_title="",
            yaxis_title="Budget ($)",
            font=dict(size=9),
            xaxis=dict(tickangle=45),
            yaxis=dict(tickformat='$,.0f'),
            showlegend=False
        )
        
        return dcc.Graph(figure=fig, className="analytics-chart")
        
    except Exception as e:
        logger.error(f"Error creating budget chart: {e}")
        return html.P("Error loading budget chart", className="chart-error")

def create_timeline_chart(programs_data):
    """Create program timeline Gantt chart"""
    try:
        # Prepare timeline data
        timeline_data = []
        for program in programs_data:
            name = program.get('name', 'Unknown')
            start_date = program.get('start_date')
            end_date = program.get('end_date')
            status = program.get('status', 'Unknown')
            
            if start_date:
                try:
                    if isinstance(start_date, str):
                        start_date = datetime.strptime(start_date, '%Y-%m-%d')
                    
                    # Use end date or estimate if not provided
                    if end_date:
                        if isinstance(end_date, str):
                            end_date = datetime.strptime(end_date, '%Y-%m-%d')
                    else:
                        # Estimate 3 months if no end date
                        end_date = start_date + timedelta(days=90)
                    
                    timeline_data.append({
                        'Task': name[:20] + '...' if len(name) > 20 else name,
                        'Start': start_date,
                        'Finish': end_date,
                        'Status': status
                    })
                except:
                    continue
        
        if not timeline_data:
            return html.P("No timeline data available", className="chart-no-data")
        
        # Sort by start date
        timeline_data.sort(key=lambda x: x['Start'])
        
        # Take recent/current programs only
        timeline_data = timeline_data[:8]
        
        df = pd.DataFrame(timeline_data)
        
        # Create Gantt chart
        fig = px.timeline(
            df,
            x_start="Start",
            x_end="Finish",
            y="Task",
            color="Status",
            title="",
            color_discrete_map={
                'Active': '#28a745',
                'Completed': '#17a2b8',
                'Planning': '#ffc107',
                'On Hold': '#6c757d',
                'Cancelled': '#dc3545'
            }
        )
        
        fig.update_layout(
            height=160,
            margin=dict(t=0, b=20, l=100, r=0),
            font=dict(size=9),
            xaxis_title="",
            yaxis_title="",
            showlegend=False
        )
        
        return dcc.Graph(figure=fig, className="analytics-chart")
        
    except Exception as e:
        logger.error(f"Error creating timeline chart: {e}")
        return html.P("Error loading timeline chart", className="chart-error")

def create_owner_distribution_chart(programs_data):
    """Create programs by owner bar chart"""
    try:
        from db_management.team_member_db import get_team_member_by_id
        
        # Count programs by owner
        owner_counts = {}
        for program in programs_data:
            owner_id = program.get('owner_id')
            if owner_id:
                owner = get_team_member_by_id(owner_id)
                owner_name = owner.get('name', 'Unknown') if owner else 'Unknown'
            else:
                owner_name = 'Unassigned'
            
            owner_counts[owner_name] = owner_counts.get(owner_name, 0) + 1
        
        if not owner_counts:
            return html.P("No owner data available", className="chart-no-data")
        
        # Sort by count
        sorted_owners = sorted(owner_counts.items(), key=lambda x: x[1], reverse=True)
        
        df = pd.DataFrame(sorted_owners, columns=['Owner', 'Count'])
        
        # Create bar chart
        fig = px.bar(
            df,
            x='Owner',
            y='Count',
            title="",
            color_discrete_sequence=['#007bff']
        )
        
        fig.update_layout(
            height=160,
            margin=dict(t=0, b=40, l=40, r=0),
            xaxis_title="",
            yaxis_title="Programs",
            font=dict(size=9),
            xaxis=dict(tickangle=45),
            showlegend=False
        )
        
        return dcc.Graph(figure=fig, className="analytics-chart")
        
    except Exception as e:
        logger.error(f"Error creating owner chart: {e}")
        return html.P("Error loading owner chart", className="chart-error")

def get_program_kpis(programs_data):
    """Calculate key performance indicators for programs"""
    try:
        if not programs_data:
            return {}
        
        total_programs = len(programs_data)
        active_programs = len([p for p in programs_data if p.get('status') == 'Active'])
        completed_programs = len([p for p in programs_data if p.get('status') == 'Completed'])
        on_time_programs = 0  # Would need end date vs actual completion tracking
        
        total_budget = sum([float(p.get('budget', 0)) for p in programs_data if p.get('budget')])
        avg_budget = total_budget / total_programs if total_programs > 0 else 0
        
        # Calculate completion rate
        completed_or_active = active_programs + completed_programs
        completion_rate = (completed_programs / completed_or_active * 100) if completed_or_active > 0 else 0
        
        return {
            'total_programs': total_programs,
            'active_programs': active_programs,
            'completed_programs': completed_programs,
            'completion_rate': round(completion_rate, 1),
            'total_budget': total_budget,
            'avg_budget': avg_budget,
            'on_time_programs': on_time_programs
        }
        
    except Exception as e:
        logger.error(f"Error calculating program KPIs: {e}")
        return {}
