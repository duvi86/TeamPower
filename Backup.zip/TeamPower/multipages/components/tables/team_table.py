"""
Team table component for Dash applications.
Features: inline edit, delete, search, CSV export with built-in pagination.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_data_table import create_data_table

def get_team_members_data():
    """Get team members data from database or return sample data"""
    try:
        # Try to get data from database
        sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
        from db_management.team_member_db import get_team_members_with_details
        
        team_members = get_team_members_with_details()
        if team_members:
            # Convert database data to display format
            data = []
            for member in team_members:
                data.append({
                    'id': member.get('id'),
                    'full_name': member.get('name', ''),
                    'email': member.get('email', ''),
                    'role': member.get('role', ''),
                    'department': member.get('department', ''),
                    'manager': member.get('manager_name', ''),
                    'start_date': member.get('start_date', ''),
                    'end_date': member.get('end_date', ''),
                    'status': member.get('status', 'Active')
                })
            return data
        else:
            return []  # Return empty list instead of sample data
    except Exception as e:
        print(f"Error loading team members from database: {e}")
        return []  # Return empty list instead of sample data

def get_sample_team_data():
    """Sample team data for testing and fallback"""
    return [
        {
            'id': 1,
            'full_name': 'Sarah Johnson',
            'email': 'sarah.johnson@company.com',
            'role': 'Senior Project Manager',
            'department': 'IT',
            'manager': 'David Thompson',
            'start_date': '2023-01-15',
            'end_date': '',
            'status': 'Active'
        },
        {
            'id': 2,
            'full_name': 'Michael Chen',
            'email': 'michael.chen@company.com',
            'role': 'Tech Lead',
            'department': 'IT',
            'manager': 'Sarah Johnson',
            'start_date': '2023-02-01',
            'status': 'Active'
        },
        {
            'id': 3,
            'full_name': 'Emma Rodriguez',
            'email': 'emma.rodriguez@company.com',
            'role': 'Product Manager',
            'department': 'Product',
            'manager': 'David Thompson',
            'start_date': '2023-03-10',
            'status': 'Active'
        },
        {
            'id': 4,
            'full_name': 'David Thompson',
            'email': 'david.thompson@company.com',
            'role': 'Program Director',
            'department': 'IT',
            'manager': None,
            'start_date': '2022-01-01',
            'status': 'Active'
        },
        {
            'id': 5,
            'full_name': 'Lisa Park',
            'email': 'lisa.park@company.com',
            'role': 'Innovation Manager',
            'department': 'R&D',
            'manager': 'David Thompson',
            'start_date': '2023-04-01',
            'status': 'Active'
        }
    ]

def get_team_table_columns():
    """Define columns for team table"""
    return [
        {'name': 'Full Name', 'id': 'full_name', 'type': 'text'},
        {'name': 'Email', 'id': 'email', 'type': 'text'},
        {'name': 'Role', 'id': 'role', 'type': 'text'},
        {'name': 'Department', 'id': 'department', 'type': 'text'},
        {'name': 'Manager', 'id': 'manager', 'type': 'text'},
        {'name': 'Start Date', 'id': 'start_date', 'type': 'datetime'},
        {'name': 'End Date', 'id': 'end_date', 'type': 'datetime'},
        {'name': 'Status', 'id': 'status', 'type': 'text'}
    ]

def create_team_table():
    """Create the team members table component"""
    return create_data_table(
        data=get_team_members_data(),
        columns=get_team_table_columns(),
        id_prefix='team-table',
        search_placeholder="Search team members...",
        item_type='team member',
        include_modals=True
    )
