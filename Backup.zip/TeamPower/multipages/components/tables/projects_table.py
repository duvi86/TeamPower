"""
Reusable project table component for Dash, using central CSS and modular utilities.
Features: inline edit, delete, search, CSV export with built-in pagination. DB via db_management.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_data_table import create_data_table, get_standard_table_columns

def get_projects_data():
    """Get projects data from database or return sample data"""
    try:
        # Try to get data from database
        sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
        from db_management.project_db import get_projects
        
        projects = get_projects()
        if projects:
            # Convert database data to display format
            data = []
            for project in projects:
                data.append({
                    'id': project.get('id'),  # Include ID for editing
                    'title': project.get('name', ''),
                    'description': project.get('description', ''),
                    'potential_value': project.get('potential_value', 0),
                    'budget': project.get('budget', 0),
                    'start_date': project.get('start_date', ''),
                    'end_date': project.get('end_date', ''),
                    'program': project.get('program_name', ''),  # Use program_name from join
                    'program_id': project.get('program_id', None),  # Include program_id for form population
                    'owner': project.get('owner_name', ''),  # Use owner_name from join
                    'owner_id': project.get('owner_id', None),  # Include owner_id for form population
                    'maturity': project.get('maturity', 'Unknown'),
                    'status': project.get('status', 'Planning')  # Add status field
                })
            return data
        else:
            return []  # Return empty list instead of sample data
    except Exception as e:
        print(f"Error loading projects from database: {e}")
        return []  # Return empty list instead of sample data

def get_sample_projects_data():
    """Get sample projects data for display"""
    sample_data = [
        {
            'id': 1,  # Add ID for sample data
            'title': 'AI-Powered Analytics Platform',
            'description': 'Building machine learning capabilities for predictive analytics',
            'potential_value': 3500000,
            'budget': 450000,
            'start_date': '2024-01-15',
            'end_date': '2024-12-31',
            'program': 'DIP',
            'owner': 'sarah.johnson',
            'maturity': 'PoV',
            'status': 'Active'
        },
        {
            'id': 2,
            'title': 'Digital Transformation Initiative',
            'description': 'Modernizing legacy systems and implementing cloud-based solutions',
            'potential_value': 5000000,
            'budget': 1200000,
            'start_date': '2024-03-01',
            'end_date': '2025-06-30',
            'program': 'TMP',
            'owner': 'michael.chen',
            'maturity': 'Scaling',
            'status': 'Active'
        },
        {
            'id': 3,
            'title': 'Customer Experience Optimization',
            'description': 'Improving customer journey and satisfaction metrics',
            'potential_value': 1500000,
            'budget': 125000,
            'start_date': '2024-02-10',
            'end_date': '2024-10-15',
            'program': 'CEP',
            'owner': 'emma.rodriguez',
            'maturity': 'Design',
            'status': 'Planning'
        },
        {
            'id': 4,
            'title': 'Mobile App Development',
            'description': 'Creating a comprehensive mobile application for customer engagement',
            'potential_value': 2200000,
            'budget': 750000,
            'start_date': '2024-01-20',
            'end_date': '2024-08-30',
            'program': 'DIP',
            'owner': 'david.thompson',
            'maturity': 'PoC',
            'status': 'Active'
        },
        {
            'id': 5,
            'title': 'Process Automation Suite',
            'description': 'Automating manual business processes to improve efficiency',
            'potential_value': 800000,
            'budget': 300000,
            'start_date': '2023-11-01',
            'end_date': '2024-04-30',
            'program': 'OEP',
            'owner': 'lisa.park',
            'maturity': 'Live',
            'status': 'Completed'
        }
    ]
    return sample_data

def create_projects_table(data=None, id_prefix="projects-table"):
    """
    Create a managed projects table with edit/delete/search/export features using generic DataTable.
    Args:
        data: List of dicts (project records)
        id_prefix: Prefix for component IDs (for multi-table support)
    Returns:
        Dash html.Div containing the DataTable and controls
    """
    
    if data is None:
        data = get_projects_data()
    
    # Get standard project columns
    columns = get_standard_table_columns('projects')
    # Replace 'Realized Value' column with 'Budget ($)'
    for col in columns:
        if col.get('id') == 'realized_value':
            col['id'] = 'budget'
            col['name'] = 'Budget ($)'
    
    # Use the generic data table component
    return create_data_table(
        data=data,
        columns=columns,
        id_prefix=id_prefix,
        search_placeholder="Search projects...",
        item_type="project",
        include_modals=True
    )
