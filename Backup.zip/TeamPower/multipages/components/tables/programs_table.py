"""
Programs table component for Dash applications.
Features: inline edit, delete, search, CSV export with built-in pagination.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_data_table import create_data_table

def get_programs_data():
    """Get programs data from database or return sample data"""
    try:
        sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
        from db_management.program_db import get_programs_with_computed_budget

        programs = get_programs_with_computed_budget()
        data = []
        from datetime import datetime
        def only_date(val):
            if isinstance(val, str) and val:
                try:
                    return datetime.strptime(val, "%Y-%m-%d").date().isoformat()
                except Exception:
                    return val.split(" ")[0] if " " in val else val
            return val
        for program in programs:
            data.append({
                'id': program.get('id'),
                'name': program.get('name', ''),
                'description': program.get('description', ''),
                'start_date': only_date(program.get('start_date', '')),
                'end_date': only_date(program.get('end_date', '')),
                'status': program.get('status', 'Planning'),
                'budget': program.get('budget', 0),
                'owner': program.get('owner', ''),
                'created_at': only_date(program.get('created_at', '')),
                'updated_at': only_date(program.get('updated_at', ''))
            })
        return data
    except Exception as e:
        print(f"Error loading programs from database: {e}")
        return []

def get_sample_programs_data():
    """Get sample programs data for display"""
    sample_data = [
        {
            'id': 1,
            'name': 'Digital Innovation Program',
            'description': 'Comprehensive digital transformation initiative focusing on AI and automation',
            'start_date': '2024-01-01',
            'end_date': '2024-12-31',
            'status': 'Active',
            'budget': 5000000,
            'owner': 'sarah.johnson',
            'created_at': '2024-01-01',
            'updated_at': '2024-01-15'
        },
        {
            'id': 2,
            'name': 'Technology Modernization Program',
            'description': 'Legacy system modernization and cloud migration program',
            'start_date': '2024-03-01',
            'end_date': '2025-02-28',
            'status': 'Active',
            'budget': 8000000,
            'owner': 'michael.chen',
            'created_at': '2024-02-15',
            'updated_at': '2024-03-01'
        },
        {
            'id': 3,
            'name': 'Customer Experience Program',
            'description': 'End-to-end customer journey optimization and experience enhancement',
            'start_date': '2024-02-01',
            'end_date': '2024-11-30',
            'status': 'Planning',
            'budget': 3000000,
            'owner': 'emma.rodriguez',
            'created_at': '2024-01-20',
            'updated_at': '2024-02-01'
        },
        {
            'id': 4,
            'name': 'Operational Excellence Program',
            'description': 'Process optimization and efficiency improvement across all operations',
            'start_date': '2023-10-01',
            'end_date': '2024-09-30',
            'status': 'Completed',
            'budget': 2500000,
            'owner': 'david.thompson',
            'created_at': '2023-09-15',
            'updated_at': '2024-09-30'
        },
        {
            'id': 5,
            'name': 'Strategic Planning Program',
            'description': 'Long-term strategic planning and roadmap development initiative',
            'start_date': '2024-04-01',
            'end_date': '2024-08-31',
            'status': 'On Hold',
            'budget': 1500000,
            'owner': 'lisa.park',
            'created_at': '2024-03-15',
            'updated_at': '2024-05-01'
        }
    ]
    return sample_data

def get_programs_table_columns():
    """Get column definitions for programs table"""
    return [
        {"name": "Name", "id": "name", "type": "text", "presentation": "markdown"},
        {"name": "Description", "id": "description", "type": "text", "presentation": "markdown"},
        {"name": "Start Date", "id": "start_date", "type": "datetime"},
        {"name": "End Date", "id": "end_date", "type": "datetime"},
        {"name": "Status", "id": "status", "type": "text"},
        {"name": "Budget", "id": "budget", "type": "numeric", "format": {"specifier": "$,.0f"}},
        {"name": "Owner", "id": "owner", "type": "text"},
    ]

def create_programs_table(data=None, id_prefix="programs-table"):
    """
    Create a managed programs table with edit/delete/search/export features.
    
    Args:
        data: List of dicts (program records)
        id_prefix: Prefix for component IDs (for multi-table support)
    
    Returns:
        Dash html.Div containing the DataTable and controls
    """
    
    if data is None:
        data = get_programs_data()
    
    # Get program-specific columns
    columns = get_programs_table_columns()
    
    # Use the generic data table component
    return create_data_table(
        data=data,
        columns=columns,
        id_prefix=id_prefix,
        search_placeholder="Search programs...",
        item_type="program",
        include_modals=True
    )
