"""
Reusable transaction table component for Dash, using central CSS and modular utilities.
Features: inline edit, delete, search, CSV export with built-in pagination. DB via db_management.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_data_table import create_data_table, get_standard_table_columns


def create_transactions_table(data, id_prefix="transactions-table"):
    """
    Create a managed transactions table with edit/delete/search/export features using generic DataTable.
    Args:
        data: List of dicts (transaction records)
        id_prefix: Prefix for component IDs (for multi-table support)
    Returns:
        Dash html.Div containing the DataTable and controls
    """
    
    # Get standard transaction columns
    columns = get_standard_table_columns('transactions')
    
    # Use the generic data table component
    return create_data_table(
        data=data,
        columns=columns,
        id_prefix=id_prefix,
        search_placeholder="Search transactions...",
        item_type="transaction",
        include_modals=True
    )
