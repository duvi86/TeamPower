"""
Value Tracking table component for Dash applications.
Features: inline edit, delete, search, CSV export with built-in pagination.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_data_table import create_data_table, get_standard_table_columns

def get_value_tracking_data():
    """Get value tracking data from database or return sample data"""
    try:
        sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
        from db_management.db import get_value_tracking_records

        value_tracking = get_value_tracking_records()
        data = []
        for record in value_tracking:
            data.append({
                'id': record.get('id', ''),  # Include the ID field for row selection
                'description': record.get('description', ''),
                'amount': record.get('amount', 0),
                'start_date': record.get('start_date', ''),
                'end_date': record.get('end_date', ''),
                'project_name': record.get('project_name', ''),
                'project_id': record.get('project_id', ''),
                'business_sponsor': record.get('business_sponsor', '')
            })
        return data
    except Exception as e:
        print(f"Error loading value tracking from database: {e}")
        return get_sample_value_tracking_data()

def get_sample_value_tracking_data():
    """Get sample value tracking data for display"""
    sample_data = [
        {
            'id': 1,  # Include sample IDs
            'description': 'Cost savings from process automation',
            'amount': 150000,
            'start_date': '2024-01-15',
            'end_date': '2024-06-15',
            'project_name': 'Digital Innovation Project',
            'business_sponsor': 'Sarah Johnson',
        },
        {
            'id': 2,  # Include sample IDs
            'description': 'Revenue increase from new AI features',
            'amount': 300000,
            'start_date': '2024-02-20',
            'end_date': '2024-08-20',
            'project_name': 'AI Enhancement Project',
            'business_sponsor': 'Michael Chen',
        },
        {
            'id': 3,  # Include sample IDs
            'description': 'Efficiency gains from system modernization',
            'amount': 200000,
            'start_date': '2024-03-10',
            'end_date': '2024-09-10',
            'project_name': 'System Modernization Project',
            'business_sponsor': 'Emma Rodriguez',
        },
        {
            'id': 4,  # Include sample IDs
            'description': 'Customer satisfaction improvement value',
            'amount': 125000,
            'start_date': '2024-03-25',
            'end_date': '2024-07-25',
            'project_name': 'Customer Experience Project',
            'business_sponsor': 'David Thompson',
        },
        {
            'id': 5,  # Include sample IDs
            'description': 'Risk mitigation value from security upgrade',
            'amount': 75000,
            'start_date': '2024-04-05',
            'end_date': '2024-10-05',
            'project_name': 'Security Enhancement Project',
            'business_sponsor': 'Lisa Park',
        }
    ]
    return sample_data

def get_value_tracking_table_columns():
    """Get column definitions for value tracking table"""
    return [
        {"name": "Description", "id": "description", "type": "text", "presentation": "markdown"},
        {"name": "Amount", "id": "amount", "type": "numeric", "format": {"specifier": "$,.0f"}},
        {"name": "Start Date", "id": "start_date", "type": "datetime"},
        {"name": "End Date", "id": "end_date", "type": "datetime"},
        {"name": "Project", "id": "project_name", "type": "text"},
        {"name": "Business Sponsor", "id": "business_sponsor", "type": "text"},
    ]

def create_value_tracking_table(data=None):
    """
    Create a managed value tracking table with edit/delete/search/export features.
    
    Args:
        data: List of dicts (value tracking records)
    
    Returns:
        Dash html.Div containing the DataTable and controls
    """
    
    if data is None:
        data = get_value_tracking_data()

    # Get value tracking columns matching DB schema
    columns = get_value_tracking_table_columns()

    # Use the generic data table component with id_prefix only
    return create_data_table(
        data=data,
        columns=columns,
        id_prefix='value-tracker-table',
        search_placeholder="Search value tracking records...",
        item_type="value record",
        include_modals=True
    )
