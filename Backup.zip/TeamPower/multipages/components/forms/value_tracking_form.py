"""
Value Tracking Form Component
Creates and manages the value tracking creation/editing form with all required fields
"""

import dash
from dash import html, dcc
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_form_components import (
	create_form_field, create_form_input, create_form_dropdown, 
	create_form_datepicker
)
from utils.create_button import create_button, create_button_group
from utils.form_data_options import get_projects_options
from datetime import datetime

def create_value_tracking_form(selected=False, value_tracking_data=None, id_prefix="value-tracker"):
	"""Create a value tracking form component using GSK design system utilities
    
	Args:
		selected (bool): If True, a row is selected and delete button will be shown
		value_tracking_data: Dict containing value tracking data for editing
		id_prefix: Prefix for component IDs to avoid conflicts
	"""
    
	# Set default values
	if value_tracking_data:
		description_value = value_tracking_data.get('description', '')
		amount_value = value_tracking_data.get('amount', '')
		start_date_value = value_tracking_data.get('start_date')
		end_date_value = value_tracking_data.get('end_date')
		project_value = value_tracking_data.get('project_id')
		business_sponsor_value = value_tracking_data.get('business_sponsor', '')
	else:
		description_value = ''
		amount_value = ''
		start_date_value = None
		end_date_value = None
		project_value = None
		business_sponsor_value = ''
    
	# Row 1: Description (full width)
	description_field = create_form_field(
		label="Description",
		component=create_form_input(
			input_id=f'{id_prefix}-description',
			input_type='text',
			placeholder='Enter value tracking description',
			value=description_value,
			required=True
		),
		required=True
	)
    
	# Row 2: Start Date and End Date (2-column)
	date_row = html.Div([
		html.Div([
			create_form_field(
				label="Start Date",
				component=create_form_datepicker(
					datepicker_id=f'{id_prefix}-start-date',
					default_date=start_date_value,
					placeholder='Select start date',
					style={'width': '100%'}
				),
				required=True
			)
		], style={'flex': '1'}),
		html.Div([
			create_form_field(
				label="End Date",
				component=create_form_datepicker(
					datepicker_id=f'{id_prefix}-end-date',
					default_date=end_date_value,
					placeholder='Select end date',
					style={'width': '100%'}
				),
				required=True
			)
		], style={'flex': '1'})
	], style={'display': 'flex', 'gap': '0.75rem'})

	# Row 3: Amount and Business Sponsor (2-column)
	amount_sponsor_row = html.Div([
		html.Div([
			create_form_field(
				label="Amount ($)",
				component=create_form_input(
					input_id=f'{id_prefix}-amount',
					input_type='number',
					placeholder='Enter amount',
					value=amount_value,
					required=True,
					step=0.01,
					min=0
				),
				required=True
			)
		], style={'flex': '1'}),
		html.Div([
			create_form_field(
				label="Business Sponsor",
				component=create_form_input(
					input_id=f'{id_prefix}-business-sponsor',
					input_type='text',
					placeholder='Enter business sponsor name',
					value=business_sponsor_value,
					required=True
				),
				required=True
			)
		], style={'flex': '1'})
	], style={'display': 'flex', 'gap': '0.75rem'})

	# Row 4: Project (full width)
	project_field = create_form_field(
		label="Project",
		component=create_form_dropdown(
			dropdown_id=f'{id_prefix}-project',
			options=get_projects_options(),
			value=project_value,
			placeholder='Select project',
			required=True
		),
		required=True
	)
    
	# Create button list with wrapper for delete button to maintain consistent sizing
	button_list = [
		create_button(
			id=f'{id_prefix}-add-btn',
			text='Add Value Record' if not selected else 'Update Value Record',
			button_type='primary'  # Primary surface style
		),
		create_button(
			id=f'{id_prefix}-clear-form-btn',
			text='Clear',
			button_type='secondary'  # Accent style for clear
		),
		html.Div([  # Wrapper div for opacity control without affecting button styling
			create_button(
				id=f'{id_prefix}-delete-btn',
				text='Delete',
				button_type='accent'  # Standard danger styling for consistent sizing
			)
		], id=f'{id_prefix}-delete-btn-wrapper', style={
			'opacity': '0' if not selected else '1',
			'pointerEvents': 'none' if not selected else 'auto'
		})
	]

	buttons = create_button_group(button_list, alignment='left')

	# Return compact form with reduced spacing
	return html.Div([
		# Hidden store to track selected value tracking ID for editing
		dcc.Store(id=f'{id_prefix}-selected-store', data=None),
		description_field,
		date_row,
		amount_sponsor_row,
		project_field,
		buttons,
		html.Div(id=f'{id_prefix}-message', style={'marginTop': '0.5rem'})
	], style={'display': 'flex', 'flexDirection': 'column', 'gap': '0.75rem'})

def get_value_tracking_form_data(
	description, amount, start_date, end_date, project_id, business_sponsor
):
	"""
	Helper function to structure value tracking form data
    
	Returns:
		Dict containing structured value tracking data
	"""
	return {
		'description': description,
		'amount': amount,
		'start_date': start_date,
		'end_date': end_date,
		'project_id': project_id,
		'business_sponsor': business_sponsor
	}
