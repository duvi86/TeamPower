import dash
from dash import html, dcc
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_form_components import (
    create_form_field, create_form_input, create_form_dropdown, 
    create_form_datepicker, create_form_container
)
from utils.create_button import create_button, create_button_group
from utils.form_data_options import (
    get_program_options, get_team_members_options, 
    get_project_status_options, get_maturity_options
)
from datetime import datetime

def create_project_form(selected=False, id_prefix="projects-table"):
    """Create a project form component using GSK design system utilities
    Args:
        selected (bool): If True, a row is selected and delete button will be shown
        id_prefix (str): Prefix for all component IDs (default 'project')
    """

    def idf(suffix):
        return f"{id_prefix}-{suffix}"

    # Row 1: Project Title (full width)
    title_field = create_form_field(
        label="Project Title",
        component=create_form_input(
            input_id=idf('title'),
            input_type='text',
            placeholder='Enter project title',
            required=True
        ),
        required=True
    )

    # Row 2: Description (full width)
    from dash import dcc
    description_field = create_form_field(
        label="Description",
        component=dcc.Textarea(
            id=idf('description'),
            placeholder='Enter project description',
            style={
                'width': '100%',
                'height': '100px',  # Increased height for better visibility
                'padding': '12px',
                'border': '1px solid var(--color-stroke-primary)',
                'borderRadius': 'var(--border-radius-medium)',
                'backgroundColor': 'var(--color-surface-secondary)',
                'color': 'var(--color-text-default)',
                'fontFamily': 'inherit',
                'fontSize': '14px',
                'resize': 'vertical',
                'lineHeight': '1.4'
            },
            value=""
        )
    )

    # Row 3: Potential Value (full width)
    value_row = html.Div([
        html.Div([
            create_form_field(
                label="Potential Value ($)",
                component=create_form_input(
                    input_id=idf('potential-value'),
                    input_type='number',
                    placeholder='0.00',
                    step=0.01,
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})

    # Row 4: Start Date and End Date (2-column)
    date_row = html.Div([
        html.Div([
            create_form_field(
                label="Start Date",
                component=create_form_datepicker(
                    datepicker_id=idf('start-date'),
                    placeholder='Select start date',
                    style={'width': '100%'}
                )
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="End Date",
                component=create_form_datepicker(
                    datepicker_id=idf('end-date'),
                    placeholder='Select end date',
                    style={'width': '100%'}
                )
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})

    # Row 5: Program Linked and Project Owner (2-column)
    from db_management.program_db import get_programs
    from utils.form_data_options import get_tech_leads_options
    # Dynamically fetch program options from the database
    program_options = [
        {'label': p['name'], 'value': p['id']} for p in get_programs()
    ]
    # Get tech leads only for project owners
    tech_lead_options = get_tech_leads_options()
    owner_program_row = html.Div([
        html.Div([
            create_form_field(
                label="Program Linked",
                component=create_form_dropdown(
                    dropdown_id=idf('program'),
                    options=program_options,
                    placeholder='Select program',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Project Owner",
                component=create_form_dropdown(
                    dropdown_id=idf('owner'),
                    options=tech_lead_options,
                    placeholder='Select project owner (Tech Lead or Program Manager)',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})

    # Row 6: Project Maturity and Status (2-column)
    maturity_status_row = html.Div([
        html.Div([
            create_form_field(
                label="Project Maturity",
                component=create_form_dropdown(
                    dropdown_id=idf('maturity'),
                    options=get_maturity_options(),
                    placeholder='Select project maturity',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Project Status",
                component=create_form_dropdown(
                    dropdown_id=idf('status'),
                    options=get_project_status_options(),
                    placeholder='Select project status',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})

    # Create button list with wrapper for delete button to maintain consistent sizing
    button_list = [
        create_button(
            id=idf('add-btn'),
            text='Add Project',
            button_type='primary'  # Primary surface style
        ),
        create_button(
            id=idf('clear-form-btn'),
            text='Clear',
            button_type='secondary'  # Accent style for clear
        ),
        html.Div([  # Wrapper div for opacity control without affecting button styling
            create_button(
                id=idf('delete-btn'),
                text='Delete',
                button_type='accent'  # Standard danger styling for consistent sizing
            )
        ], id=idf('delete-btn-wrapper'), style={
            'opacity': '0' if not selected else '1',
            'pointerEvents': 'none' if not selected else 'auto'
        })
    ]

    buttons = create_button_group(button_list, alignment='left')

    # Return compact form with reduced spacing
    return html.Div([
        # Hidden store to track selected project ID for editing
        dcc.Store(id=idf('selected-store'), data=None),
        title_field,
        description_field,
        value_row,
        date_row,
        owner_program_row,
        maturity_status_row,  # Updated to use the new 2-column row
        buttons,
        html.Div(id=idf('message'), style={'marginTop': '0.5rem'})
    ], style={'display': 'flex', 'flexDirection': 'column', 'gap': '0.75rem'})
