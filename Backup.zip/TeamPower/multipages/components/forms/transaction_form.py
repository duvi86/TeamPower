import dash
from dash import html, dcc
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_form_components import (
    create_form_field, create_form_input, create_form_dropdown, 
    create_form_datepicker, create_form_container
)
from utils.create_button import create_button, create_button_group
from utils.form_data_options import (
    get_transaction_category_options, get_transaction_type_options, get_projects_options
)
from datetime import datetime

def create_transaction_form(selected=False):
    """Create a compact transaction form component using GSK design system utilities
    
    Args:
        selected (bool): If True, a row is selected and delete button will be shown
    """
    
    # Row 1: Description (full width)
    description_field = create_form_field(
        label="Description",
        component=create_form_input(
            input_id='transaction-description',
            input_type='text',
            placeholder='Enter transaction description',
            required=True
        ),
        required=True
    )
    
    # Row 2: Amount and Date (same row)
    amount_date_row = html.Div([
        html.Div([
            create_form_field(
                label="Amount ($)",
                component=create_form_input(
                    input_id='transaction-amount',
                    input_type='number',
                    placeholder='0.00',
                    step=0.01,
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Date",
                component=create_form_datepicker(
                    datepicker_id='transaction-date',
                    default_date=datetime.today(),
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Row 3: Project dropdown, Cost Center Project and SOW (3-column)
    cost_center_row = html.Div([
        
        html.Div([
            create_form_field(
                label="Cost Center Project",
                component=create_form_input(
                    input_id='transaction-cost-center-project',
                    input_type='text',
                    placeholder='CC-PROJ-001',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Cost Center SOW",
                component=create_form_input(
                    input_id='transaction-cost-center-sow',
                    input_type='text',
                    placeholder='CC-SOW-001',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Row 4: SOW Number and PO Number (2-column)
    sow_po_row = html.Div([
        html.Div([
            create_form_field(
                label="SOW Number",
                component=create_form_input(
                    input_id='transaction-sow-number',
                    input_type='text',
                    placeholder='SOW-2025-001',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="PO Number",
                component=create_form_input(
                    input_id='transaction-po-number',
                    input_type='text',
                    placeholder='PO-2025-001',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Row 5: Category, Type, and Project (3-column, no currency)
    category_type_project_row = html.Div([
        html.Div([
            create_form_field(
                label="Category",
                component=create_form_dropdown(
                    dropdown_id='transaction-category',
                    options=get_transaction_category_options(),
                    placeholder='Category',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Type",
                component=create_form_dropdown(
                    dropdown_id='transaction-type',
                    options=get_transaction_type_options(),
                    placeholder='Type',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Project",
                component=create_form_dropdown(
                    dropdown_id='transaction-project-bottom',
                    options=get_projects_options(),
                    placeholder='Select Project',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Create button list with wrapper for delete button to maintain consistent sizing
    button_list = [
        create_button(
            id='add-transaction-btn',
            text='Add Transaction',
            button_type='primary'  # Primary surface style
        ),
        create_button(
            id='clear-form-btn',
            text='Clear',
            button_type='secondary'  # Accent style for clear
        ),
        html.Div([  # Wrapper div for opacity control without affecting button styling
            create_button(
                id='delete-form-btn',
                text='Delete',
                button_type='accent'  # Standard danger styling for consistent sizing
            )
        ], id='delete-btn-wrapper', style={
            'opacity': '0' if not selected else '1',
            'pointerEvents': 'none' if not selected else 'auto'
        })
    ]
    
    buttons = create_button_group(button_list, alignment='left')
    
    # Return compact form with reduced spacing
    return html.Div([
        # Hidden store to track selected transaction ID for editing
        dcc.Store(id='selected-transaction-store', data=None),
        description_field,
        amount_date_row,
        cost_center_row,
        sow_po_row,
        category_type_project_row,
        buttons,
        html.Div(id='transaction-message', style={'marginTop': '0.5rem'})
    ], style={'display': 'flex', 'flexDirection': 'column', 'gap': '0.75rem'})
