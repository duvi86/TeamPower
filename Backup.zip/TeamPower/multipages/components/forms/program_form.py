"""
Program Form Component
Creates and manages the program creation/editing form with all required fields
"""

import dash
from dash import html, dcc
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_form_components import (
    create_form_field, create_form_input, create_form_dropdown, 
    create_form_datepicker, create_form_container
)
from utils.create_button import create_button, create_button_group
from utils.form_data_options import get_program_status_options, get_tech_leads_options
from datetime import datetime

def create_program_form(selected=False, program_data=None, id_prefix="programs-table"):
    """Create a program form component using GSK design system utilities
    
    Args:
        selected (bool): If True, a row is selected and delete button will be shown
        program_data: Dict containing program data for editing
        id_prefix: Prefix for component IDs to avoid conflicts
    """
    
    # Set default values
    if program_data:
        name_value = program_data.get('name', '')
        description_value = program_data.get('description', '')
        start_date_value = program_data.get('start_date')
        end_date_value = program_data.get('end_date')
        status_value = program_data.get('status', 'Planning')
        owner_value = program_data.get('owner_id')
    else:
        name_value = ''
        description_value = ''
        start_date_value = None
        end_date_value = None
        status_value = 'Planning'
        owner_value = None
    
    # Row 1: Program Name (full width)
    name_field = create_form_field(
        label="Program Name",
        component=create_form_input(
            input_id=f'{id_prefix}-name',
            input_type='text',
            placeholder='Enter program name',
            value=name_value,
            required=True
        ),
        required=True
    )
    
    # Row 2: Description (full width)
    description_field = create_form_field(
        label="Description",
        component=dcc.Textarea(
            id=f'{id_prefix}-description',
            placeholder='Enter program description',
            value=description_value if description_value else '',
            style={
                'width': '100%',
                'height': '100px',  # Increased height for better visibility
                'padding': '12px',
                'border': '1px solid var(--color-stroke-primary)',
                'borderRadius': 'var(--border-radius-medium)',
                'backgroundColor': 'var(--color-surface-secondary)',
                'color': 'var(--color-text-default)',
                'fontFamily': 'inherit',
                'fontSize': '14px',
                'resize': 'vertical',
                'lineHeight': '1.4'
            }
        )
    )
    
    # Row 3: Start Date and End Date (2-column)
    date_row = html.Div([
        html.Div([
            create_form_field(
                label="Start Date",
                component=create_form_datepicker(
                    datepicker_id=f'{id_prefix}-start-date',
                    default_date=start_date_value,
                    placeholder='Select start date',
                    style={'width': '100%'}
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="End Date",
                component=create_form_datepicker(
                    datepicker_id=f'{id_prefix}-end-date',
                    default_date=end_date_value,
                    placeholder='Select end date',
                    style={'width': '100%'}
                )
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Row 4: Status (full width)
    status_field = create_form_field(
        label="Status",
        component=create_form_dropdown(
            dropdown_id=f'{id_prefix}-status',
            options=get_program_status_options(),
            value=status_value,
            placeholder='Select status',
            required=True
        ),
        required=True
    )
    # Row 5: Program Owner (on same row as status)
    status_owner_row = html.Div([
        html.Div([status_field], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Program Owner",
                component=create_form_dropdown(
                    dropdown_id=f'{id_prefix}-owner',
                    options=get_tech_leads_options(),
                    value=owner_value,
                    placeholder='Select Program Owner'
                )
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Create button list with wrapper for delete button to maintain consistent sizing
    button_list = [
        create_button(
            id=f'add-{id_prefix}-btn',
            text='Add Program' if not selected else 'Update Program',
            button_type='primary'  # Primary surface style
        ),
        create_button(
            id=f'clear-{id_prefix}-form-btn',
            text='Clear',
            button_type='secondary'  # Accent style for clear
        ),
        html.Div([  # Wrapper div for opacity control without affecting button styling
            create_button(
                id=f'delete-{id_prefix}-btn',
                text='Delete',
                button_type='accent'  # Standard danger styling for consistent sizing
            )
        ], id=f'delete-{id_prefix}-btn-wrapper', style={
            'opacity': '0' if not selected else '1',
            'pointerEvents': 'none' if not selected else 'auto'
        })
    ]
    
    buttons = create_button_group(button_list, alignment='left')
    
    # Return compact form with reduced spacing
    return html.Div([
        # Hidden store to track selected program ID for editing
        dcc.Store(id=f'selected-{id_prefix}-store', data=None),
        name_field,
        description_field,
        date_row,
        status_owner_row,
        buttons,
        html.Div(id=f'{id_prefix}-message', style={'marginTop': '0.5rem'})
    ], style={'display': 'flex', 'flexDirection': 'column', 'gap': '0.75rem'})

def get_program_form_data(
    name, description, start_date, end_date, 
    status, owner_id
):
    """
    Helper function to structure program form data
    Department is automatically handled in the backend based on owner_id
    Budget is computed from reporting projects and not manually entered
    
    Returns:
        Dict containing structured program data
    """
    return {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': 0,  # Budget is computed, not manually entered
        'owner_id': owner_id
    }
