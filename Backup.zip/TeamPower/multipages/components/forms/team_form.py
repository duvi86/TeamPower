import dash
from dash import html, dcc
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from utils.create_form_components import (
    create_form_field, create_form_input, create_form_dropdown, 
    create_form_datepicker, create_form_container
)
from utils.create_button import create_button, create_button_group
from utils.form_data_options import get_team_members_options, get_programs_options, get_projects_options
from datetime import datetime
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
from db_management.team_member_db import get_team_members_with_details

def get_team_member_status_options():
    """Get team member status dropdown options"""
    return [
        {"label": "Active", "value": "Active"},
        {"label": "On Leave", "value": "On Leave"},
        {"label": "Inactive", "value": "Inactive"}
    ]

def get_role_options():
    """Get role dropdown options with only the predefined AI roles"""
    roles = [
        "AI Director",
        "Tech Lead",
        "AI Model Engineer",
        "AI Soft. Engineer",
        "Program Manager",
        "Product Owner",
        "Product Manager"
    ]
    return [{"label": role, "value": role} for role in roles]

def get_department_options():
    """Get department dropdown options with only the predefined AI departments"""
    departments = [
        "Digital Twins",
        "Vision",
        "GenAI",
        "Decision Sciences",
        "AI Services"
    ]
    return [{"label": dept, "value": dept} for dept in departments]

def create_team_form(selected=False):
    """Create a team member form component using GSK design system utilities
    
    Args:
        selected (bool): If True, a row is selected and delete button will be shown
    """
    
    # Row 1: Full Name (full width)
    name_field = create_form_field(
        label="Full Name",
        component=create_form_input(
            input_id='team-full-name',
            input_type='text',
            placeholder='Enter full name',
            required=True
        ),
        required=True
    )
    
    # Row 2: Email (full width)
    email_field = create_form_field(
        label="Email",
        component=create_form_input(
            input_id='team-email',
            input_type='email',
            placeholder='Enter email address',
            required=True
        ),
        required=True
    )
    
    # Row 3: Role and Department (2-column)
    role_department_row = html.Div([
        html.Div([
            create_form_field(
                label="Role",
                component=create_form_dropdown(
                    dropdown_id='team-role',
                    options=get_role_options(),
                    placeholder='Select role',
                    required=True,
                    value="AI Model Engineer"
                ),
                required=True
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Department",
                component=create_form_dropdown(
                    dropdown_id='team-department',
                    options=get_department_options(),
                    placeholder='Select department',
                    required=True,
                    value="Digital Twins"
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Row 4: Manager and Status (2-column)
    from db_management.team_member_db import get_team_members

    # Always fetch the latest team members when rendering the form
    team_members = get_team_members()
    team_member_options = [
        {'label': m['name'], 'value': m['id']} for m in team_members
    ]
    manager_status_row = html.Div([
        html.Div([
            create_form_field(
                label="Manager",
                component=create_form_dropdown(
                    dropdown_id='team-manager',
                    options=team_member_options,
                    placeholder='Select manager',
                    required=False
                )
            )
        ], style={'flex': '1'}),
        html.Div([
            create_form_field(
                label="Status",
                component=create_form_dropdown(
                    dropdown_id='team-status',
                    options=get_team_member_status_options(),
                    placeholder='Select status',
                    required=True
                ),
                required=True
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    

    # Row 5: Start Date and End Date (side by side)
    date_row = html.Div([
        html.Div([
            create_form_field(
                label="Start Date",
                component=create_form_datepicker(
                    datepicker_id='team-start-date',
                    default_date=datetime.today(),  # Start date defaults to today
                    placeholder='Select start date',
                    style={'width': '100%'}
                )
            )
        ], style={'flex': '1', 'marginRight': '0.75rem'}),
        html.Div([
            create_form_field(
                label="End Date",
                component=create_form_datepicker(
                    datepicker_id='team-end-date',
                    default_date=None,  # End date starts empty
                    placeholder='Select end date',
                    style={'width': '100%'}
                )
            )
        ], style={'flex': '1'})
    ], style={'display': 'flex', 'gap': '0.75rem'})
    
    # Create button list with wrapper for delete button to maintain consistent sizing
    button_list = [
        create_button(
            id='add-team-member-btn',
            text='Add Team Member',
            button_type='primary'  # Primary surface style
        ),
        create_button(
            id='clear-team-form-btn',
            text='Clear',
            button_type='secondary'  # Accent style for clear
        ),
        html.Div([  # Wrapper div for opacity control without affecting button styling
            create_button(
                id='delete-team-member-btn',
                text='Delete',
                button_type='accent'  # Standard danger styling for consistent sizing
            )
        ], id='delete-team-member-btn-wrapper', style={
            'opacity': '0' if not selected else '1',
            'pointerEvents': 'none' if not selected else 'auto'
        })
    ]
    
    buttons = create_button_group(button_list, alignment='left')
    
    # Return compact form with reduced spacing
    return html.Div([
        # Hidden store to track selected team member ID for editing
        dcc.Store(id='selected-team-member-store', data=None),
        name_field,
        email_field,
        role_department_row,
        manager_status_row,
        date_row,
        buttons,
        html.Div(id='team-member-message', style={'marginTop': '0.5rem'})
    ], style={'display': 'flex', 'flexDirection': 'column', 'gap': '0.75rem'})
