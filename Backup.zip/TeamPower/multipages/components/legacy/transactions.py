"""
Transaction Management Components
Contains form, table and modal components for transaction management functionality
"""

import pandas as pd
from dash import html, dcc, dash_table, Input, Output, State, callback, no_update
from dash.exceptions import PreventUpdate
import dash_bootstrap_components as dbc
from datetime import datetime, date
import logging

# Configure logger
logger = logging.getLogger(__name__)

def transaction_form():
    """Create the transaction form component"""
    return html.Div([
        html.H2('Add Transaction', 
               style={'color': '#2C3E50',
                      'fontSize': '24px',
                      'fontWeight': '600',
                      'marginBottom': '20px'}),
        
        # Transaction Form
        html.Div([
            # Description field
            html.Div([
                html.Label('Description', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                dcc.Input(
                    id='transaction-description',
                    type='text',
                    placeholder='Enter transaction description',
                    style={
                        'width': '100%',
                        'padding': '10px',
                        'border': '1px solid #BDC3C7',
                        'borderRadius': '5px',
                        'fontSize': '14px'
                    }
                )
            ], style={'marginBottom': '15px'}),
            
            # Amount field
            html.Div([
                html.Label('Amount', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                dcc.Input(
                    id='transaction-amount',
                    type='number',
                    step=0.01,
                    placeholder='0.00',
                    style={
                        'width': '100%',
                        'padding': '10px',
                        'border': '1px solid #BDC3C7',
                        'borderRadius': '5px',
                        'fontSize': '14px'
                    }
                )
            ], style={'marginBottom': '15px'}),
            
            # Category dropdown
            html.Div([
                html.Label('Category', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                dcc.Dropdown(
                    id='transaction-category',
                    options=[
                        {'label': 'Revenue', 'value': 'Revenue'},
                        {'label': 'Expenses', 'value': 'Expenses'},
                        {'label': 'Investment', 'value': 'Investment'},
                        {'label': 'Operations', 'value': 'Operations'},
                        {'label': 'Marketing', 'value': 'Marketing'},
                        {'label': 'HR', 'value': 'HR'},
                        {'label': 'Technology', 'value': 'Technology'},
                        {'label': 'Other', 'value': 'Other'}
                    ],
                    placeholder='Select category',
                    style={'fontSize': '14px'}
                )
            ], style={'marginBottom': '15px'}),
            
            # Date picker
            html.Div([
                html.Label('Date', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                dcc.DatePickerSingle(
                    id='transaction-date',
                    date=date.today(),
                    display_format='YYYY-MM-DD',
                    style={'width': '100%'}
                )
            ], style={'marginBottom': '20px'}),
            
            # Submit button
            html.Button(
                'Add Transaction',
                id='add-transaction-btn',
                style={
                    'width': '100%',
                    'padding': '12px',
                    'backgroundColor': '#27AE60',
                    'color': 'white',
                    'border': 'none',
                    'borderRadius': '5px',
                    'fontSize': '16px',
                    'fontWeight': '600',
                    'cursor': 'pointer',
                    'transition': 'all 0.3s ease'
                }
            ),
            
            # Success/Error message
            html.Div(id='transaction-message', style={'marginTop': '15px'})
        ])
    ])


def create_transaction_table(data=None):
    """Create the transaction table component"""
    if data is None or len(data) == 0:
        return html.Div([
            html.P('No transactions found.', 
                  style={'textAlign': 'center', 
                         'color': '#7F8C8D',
                         'fontSize': '16px',
                         'marginTop': '40px'})
        ])
    
    # Convert data to DataFrame if it's not already
    if not isinstance(data, pd.DataFrame):
        df = pd.DataFrame(data)
    else:
        df = data.copy()
    
    # Ensure we have the required columns
    required_columns = ['id', 'description', 'amount', 'category', 'date']
    for col in required_columns:
        if col not in df.columns:
            if col == 'id':
                df['id'] = range(1, len(df) + 1)
            else:
                df[col] = ''
    
    # Format amount as currency
    if 'amount' in df.columns:
        df['amount_formatted'] = df['amount'].apply(lambda x: f"${x:,.2f}" if pd.notnull(x) else "$0.00")
    
    # Format date
    if 'date' in df.columns:
        df['date_formatted'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
    
    # Create table data
    table_data = []
    for _, row in df.iterrows():
        table_data.append({
            'id': row.get('id', ''),
            'description': row.get('description', ''),
            'amount': row.get('amount_formatted', row.get('amount', '')),
            'category': row.get('category', ''),
            'date': row.get('date_formatted', row.get('date', '')),
            'actions': row.get('id', '')  # Use id for actions
        })
    
    return dash_table.DataTable(
        id='transactions-table',
        data=table_data,
        columns=[
            {'name': 'ID', 'id': 'id', 'type': 'numeric', 'editable': False},
            {'name': 'Description', 'id': 'description', 'type': 'text', 'editable': False},
            {'name': 'Amount', 'id': 'amount', 'type': 'text', 'editable': False},
            {'name': 'Category', 'id': 'category', 'type': 'text', 'editable': False},
            {'name': 'Date', 'id': 'date', 'type': 'text', 'editable': False},
            {'name': 'Actions', 'id': 'actions', 'presentation': 'markdown', 'editable': False}
        ],
        style_cell={
            'textAlign': 'left',
            'padding': '12px',
            'fontFamily': 'Arial, sans-serif',
            'fontSize': '14px',
            'border': '1px solid #ECF0F1'
        },
        style_header={
            'backgroundColor': '#34495E',
            'color': 'white',
            'fontWeight': '600',
            'textAlign': 'center'
        },
        style_data={
            'backgroundColor': 'white',
            'color': '#2C3E50'
        },
        style_data_conditional=[
            {
                'if': {'row_index': 'odd'},
                'backgroundColor': '#F8F9FA'
            }
        ],
        page_action='native',
        sort_action='native',
        filter_action='native'
    )


def transaction_modals():
    """Create modal components for editing and deleting transactions"""
    return html.Div([
        # Edit Modal
        dbc.Modal([
            dbc.ModalHeader("Edit Transaction"),
            dbc.ModalBody([
                html.Div([
                    # Description field
                    html.Div([
                        html.Label('Description', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                        dcc.Input(
                            id='edit-transaction-description',
                            type='text',
                            placeholder='Enter transaction description',
                            style={
                                'width': '100%',
                                'padding': '10px',
                                'border': '1px solid #BDC3C7',
                                'borderRadius': '5px',
                                'fontSize': '14px'
                            }
                        )
                    ], style={'marginBottom': '15px'}),
                    
                    # Amount field
                    html.Div([
                        html.Label('Amount', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                        dcc.Input(
                            id='edit-transaction-amount',
                            type='number',
                            step=0.01,
                            placeholder='0.00',
                            style={
                                'width': '100%',
                                'padding': '10px',
                                'border': '1px solid #BDC3C7',
                                'borderRadius': '5px',
                                'fontSize': '14px'
                            }
                        )
                    ], style={'marginBottom': '15px'}),
                    
                    # Category dropdown
                    html.Div([
                        html.Label('Category', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                        dcc.Dropdown(
                            id='edit-transaction-category',
                            options=[
                                {'label': 'Revenue', 'value': 'Revenue'},
                                {'label': 'Expenses', 'value': 'Expenses'},
                                {'label': 'Investment', 'value': 'Investment'},
                                {'label': 'Operations', 'value': 'Operations'},
                                {'label': 'Marketing', 'value': 'Marketing'},
                                {'label': 'HR', 'value': 'HR'},
                                {'label': 'Technology', 'value': 'Technology'},
                                {'label': 'Other', 'value': 'Other'}
                            ],
                            placeholder='Select category',
                            style={'fontSize': '14px'}
                        )
                    ], style={'marginBottom': '15px'}),
                    
                    # Date picker
                    html.Div([
                        html.Label('Date', style={'fontWeight': '600', 'marginBottom': '5px', 'display': 'block'}),
                        dcc.DatePickerSingle(
                            id='edit-transaction-date',
                            date=date.today(),
                            display_format='YYYY-MM-DD',
                            style={'width': '100%'}
                        )
                    ], style={'marginBottom': '20px'}),
                ])
            ]),
            dbc.ModalFooter([
                dbc.Button("Save Changes", id="save-edit-transaction", color="success", style={'marginRight': '10px'}),
                dbc.Button("Cancel", id="cancel-edit-transaction", color="secondary")
            ])
        ], id="edit-transaction-modal", size="md"),
        
        # Delete Confirmation Modal
        dbc.Modal([
            dbc.ModalHeader("Confirm Delete"),
            dbc.ModalBody([
                html.P("Are you sure you want to delete this transaction? This action cannot be undone.",
                      style={'fontSize': '16px', 'textAlign': 'center'})
            ]),
            dbc.ModalFooter([
                dbc.Button("Delete", id="confirm-delete-transaction", color="danger", style={'marginRight': '10px'}),
                dbc.Button("Cancel", id="cancel-delete-transaction", color="secondary")
            ])
        ], id="delete-transaction-modal", size="sm"),
        
        # Success/Error Toast
        dbc.Toast([
            html.P(id="transaction-toast-message")
        ], id="transaction-toast", header="Transaction Update", is_open=False, dismissable=True, duration=4000)
    ])
