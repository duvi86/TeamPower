from dash import Input, Output, State, callback, html
import sys
sys.path.append('/Users/md395378/TeamPowerGSK/TeamPower')
sys.path.append('/Users/md395378/TeamPowerGSK/TeamPower/multipages')
from pages.ai_financials import generate_dashboard_content
import plotly.express as px
import pandas as pd
sys.path.append('/Users/md395378/TeamPowerGSK/TeamPower')
from utils.db import get_transactions_df

@callback(
    Output("navbar-collapse", "is_open"),
    [Input("navbar-toggler", "n_clicks")],
    [State("navbar-collapse", "is_open")]
)
def toggle_navbar_collapse(n, is_open):
    if n:
        return not is_open
    return is_open

@callback(
    Output('dashboard-content', 'children'),
    [Input('year-selector', 'value')]
)
def update_dashboard_content(selected_year):
    """Update dashboard content when year selection changes"""
    if selected_year is None:
        # Use current year as default
        import pandas as pd
        selected_year = pd.Timestamp.now().year
    
    return generate_dashboard_content(selected_year)

@callback(
    Output('monthly-analysis-chart-graph', 'figure'),
    [Input('monthly-category-selector', 'value'),
     Input('year-selector', 'value')]
)
def update_monthly_chart(selected_category, selected_year):
    """Update monthly chart based on selected category and year"""
    if selected_year is None:
        selected_year = pd.Timestamp.now().year
    if selected_category is None:
        selected_category = 'Consumed'
    
    # Get filtered transaction data
    df = get_transactions_df()
    if df.empty:
        return px.bar(title='No transaction data available')
    
    # Convert Date to datetime and filter by selected year
    df['Date'] = pd.to_datetime(df['Date'])
    df_filtered = df[df['Date'].dt.year == selected_year]
    
    if df_filtered.empty:
        return px.bar(title=f'No transaction data available for {selected_year}')
    
    # Create year date range
    year_start = pd.Timestamp(f'{selected_year}-01-01')
    all_months = pd.date_range(start=year_start, end=pd.Timestamp(f'{selected_year}-12-01'), freq='MS')
    month_index = [d.strftime('%Y-%m') for d in all_months]
    month_labels = [d.strftime('%b') for d in all_months]
    
    # Filter data by selected category
    cat_data = df_filtered[df_filtered['Category'] == selected_category]
    
    if not cat_data.empty:
        # Group by month and type (OPEX/CAPEX)
        monthly_cat = cat_data.groupby([cat_data['Date'].dt.strftime('%Y-%m'), 'Type'])['Amount'].sum().unstack(fill_value=0)
        monthly_df = pd.DataFrame(index=month_index, columns=['OPEX', 'CAPEX'], dtype=float).fillna(0.0)
        if not monthly_cat.empty:
            for col in monthly_cat.columns:
                if col in monthly_df.columns:
                    monthly_df[col] = monthly_cat[col].astype(float)
    else:
        monthly_df = pd.DataFrame(index=month_index, columns=['OPEX', 'CAPEX'], dtype=float).fillna(0.0)
    
    # Create the figure
    figure = px.bar(
        monthly_df,
        x=month_labels,
        y=['OPEX', 'CAPEX'],
        title=f'Monthly {selected_category} Distribution - {selected_year}',
        labels={'value': 'Amount ($)', 'x': 'Month', 'variable': 'Type'},
        barmode='stack'
    )
    
    figure.update_layout(
        template='plotly_white',
        title={'x': 0.5, 'xanchor': 'center'},
        xaxis={'tickangle': 0, 'title': 'Month'},
        yaxis={'tickformat': '$,.0f', 'title': 'Amount ($)'},
        margin={'t': 80, 'b': 40, 'l': 60, 'r': 20}
    )
    
    return figure

# Transactions page callbacks (commented out for simplified form-only page)
# @callback(
#     Output('transactions-content', 'children'),
#     [Input('transactions-year-selector', 'value'),
#      Input('transactions-type-selector', 'value')]
# )
# def update_transactions_content(selected_year, selected_type):
#     """Update transactions content when year or type selection changes"""
#     if selected_year is None:
#         # Use current year as default
#         selected_year = pd.Timestamp.now().year
#     if selected_type is None:
#         selected_type = 'All'
#     
#     return generate_transactions_content(selected_year, selected_type)


# Transaction Management Callbacks (commented out for simplified form-only page)
# from utils.db import add_transaction, update_transaction, delete_transaction, get_transactions
# from components.transactions import create_transaction_table
# from datetime import datetime
# import json

@callback(
    [Output('transaction-message', 'children'),
     Output('transactions-store', 'data'),
     Output('transaction-table-container', 'children'),
     Output('record-count', 'children')],
    [Input('add-transaction-btn', 'n_clicks')],
    [State('transaction-description', 'value'),
     State('transaction-amount', 'value'),
     State('transaction-category', 'value'),
     State('transaction-date', 'date')]
)
def handle_add_transaction(n_clicks, description, amount, category, date):
    """Handle adding new transaction"""
    if not n_clicks:
        transactions_data = get_transactions()
        table = create_transaction_table(transactions_data)
        count = len(transactions_data) if transactions_data else 0
        return "", transactions_data, table, str(count)
    
    # Validate inputs
    if not all([description, amount, category, date]):
        message = html.Div("Please fill in all fields", style={'color': 'red'})
        transactions_data = get_transactions()
        table = create_transaction_table(transactions_data)
        count = len(transactions_data) if transactions_data else 0
        return message, transactions_data, table, str(count)
    
    try:
        # Add transaction to database
        # Note: The add_transaction function expects specific parameters
        # We'll need to adapt this based on the actual database schema
        add_transaction(
            date=date,
            ccp='',  # Cost Center Project - you may want to add this field
            ccs='',  # Cost Center SOW - you may want to add this field  
            sow='',  # SOW Number - you may want to add this field
            po='',   # PO - you may want to add this field
            amount=amount,
            category=category,
            type_='Transaction'  # Default type
        )
        
        # Get updated data
        transactions_data = get_transactions()
        table = create_transaction_table(transactions_data)
        count = len(transactions_data) if transactions_data else 0
        
        success_message = html.Div("Transaction added successfully!", 
                                 style={'color': 'green', 'fontWeight': '600'})
        
        return success_message, transactions_data, table, str(count)
        
    except Exception as e:
        error_message = html.Div(f"Error adding transaction: {str(e)}", 
                               style={'color': 'red'})
        transactions_data = get_transactions()
        table = create_transaction_table(transactions_data)
        count = len(transactions_data) if transactions_data else 0
        return error_message, transactions_data, table, str(count)


@callback(
    Output('download-transactions-csv', 'data'),
    [Input('export-csv-btn', 'n_clicks')],
    [State('transactions-store', 'data')]
)
def export_transactions_csv(n_clicks, transactions_data):
    """Export transactions to CSV"""
    if not n_clicks or not transactions_data:
        return None
    
    try:
        import pandas as pd
        df = pd.DataFrame(transactions_data)
        
        # Format the CSV data
        csv_string = df.to_csv(index=False)
        
        return {
            'content': csv_string,
            'filename': f'transactions_{datetime.now().strftime("%Y%m%d")}.csv',
            'type': 'text/csv'
        }
    except Exception as e:
        return None


# Clear form after successful submission
@callback(
    [Output('transaction-description', 'value'),
     Output('transaction-amount', 'value'),
     Output('transaction-category', 'value'),
     Output('transaction-date', 'date')],
    [Input('transaction-message', 'children')]
)
def clear_form_on_success(message):
    """Clear form fields after successful submission"""
    if message and hasattr(message, 'children'):
        if isinstance(message.children, str) and 'successfully' in message.children:
            from datetime import date
            return "", None, None, date.today()
    return None, None, None, None