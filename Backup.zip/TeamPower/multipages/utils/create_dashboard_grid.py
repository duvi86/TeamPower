import dash_bootstrap_components as dbc
from dash import html
from utils.create_graph_card import create_graph_card
from utils.create_card import create_card

def create_dashboard_grid(items, grid_style=None):
    """
    Creates a responsive grid layout for dashboard items
    
    Parameters:
    -----------
    items : list of dicts
        Each dict contains:
        - type: 'graph' or 'card'
        - title: Title of the card/graph
        - id: Component ID
        - width: Column width (1-12)
        - For graphs:
            - figure: The plotly figure object
            - height: Height of the graph in px
        - For cards:
            - content: Content of the card (dash components)
            - color: Optional card color
    grid_style : dict, optional
        Additional styling for the grid container
        
    Returns:
    --------
    dbc.Container
        Container with responsive grid layout
    """
    if grid_style is None:
        grid_style = {'padding': '5px'}  # Reduced padding
        
    rows = []
    current_row = []
    current_width = 0
    
    for item in items:
        item_width = item.get('width', 4)
        
        # If adding this item exceeds 12 columns, start a new row
        if current_width + item_width > 12:
            rows.append(dbc.Row(current_row, className="mb-2"))  # Reduced margin
            current_row = []
            current_width = 0
        
        # Create the appropriate component based on type
        if item['type'] == 'graph':
            component = create_graph_card(
                id=item['id'],
                title=item['title'],
                figure=item['figure'],
                height=item.get('height', 380)  # Increased default height
            )
        else:  # card
            component = create_card(
                title=item['title'],
                content=item['content'],
                id=item['id'],
                color=item.get('color', None),
                height=item.get('height', 150),  # Explicit height for cards
                style={"overflow": "auto"}  # Allow scrolling in cards if needed
            )
            
        # Add component to the current row with reduced gutter
        current_row.append(dbc.Col(component, width=item_width, className="px-1"))  # Reduced horizontal padding
        current_width += item_width
    
    # Add any remaining items in the last row
    if current_row:
        rows.append(dbc.Row(current_row, className="mb-2"))  # Reduced margin
    
    return dbc.Container(rows, fluid=True, style=grid_style, className="px-1")
