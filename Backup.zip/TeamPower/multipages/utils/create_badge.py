"""Reusable badge component aligned with central CSS styling"""

import dash_bootstrap_components as dbc
from dash import html


def create_badge(text, color="primary", size="md", pill=True, className="", **kwargs):
    """
    Create a standardized badge component using Bootstrap classes from bootstrap-overrides.css.
    
    Args:
        text: Badge text content
        color: Bootstrap color variant (primary, secondary, success, warning, danger, info)
        size: Badge size (sm, md, lg) - handled by Bootstrap
        pill: Whether to use pill shape (rounded)
        className: Additional CSS classes
        **kwargs: Additional props for the Badge component
    """
    
    return dbc.Badge(
        text,
        color=color,  # Use Bootstrap color directly
        pill=pill,
        className=className,
        **kwargs
    )


def create_status_badge(status, size="sm"):
    """
    Create a status-specific badge using Bootstrap classes from bootstrap-overrides.css.
    
    Args:
        status: Employee status (Active, On Leave, Terminated, etc.)
        size: Badge size (sm, md, lg) - handled by Bootstrap
    """
    
    # Status to Bootstrap color mapping
    status_colors = {
        'Active': 'success',
        'On Leave': 'warning', 
        'Terminated': 'danger',
        'Inactive': 'danger'
    }
    
    # Get the appropriate Bootstrap color
    color = status_colors.get(status, 'success')
    
    return create_badge(
        text=status,
        color=color,
        pill=True
    )


def create_count_badge(count, label="", color="primary"):
    """
    Create a count badge for displaying numerical values using Bootstrap classes.
    
    Args:
        count (int): Numerical count
        label (str): Optional label to include
        color (str): Bootstrap color variant (primary, secondary, success, etc.)
        
    Returns:
        dbc.Badge: Styled count badge using Bootstrap classes
    """
    
    # Format the display text
    display_text = f"{count} {label}".strip() if label else str(count)
    
    return create_badge(
        text=display_text,
        color=color,
        pill=True
    )
