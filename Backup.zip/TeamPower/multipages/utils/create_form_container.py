"""
Form container utility for GSK Design System
Creates styled form containers
"""

from dash import html

def create_form_container(children, title=None, max_width='500px'):
    """
    Create a styled form container
    
    Parameters:
    -----------
    children : list
        Form field components
    title : str, optional
        Form title
    max_width : str
        Maximum width of the form
        
    Returns:
    --------
    html.Div
        Styled form container
    """
    form_content = []
    
    if title:
        form_content.append(
            html.H2(title, className="form-container-title")
        )
    
    form_content.extend(children)
    
    # Add width class based on max_width parameter
    width_class = "form-container-wide" if max_width != '500px' else "form-container-standard"
    
    return html.Div(form_content, className=f"form-container {width_class}")
