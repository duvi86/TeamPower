"""
Form data and options utilities
Centralized place for form dropdown options and data configurations
"""
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from db_management.team_member_db import get_team_members
from db_management.program_db import get_programs
from db_management.project_db import get_projects

def get_transaction_category_options():
    """
    Get standardized transaction category options (Expenditure Classification)
    
    Returns:
    --------
    list
        List of category option dictionaries
    """
    return [
        {"label": "OPEX", "value": "OPEX"},
        {"label": "CAPEX", "value": "CAPEX"}
    ]

def get_transaction_type_options():
    """
    Get standardized transaction type options (Budget/Financial Status)
    
    Returns:
    --------
    list
        List of type option dictionaries
    """
    return [
        {"label": "Budget", "value": "Budget"},
        {"label": "X-charged", "value": "X-charged"},
        {"label": "Consumed", "value": "Consumed"}
    ]

def get_transaction_status_options():
    """
    Get standardized transaction status options
    
    Returns:
    --------
    list
        List of status option dictionaries
    """
    return [
        {"label": "Pending", "value": "Pending"},
        {"label": "Approved", "value": "Approved"},
        {"label": "Rejected", "value": "Rejected"},
        {"label": "Completed", "value": "Completed"}
    ]

def get_priority_options():
    """
    Get standardized priority options
    
    Returns:
    --------
    list
        List of priority option dictionaries
    """
    return [
        {"label": "Low", "value": "low"},
        {"label": "Medium", "value": "medium"},
        {"label": "High", "value": "high"},
        {"label": "Critical", "value": "critical"}
    ]

def get_yes_no_options():
    """
    Get standardized yes/no options
    
    Returns:
    --------
    list
        List of yes/no option dictionaries
    """
    return [
        {"label": "Yes", "value": "yes"},
        {"label": "No", "value": "no"}
    ]

def get_currency_options():
    """
    Get standardized currency options
    
    Returns:
    --------
    list
        List of currency option dictionaries
    """
    return [
        {"label": "£", "value": "GBP"},
        {"label": "€", "value": "EUR"},
        {"label": "$", "value": "USD"}
    ]

def get_cost_center_project_options():
    """
    Get standardized cost center project options
    
    Returns:
    --------
    list
        List of cost center project option dictionaries
    """
    return [
        {"label": "CC-PROJ-001 - Digital Transformation", "value": "CC-PROJ-001"},
        {"label": "CC-PROJ-002 - Infrastructure Upgrade", "value": "CC-PROJ-002"},
        {"label": "CC-PROJ-003 - AI Implementation", "value": "CC-PROJ-003"},
        {"label": "CC-PROJ-004 - Cloud Migration", "value": "CC-PROJ-004"},
        {"label": "CC-PROJ-005 - Security Enhancement", "value": "CC-PROJ-005"},
        {"label": "CC-PROJ-006 - Process Automation", "value": "CC-PROJ-006"}
    ]

def get_cost_center_sow_options():
    """
    Get standardized cost center SOW (Statement of Work) options
    
    Returns:
    --------
    list
        List of cost center SOW option dictionaries
    """
    return [
        {"label": "CC-SOW-001 - System Integration", "value": "CC-SOW-001"},
        {"label": "CC-SOW-002 - Software Development", "value": "CC-SOW-002"},
        {"label": "CC-SOW-003 - Consulting Services", "value": "CC-SOW-003"},
        {"label": "CC-SOW-004 - Training & Support", "value": "CC-SOW-004"},
        {"label": "CC-SOW-005 - Maintenance & Operations", "value": "CC-SOW-005"},
        {"label": "CC-SOW-006 - Research & Development", "value": "CC-SOW-006"}
    ]

def get_sow_number_options():
    """
    Get standardized SOW number options
    
    Returns:
    --------
    list
        List of SOW number option dictionaries
    """
    return [
        {"label": "SOW-2025-001", "value": "SOW-2025-001"},
        {"label": "SOW-2025-002", "value": "SOW-2025-002"},
        {"label": "SOW-2025-003", "value": "SOW-2025-003"},
        {"label": "SOW-2025-004", "value": "SOW-2025-004"},
        {"label": "SOW-2025-005", "value": "SOW-2025-005"},
        {"label": "SOW-2025-006", "value": "SOW-2025-006"},
        {"label": "SOW-2025-007", "value": "SOW-2025-007"},
        {"label": "SOW-2025-008", "value": "SOW-2025-008"}
    ]

def get_po_number_options():
    """
    Get standardized PO (Purchase Order) number options
    
    Returns:
    --------
    list
        List of PO number option dictionaries
    """
    return [
        {"label": "PO-2025-001", "value": "PO-2025-001"},
        {"label": "PO-2025-002", "value": "PO-2025-002"},
        {"label": "PO-2025-003", "value": "PO-2025-003"},
        {"label": "PO-2025-004", "value": "PO-2025-004"},
        {"label": "PO-2025-005", "value": "PO-2025-005"},
        {"label": "PO-2025-006", "value": "PO-2025-006"},
        {"label": "PO-2025-007", "value": "PO-2025-007"},
        {"label": "PO-2025-008", "value": "PO-2025-008"}
    ]

def get_department_options():
    """
    Get standardized department options
    
    Returns:
    --------
    list
        List of department option dictionaries
    """
    return [
        {"label": "IT", "value": "IT"},
        {"label": "Finance", "value": "Finance"},
        {"label": "HR", "value": "HR"},
        {"label": "Marketing", "value": "Marketing"},
        {"label": "Operations", "value": "Operations"},
        {"label": "Research & Development", "value": "R&D"},
        {"label": "Sales", "value": "Sales"}
    ]

def get_program_options():
    """
    Get program options from database
    
    Returns:
    --------
    list
        List of program option dictionaries
    """
    try:
        programs = get_programs()
        if programs:
            return [
                {"label": program.get('name', f"Program {program.get('id')}"), "value": program.get('id')}
                for program in programs
            ]
        else:
            # Fallback to hardcoded options if database is empty
            return [
                {"label": "Digital Innovation Program", "value": "DIP"},
                {"label": "Customer Experience Program", "value": "CEP"},
                {"label": "Operational Excellence Program", "value": "OEP"},
                {"label": "Technology Modernization Program", "value": "TMP"},
                {"label": "Data & Analytics Program", "value": "DAP"},
                {"label": "Sustainability Program", "value": "SP"},
                {"label": "Growth & Expansion Program", "value": "GEP"}
            ]
    except Exception as e:
        print(f"Error loading programs from database: {e}")
        # Fallback to hardcoded options if there's an error
        return [
            {"label": "Digital Innovation Program", "value": "DIP"},
            {"label": "Customer Experience Program", "value": "CEP"},
            {"label": "Operational Excellence Program", "value": "OEP"},
            {"label": "Technology Modernization Program", "value": "TMP"},
            {"label": "Data & Analytics Program", "value": "DAP"},
            {"label": "Sustainability Program", "value": "SP"},
            {"label": "Growth & Expansion Program", "value": "GEP"}
        ]

def get_project_owner_options():
    """
    Get project owner options from database (Tech Leads only)
    
    Returns:
    --------
    list
        List of project owner option dictionaries (Tech Leads only)
    """
    return get_tech_leads_options()

def get_program_status_options():
    """
    Get program status options based on database constraints
    
    Returns:
    --------
    list
        List of program status option dictionaries
    """
    return [
        {"label": "Planning", "value": "Planning"},
        {"label": "Active", "value": "Active"},
        {"label": "On Hold", "value": "On Hold"},
        {"label": "Completed", "value": "Completed"},
        {"label": "Cancelled", "value": "Cancelled"}
    ]

def get_project_status_options():
    """
    Get project status options based on database constraints
    
    Returns:
    --------
    list
        List of project status option dictionaries
    """
    return [
        {"label": "Planning", "value": "Planning"},
        {"label": "Active", "value": "Active"},
        {"label": "On Hold", "value": "On Hold"},
        {"label": "Completed", "value": "Completed"},
        {"label": "Cancelled", "value": "Cancelled"}
    ]

def get_maturity_options():
    """Get maturity options from database constraint"""
    return [
        {"label": "Seed", "value": "Seed"},
        {"label": "Scoping", "value": "Scoping"},
        {"label": "PoC", "value": "PoC"},
        {"label": "PoV", "value": "PoV"},
        {"label": "Scaling", "value": "Scaling"},
        {"label": "Live", "value": "Live"}
    ]

def get_programs_options():
    """Get programs from database for dropdown options"""
    try:
        programs = get_programs()
        return [{"label": program["name"], "value": program["id"]} for program in programs]
    except Exception as e:
        print(f"Error loading programs: {e}")
        return []

def get_projects_options():
    """Get projects from database for dropdown options"""
    try:
        projects = get_projects()
        return [{"label": project["name"], "value": project["id"]} for project in projects]
    except Exception as e:
        print(f"Error loading projects: {e}")
        return []

def get_team_members_options():
    """
    Get team members options from database
    
    Returns:
    --------
    list
        List of team member option dictionaries
    """
    try:
        team_members = get_team_members()
        if team_members:
            return [
                {"label": member.get('name', f"User {member.get('id')}"), "value": member.get('id')}
                for member in team_members
            ]
        else:
            # Fallback to hardcoded options if database is empty
            return []
    except Exception as e:
        print(f"Error loading team members from database: {e}")
        # Fallback to hardcoded options if there's an error
        return []

def get_tech_leads_options():
    """
    Get Tech Lead and Program Manager team members options from database (for program owners)
    Returns team members with role = 'Tech Lead' or 'Program Manager'
    
    Returns:
    --------
    list
        List of Tech Lead and Program Manager option dictionaries
    """
    return get_program_leadership_options()

def get_program_leadership_options():
    """
    Get program leadership team members (Tech Leads and Program Managers) from database
    Returns team members with role = 'Tech Lead' or 'Program Manager'
    
    Returns:
    --------
    list
        List of leadership option dictionaries
    """
    try:
        team_members = get_team_members()
        if team_members:
            # Filter Tech Leads and Program Managers
            eligible_roles = ['tech lead', 'program manager']
            eligible_members = [
                member for member in team_members 
                if member.get('role', '').lower() in eligible_roles
            ]
            options = []
            for member in eligible_members:
                name = member.get('name', f"User {member.get('id', 'Unknown')}")
                department = member.get('department', 'Unknown Dept')
                label = f"{name} ({department})"
                options.append({"label": label, "value": member.get('id')})
            return options
        else:
            # By default, return empty if no eligible members
            return []
    except Exception as e:
        print(f"Error loading program leadership from database: {e}")
        # Fallback to hardcoded options if there's an error
        return []
