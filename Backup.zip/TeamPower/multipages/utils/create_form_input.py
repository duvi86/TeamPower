"""
Form input utility for GSK Design System
Creates styled form inputs
"""

from dash import dcc

def create_form_input(input_id, input_type='text', placeholder='', required=False, **kwargs):
    """
    Create a styled form input
    
    Parameters:
    -----------
    input_id : str
        Input component ID
    input_type : str
        Input type (text, number, email, etc.)
    placeholder : str
        Placeholder text
    required : bool
        Whether input is required
    **kwargs : dict
        Additional properties for dcc.Input
        
    Returns:
    --------
    dcc.Input
        Styled input component
    """
    
    return dcc.Input(
        id=input_id,
        type=input_type,
        placeholder=placeholder,
        required=required,
        className='form-input',
        **kwargs
    )
