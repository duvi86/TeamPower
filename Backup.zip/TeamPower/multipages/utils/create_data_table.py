"""
Generic data table component for Dash applications.
Provides a reusable table with search, pagination, export, and modal functionality.
"""

from dash import html, dcc, dash_table
import dash_bootstrap_components as dbc
from utils.create_button import create_button
from utils.create_dropdown import create_dropdown
from utils.create_modal import get_modal_set


def create_data_table(
    data, 
    columns, 
    id_prefix, 
    search_placeholder="Search...",
    item_type="item",
    include_modals=True
):
    """
    Create a generic data table with consistent styling and features.
    
    Args:
        data: List of dicts (data records)
        columns: List of column definitions for DataTable
        id_prefix: Prefix for component IDs (e.g., 'transactions-table', 'projects-table')
        search_placeholder: Placeholder text for search input
        item_type: Type of items in table (e.g., 'transaction', 'project')
        include_modals: Whether to include edit/delete modals
    
    Returns:
        html.Div containing the DataTable and all controls
    """
    
    # Create tooltip data for better UX with truncated text
    tooltip_data = []
    if data:
        tooltip_data = [
            {
                column['id']: {'value': str(row.get(column['id'], '')), 'type': 'markdown'}
                for column in columns
            } for row in data
        ]
    
    # Set a fixed page size that fits the card and pagination well
    fixed_page_size = 10
    
    # Main table container
    table_components = [
        # Search and controls bar (no rows per page dropdown)
        html.Div([
            html.Div([
                dcc.Input(
                    id=f"{id_prefix}-search",
                    type="text",
                    placeholder=search_placeholder,
                    className="table-search-input"
                )
            ], className="table-controls-left"),
            html.Div([
                create_button(
                    html.Span([
                        html.I(className="fa fa-file-csv export-icon"),
                        "Export CSV"
                    ]),
                    f"{id_prefix}-export-csv",
                    button_type='secondary',
                    n_clicks=0,
                    class_name="export-csv-button"
                )
            ], className="table-controls-right")
        ], className="table-controls-bar"),

        # DataTable container
        html.Div([
            html.Div([
                dash_table.DataTable(
                    id=f"{id_prefix}-datatable",
                    columns=columns,
                    data=data,
                    page_action='native',
                    page_size=fixed_page_size,
                    page_current=0,
                    sort_action='native',
                    row_selectable='single',
                    selected_rows=[],
                    active_cell=None,
                    css=[
                        {
                            'selector': '.dash-table-pagination',
                            'rule': 'position: absolute !important; left: 0; right: 0; bottom: 0; background: var(--color-surface-secondary); border-top: 1px solid var(--color-stroke-primary); z-index: 2;'
                        },
                        {
                            'selector': '.dash-table-pagination .current-page',
                            'rule': 'color: var(--color-accent-primary);'
                        }
                    ]
                )
            ], className='datatable-card-body datatable-wrapper'),
        ], className="table-container"),
        
        # Download component
        dcc.Download(id=f"{id_prefix}-download-csv"),
        
        # Filtered data store
        dcc.Store(id=f"{id_prefix}-filtered-data", data=data)
    ]
    
    # Add modals if requested
    if include_modals:
        modals = get_modal_set(id_prefix, item_type, include_edit=True, include_info=False)
        table_components.extend(modals)
    
    return html.Div(
        table_components,
        className='generic-table-container'
    )


def get_standard_table_columns(table_type):
    """
    Get standard column definitions for different table types with optimized widths.
    
    Args:
        table_type: Type of table ('transactions', 'projects')
    
    Returns:
        List of column definitions with width specifications
    """
    
    if table_type == 'transactions':
        return [
            {"name": "Date", "id": "date", "type": "text", "presentation": "markdown"},
            {"name": "Description", "id": "description", "type": "text", "presentation": "markdown"},
            {"name": "Amount ($)", "id": "amount", "type": "numeric", "format": {"specifier": "$,.2f"}},
            {"name": "Project", "id": "project", "type": "text"},
            {"name": "CC Project", "id": "cost_center_project", "type": "text"},
            {"name": "CC SOW", "id": "cost_center_sow", "type": "text"},
            {"name": "SOW #", "id": "sow_number", "type": "text"},
            {"name": "PO #", "id": "po", "type": "text"},
            {"name": "Category", "id": "category", "type": "text"},
            {"name": "Type", "id": "type", "type": "text"},
        ]
    
    elif table_type == 'projects':
        return [
            {"name": "Title", "id": "title", "type": "text", "presentation": "markdown"},
            {"name": "Description", "id": "description", "type": "text", "presentation": "markdown"},
            {"name": "Potential ($)", "id": "potential_value", "type": "numeric", "format": {"specifier": "$,.0f"}},
            {"name": "Realized ($)", "id": "realized_value", "type": "numeric", "format": {"specifier": "$,.0f"}},
            {"name": "Start", "id": "start_date", "type": "datetime"},
            {"name": "End", "id": "end_date", "type": "datetime"},
            {"name": "Program", "id": "program", "type": "text"},
            {"name": "Owner", "id": "owner", "type": "text"},
            {"name": "Maturity", "id": "maturity", "type": "text"},
            {"name": "Status", "id": "status", "type": "text"},
        ]
    
    else:
        return []
