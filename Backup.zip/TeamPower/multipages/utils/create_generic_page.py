"""
Generic page template for creating consistent form + table pages
This provides a reusable pattern for all CRUD pages in the application.
"""

from dash import html, dcc, callback, Input, Output, State
import dash
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.create_navbar import create_navbar
from utils.create_feedback_button import create_feedback_button
from utils.create_card import create_card

def create_generic_page_layout(page_config):
    """
    Create a generic page layout with consistent structure
    
    Args:
        page_config (dict): Configuration dictionary with the following structure:
        {
            'page_title': str,           # Page title (e.g., 'Config')
            'path': str,                 # URL path (e.g., '/config')
            'navbar_tab': str,           # Active navbar tab name
            'form_title': str,           # Form card title (e.g., 'Add New Transaction')
            'table_title': str,          # Table card title (e.g., 'Transaction History')
            'form_component': function,  # Function that returns form component
            'table_component': function, # Function that returns table component
            'tabs': list,               # Optional: List of tab configurations for multi-tab pages
            'form_width': str,          # Optional: Form width (default: '400px')
            'min_table_width': str,     # Optional: Min table width (default: '800px')
            'max_page_width': str,      # Optional: Max page width (default: '1600px')
            'version': str              # Optional: Version string (default: '2.0.0')
        }
    
    Returns:
        html.Div: Complete page layout
    """
    
    # Extract configuration with defaults
    page_title = page_config.get('page_title', 'Page')
    navbar_tab = page_config.get('navbar_tab', page_title)
    form_title = page_config.get('form_title', 'Add New Item')
    table_title = page_config.get('table_title', 'Items')
    form_component = page_config.get('form_component')
    table_component = page_config.get('table_component')
    tabs = page_config.get('tabs', [])
    form_width = page_config.get('form_width', '400px')
    min_table_width = page_config.get('min_table_width', '800px')
    max_page_width = page_config.get('max_page_width', '1600px')
    version = page_config.get('version', '2.0.0')
    
    # Create main content based on whether tabs are present
    if tabs:
        main_content = create_tabbed_content(page_config)
    else:
        main_content = create_form_table_layout(
            form_title=form_title,
            table_title=table_title,
            form_component=form_component,
            table_component=table_component,
            form_width=form_width,
            min_table_width=min_table_width,
            max_page_width=max_page_width
        )
    
    # Return complete page layout
    return html.Div([
        html.Div([
            create_navbar(active_tab=navbar_tab, logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg", version="1.0.0")
        ], style={'margin': '0', 'padding': '0'}),
        html.Div(
            style={
                'margin-left': '20px', 
                'margin-right': '20px',
                'margin-bottom': '30px',  # Account for bottom bar height
                'margin-top': '10px',
                'flex': '1',
                'overflow': 'auto',
                'display': 'flex',
                'flexDirection': 'column'
            },
            children=[
                # Page header
                html.Div(
                    id='main-content',
                    children=[
                        html.H1(page_title, style={'fontSize': '1.8rem', 'marginBottom': '10px'}),
                        create_feedback_button(id_prefix=f"{page_title.lower().replace(' ', '-')}-feedback")
                    ],
                    style={'margin-bottom': '10px', 'flex': '0 0 auto'}
                ),
                html.Div(
                    children=[main_content],
                    style={'flex': '1', 'overflow': 'auto'}
                ),
            ]
        ),
        html.Span("TwinOps AI Powered | 2.0.0", className="bottom-section b1")
    ], style={'height': '100vh', 'overflow': 'hidden', 'display': 'flex', 'flexDirection': 'column', 'margin': '0', 'padding': '0'})

def create_form_table_layout(form_title, table_title, form_component, table_component, 
                           form_width='400px', min_table_width='800px', max_page_width='1600px'):
    """
    Create a generic form + table layout
    
    Args:
        form_title (str): Title for the form card
        table_title (str): Title for the table card
        form_component (function): Function that returns form component
        table_component (function): Function that returns table component
        form_width (str): Width of the form column
        min_table_width (str): Minimum width of the table
        max_page_width (str): Maximum width of the entire layout
    
    Returns:
        html.Div: Form + table layout
    """
    
    return html.Div([
        # Form Card
        html.Div([
            create_card(
                title=form_title,
                content=html.Div(
                    id=f"{form_title.lower().replace(' ', '-')}-container",
                    children=form_component(selected=False) if form_component else html.Div("No form component provided")
                ),
                id=f"{form_title.lower().replace(' ', '-')}-card"
            )
        ], style={
            'flex': f'0 0 {form_width}',
            'marginRight': '24px',
            'display': 'flex',
            'flexDirection': 'column'
        }),
        
        # Table Card
        html.Div([
            create_card(
                title=table_title,
                content=table_component() if table_component else html.Div("No table component provided"),
                id=f"{table_title.lower().replace(' ', '-')}-card"
            )
        ], style={
            'flex': '1',
            'minWidth': min_table_width,
            'display': 'flex',
            'flexDirection': 'column'
        })
    ], style={
        'display': 'flex', 
        'gap': '24px', 
        'alignItems': 'stretch',
        'width': '100%',
        'maxWidth': max_page_width,
        'margin': '0 auto',
        'minHeight': '600px'
    })

def create_tabbed_content(page_config):
    """
    Create tabbed content for multi-tab pages
    
    Args:
        page_config (dict): Page configuration including tabs list
    
    Returns:
        html.Div: Tabbed content layout
    """
    tabs = page_config.get('tabs', [])
    page_id = page_config.get('page_id', page_config.get('path', 'default').replace('/', '').replace('-', '_'))
    
    if not tabs:
        return html.Div("No tabs configured")
    
    # Create unique IDs for this page
    tab_content_id = f'tab-content-{page_id}'
    
    # Create tab buttons with unique IDs
    tab_buttons = []
    for i, tab in enumerate(tabs):
        tab_id = tab.get('id', f'tab-{i}')
        tab_label = tab.get('label', f'Tab {i+1}')
        is_active = tab.get('active', i == 0)  # First tab is active by default
        
        tab_buttons.append(
            html.A(
                tab_label,
                href="#",
                className="tab tab-active tab-item" if is_active else "tab tab-item",
                id=f"{tab_id}-tab-{page_id}",  # Make tab ID unique
                style={
                    'padding': '10px 20px',
                    'marginRight': '10px',
                    'display': 'inline-block',
                    'borderRadius': '4px 4px 0 0'
                }
            )
        )

    return html.Div([
        # Tab Navigation
        html.Div([
            html.Div(tab_buttons, style={
                'borderBottom': '1px solid var(--color-stroke-primary)',
                'marginBottom': '20px',
                'display': 'flex',
                'alignItems': 'flex-end'
            })
        ], style={'marginBottom': '20px'}),
        
        # Tab Content Container with unique ID
        html.Div(id=tab_content_id, children=[
            create_form_table_layout(
                form_title=tabs[0].get('form_title', 'Add New Item'),
                table_title=tabs[0].get('table_title', 'Items'),
                form_component=tabs[0].get('form_component'),
                table_component=tabs[0].get('table_component'),
                form_width=page_config.get('form_width', '400px'),
                min_table_width=page_config.get('min_table_width', '800px'),
                max_page_width=page_config.get('max_page_width', '1600px')
            )
        ])
    ])

def create_tab_callback_factory(page_config):
    """
    Create tab switching callback for a tabbed page configuration
    This creates a dynamic callback that handles tab switching for the given page.
    
    Args:
        page_config (dict): Page configuration containing tabs information
    """
    if not page_config.get('tabs'):
        return
    
    tabs = page_config['tabs']
    page_id = page_config.get('page_id', page_config.get('path', 'default').replace('/', '').replace('-', '_'))
    
    # Create unique IDs for this page to avoid conflicts
    tab_content_id = f'tab-content-{page_id}'
    
    # Create tab outputs with unique IDs
    tab_outputs = []
    for tab in tabs:
        tab_id = f"{tab['id']}-tab-{page_id}"
        tab_outputs.append(Output(tab_id, 'className'))
    
    tab_outputs.append(Output(tab_content_id, 'children'))
    
    # Create tab inputs with unique IDs
    tab_inputs = []
    for tab in tabs:
        tab_id = f"{tab['id']}-tab-{page_id}"
        tab_inputs.append(Input(tab_id, 'n_clicks'))
    
    @callback(
        tab_outputs,
        tab_inputs,
        prevent_initial_call=False
    )
    def update_tab_content(*tab_clicks):
        """Handle tab switching for the page"""
        # Determine which tab is active
        ctx = dash.callback_context
        active_tab_id = None
        
        if ctx.triggered:
            # Get the triggered component ID and extract tab ID
            trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
            # Remove the page suffix to get the original tab ID
            active_tab_id = trigger_id.replace(f'-tab-{page_id}', '')
        
        # If no trigger or invalid trigger, use the default active tab
        if not active_tab_id:
            for tab in tabs:
                if tab.get('active', False):
                    active_tab_id = tab['id']
                    break
            if not active_tab_id:
                active_tab_id = tabs[0]['id']
        
        # Update tab classes and content
        tab_classes = []
        content = None
        
        for tab in tabs:
            if tab['id'] == active_tab_id:
                tab_classes.append('tab-button active')
                # Create content for active tab
                content = create_form_table_layout(
                    form_component=tab['form_component'],
                    table_component=tab['table_component'], 
                    form_title=tab.get('form_title', 'Form'),
                    table_title=tab.get('table_title', 'Data'),
                    form_width=page_config.get('form_width', '400px'),
                    min_table_width=page_config.get('min_table_width', '800px')
                )
            else:
                tab_classes.append('tab-button')
        
        return tab_classes + [content]
