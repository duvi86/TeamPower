import dash_bootstrap_components as dbc
from dash import html
from utils.create_dropdown import create_dropdown

def create_filters(filters, row_style=None):
    """
    Creates a row of filter dropdowns
    
    Parameters:
    -----------
    filters : list of dicts
        Each dict contains:
        - label: Label for the dropdown
        - id: Component ID
        - options: List of dropdown options
        - default_value: Default value for the dropdown
        - width: Column width (1-12)
    row_style : dict, optional
        Additional styling for the row
        
    Returns:
    --------
    dbc.Row
        Row of filter dropdowns
    """
    if row_style is None:
        row_style = {'margin-bottom': '10px'}
        
    cols = []
    
    for filter_item in filters:
        cols.append(
            dbc.Col(
                [
                    html.H3(
                        filter_item['label'], 
                        className="stacked-label custom-h4", 
                        style={'font-size': '1.2rem', 'margin-bottom': '5px'}
                    ),
                    create_dropdown(
                        id=filter_item['id'],
                        options=filter_item['options'],
                        default_value=filter_item['default_value'],
                        class_name="custom-dropdown b1"
                    ),
                ],
                width=filter_item.get('width', 4),
            )
        )
    
    return dbc.Row(cols, className="mb-2 b1", style=row_style)
