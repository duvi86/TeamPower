from dash import html
import dash_bootstrap_components as dbc

def create_navbar(active_tab, logo_src, version, nav_items=None):
    """
    Create a navigation bar with the specified active tab.
    
    Parameters:
    -----------
    active_tab : str
        The name of the currently active tab
    logo_src : str
        Path to the logo image
    version : str
        Version string to display
    nav_items : list, optional
        List of navigation items with 'name' and 'path' keys.
        If None, uses default navigation items.
    """
    if nav_items is None:
        nav_items = [
            {"name": "Overview", "path": "/"},
            {"name": "AI Financials", "path": "/ai-financials"},
                {"name": "Team", "path": "/team-hierarchy"},
                {"name": "Config", "path": "/config"}
        ]
    
    nav_links = []
    for item in nav_items:
        is_active = item["name"] == active_tab
        nav_links.append(
            dbc.NavItem(
                dbc.NavLink(
                    item["name"],
                    href=item["path"],
                    active=is_active,
                    className="tab tab-active tab-item" if is_active else "tab tab-item"
                )
            )
        )
    
    return dbc.Navbar(
        dbc.Container(
            [
                html.Img(src=logo_src, className="img"), 
                html.Span(f"AI Oracle | {version}", className="span b1"),
                dbc.Row(className="flex-spacer", style={"flex-grow": 1}),
                html.Div(style={"padding-left": "0", "padding-right": "0"}),
                dbc.Collapse(
                    dbc.Nav(
                        nav_links, 
                        pills=True, 
                        className="ml-auto h6", 
                        style={"display": "flex", "justify-content": "flex-end"}
                    ),
                    id="navbar-collapse",
                    navbar=True,
                ),
                dbc.NavbarToggler(id="navbar-toggler", className="ml-2"),
            ],
            fluid=True,
            className="d-flex align-items-center",
        ),
        className="top-bar",
        color=""
    )
