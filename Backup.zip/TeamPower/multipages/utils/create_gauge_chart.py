"""
Generic Gauge Chart Component
Creates reusable gauge charts with configurable data and styling
"""
import plotly.graph_objects as go
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from config.chart_config import get_chart_config


def create_gauge_chart(data, config=None):
    """
    Create a generic gauge chart with configurable data and styling
    
    Args:
        data (dict): Chart data containing:
            - value: Current value to display
            - min_value: Minimum value for gauge range (optional, default 0)
            - max_value: Maximum value for gauge range (optional, default 100)
            - thresholds: List of threshold dictionaries with:
                - min: Minimum value for this threshold
                - max: Maximum value for this threshold
                - color: Color for this threshold range
                - label: Label for this threshold (optional)
        config (dict): Chart configuration containing:
            - title: Chart title
            - height: Chart height
            - margin: Chart margins
            - font_family: Font family for chart
            - font_size: Base font size
            - title_font_size: Title font size
            - value_font_size: Value display font size
            - gauge_color: Main gauge bar color
            - background_color: Background color
            - show_axis: Whether to show axis numbers
            - number_format: Format for displayed number (e.g., ':.1%', ':.0f')
    
    Returns:
        plotly.graph_objects.Figure: Configured gauge chart
    """
    
    # Get complete configuration using centralized system  
    chart_config = get_chart_config('gauge_chart', config)
    
    # Validate required data fields
    if 'value' not in data:
        raise ValueError("Data must contain 'value' field")
    
    # Set default range
    min_value = data.get('min_value', 0)
    max_value = data.get('max_value', 100)
    value = data['value']
    
    # Default thresholds using GSK colors
    default_thresholds = [
        {'min': min_value, 'max': min_value + (max_value - min_value) * 0.6, 'color': '#C83629', 'label': 'Low'},      # GSK Error Strong
        {'min': min_value + (max_value - min_value) * 0.6, 'max': min_value + (max_value - min_value) * 0.8, 'color': '#FFC709', 'label': 'Medium'},  # GSK Warning Strong
        {'min': min_value + (max_value - min_value) * 0.8, 'max': max_value, 'color': '#448422', 'label': 'High'}       # GSK Success Strong
    ]
    
    thresholds = data.get('thresholds', default_thresholds)
    
    # Create gauge steps from thresholds
    steps = []
    for threshold in thresholds:
        steps.append({
            'range': [threshold['min'], threshold['max']],
            'color': threshold['color']
        })
    
    # Determine current threshold for bar color
    gauge_bar_color = chart_config['gauge_color']
    for threshold in thresholds:
        if threshold['min'] <= value <= threshold['max']:
            gauge_bar_color = threshold['color']
            break
    
    # Create gauge indicator
    indicator = go.Indicator(
        mode="gauge+number",
        value=value,
        title={'text': chart_config['title'], 'font': {'size': chart_config['title_font_size'], 'family': chart_config['title_font_family'], 'color': chart_config['title_color']}},
        number={'font': {'size': chart_config['value_font_size'], 'family': chart_config['font_family']}, 'valueformat': chart_config['number_format']},
        gauge={
            'axis': {'range': [min_value, max_value], 'visible': chart_config['show_axis']},
            'bar': {'color': gauge_bar_color, 'thickness': 0.8},
            'bgcolor': chart_config['background_color'],
            'borderwidth': 2,
            'bordercolor': "#D8D7D5",
            'steps': steps,
        }
    )
    
    # Create figure
    fig = go.Figure(indicator)
    
    # Add threshold labels if enabled
    if chart_config['show_threshold_text'] and 'label' in thresholds[0]:
        threshold_labels = []
        for i, threshold in enumerate(thresholds):
            if 'label' in threshold:
                threshold_labels.append({
                    'x': 0.5,
                    'y': 0.1 + (i * 0.05),  # Stack labels vertically
                    'text': f"<span style='color: {threshold['color']}'>{threshold['label']}</span>",
                    'showarrow': False,
                    'font': {'size': 10, 'family': chart_config['font_family']},
                    'xref': 'paper',
                    'yref': 'paper'
                })
        
        # Add annotations to the figure layout
        fig.update_layout(annotations=threshold_labels)
    
    # Update layout
    fig.update_layout(
        font=dict(
            family=chart_config['font_family'], 
            size=chart_config['font_size']
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        height=chart_config['height'],
        margin=chart_config['margin']
    )
    
    return fig


def create_performance_gauge(value, title="Performance", thresholds=None):
    """
    Create a performance gauge with standard GSK color thresholds
    
    Args:
        value (float): Performance value (0-1 range expected)
        title (str): Gauge title
        thresholds (list): Optional custom thresholds
    
    Returns:
        plotly.graph_objects.Figure: Performance gauge chart
    """
    
    # Default performance thresholds
    if thresholds is None:
        thresholds = [
            {'min': 0, 'max': 0.6, 'color': '#C83629', 'label': 'Needs Improvement'},    # GSK Error Strong
            {'min': 0.6, 'max': 0.8, 'color': '#FFC709', 'label': 'Good'},              # GSK Warning Strong
            {'min': 0.8, 'max': 1.0, 'color': '#448422', 'label': 'Excellent'}          # GSK Success Strong
        ]
    
    data = {
        'value': value,
        'min_value': 0,
        'max_value': 1,
        'thresholds': thresholds
    }
    
    config = {
        'title': title,
        'height': 250,
        'number_format': ':.1%',
        'value_font_size': 20,
        'show_threshold_text': True
    }
    
    return create_gauge_chart(data, config)


def create_kpi_gauge(value, target, title="KPI", unit=""):
    """
    Create a KPI gauge comparing actual vs target
    
    Args:
        value (float): Actual KPI value
        target (float): Target KPI value
        title (str): KPI title
        unit (str): Unit for display (e.g., "$", "%", "units")
    
    Returns:
        plotly.graph_objects.Figure: KPI gauge chart
    """
    
    # Calculate percentage of target achieved
    percentage = (value / target) if target > 0 else 0
    
    # Set thresholds based on target achievement
    thresholds = [
        {'min': 0, 'max': 0.7 * target, 'color': '#C83629', 'label': 'Below Target'},     # GSK Error Strong
        {'min': 0.7 * target, 'max': 0.95 * target, 'color': '#FFC709', 'label': 'Close to Target'},  # GSK Warning Strong
        {'min': 0.95 * target, 'max': 1.5 * target, 'color': '#448422', 'label': 'Target Achieved'}   # GSK Success Strong
    ]
    
    data = {
        'value': value,
        'min_value': 0,
        'max_value': 1.5 * target,  # Show up to 150% of target
        'thresholds': thresholds
    }
    
    config = {
        'title': f"{title}<br><sub>Target: {target:,.0f}{unit}</sub>",
        'height': 280,
        'number_format': f':.0f{unit}' if unit else ':.0f',
        'value_font_size': 18,
        'title_font_size': 14,
        'show_threshold_text': False
    }
    
    return create_gauge_chart(data, config)


def create_score_gauge(score, max_score=100, title="Score"):
    """
    Create a score gauge (e.g., test scores, ratings)
    
    Args:
        score (float): Current score
        max_score (float): Maximum possible score
        title (str): Score title
    
    Returns:
        plotly.graph_objects.Figure: Score gauge chart
    """
    
    # Standard score thresholds
    thresholds = [
        {'min': 0, 'max': 0.6 * max_score, 'color': '#C83629', 'label': 'Poor'},          # GSK Error Strong
        {'min': 0.6 * max_score, 'max': 0.8 * max_score, 'color': '#FFC709', 'label': 'Fair'},    # GSK Warning Strong
        {'min': 0.8 * max_score, 'max': max_score, 'color': '#448422', 'label': 'Good'}             # GSK Success Strong
    ]
    
    data = {
        'value': score,
        'min_value': 0,
        'max_value': max_score,
        'thresholds': thresholds
    }
    
    config = {
        'title': title,
        'height': 250,
        'number_format': ':.0f',
        'value_font_size': 20,
        'show_threshold_text': True
    }
    
    return create_gauge_chart(data, config)
