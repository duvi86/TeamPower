"""
Form datepicker utility for GSK Design System
Creates styled date pickers
"""

from dash import dcc
from datetime import datetime

def create_form_datepicker(datepicker_id, default_date=None, placeholder='Select date', required=False, **kwargs):
    """
    Create a styled date picker
    
    Parameters:
    -----------
    datepicker_id : str
        DatePicker component ID
    default_date : datetime, optional
        Default selected date. If None, date picker will be empty
    placeholder : str
        Placeholder text
    required : bool
        Whether date selection is required
    **kwargs : dict
        Additional properties for dcc.DatePickerSingle
        
    Returns:
    --------
    dcc.DatePickerSingle
        Styled date picker component
    """
    return dcc.DatePickerSingle(
        id=datepicker_id,
        date=default_date,  # Allow None to create empty date picker
        display_format='YYYY-MM-DD',
        className='form-datepicker',
        **kwargs
    )
