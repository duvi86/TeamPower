import dash_bootstrap_components as dbc
from dash import html, dcc

def create_feedback_button(id_prefix="feedback", position="bottom-right", tooltip_text="Provide Feedback"):
    """
    Creates a feedback button using the centered-button CSS class
    
    Parameters:
    -----------
    id_prefix : str
        Prefix for component IDs
    position : str
        Position of the button (ignored, uses CSS positioning)
    tooltip_text : str
        Text for the tooltip
        
    Returns:
    --------
    html.Div
        Container with feedback button and modal
    """
    
    # Create a feedback button that opens a mailto link
    feedback_button = html.Div(
        [
            html.A(
                dbc.Button(
                    "Feedback",
                    id=f"{id_prefix}-button",
                    className="centered-button",
                ),
                href="mailto:matthieu.x.duvinage@gsk.com?subject=TeamPower%20Feedback",
                target="_blank",
                style={"textDecoration": "none"}
            ),
            dbc.Tooltip(
                tooltip_text,
                target=f"{id_prefix}-button",
                placement="left"
            ),
        ]
    )
    return feedback_button
