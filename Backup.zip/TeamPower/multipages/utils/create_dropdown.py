from dash import dcc

def create_dropdown(id, options, default_value, class_name="form-dropdown", style=None):
    """
    Creates a styled dropdown component
    
    Parameters:
    -----------
    id : str
        Component ID
    options : list
        List of option dictionaries with 'label' and 'value' keys
    default_value : any
        Default selected value
    class_name : str, optional
        CSS class name (default: "form-dropdown")
    style : dict, optional
        Additional inline styles
        
    Returns:
    --------
    dcc.Dropdown
        Styled dropdown component
    """
    return dcc.Dropdown(
        options=options,
        value=default_value,
        id=id,
        className=class_name,
        clearable=False
    )
