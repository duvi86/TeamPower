"""
Generic Bar Chart Component
Creates reusable bar charts with configurable data and styling
"""
import plotly.graph_objects as go
import plotly.express as px
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from config.chart_config import get_chart_config


def create_bar_chart(data, config=None):
    """
    Create a generic bar chart with configurable data and styling
    
    Args:
        data (dict): Chart data containing:
            - categories: List of category names (x-axis)
            - values: List of values (y-axis) OR
            - series: List of series data for grouped/stacked bars, each containing:
                - name: Series name
                - values: List of values for each category
                - color: Color for this series
        config (dict): Chart configuration containing:
            - title: Chart title
            - height: Chart height
            - x_title: X-axis title
            - y_title: Y-axis title
            - margin: Chart margins
            - font_family: Font family for chart
            - font_size: Base font size
            - show_legend: Whether to show legend
            - bar_mode: 'group' or 'stack' for multiple series
            - orientation: 'vertical' or 'horizontal'
            - color: Single color for simple bar chart
    
    Returns:
        plotly.graph_objects.Figure: Configured bar chart
    """
    
    # Get complete configuration using centralized system
    chart_config = get_chart_config('bar_chart', config)
    
    # Validate required data fields
    if 'categories' not in data:
        raise ValueError("Data must contain 'categories' field")
    
    # Check if this is a simple bar chart (single series) or multi-series
    is_single_series = 'values' in data
    is_multi_series = 'series' in data
    
    if not is_single_series and not is_multi_series:
        raise ValueError("Data must contain either 'values' or 'series' field")
    
    # Default color palette for multi-series
    default_colors = [
        '#154EC2',   # GSK viz blue
        '#21837E',   # GSK viz teal
        '#66A73d',   # GSK viz green
        '#ca305b',   # GSK viz purple
        '#f7C650',   # GSK viz yellow
        '#7540EE',   # GSK viz violet
        '#464646',   # GSK text subtle
        '#C83629',   # GSK error strong
        '#448422',   # GSK success strong
        '#FFC709'    # GSK warning strong
    ]
    
    # Create figure
    fig = go.Figure()
    
    if is_single_series:
        # Simple bar chart with single series
        if chart_config['orientation'] == 'horizontal':
            trace = go.Bar(
                y=data['categories'],
                x=data['values'],
                orientation='h',
                marker_color=chart_config['color'],
                hovertemplate='<b>%{y}</b><br>%{x}<extra></extra>',
                showlegend=False
            )
        else:
            trace = go.Bar(
                x=data['categories'],
                y=data['values'],
                marker_color=chart_config['color'],
                hovertemplate=chart_config['hover_template'],
                showlegend=False
            )
        
        # Add values on bars if requested
        if chart_config['show_values_on_bars']:
            trace.update(
                text=data['values'],
                textposition='outside' if chart_config['orientation'] == 'vertical' else 'auto',
                textfont=dict(size=chart_config['value_font_size'], family=chart_config['font_family'])
            )
        
        fig.add_trace(trace)
        
    else:
        # Multi-series bar chart
        for i, series in enumerate(data['series']):
            if 'name' not in series or 'values' not in series:
                raise ValueError("Each series must have 'name' and 'values' fields")
            
            color = series.get('color', default_colors[i % len(default_colors)])
            
            if chart_config['orientation'] == 'horizontal':
                trace = go.Bar(
                    name=series['name'],
                    y=data['categories'],
                    x=series['values'],
                    orientation='h',
                    marker_color=color,
                    hovertemplate='<b>%{y}</b><br>%{fullData.name}: %{x}<extra></extra>'
                )
            else:
                trace = go.Bar(
                    name=series['name'],
                    x=data['categories'],
                    y=series['values'],
                    marker_color=color,
                    hovertemplate='<b>%{x}</b><br>%{fullData.name}: %{y}<extra></extra>'
                )
            
            # Add values on bars if requested
            if chart_config['show_values_on_bars']:
                trace.update(
                    text=series['values'],
                    textposition='outside' if chart_config['orientation'] == 'vertical' else 'auto',
                    textfont=dict(size=chart_config['value_font_size'], family=chart_config['font_family'])
                )
            
            fig.add_trace(trace)
    
    # Configure axes based on orientation
    if chart_config['orientation'] == 'horizontal':
        xaxis_config = {
            'title': {
                'text': chart_config['y_title'],  # Swapped for horizontal
                'font': {
                    'size': chart_config['axis_title_size'],
                    'family': chart_config['font_family']
                }
            },
            'showgrid': True,
            'gridcolor': 'rgba(216,215,213,0.5)',
            'linecolor': '#D8D7D5',
            'linewidth': 1
        }
        yaxis_config = {
            'title': {
                'text': chart_config['x_title'],  # Swapped for horizontal
                'font': {
                    'size': chart_config['axis_title_size'],
                    'family': chart_config['font_family']
                }
            },
            'showgrid': False,
            'linecolor': '#D8D7D5',
            'linewidth': 1
        }
    else:
        xaxis_config = {
            'title': {
                'text': chart_config['x_title'],
                'font': {
                    'size': chart_config['axis_title_size'],
                    'family': chart_config['font_family']
                }
            },
            'showgrid': False,
            'linecolor': '#D8D7D5',
            'linewidth': 1
        }
        yaxis_config = {
            'title': {
                'text': chart_config['y_title'],
                'font': {
                    'size': chart_config['axis_title_size'],
                    'family': chart_config['font_family']
                }
            },
            'showgrid': True,
            'gridcolor': 'rgba(216,215,213,0.5)',
            'linecolor': '#D8D7D5',
            'linewidth': 1
        }
    
    # Update layout with configuration
    fig.update_layout(
        title={
            'text': chart_config['title'],
            'x': 0.5,
            'xanchor': 'center',
            'font': {
                'size': chart_config['title_font_size'],
                'family': chart_config['title_font_family'],
                'color': chart_config['title_color']
            }
        },
        xaxis=xaxis_config,
        yaxis=yaxis_config,
        font=dict(
            family=chart_config['font_family'], 
            size=chart_config['font_size']
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        height=chart_config['height'],
        margin=chart_config['margin'],
        barmode=chart_config['bar_mode'],
        bargap=chart_config['bar_gap'],
        showlegend=chart_config['show_legend'] and is_multi_series
    )
    
    # Configure legend if enabled
    if chart_config['show_legend'] and is_multi_series:
        fig.update_layout(
            legend=dict(
                orientation=chart_config['legend_orientation'],
                yanchor="bottom",
                y=chart_config['legend_y'],
                xanchor="center",
                x=0.5,
                bgcolor='rgba(255,255,255,0.9)',
                bordercolor='#D8D7D5',
                borderwidth=1
            )
        )
    
    return fig


def prepare_category_data(data_points, category_field='category', value_field='value'):
    """
    Transform categorical data for bar chart visualization
    
    Args:
        data_points (list): List of data point dictionaries
        category_field (str): Field name for categories
        value_field (str): Field name for values
    
    Returns:
        dict: Formatted data for bar chart
    """
    
    if not data_points:
        return {
            'categories': ['No Data'],
            'values': [0]
        }
    
    # Aggregate data by category
    category_totals = {}
    for point in data_points:
        category = point.get(category_field, 'Unknown')
        value = point.get(value_field, 0)
        
        if category in category_totals:
            category_totals[category] += value
        else:
            category_totals[category] = value
    
    # Sort by value (descending)
    sorted_items = sorted(category_totals.items(), key=lambda x: x[1], reverse=True)
    
    return {
        'categories': [item[0] for item in sorted_items],
        'values': [item[1] for item in sorted_items]
    }


def prepare_comparison_data(data_points, category_field='category', series_field='series', value_field='value'):
    """
    Transform comparison data for grouped/stacked bar chart
    
    Args:
        data_points (list): List of data point dictionaries
        category_field (str): Field name for categories (x-axis)
        series_field (str): Field name for series grouping
        value_field (str): Field name for values
    
    Returns:
        dict: Formatted data for grouped/stacked bar chart
    """
    
    if not data_points:
        return {
            'categories': ['No Data'],
            'series': [{
                'name': 'Empty',
                'values': [0],
                'color': '#6A6A6A'
            }]
        }
    
    # Get unique categories and series
    categories = sorted(list(set(point.get(category_field) for point in data_points)))
    series_names = list(set(point.get(series_field) for point in data_points))
    
    # Default colors
    default_colors = [
        '#154EC2',   # GSK viz blue
        '#21837E',   # GSK viz teal
        '#66A73d',   # GSK viz green
        '#ca305b',   # GSK viz purple
        '#f7C650',   # GSK viz yellow
        '#7540EE',   # GSK viz violet
    ]
    
    # Prepare series data
    series_data = []
    for i, series_name in enumerate(series_names):
        values = []
        for category in categories:
            # Find value for this series and category
            value = sum(point.get(value_field, 0) for point in data_points 
                       if point.get(category_field) == category and point.get(series_field) == series_name)
            values.append(value)
        
        series_data.append({
            'name': series_name,
            'values': values,
            'color': default_colors[i % len(default_colors)]
        })
    
    return {
        'categories': categories,
        'series': series_data
    }
