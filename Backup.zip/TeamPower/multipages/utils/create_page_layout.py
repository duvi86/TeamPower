from dash import html
import dash_bootstrap_components as dbc
from utils.create_navbar import create_navbar

def create_page_layout(
    title,
    content,
    description=None,
    version="2.0.0",
    logo_src="assets/GSK_Logo_Full_Colour_RGB_57kb_28064.svg"
):
    """
    Creates a consistent page layout with content area and footer
    
    Parameters:
    -----------
    title : str
        Title of the page (used for SEO and accessibility)
    content : dash component
        The main content to display in the page
    description : str, optional
        Description of the page (used for SEO)
    version : str, optional
        Version string to display in footer
    logo_src : str, optional
        Path to the logo image
        
    Returns:
    --------
    dash.html.Div
        Complete page layout
    """
    return html.Div([
        html.Div(
            style={
                'margin-left': '10px',  # Reduced margin
                'margin-right': '10px', # Reduced margin
                'margin-bottom': '30px', # Reduced margin
                'margin-top': '5px',    # Reduced margin
                'height': 'calc(100vh - 90px)', # Smaller footer space
                'max-height': 'calc(100vh - 90px)',
                'display': 'flex',
                'flex-direction': 'column',
                'overflow': 'hidden'  # No scrolling on main container - will make components responsive
            },
            children=[content]
        ),
        html.Div(
            html.Span(f"TwinOps AI Powered | {version}", className="b1"),
            className="bottom-section",
            style={'height': '30px', 'padding': '5px'}  # Smaller footer
        )
    ], style={'height': '100vh', 'max-height': '100vh', 'overflow': 'hidden'})
