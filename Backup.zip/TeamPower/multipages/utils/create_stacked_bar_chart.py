"""
Generic Stacked Bar Chart Component
Creates reusable stacked bar charts with configurable data and styling
"""
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from config.chart_config import get_chart_config


def create_stacked_bar_chart(data, config=None):
    """
    Create a stacked bar chart with standardized GSK styling
    
    Args:
        data: Dictionary containing:
            - categories: List of x-axis categories
            - series: List of dictionaries with 'name', 'values', and optional 'color'
        config: Optional configuration overrides
    
    Returns:
        Plotly figure object
    """
    
    # Get complete configuration using centralized system
    chart_config = get_chart_config('stacked_bar_chart', config)
    
    # Validate required data fields
    if 'categories' not in data or 'series' not in data:
        raise ValueError("Data must contain 'categories' and 'series' fields")
    
    if not data['series']:
        raise ValueError("At least one series must be provided")
    
    # Create figure
    fig = go.Figure()
    
    # Add traces for each series
    for series in data['series']:
        if 'name' not in series or 'values' not in series:
            raise ValueError("Each series must have 'name' and 'values' fields")
        
        fig.add_trace(go.Bar(
            name=series['name'],
            x=data['categories'],
            y=series['values'],
            marker_color=series.get('color', '#6A6A6A'),
            hovertemplate=chart_config['hover_template']
        ))
    
    # Update layout with configuration
    fig.update_layout(
        title={
            'text': chart_config['title'],
            'x': 0.5,
            'xanchor': 'center',
            'font': {
                'size': chart_config['title_font_size'],
                'family': chart_config['title_font_family'],
                'color': chart_config['title_color']
            }
        },
        xaxis_title={
            'text': chart_config['x_title'],
            'font': {
                'size': chart_config['axis_title_size'],
                'family': chart_config['font_family']
            }
        },
        yaxis_title={
            'text': chart_config['y_title'],
            'font': {
                'size': chart_config['axis_title_size'],
                'family': chart_config['font_family']
            }
        },
        font=dict(
            family=chart_config['font_family'], 
            size=chart_config['font_size']
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        height=chart_config['height'],
        margin=chart_config['margin'],
        barmode='stack',
        bargap=chart_config['bar_gap'],
        showlegend=chart_config['show_legend']
    )
    
    # Configure legend if enabled
    if chart_config['show_legend']:
        fig.update_layout(
            legend=dict(
                orientation=chart_config['legend_orientation'],
                yanchor=chart_config.get('legend_yanchor', 'top'),
                y=chart_config['legend_y'],
                xanchor="center",
                x=0.5,
                bgcolor='rgba(255,255,255,0.9)',
                bordercolor=chart_config.get('grid_color', '#D8D7D5'),
                borderwidth=1,
                font=dict(size=chart_config['font_size'])
            )
        )
    
    return fig


import plotly.graph_objects as go
from .gsk_colors import get_status_color_mapping


def prepare_department_status_data(team_members, color_mapping=None):
    """
    Transform team member data for department status stacked bar chart
    
    Args:
        team_members (list): List of team member dictionaries
        color_mapping (dict): Optional color mapping for statuses
    
    Returns:
        dict: Formatted data for stacked bar chart
    """
    
    if not team_members:
        return {
            'categories': ['No Data'],
            'series': [{
                'name': 'Empty',
                'values': [0],
                'color': '#6A6A6A'
            }]
        }
    
    # Default color mapping using GSK Design System colors
    colors = color_mapping if color_mapping else get_status_color_mapping()
    
    # Group data by department and status
    departments = {}
    for member in team_members:
        dept = member.get('department', 'Unassigned')
        status = member.get('status', 'Active')
        
        if dept not in departments:
            departments[dept] = {'Active': 0, 'On Leave': 0, 'Inactive': 0}
        departments[dept][status] += 1
    
    # Sort departments by total count (descending)
    sorted_depts = sorted(departments.items(), 
                         key=lambda x: sum(x[1].values()), 
                         reverse=True)
    
    # Prepare data structure
    categories = [dept for dept, _ in sorted_depts]
    series_data = []
    
    # Create series for each status
    for status in ['Active', 'On Leave', 'Inactive']:
        values = [departments[dept][status] for dept in categories]
        series_data.append({
            'name': status,
            'values': values,
            'color': colors[status]
        })
    
    return {
        'categories': categories,
        'series': series_data
    }


def prepare_time_series_data(data_points, color_mapping=None):
    """
    Transform time series data for stacked bar chart visualization
    
    Args:
        data_points (list): List of data point dictionaries with date and categories
        color_mapping (dict): Optional color mapping for categories
    
    Returns:
        dict: Formatted data for stacked bar chart
    """
    
    if not data_points:
        return {
            'categories': ['No Data'],
            'series': [{
                'name': 'Empty',
                'values': [0],
                'color': '#6A6A6A'
            }]
        }
    
    # Default colors - will use CSS variables in future phases
    default_colors = {
        'Category1': '#154EC2',   # GSK viz blue
        'Category2': '#21837E',   # GSK viz teal
        'Category3': '#66A73d',   # GSK viz green
        'Category4': '#ca305b',   # GSK viz purple
        'Category5': '#f7C650',   # GSK viz yellow
    }
    
    colors = color_mapping if color_mapping else default_colors
    
    # Extract unique dates and categories
    dates = sorted(list(set(point.get('date') for point in data_points)))
    categories = list(set(point.get('category') for point in data_points))
    
    # Prepare series data
    series_data = []
    for category in categories:
        values = []
        for date in dates:
            # Find value for this category and date
            value = next((point.get('value', 0) for point in data_points 
                         if point.get('date') == date and point.get('category') == category), 0)
            values.append(value)
        
        series_data.append({
            'name': category,
            'values': values,
            'color': colors.get(category, '#6A6A6A')
        })
    
    return {
        'categories': dates,
        'series': series_data
    }
