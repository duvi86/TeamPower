"""
Generic modal utilities for consistent modal dialogs across the application
"""

import dash_bootstrap_components as dbc
from dash import html, dcc


def create_delete_confirmation_modal(id_prefix, item_type="item"):
    """
    Create a generic delete confirmation modal
    
    Args:
        id_prefix (str): Prefix for component IDs (e.g., 'transactions-table', 'projects-table')
        item_type (str): Type of item being deleted (e.g., 'transaction', 'project')
    
    Returns:
        dbc.Modal: Delete confirmation modal component
    """
    return dbc.Modal([
        dbc.ModalHeader([
            html.I(className="fas fa-exclamation-triangle", style={'color': '#dc3545', 'marginRight': '8px'}),
            f"Confirm Delete {item_type.title()}"
        ], style={'borderBottom': '1px solid #dee2e6'}),
        dbc.ModalBody([
            html.Div([
                html.P([
                    "⚠️ Are you sure you want to delete this ",
                    html.Strong(item_type),
                    "?"
                ], style={'fontSize': '16px', 'marginBottom': '12px'}),
                html.P(
                    "This action cannot be undone.", 
                    style={'color': '#6c757d', 'fontSize': '14px', 'marginBottom': '16px'}
                ),
                html.Div(
                    id=f"{id_prefix}-delete-info",
                    style={
                        'backgroundColor': '#f8f9fa',
                        'padding': '12px',
                        'borderRadius': '6px',
                        'border': '1px solid #dee2e6'
                    }
                )
            ])
        ]),
        dbc.ModalFooter([
            dbc.Button(
                "Cancel", 
                id=f"{id_prefix}-cancel-delete", 
                color="secondary", 
                style={'marginRight': '8px'},
                className="btn-sm"
            ),
            dbc.Button(
                [html.I(className="fas fa-trash", style={'marginRight': '6px'}), f"Delete {item_type.title()}"], 
                id=f"{id_prefix}-confirm-delete", 
                color="danger",
                className="btn-sm"
            )
        ], style={'borderTop': '1px solid #dee2e6'})
    ], 
    id=f"{id_prefix}-delete-modal", 
    is_open=False,
    backdrop="static",  # Prevent closing by clicking outside
    keyboard=False,     # Prevent closing with Escape key
    size="sm"
    )


def create_edit_modal(id_prefix, item_type="item", size="lg"):
    """
    Create a generic edit modal
    
    Args:
        id_prefix (str): Prefix for component IDs (e.g., 'transactions-table', 'projects-table')
        item_type (str): Type of item being edited (e.g., 'transaction', 'project')
        size (str): Modal size ('sm', 'lg', 'xl')
    
    Returns:
        dbc.Modal: Edit modal component
    """
    return dbc.Modal([
        dbc.ModalHeader([
            html.I(className="fas fa-edit", style={'color': '#007bff', 'marginRight': '8px'}),
            f"Edit {item_type.title()}"
        ], style={'borderBottom': '1px solid #dee2e6'}),
        dbc.ModalBody([
            html.Div(id=f"{id_prefix}-edit-form")
        ]),
        dbc.ModalFooter([
            dbc.Button(
                "Cancel", 
                id=f"{id_prefix}-cancel-edit", 
                color="secondary", 
                style={'marginRight': '8px'},
                className="btn-sm"
            ),
            dbc.Button(
                [html.I(className="fas fa-save", style={'marginRight': '6px'}), f"Save {item_type.title()}"], 
                id=f"{id_prefix}-save-edit", 
                color="primary",
                className="btn-sm"
            )
        ], style={'borderTop': '1px solid #dee2e6'})
    ], 
    id=f"{id_prefix}-edit-modal", 
    is_open=False,
    backdrop="static",
    keyboard=False,
    size=size
    )


def create_info_modal(id_prefix, title="Information", size="md"):
    """
    Create a generic information/details modal
    
    Args:
        id_prefix (str): Prefix for component IDs
        title (str): Modal title
        size (str): Modal size ('sm', 'md', 'lg', 'xl')
    
    Returns:
        dbc.Modal: Information modal component
    """
    return dbc.Modal([
        dbc.ModalHeader([
            html.I(className="fas fa-info-circle", style={'color': '#17a2b8', 'marginRight': '8px'}),
            title
        ], style={'borderBottom': '1px solid #dee2e6'}),
        dbc.ModalBody([
            html.Div(id=f"{id_prefix}-info-content")
        ]),
        dbc.ModalFooter([
            dbc.Button(
                "Close", 
                id=f"{id_prefix}-close-info", 
                color="primary",
                className="btn-sm"
            )
        ], style={'borderTop': '1px solid #dee2e6'})
    ], 
    id=f"{id_prefix}-info-modal", 
    is_open=False,
    size=size
    )


def create_success_modal(id_prefix, title="Success", size="sm"):
    """
    Create a success confirmation modal
    
    Args:
        id_prefix (str): Prefix for component IDs
        title (str): Modal title
        size (str): Modal size
    
    Returns:
        dbc.Modal: Success modal component
    """
    return dbc.Modal([
        dbc.ModalHeader([
            html.I(className="fas fa-check-circle", style={'color': '#28a745', 'marginRight': '8px'}),
            title
        ], style={'borderBottom': '1px solid #dee2e6'}),
        dbc.ModalBody([
            html.Div(id=f"{id_prefix}-success-content")
        ]),
        dbc.ModalFooter([
            dbc.Button(
                "OK", 
                id=f"{id_prefix}-close-success", 
                color="success",
                className="btn-sm"
            )
        ], style={'borderTop': '1px solid #dee2e6'})
    ], 
    id=f"{id_prefix}-success-modal", 
    is_open=False,
    size=size
    )


def create_store_components(id_prefix):
    """
    Create store components for modal state management
    
    Args:
        id_prefix (str): Prefix for component IDs
    
    Returns:
        list: List of store components
    """
    return [
        dcc.Store(id=f"{id_prefix}-delete-store", data=None),
        dcc.Store(id=f"{id_prefix}-edit-store", data=None),
        dcc.Store(id=f"{id_prefix}-selected-item-store", data=None)
    ]


def get_modal_set(id_prefix, item_type="item", include_edit=True, include_info=False):
    """
    Get a complete set of modals for a component
    
    Args:
        id_prefix (str): Prefix for component IDs
        item_type (str): Type of item (e.g., 'transaction', 'project')
        include_edit (bool): Whether to include edit modal
        include_info (bool): Whether to include info modal
    
    Returns:
        list: List of modal components
    """
    modals = [
        create_delete_confirmation_modal(id_prefix, item_type),
        create_success_modal(id_prefix, f"{item_type.title()} Operation Complete")
    ]
    
    if include_edit:
        modals.append(create_edit_modal(id_prefix, item_type))
    
    if include_info:
        modals.append(create_info_modal(id_prefix, f"{item_type.title()} Details"))
    
    # Add store components
    modals.extend(create_store_components(id_prefix))
    
    return modals
