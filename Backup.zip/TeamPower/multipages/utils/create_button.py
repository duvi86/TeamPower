from dash import html

def create_button(text, id, button_type='primary', onclick=None, disabled=False, style=None, class_name=None, **kwargs):
    """
    Create a styled button component
    
    Args:
        text (str): Button text
        id (str): Button ID
        button_type (str): Button type - 'primary', 'secondary', or 'accent'
        onclick (str): JavaScript onclick handler
        disabled (bool): Whether button is disabled
        style (dict): Additional CSS styles
        class_name (str): Additional CSS classes
        **kwargs: Additional HTML attributes
    
    Returns:
        html.Button: Styled button component
    """
    
    # Define button type to CSS class mapping
    button_classes = {
        'primary': 'btn-primary',
        'secondary': 'btn-secondary',
        'accent': 'btn-accent'
    }
    
    base_class = button_classes.get(button_type, 'btn-bottom-prim')
    
    # Combine base class with additional classes
    if class_name:
        full_class = f"{base_class} {class_name}"
    else:
        full_class = base_class
    
    default_style = {
        'marginRight': '10px',
        'marginBottom': '10px'
    }
    
    if style:
        default_style.update(style)
    
    import dash_bootstrap_components as dbc
    button_props = {
        'children': text,
        'id': id,
        'className': full_class,
        'disabled': disabled,
        'style': default_style,
        **kwargs
    }
    if onclick:
        button_props['onClick'] = onclick
    return dbc.Button(**button_props)

def create_button_group(buttons, alignment='left'):
    """
    Create a group of buttons with proper spacing
    
    Parameters:
    -----------
    buttons : list
        List of button components
    alignment : str
        Alignment: 'left', 'center', 'right'
        
    Returns:
    --------
    html.Div
        Button group container
    """
    style = {
        'display': 'flex',
        'gap': 'var(--spacing-12)',
        'marginTop': 'var(--spacing-16)'
    }
    
    if alignment == 'center':
        style['justifyContent'] = 'center'
    elif alignment == 'right':
        style['justifyContent'] = 'flex-end'
    # 'left' is default (flex-start)
    
    return html.Div(
        buttons,
        style=style
    )
