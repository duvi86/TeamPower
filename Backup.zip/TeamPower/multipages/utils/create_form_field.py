"""
Form field utility for GSK Design System
Creates consistent form fields with label and component
"""

from dash import html

def create_form_field(label, component, field_id=None, required=False, help_text=None, error=None):
    """
    Create a consistent form field with label and component
    
    Parameters:
    -----------
    label : str
        Field label text
    component : dash component
        Form input component (dcc.Input, dcc.Dropdown, etc.)
    field_id : str, optional
        ID for the field container
    required : bool
        Whether the field is required
    help_text : str, optional
        Help text to display below the field
    error : str, optional
        Error message to display
        
    Returns:
    --------
    html.Div
        Complete form field with label and component
    """
    
    if required:
        label_content = [label, html.Span(' *', className='form-field-required')]
    else:
        label_content = label
    
    field_components = [
        html.Label(label_content, className='form-field-label'),
        component
    ]
    
    if help_text:
        field_components.append(
            html.Small(help_text, className='form-field-help')
        )
    
    if error:
        field_components.append(
            html.Div(error, className='form-field-error')
        )
    
    # Only include id if it's provided
    div_props = {'className': 'form-field'}
    if field_id:
        div_props['id'] = field_id
    
    return html.Div(field_components, **div_props)
