from dash import dcc, html

def create_generic_graph(title, figure, graph_id=None, width=12, height=450, class_name=None):
    """
    Generic graph card for dashboard, expandable for any plotly figure.
    """
    return html.Div([
        html.H2(title, className='dashboard-section-title'),
        dcc.Graph(
            id=graph_id,
            figure=figure,
            style={'height': f'{height}px'},
            className='dashboard-graph'
        )
    ], className=f'dashboard-graph-container{f" {class_name}" if class_name else ""}', style={'width': f'{int(width/12*100)}%'})


def create_generic_bar_plot(title, figure, graph_id=None, width=12, height=450, class_name=None):
    """
    Generic bar plot card for dashboard, expandable for any plotly bar figure.
    """
    return create_generic_graph(title, figure, graph_id, width, height, class_name)
