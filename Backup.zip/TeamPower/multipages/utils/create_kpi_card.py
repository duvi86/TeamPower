from dash import html

from dash import html
from .create_card import create_card

def create_kpi_card(title, value, subtitle=None, card_class=None, value_class=None, id=None, height=130):
    """
    Generic KPI card for dashboard metrics using the existing create_card component.
    
    Parameters:
    -----------
    title : str
        Title for the card header
    value : str
        Value to display in the card body
    subtitle : str, optional
        Small text to display below the value (e.g., breakdown information)
    card_class : str, optional
        Additional CSS class for the card
    value_class : str, optional
        CSS class for value styling (e.g., 'budget', 'planned', 'consumed')
    id : str, optional
        ID for the card
    height : int, optional
        Height of the card in pixels (default: 130)
    """
    # Create the KPI value content with proper styling
    kpi_content = html.Div([
        html.H3(
            value,
            className=f'kpi-value {value_class}' if value_class else 'kpi-value'
        ),
        html.H4(
            subtitle,
            className='kpi-subtitle'
        ) if subtitle else None
    ], className='kpi-content')
    
    # Use the existing create_card function
    return create_card(
        title=title,
        content=kpi_content,
        id=id,
        class_name=f'kpi-card{f" {card_class}" if card_class else ""}',
        height=height  # Now using the height parameter
    )


def create_kpi_row(cards):
    """
    Row of KPI cards for dashboard.
    """
    return html.Div(cards, className='kpi-cards-row')
