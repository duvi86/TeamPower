"""
Form dropdown utility for GSK Design System
Creates styled form dropdowns
"""

from dash import dcc

def create_form_dropdown(dropdown_id, options, placeholder='Select...', required=False, **kwargs):
    """
    Create a styled form dropdown
    
    Parameters:
    -----------
    dropdown_id : str
        Dropdown component ID
    options : list
        List of option dictionaries
    placeholder : str
        Placeholder text
    required : bool
        Whether selection is required
    **kwargs : dict
        Additional properties for dcc.Dropdown
        
    Returns:
    --------
    dcc.Dropdown
        Styled dropdown component
    """
    return dcc.Dropdown(
        id=dropdown_id,
        options=options,
        placeholder=placeholder,
        className='form-dropdown',
        **kwargs
    )
