"""
Generic Sunburst Chart Component
Creates reusable sunburst charts with configurable data and styling
"""
import plotly.graph_objects as go
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from config.chart_config import get_chart_config


def create_sunburst_chart(data, config=None):
    """
    Create a generic sunburst chart with configurable data and styling
    
    Args:
        data (dict): Chart data containing:
            - ids: List of node IDs
            - labels: List of node labels
            - parents: List of parent node IDs
            - values: List of node values
            - colors: List of colors for each node
        config (dict): Chart configuration containing:
            - title: Chart title
            - height: Chart height
            - maxdepth: Maximum depth to display
            - margin: Chart margins
            - font_family: Font family for chart
            - font_size: Base font size
    
    Returns:
        plotly.graph_objects.Figure: Configured sunburst chart
    """
    
    # Get complete configuration using centralized system
    chart_config = get_chart_config('sunburst_chart', config)
    
    # Validate required data fields
    required_fields = ['ids', 'labels', 'parents', 'values']
    for field in required_fields:
        if field not in data:
            raise ValueError(f"Missing required data field: {field}")
    
    # Create sunburst chart
    fig = go.Figure(go.Sunburst(
        ids=data['ids'],
        labels=data['labels'],
        parents=data['parents'],
        values=data['values'],
        branchvalues="total",
        marker=dict(
            colors=data.get('colors', []),
            line=dict(
                color=chart_config['line_color'], 
                width=chart_config['line_width']
            )
        ),
        hovertemplate=chart_config['hover_template'],
        maxdepth=chart_config['maxdepth'],
    ))
    
    # Update layout with configuration
    fig.update_layout(
        title={
            'text': chart_config['title'],
            'x': 0.5,
            'xanchor': 'center',
            'font': {
                'size': chart_config['title_font_size'],
                'family': chart_config['title_font_family'],
                'color': chart_config['title_color']
            }
        },
        font=dict(
            family=chart_config['font_family'], 
            size=chart_config['font_size']
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        height=chart_config['height'],
        margin=chart_config['margin']
    )
    
    return fig


import plotly.graph_objects as go
from .gsk_colors import get_department_color_mapping, get_status_color_mapping, GSK_VIZ_COLORS, get_department_color_sequence

# Import the team member function at module level to avoid relative import issues
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from db_management.team_member_db import get_team_member_by_id


def prepare_programs_data(programs, projects, config=None):
    """
    Transform programs and projects data for portfolio sunburst visualization
    
    Args:
        programs (list): List of program dictionaries
        projects (list): List of project dictionaries
        config (dict): Optional configuration for data preparation
            - selected_year: int, the year to filter projects for (default: current year)
            - value_type: str, 'potential' or 'realized' (default: 'potential')
    
    Returns:
        dict: Formatted data for sunburst chart
    """
    from datetime import datetime
    
    # Extract configuration or set defaults
    config = config or {}
    selected_year = config.get('selected_year', datetime.now().year)
    value_type = config.get('value_type', 'potential')
    
    if not programs or not projects:
        return {
            'ids': ['empty'],
            'labels': ['No data available'],
            'parents': [''],
            'values': [1],
            'colors': ['#6A6A6A']
        }
    
    # Filter projects based on completion status and year
    filtered_projects = []
    for project in projects:
        status = project.get('status', '').lower()
        end_date_str = project.get('end_date')
        
        # Skip cancelled projects entirely
        if status == 'cancelled':
            continue
        
        # Include completed projects only if they completed in the selected year
        if status == 'completed':
            if end_date_str:
                try:
                    end_date = datetime.strptime(end_date_str, "%Y-%m-%d")
                    if end_date.year == selected_year:
                        filtered_projects.append(project)
                except ValueError:
                    # If date parsing fails, skip this project
                    continue
        else:
            # Include non-completed, non-cancelled projects for the selected year
            filtered_projects.append(project)
    
    # Initialize data for sunburst
    ids = []
    labels = []
    parents = []
    values = []
    colors = []
    
    # Calculate project-program mapping and values using filtered projects
    program_projects = {}
    for project in filtered_projects:
        program_id = project.get('program_id')
        if program_id:
            if program_id not in program_projects:
                program_projects[program_id] = []
            program_projects[program_id].append(project)
    
    # Calculate total value across filtered projects based on value type
    value_field = 'potential_value' if value_type == 'potential' else 'realized_value'
    total_value = sum(p.get(value_field, 0) for p in filtered_projects)
    
    if total_value == 0:
        return {
            'ids': ['empty'],
            'labels': [f'No {value_type} value data available'],
            'parents': [''],
            'values': [1],
            'colors': ['#6A6A6A']
        }
    
    # Level 1: Root level - Total Portfolio Value
    total_value_millions = total_value / 1_000_000
    value_label = 'Potential' if value_type == 'potential' else 'Realized'
    ids.append('Portfolio')
    labels.append(f'{total_value_millions:.2f} M$')
    parents.append('')
    values.append(total_value)
    colors.append(GSK_VIZ_COLORS['violet'])
    
    # Group programs by department (from owner) and calculate department values
    dept_programs = {}
    dept_values = {}
    for program in programs:
        # Try to get department from owner, fallback to program's own department
        owner_id = program.get('owner_id')
        dept = None
        
        if owner_id:
            try:
                owner = get_team_member_by_id(owner_id)
                if owner:
                    dept = owner.get('department')
            except Exception as e:
                print(f"Error getting team member {owner_id}: {e}")
        
        # Fallback to program's own department or Unknown
        if not dept:
            dept = program.get('department', 'Unknown')
            
        if dept not in dept_programs:
            dept_programs[dept] = []
            dept_values[dept] = 0
        dept_programs[dept].append(program)
        # Calculate department value from its programs' filtered projects
        program_id = program.get('id')
        if program_id in program_projects:
            program_value = sum(p.get(value_field, 0) for p in program_projects[program_id])
            dept_values[dept] += program_value
    
    # Level 2: Departments
    active_departments = [dept for dept, value in dept_values.items() if value > 0]
    dept_colors = get_department_color_sequence(active_departments)
    
    for idx, dept in enumerate(active_departments):
        dept_actual_value = dept_values[dept]
        ids.append(dept)
        labels.append(dept)
        parents.append('Portfolio')
        values.append(dept_actual_value)
        colors.append(dept_colors[idx] if idx < len(dept_colors) else GSK_VIZ_COLORS['teal'])
    
    # Level 3: Programs (weighted by actual value)
    program_colors = [GSK_VIZ_COLORS['orange'], GSK_VIZ_COLORS['yellow'], GSK_VIZ_COLORS['purple'], GSK_VIZ_COLORS['blue']]
    program_idx = 0
    
    for program in programs:
        program_id = program['id']
        program_name = program['name']
        
        # Get the correct department for this program (same logic as above)
        owner_id = program.get('owner_id')
        dept = None
        
        if owner_id:
            try:
                owner = get_team_member_by_id(owner_id)
                if owner:
                    dept = owner.get('department')
            except Exception as e:
                print(f"Error getting team member {owner_id}: {e}")
        
        if not dept:
            dept = program.get('department', 'Unknown')
            
        if program_id in program_projects and dept in active_departments:
            program_value = sum(p.get(value_field, 0) for p in program_projects[program_id])
            if program_value > 0:
                ids.append(f'prog_{program_id}')
                labels.append(program_name)
                parents.append(dept)
                values.append(program_value)
                colors.append(program_colors[program_idx % len(program_colors)])
                program_idx += 1
    
    # Level 4: Projects (weighted by individual value) - using filtered projects
    project_colors = [GSK_VIZ_COLORS['green'], GSK_VIZ_COLORS['teal'], GSK_VIZ_COLORS['blue'], GSK_VIZ_COLORS['purple']]
    project_idx = 0
    
    for project in filtered_projects:
        program_id = project.get('program_id')
        project_name = project.get('name', 'Unknown Project')
        project_value = project.get(value_field, 0)
        if program_id and project_value > 0:
            ids.append(f'proj_{project["id"]}')
            labels.append(project_name)
            parents.append(f'prog_{program_id}')
            values.append(project_value)
            colors.append(project_colors[project_idx % len(project_colors)])
            project_idx += 1
    
    return {
        'ids': ids,
        'labels': labels,
        'parents': parents,
        'values': values,
        'colors': colors
    }


def prepare_org_chart_data(team_members, color_mapping=None):
    """
    Transform team member data for org chart sunburst visualization
    
    Args:
        team_members (list): List of team member dictionaries
        color_mapping (dict): Optional color mapping for statuses and departments
    
    Returns:
        dict: Formatted data for sunburst chart
    """
    
    if not team_members:
        return {
            'ids': ['empty'],
            'labels': ['No data available'],
            'parents': [''],
            'values': [1],
            'colors': ['#6A6A6A']
        }
    
    # Default color mapping using GSK Design System visualization colors
    default_colors = {
        'status': get_status_color_mapping(),
        'department': get_department_color_mapping()
    }
    
    colors = color_mapping if color_mapping else default_colors
    
    # Prepare data structure
    ids = []
    labels = []
    parents = []
    values = []
    chart_colors = []
    
    # Group by department and status
    departments = {}
    for member in team_members:
        dept = member.get('department', 'Unassigned')
        status = member.get('status', 'Active')
        if dept not in departments:
            departments[dept] = {'Active': 0, 'On Leave': 0, 'Inactive': 0}
        departments[dept][status] += 1
    
    # Add root
    ids.append("Company")
    labels.append("Team")
    parents.append("")
    values.append(len(team_members))
    chart_colors.append('#151515')  # GSK text default
    
    # Add departments
    for dept, counts in departments.items():
        total = sum(counts.values())
        ids.append(dept)
        labels.append(f"{dept}<br>({total} members)")
        parents.append("Company")
        values.append(total)
        chart_colors.append(colors['department'].get(dept, '#6A6A6A'))
        
        # Add status groups within departments
        for status, count in counts.items():
            if count > 0:
                status_id = f"{dept}-{status}"
                ids.append(status_id)
                labels.append(f"{status}<br>({count})")
                parents.append(dept)
                values.append(count)
                chart_colors.append(colors['status'][status])
    
    return {
        'ids': ids,
        'labels': labels,
        'parents': parents,
        'values': values,
        'colors': chart_colors
    }
