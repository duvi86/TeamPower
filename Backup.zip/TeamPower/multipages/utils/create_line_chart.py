"""
Generic Line Chart Component
Creates reusable line charts with configurable data and styling
"""
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from config.chart_config import get_chart_config


def create_line_chart(data, config=None):
    """
    Create a generic line chart with configurable data and styling
    
    Args:
        data (dict): Chart data containing:
            - x: List of x-axis values (dates, categories, etc.)
            - series: List of series data, each containing:
                - name: Series name
                - y: List of y-axis values
                - color: Color for this series (optional)
                - line_style: Line style - 'solid', 'dash', 'dot', 'dashdot' (optional)
                - marker_style: Marker style - 'circle', 'square', 'diamond' (optional)
        config (dict): Chart configuration containing:
            - title: Chart title
            - height: Chart height
            - x_title: X-axis title
            - y_title: Y-axis title
            - margin: Chart margins
            - font_family: Font family for chart
            - font_size: Base font size
            - show_legend: Whether to show legend
            - line_width: Default line width
            - show_markers: Whether to show markers on lines
    
    Returns:
        plotly.graph_objects.Figure: Configured line chart
    """
    
    # Get complete configuration using centralized system
    chart_config = get_chart_config('line_chart', config)
    
    # Validate required data fields
    if 'x' not in data or 'series' not in data:
        raise ValueError("Data must contain 'x' and 'series' fields")
    
    if not data['series']:
        raise ValueError("At least one series must be provided")
    
    # Default color palette using GSK colors
    default_colors = [
        '#154EC2',   # GSK viz blue
        '#21837E',   # GSK viz teal
        '#66A73d',   # GSK viz green
        '#ca305b',   # GSK viz purple
        '#f7C650',   # GSK viz yellow
        '#7540EE',   # GSK viz violet
        '#464646',   # GSK text subtle
        '#C83629',   # GSK error strong
        '#448422',   # GSK success strong
        '#FFC709'    # GSK warning strong
    ]
    
    # Line style mapping
    line_styles = {
        'solid': 'solid',
        'dash': 'dash',
        'dot': 'dot',
        'dashdot': 'dashdot'
    }
    
    # Marker style mapping
    marker_styles = {
        'circle': 'circle',
        'square': 'square',
        'diamond': 'diamond',
        'triangle': 'triangle-up',
        'star': 'star'
    }
    
    # Create figure
    fig = go.Figure()
    
    # Add traces for each series
    for i, series in enumerate(data['series']):
        if 'name' not in series or 'y' not in series:
            raise ValueError("Each series must have 'name' and 'y' fields")
        
        # Set default color if not provided
        color = series.get('color', default_colors[i % len(default_colors)])
        
        # Configure line style
        line_style = line_styles.get(series.get('line_style', 'solid'), 'solid')
        
        # Configure marker style
        marker_style = marker_styles.get(series.get('marker_style', 'circle'), 'circle')
        
        # Create trace
        trace_kwargs = {
            'name': series['name'],
            'x': data['x'],
            'y': series['y'],
            'mode': 'lines+markers' if chart_config['show_markers'] else 'lines',
            'line': dict(
                color=color,
                width=chart_config['line_width'],
                dash=line_style
            ),
            'hovertemplate': chart_config['hover_template']
        }
        
        # Add markers if enabled
        if chart_config['show_markers']:
            trace_kwargs['marker'] = dict(
                symbol=marker_style,
                size=chart_config['marker_size'],
                color=color,
                line=dict(width=1, color='white')
            )
        
        fig.add_trace(go.Scatter(**trace_kwargs))
    
    # Update layout with configuration
    fig.update_layout(
        title={
            'text': chart_config['title'],
            'x': 0.5,
            'xanchor': 'center',
            'font': {
                'size': chart_config['title_font_size'],
                'family': chart_config['title_font_family'],
                'color': chart_config['title_color']
            }
        },
        xaxis=dict(
            title={
                'text': chart_config['x_title'],
                'font': {
                    'size': chart_config['axis_title_size'],
                    'family': chart_config['font_family']
                }
            },
            showgrid=True,
            gridcolor=chart_config['grid_color'],
            linecolor=chart_config['line_color'],
            linewidth=1
        ),
        yaxis=dict(
            title={
                'text': chart_config['y_title'],
                'font': {
                    'size': chart_config['axis_title_size'],
                    'family': chart_config['font_family']
                }
            },
            showgrid=True,
            gridcolor=chart_config['grid_color'],
            linecolor=chart_config['line_color'],
            linewidth=1
        ),
        font=dict(
            family=chart_config['font_family'], 
            size=chart_config['font_size']
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        height=chart_config['height'],
        margin=chart_config['margin'],
        showlegend=chart_config['show_legend']
    )
    
    # Configure legend if enabled
    if chart_config['show_legend']:
        fig.update_layout(
            legend=dict(
                orientation=chart_config['legend_orientation'],
                yanchor="bottom",
                y=chart_config['legend_y'],
                xanchor="center",
                x=0.5,
                bgcolor='rgba(255,255,255,0.9)',
                bordercolor='#D8D7D5',
                borderwidth=1
            )
        )
    
    return fig


def prepare_time_series_data(data_points, x_field='date', y_field='value', series_field='series'):
    """
    Transform time series data for line chart visualization
    
    Args:
        data_points (list): List of data point dictionaries
        x_field (str): Field name for x-axis values
        y_field (str): Field name for y-axis values
        series_field (str): Field name for series grouping
    
    Returns:
        dict: Formatted data for line chart
    """
    
    if not data_points:
        return {
            'x': ['No Data'],
            'series': [{
                'name': 'Empty',
                'y': [0],
                'color': '#6A6A6A'
            }]
        }
    
    # Extract unique x values and series
    x_values = sorted(list(set(point.get(x_field) for point in data_points)))
    series_names = list(set(point.get(series_field) for point in data_points))
    
    # Default colors - will use CSS variables in future phases
    default_colors = [
        '#154EC2',   # GSK viz blue
        '#21837E',   # GSK viz teal
        '#66A73d',   # GSK viz green
        '#ca305b',   # GSK viz purple
        '#f7C650',   # GSK viz yellow
        '#7540EE',   # GSK viz violet
    ]
    
    # Prepare series data
    series_data = []
    for i, series_name in enumerate(series_names):
        y_values = []
        for x_val in x_values:
            # Find value for this series and x value
            value = next((point.get(y_field, 0) for point in data_points 
                         if point.get(x_field) == x_val and point.get(series_field) == series_name), 0)
            y_values.append(value)
        
        series_data.append({
            'name': series_name,
            'y': y_values,
            'color': default_colors[i % len(default_colors)]
        })
    
    return {
        'x': x_values,
        'series': series_data
    }


def prepare_metrics_data(metrics_dict, x_labels=None):
    """
    Transform metrics dictionary for line chart visualization
    
    Args:
        metrics_dict (dict): Dictionary with metric names as keys and lists of values
        x_labels (list): Optional list of x-axis labels (defaults to indices)
    
    Returns:
        dict: Formatted data for line chart
    """
    
    if not metrics_dict:
        return {
            'x': ['No Data'],
            'series': [{
                'name': 'Empty',
                'y': [0],
                'color': '#6A6A6A'
            }]
        }
    
    # Use indices if no x_labels provided
    max_length = max(len(values) for values in metrics_dict.values())
    if x_labels is None:
        x_labels = list(range(max_length))
    
    # Default colors
    default_colors = [
        '#154EC2',   # GSK viz blue
        '#21837E',   # GSK viz teal
        '#66A73d',   # GSK viz green
        '#ca305b',   # GSK viz purple
        '#f7C650',   # GSK viz yellow
        '#7540EE',   # GSK viz violet
    ]
    
    # Prepare series data
    series_data = []
    for i, (metric_name, values) in enumerate(metrics_dict.items()):
        # Pad values to match x_labels length
        padded_values = values + [None] * (len(x_labels) - len(values))
        
        series_data.append({
            'name': metric_name,
            'y': padded_values,
            'color': default_colors[i % len(default_colors)]
        })
    
    return {
        'x': x_labels,
        'series': series_data
    }
