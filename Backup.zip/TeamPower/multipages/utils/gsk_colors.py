"""
GSK Design System Color Utilities
=================================

This module provides standardized access to GSK Design System colors for visualizations.
All colors are based on the official GSK Design System CSS variables.
"""

# GSK Design System Visualization Colors
GSK_VIZ_COLORS = {
    'blue': '#154EC2',      # --color-viz-blue
    'teal': '#21837E',      # --color-viz-teal  
    'green': '#66A73d',     # --color-viz-green
    'purple': '#ca305b',    # --color-viz-purple
    'yellow': '#f7C650',    # --color-viz-yellow
    'violet': '#7540EE',    # --color-viz-violet
    'orange': '#F36633',    # --color-accent-primary (GSK Orange)
}

# GSK Status Colors
GSK_STATUS_COLORS = {
    'success': '#448422',   # --color-surface-success-strong
    'warning': '#FFC709',   # --color-surface-warning-strong
    'error': '#C83629',     # --color-surface-error-strong
    'active': '#448422',    # --color-surface-success-strong
    'on_leave': '#FFC709',  # --color-surface-warning-strong
    'inactive': '#C83629',  # --color-surface-error-strong
}

# GSK Text Colors
GSK_TEXT_COLORS = {
    'default': '#151515',   # --color-text-default
    'subtle': '#464646',    # --color-text-subtle
    'disabled': '#6A6A6A',  # --color-text-disabled
}

def get_department_color_mapping():
    """
    Get the standardized department color mapping using GSK visualization colors.
    
    Returns:
        dict: Mapping of department names to GSK visualization colors
    """
    return {
        # Current departments
        'Digital Twins': GSK_VIZ_COLORS['blue'],        # Technology/Innovation focus
        'Vision': GSK_VIZ_COLORS['teal'],               # Vision/Strategy focus
        
        # Standard department categories
        'Executive': GSK_VIZ_COLORS['violet'],          # Leadership
        'Technology': GSK_VIZ_COLORS['teal'],           # Tech teams
        'Product': GSK_VIZ_COLORS['green'],             # Product teams
        'Design': GSK_VIZ_COLORS['purple'],             # Creative teams
        'Sales': GSK_VIZ_COLORS['yellow'],              # Revenue teams
        'Marketing': GSK_VIZ_COLORS['orange'],          # Brand teams
        'Operations': GSK_TEXT_COLORS['subtle'],        # Operations
        'HR': GSK_STATUS_COLORS['success'],             # People teams
        'Finance': GSK_VIZ_COLORS['blue'],              # Financial teams
        'Data & Analytics': GSK_VIZ_COLORS['teal'],     # Data-focused
        'Research': GSK_VIZ_COLORS['green'],            # R&D teams
        'Quality': GSK_VIZ_COLORS['purple'],            # Quality teams
        'Legal': GSK_TEXT_COLORS['subtle'],             # Legal teams
        'Compliance': GSK_STATUS_COLORS['error'],       # Compliance
        'IT': GSK_VIZ_COLORS['teal'],                   # IT teams
        'Innovation': GSK_VIZ_COLORS['orange'],         # Innovation
        'Strategy': GSK_VIZ_COLORS['violet'],           # Strategy
        'Manufacturing': GSK_VIZ_COLORS['green'],       # Manufacturing
        'Clinical': GSK_VIZ_COLORS['purple'],           # Clinical
        'Regulatory': GSK_STATUS_COLORS['error'],       # Regulatory
        'Commercial': GSK_VIZ_COLORS['yellow'],         # Commercial
        'Unassigned': GSK_TEXT_COLORS['disabled']       # Fallback
    }

def get_status_color_mapping():
    """
    Get the standardized status color mapping using GSK status colors.
    
    Returns:
        dict: Mapping of status names to GSK status colors
    """
    return {
        'Active': GSK_STATUS_COLORS['active'],
        'On Leave': GSK_STATUS_COLORS['on_leave'],
        'Inactive': GSK_STATUS_COLORS['inactive']
    }

def get_department_color_sequence(departments):
    """
    Get a color sequence for a list of departments using GSK colors.
    
    Args:
        departments (list): List of department names
        
    Returns:
        list: List of hex color codes matching the departments
    """
    dept_colors = get_department_color_mapping()
    return [dept_colors.get(dept, GSK_TEXT_COLORS['disabled']) for dept in departments]

def get_gsk_color_palette(count=None):
    """
    Get a GSK visualization color palette.
    
    Args:
        count (int, optional): Number of colors needed. If None, returns all colors.
        
    Returns:
        list: List of GSK visualization color hex codes
    """
    colors = list(GSK_VIZ_COLORS.values())
    if count is None:
        return colors
    
    # Repeat colors if more are needed than available
    if count > len(colors):
        multiplier = (count // len(colors)) + 1
        colors = colors * multiplier
    
    return colors[:count]

def create_plotly_color_scale(colors=None):
    """
    Create a Plotly-compatible color scale from GSK colors.
    
    Args:
        colors (list, optional): List of color hex codes. If None, uses GSK viz colors.
        
    Returns:
        list: Plotly-compatible color scale
    """
    if colors is None:
        colors = list(GSK_VIZ_COLORS.values())
    
    return colors
