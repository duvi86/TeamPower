import dash_bootstrap_components as dbc
from dash import html

def create_card(title=None, body_id=None, content=None, id=None, class_name='b1', color=None, style=None, height=None, header=None):
    """
    Creates a card with header and content
    
    Parameters:
    -----------
    title : str
        Title for the card header
    body_id : str, optional
        ID for the card body (if no content provided)
    content : dash component, optional
        Custom content for the card body (overrides body_id)
    id : str, optional
        ID for the entire card
    class_name : str, optional
        Additional CSS class for the card body
    color : str, optional
        Card accent color: primary, secondary, tertiary, success, warning, danger
    style : dict, optional
        Additional inline styling for the card
    height : int or str, optional
        Height of the card in pixels or as CSS value (e.g., "300px", "auto")
    header : str, optional
        Backward compatibility for title parameter
        
    Returns:
    --------
    dbc.Card
        Bootstrap card component
    """
    # For backward compatibility
    if title is None and header is not None:
        title = header
    card_props = {"className": 'card-spacing'}
    if id:
        card_props["id"] = id
        
    # Default card styling using CSS variables
    card_style = {
        "backgroundColor": "var(--color-surface-primary)",
        "color": "var(--color-text-default)",
        "border": "1px solid var(--color-stroke-primary)",
        "borderRadius": "var(--border-radius-medium)",
        "boxShadow": "0 var(--elevation-medium) 6px rgba(0, 0, 0, 0.1)"
    }
    
    # Add height if specified
    if height:
        if isinstance(height, int):
            card_style["height"] = f"{height}px"
            card_style["maxHeight"] = f"{height}px"
        else:
            card_style["height"] = height
            if height != "auto":
                card_style["maxHeight"] = height
        
        card_style["overflow"] = "hidden"
    
    # Add custom styling if provided
    if style:
        card_style.update(style)
        
    card_props["style"] = card_style
    
    # Custom styling for colored cards
    if color:
        # Map color names to CSS variables
        bg_color = {
            "primary": "var(--color-accent-primary)",
            "secondary": "var(--color-accent-secondary)",
            "tertiary": "var(--color-accent-tertiary)",
            "success": "var(--color-surface-success-strong)",
            "warning": "var(--color-surface-warning-strong)",
            "danger": "var(--color-surface-error-strong)",
            "info": "var(--color-viz-blue)"
        }.get(color)
        
        text_color = {
            "primary": "var(--color-text-default)",
            "secondary": "var(--color-text-default)",
            "tertiary": "var(--color-text-default)",
            "success": "var(--color-text-success-onStrong)",
            "warning": "var(--color-text-warning-onStrong)",
            "danger": "var(--color-text-error-onStrong)",
            "info": "var(--color-text-default)"
        }.get(color)
        
        if bg_color:
            card_style["backgroundColor"] = bg_color
        if text_color:
            card_style["color"] = text_color
    
    # Calculate body height if overall height is specified
    body_style = {
        "padding": "8px",  # Reduced padding
        "display": "flex",
        "flexDirection": "column"
    }
    
    if height and isinstance(height, int):
        # Subtract header height (approximately 40px)
        body_height = height - 40
        body_style.update({
            "height": f"{body_height}px",
            "maxHeight": f"{body_height}px",
            "overflow": "auto"  # Allow scrolling within the body if needed
        })
    elif height and height != "auto":
        body_style.update({
            "height": "calc(100% - 40px)",
            "maxHeight": "calc(100% - 40px)",
            "overflow": "auto"
        })
    
    # Create card body
    if content is not None:
        body = dbc.CardBody(content, className=class_name, style=body_style)
    else:
        body = dbc.CardBody("No data", id=body_id, className=class_name, style=body_style)
    
    return dbc.Card(
        [
            dbc.CardHeader(title, className="h5", 
                          style={"backgroundColor": "var(--color-surface-secondary)",
                                "color": "var(--color-text-default)",
                                "borderBottom": "1px solid var(--color-stroke-primary)"}),
            body
        ],
        **card_props
    )
