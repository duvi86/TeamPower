import dash_bootstrap_components as dbc
from dash import dcc, html
import plotly.graph_objs as go

def create_graph_card(id=None, df=None, graph_id=None, title="Process Data", figure=None, height=380, actions=True):
    """
    Creates a card with a graph
    
    Parameters:
    -----------
    id : str, optional
        ID for the card component
    df : pandas.DataFrame, optional
        DataFrame with data to plot
    graph_id : str, optional
        ID for the graph component (falls back to id if provided)
    title : str, optional
        Title for the card header
    figure : dict or plotly.graph_objs.Figure, optional
        Plotly figure to display (overrides df if provided)
    height : int, optional
        Height of the graph in pixels (default: 380)
    actions : bool, optional
        Whether to show action buttons at the bottom
        
    Returns:
    --------
    dbc.Card
        Card with a graph
    """
    # Backward compatibility - if first argument is a DataFrame, rearrange parameters
    if id is not None and isinstance(id, object) and not isinstance(id, (str, dict)) and df is None:
        df = id
        id = None
    
    # Use id as graph_id if graph_id is not provided but id is
    if graph_id is None and id is not None:
        graph_id = f"{id}-graph"
    
    # Create the figure from df if not provided directly
    if figure is None and df is not None:
        figure = {
            'data': [
                go.Scatter(
                    x=df['date'],
                    y=df['value'],
                    mode='lines',
                    name='Sensor Data',
                    line=dict(color='var(--color-viz-teal)')
                )
            ],
            'layout': go.Layout(
                xaxis={'title': {'text': 'Time', 'font': {'family': 'b1'}}, 'color': '#464646'},
                yaxis={'title': {'text': 'Value', 'font': {'family': 'b1'}}, 'color': '#464646'},
                font=dict(color='#464646'),
                margin={'l': 40, 'b': 40, 't': 40, 'r': 0},
                hovermode='closest',
                paper_bgcolor='#F0EFED',
                plot_bgcolor='#E4E3E1',
                height=height - 50  # Subtract some height for padding
            )
        }
    elif isinstance(figure, dict) and 'layout' in figure:
        # Ensure figure has a fixed height if it's a dict
        if 'height' not in figure['layout']:
            figure['layout']['height'] = height - 50
    
    # Calculate heights for different components
    # Account for the header space but no buttons
    header_space = 50
    graph_height = height - header_space  # Account for header
    card_height = height + 20   # Add a bit for the card container
    
    # Create the graph component with fixed height
    graph = dcc.Graph(
        id=graph_id,
        figure=figure,
        className="graph",
        style={
            'height': f"{graph_height}px",
            'maxHeight': f"{graph_height}px",
            'minHeight': f"{graph_height}px",
            'overflow': 'hidden'
        },
        config={'displayModeBar': False}  # Hide the mode bar for cleaner appearance
    )
    
    # Create the card content
    card_content = [graph]
    
    # Action buttons section removed - no buttons will be displayed
    
    # Prepare card kwargs
    card_kwargs = {
        "style": {
            "border": "1px solid var(--color-stroke-primary)",
            "borderRadius": "var(--border-radius-medium)",
            "boxShadow": "0 var(--elevation-medium) 6px rgba(0, 0, 0, 0.1)",
            "backgroundColor": "var(--color-surface-primary)",
            "height": f"{card_height}px",
            "maxHeight": f"{card_height}px",
            "overflow": "hidden"  # Prevent content overflow
        }
    }
    
    # Only add id if it's not None
    if id is not None:
        card_kwargs["id"] = id
    
    return dbc.Card(
        [
            dbc.CardHeader(
                title, 
                className='card-header h5',
                style={
                    "backgroundColor": "var(--color-surface-secondary)",
                    "color": "var(--color-text-default)",
                    "borderBottom": "1px solid var(--color-stroke-primary)",
                    "borderRadius": "var(--border-radius-medium) var(--border-radius-medium) 0 0"
                }
            ),
            dbc.CardBody(
                card_content,
                className="d-flex flex-column card-body",
                style={
                    'height': f"{height}px",
                    'maxHeight': f"{height}px",
                    "backgroundColor": "var(--color-surface-primary)",
                    "color": "var(--color-text-default)",
                    "borderRadius": "0 0 var(--border-radius-medium) var(--border-radius-medium)",
                    "padding": "var(--spacing-8)",
                    "overflow": "hidden",
                    "display": "flex",
                    "flexDirection": "column"
                }
            )
        ],
        **card_kwargs
    )
