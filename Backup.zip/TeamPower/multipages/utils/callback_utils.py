# === GENERIC UTILITY CALLBACK FACTORIES ===
from dash import callback, Input, Output, State, no_update, html
import pandas as pd

def make_clear_duplicate_button_text_callback(clear_btn_id, store_id, label_clear="Clear", label_duplicate="Duplicate"):
    @callback(
        Output(clear_btn_id, 'children'),
        Input(store_id, 'data'),
        prevent_initial_call=False
    )
    def _update_clear_btn_text(selected_id):
        return label_duplicate if selected_id is not None else label_clear

def make_clear_duplicate_form_callback(
    clear_btn_id, form_field_ids, store_id, add_btn_id, delete_btn_wrapper_id, message_output_id, add_label, duplicate_message="Form data preserved for new record", clear_message="Form cleared", date_fields=None
):
    @callback(
        [Output(fid, 'value' if not (date_fields and fid.split('-')[-1] in date_fields) else 'date', allow_duplicate=True) for fid in form_field_ids] +
        [
            Output(message_output_id, 'children', allow_duplicate=True),
            Output(store_id, 'data', allow_duplicate=True),
            Output(add_btn_id, 'children', allow_duplicate=True),
            Output(delete_btn_wrapper_id, 'style', allow_duplicate=True)
        ],
        Input(clear_btn_id, 'n_clicks'),
        [State(store_id, 'data')] + [State(fid, 'value' if not (date_fields and fid.split('-')[-1] in date_fields) else 'date') for fid in form_field_ids],
        prevent_initial_call=True
    )
    def _clear_or_duplicate(n_clicks, selected_id, *current_values):
        if n_clicks:
            if selected_id is not None:
                # Duplicate mode: preserve form, reset selection, hide delete
                return (
                    *current_values,
                    html.Div(duplicate_message, style={'color': 'var(--color-text-info)', 'backgroundColor': 'var(--color-surface-info-primary)','padding': 'var(--spacing-8)','borderRadius': 'var(--border-radius-small)','border': '1px solid var(--color-stroke-info-primary)','fontSize': 'var(--font-size-small)'}),
                    None,
                    add_label,
                    {'opacity': '0', 'pointerEvents': 'none'}
                )
            # Clear mode: empty form, reset selection, hide delete
            cleared = ["" if not (date_fields and fid.split('-')[-1] in date_fields) else None for fid in form_field_ids]
            return (
                *cleared,
                html.Div(clear_message, style={'color': 'var(--color-text-info)', 'backgroundColor': 'var(--color-surface-info-primary)','padding': 'var(--spacing-8)','borderRadius': 'var(--border-radius-small)','border': '1px solid var(--color-stroke-info-primary)','fontSize': 'var(--font-size-small)'}),
                None,
                add_label,
                {'opacity': '0', 'pointerEvents': 'none'}
            )
        return (no_update,) * (len(form_field_ids) + 4)

def make_export_csv_callback(export_btn_id, table_id, download_id, filename):
    @callback(
        Output(download_id, 'data'),
        Input(export_btn_id, 'n_clicks'),
        State(table_id, 'data'),
        prevent_initial_call=True
    )
    def _export_csv(n_clicks, table_data):
        if not n_clicks or not table_data:
            return no_update
        df = pd.DataFrame(table_data)
        csv_string = df.to_csv(index=False)
        return dict(content=csv_string, filename=filename)

def make_search_callback(search_input_id, table_id, get_data_func, search_fields):
    @callback(
        Output(table_id, 'data', allow_duplicate=True),
        Input(search_input_id, 'value'),
        prevent_initial_call=True
    )
    def _search(search_value):
        all_data = get_data_func()
        if not all_data:
            return []
        if search_value and search_value.strip():
            search_term = search_value.lower().strip()
            filtered = []
            for row in all_data:
                searchable_text = " ".join(str(row.get(f, "")) for f in search_fields).lower()
                if search_term in searchable_text:
                    filtered.append(row)
            return filtered
        return all_data
from dash import Input, Output, State, callback, html, ctx
import dash_bootstrap_components as dbc
import inspect

def register_feedback_callbacks(app, id_prefix="feedback"):
    """
    Registers callbacks for the feedback button and modal
    
    Parameters:
    -----------
    app : Dash app instance
    id_prefix : str
        Prefix used for component IDs
    """
    @app.callback(
        Output(f"{id_prefix}-modal", "is_open"),
        [
            Input(f"{id_prefix}-button", "n_clicks"),
            Input(f"{id_prefix}-close", "n_clicks"),
            Input(f"{id_prefix}-submit", "n_clicks"),
        ],
        [State(f"{id_prefix}-modal", "is_open")],
    )
    def toggle_modal(open_clicks, close_clicks, submit_clicks, is_open):
        if not ctx.triggered:
            return is_open
        trigger_id = ctx.triggered[0]["prop_id"].split(".")[0]
        if trigger_id == f"{id_prefix}-button":
            return True
        return False

    @app.callback(
        Output(f"{id_prefix}-toast", "is_open"),
        [Input(f"{id_prefix}-submit", "n_clicks")],
    )
    def show_toast(submit_clicks):
        if not ctx.triggered:
            return False
        if submit_clicks:
            return True
        return False

def register_filter_callbacks(app, filter_ids, output_id):
    """
    Registers callbacks for filters affecting a component
    
    Parameters:
    -----------
    app : Dash app instance
    filter_ids : list
        List of filter component IDs
    output_id : str or dict
        Output component ID and property
    """
    inputs = [Input(filter_id, "value") for filter_id in filter_ids]
    
    @app.callback(
        output_id,
        inputs
    )
    def update_output(*filter_values):
        # This is a template function - implement specific logic in actual pages
        return f"Filters selected: {', '.join(str(val) for val in filter_values if val)}"

def create_callback_templates():
    """
    Returns a string with template callback code to copy into page files
    """
    templates = """
# Example callbacks for using the generic components:

# 1. Filter callback example:
@callback(
    Output("filtered-output-id", "children"),
    [
        Input("filter1-id", "value"),
        Input("filter2-id", "value")
    ]
)
def update_filtered_output(filter1_value, filter2_value):
    # Your filtering logic here
    return f"Selected: {filter1_value}, {filter2_value}"

# 2. Feedback button callback example:
@callback(
    Output("feedback-modal", "is_open"),
    [
        Input("feedback-button", "n_clicks"),
        Input("feedback-close", "n_clicks"),
        Input("feedback-submit", "n_clicks"),
    ],
    [State("feedback-modal", "is_open")],
)
def toggle_feedback_modal(open_clicks, close_clicks, submit_clicks, is_open):
    if not ctx.triggered:
        return is_open
    trigger_id = ctx.triggered[0]["prop_id"].split(".")[0]
    if trigger_id == "feedback-button":
        return True
    return False

# 3. Dashboard grid update callback example:
@callback(
    Output("graph1-id", "figure"),
    [Input("filter1-id", "value")]
)
def update_graph1(filter_value):
    # Update the graph based on filter
    # return updated_figure
    pass
"""
    return templates

def make_row_selection_callback(
    table_id,
    form_field_ids,
    store_id,
    db_get_by_id_func,
    add_btn_id,
    delete_btn_wrapper_id,
    date_fields=None,
    id_field_name="id",
    add_label="Add Team Member",
    update_label="Update Team Member",
    form_field_map=None,
    message_output_id="team-member-message",
):
    """
    Generic callback factory for row selection in a Dash DataTable.
    Args:
        table_id (str): DataTable component ID
        form_field_ids (list): List of form field IDs (order matters)
        store_id (str): dcc.Store ID for selected row
        db_get_by_id_func (callable): Function to fetch record by ID
        add_btn_id (str): Add/Update button ID
        delete_btn_wrapper_id (str): Wrapper ID for delete button (for style)
        date_fields (list): List of field names that are dates (optional)
        id_field_name (str): Name of the ID field in the record (default 'id')
        add_label (str): Label for add button
        update_label (str): Label for update button
    """
    from dash import callback, Input, Output, State, no_update
    from datetime import datetime, date
    if date_fields is None:
        date_fields = []
    # Allow explicit mapping from form field IDs to DB fields


    # Build outputs: use 'date' for date fields, 'value' for others
    output_props = [
        Output(fid, 'date' if form_field_map[fid] in date_fields else 'value', allow_duplicate=True)
        for fid in form_field_ids
    ]
    # Add Output for message output (parameterized)
    output_props += [
        Output(store_id, "data", allow_duplicate=True),
        Output(delete_btn_wrapper_id, "style", allow_duplicate=True),
        Output(add_btn_id, "children", allow_duplicate=True),
        Output(table_id, "selected_rows", allow_duplicate=True),
        Output(message_output_id, "children", allow_duplicate=True)
    ]
    @callback(
        output_props,
        [Input(table_id, "active_cell")],
        [State(table_id, "data"), State(store_id, "data")],
        prevent_initial_call=True
    )
    def _row_select_callback(active_cell, table_data, current_selected_id):
        # form_field_map: dict mapping form field id to db field name
        if form_field_map is None:
            raise ValueError("form_field_map must be provided explicitly for make_row_selection_callback; no fallback mapping is assumed.")
        if not active_cell:
            # Clear form, hide delete button, clear message
            return ["" for _ in form_field_ids] + [None, {"opacity": "0", "pointerEvents": "none"}, add_label, [], ""]
        row_index = active_cell["row"]
        selected_row = table_data[row_index]
        record_id = selected_row.get(id_field_name)
        if record_id == current_selected_id:
            # Deselect, clear message
            return ["" for _ in form_field_ids] + [None, {"opacity": "0", "pointerEvents": "none"}, add_label, [], ""]
        record_data = db_get_by_id_func(record_id)
        if record_data:
            values = []
            for fid in form_field_ids:
                if fid not in form_field_map:
                    raise KeyError(f"Missing mapping for form field id '{fid}' in form_field_map.")
                db_field = form_field_map[fid]
                val = record_data.get(db_field, "")
                if db_field in date_fields:
                    # If empty or None, set to None for datepicker; else, ensure string
                    val = val if val else None
                values.append(val)
            return values + [record_id, {"opacity": "1", "pointerEvents": "auto"}, update_label, [row_index], ""]
        # Clear form: use None for date fields, "" for others, clear message
        cleared = [None if form_field_map[fid] in date_fields else "" for fid in form_field_ids]
        return cleared + [None, {"opacity": "0", "pointerEvents": "none"}, add_label, [], ""]
    return _row_select_callback

def make_add_update_callback(
    form_field_ids,
    add_btn_id,
    store_id,
    db_add_func,
    db_update_func,
    table_id,
    id_field_name="id",
    add_label="Add Team Member",
    update_label="Update Team Member",
    required_fields=None,
    get_table_data_func=None,
    message_func=None,
    field_map=None,
    date_fields=None,
    message_output_id="team-member-message",
):
    """
    Generic callback factory for add/update logic in a Dash form/table.
    Args:
        form_field_ids (list): List of form field IDs (order matters)
        add_btn_id (str): Add/Update button ID
        store_id (str): dcc.Store ID for selected row
        db_add_func (callable): Function to add a record
        db_update_func (callable): Function to update a record
        table_id (str): DataTable component ID
        id_field_name (str): Name of the ID field in the record (default 'id')
        add_label (str): Label for add button
        update_label (str): Label for update button
        required_fields (list): List of required field names (optional)
        get_table_data_func (callable): Function to get all table data (optional)
        message_func (callable): Function to generate a message (optional)
        field_map (dict): Optional mapping from form field names to DB argument names.
    """
    from dash import callback, Input, Output, State, no_update, html
    from datetime import date
    if required_fields is None:
        required_fields = []
    if field_map is None:
        field_map = {}
    if date_fields is None:
        date_fields = []
    # Build outputs and states: use 'date' for date fields, 'value' for others
    output_props = [
        Output(fid, 'date' if field_map.get(fid, fid.split('-', 2)[-1]) in date_fields else 'value', allow_duplicate=True)
        for fid in form_field_ids
    ]
    output_props += [
        Output(store_id, "data", allow_duplicate=True),
        Output(message_output_id, 'children', allow_duplicate=True),
        Output(table_id, "data", allow_duplicate=True),
        Output(add_btn_id, "children", allow_duplicate=True)
    ]
    state_props = [
        State(fid, 'date' if field_map.get(fid, fid.split('-', 2)[-1]) in date_fields else 'value')
        for fid in form_field_ids
    ]
    state_props += [
        State(store_id, "data"),
        State(table_id, "data")
    ]
    @callback(
        output_props,
        [Input(add_btn_id, "n_clicks")],
        state_props,
        prevent_initial_call=True
    )
    def _add_update_callback(n_clicks, *args):
        if not n_clicks:
            return tuple([no_update] * (len(form_field_ids) + 4))
        *field_values, selected_id, table_data = args
        # Build record with mapping and handle date fields as string
        record = {}
        for fid, val in zip(form_field_ids, field_values):
            db_field = field_map.get(fid, fid.split("-", 2)[-1]) if field_map else fid.split("-", 2)[-1]
            # Convert date objects to string if needed
            if db_field in (date_fields or []):
                if hasattr(val, 'strftime'):
                    val = val.strftime("%Y-%m-%d")
            record[db_field] = val
        # Remove any keys not in the DB function signature
        add_func_params = inspect.signature(db_add_func).parameters
        record = {k: v for k, v in record.items() if k in add_func_params}
        # Validate required fields
        if required_fields and not all(record.get(f) for f in required_fields):
            return tuple(field_values) + (selected_id, create_feedback_message("Please fill in all required fields", 'error'), no_update, add_label)
        try:
            if selected_id:
                db_update_func(selected_id, **record)
                msg = "Team member updated successfully!"
            else:
                db_add_func(**record)
                msg = "Team member added successfully!"
            if get_table_data_func:
                fresh_data = get_table_data_func()
            else:
                fresh_data = table_data
            from datetime import date
            cleared = []
            for fid in form_field_ids:
                db_field = field_map.get(fid, fid.split('-', 2)[-1]) if field_map else fid.split('-', 2)[-1]
                if db_field in date_fields:
                    cleared.append(date.today().strftime('%Y-%m-%d'))
                else:
                    cleared.append("")
            return tuple(cleared) + (None, create_feedback_message(msg, 'success'), fresh_data, add_label)
        except Exception as e:
            return tuple(field_values) + (selected_id, create_feedback_message(f"Error: {str(e)}", 'error'), no_update, add_label)
    return _add_update_callback

def make_delete_modal_callback(
    delete_btn_id,
    modal_id,
    cancel_btn_id=None,
    confirm_btn_id=None,
    table_id=None,
    store_id=None,
    info_output_id=None,
    info_func=None,
):
    """
    Generic callback factory for delete modal open/close logic.
    Args:
        delete_btn_id (str): Delete button ID
        modal_id (str): Modal component ID
        cancel_btn_id (str): Cancel button ID (optional)
        confirm_btn_id (str): Confirm button ID (optional)
        table_id (str): DataTable ID (optional, for info_func)
        store_id (str): Store ID (optional, for info_func)
        info_output_id (str): Output ID for info (optional)
        info_func (callable): Function to generate info for modal (optional)
    """
    from dash import callback, Input, Output, State, no_update, html, callback_context
    inputs = [Input(delete_btn_id, "n_clicks")]
    if cancel_btn_id:
        inputs.append(Input(cancel_btn_id, "n_clicks"))
    if confirm_btn_id:
        inputs.append(Input(confirm_btn_id, "n_clicks"))
    states = []
    if table_id:
        states.append(State(table_id, "selected_rows"))
        states.append(State(table_id, "data"))
    if store_id:
        states.append(State(store_id, "data"))
    outputs = [Output(modal_id, "is_open")]
    if info_output_id:
        outputs.append(Output(info_output_id, "children"))
        outputs.append(Output(store_id, "data"))
    @callback(outputs, inputs, states, prevent_initial_call=True)
    def _toggle_modal(*args):
        ctx = callback_context
        triggered_id = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else None
        # Default outputs
        if info_output_id:
            default = (no_update, [], None)
        else:
            default = (no_update,)
        if triggered_id == delete_btn_id:
            if info_func and table_id and store_id:
                selected_rows, table_data = args[-3], args[-2]
                info, store_val = info_func(selected_rows, table_data)
                return (True, info, store_val)
            return (True,) + default[1:]
        elif cancel_btn_id and triggered_id == cancel_btn_id:
            return (False,) + default[1:]
        elif confirm_btn_id and triggered_id == confirm_btn_id:
            return (False,) + default[1:]
        return default
    return _toggle_modal

def make_delete_confirm_callback(
    confirm_btn_id,
    store_id,
    db_delete_func,
    table_id,
    get_table_data_func=None,
    info_output_id=None,
    message_output_id=None,
):
    """
    Generic callback factory for delete confirm logic.
    Args:
        confirm_btn_id (str): Confirm button ID
        store_id (str): Store ID for selected record
        db_delete_func (callable): Function to delete record
        table_id (str): DataTable ID
        get_table_data_func (callable): Function to get all table data (optional)
        info_output_id (str): Output ID for info (optional)
        message_output_id (str): Output ID for message (optional)
    """
    from dash import callback, Input, Output, State, no_update, html
    outputs = [Output(table_id, "data", allow_duplicate=True),
               Output(store_id, "data", allow_duplicate=True)]
    if info_output_id:
        outputs.append(Output(info_output_id, "children", allow_duplicate=True))
    if message_output_id:
        outputs.append(Output(message_output_id, "children", allow_duplicate=True))
    @callback(outputs, [Input(confirm_btn_id, "n_clicks")], [State(store_id, "data")], prevent_initial_call=True)
    def _delete_confirm(n_clicks, selected_id):
        if not n_clicks or not selected_id:
            return tuple([no_update] * len(outputs))
        try:
            db_delete_func(selected_id.get('id') if isinstance(selected_id, dict) else selected_id)
            if get_table_data_func:
                fresh_data = get_table_data_func()
            else:
                fresh_data = no_update
            out = [fresh_data, None]
            if info_output_id:
                out.append([])
            if message_output_id:
                out.append(create_feedback_message("✅ Deleted successfully!", 'success'))
            return tuple(out)
        except Exception as e:
            out = [no_update, None]
            if info_output_id:
                out.append([])
            if message_output_id:
                out.append(create_feedback_message(f"❌ Error deleting: {str(e)}", 'error'))
            return tuple(out)
    return _delete_confirm

def create_feedback_message(text, type_):
    """
    Returns a standardized feedback message Div using central CSS variables.
    type_: 'info', 'success', or 'error'
    """
    from dash import html
    style_map = {
        'info': {
            'color': 'var(--color-text-info)',
            'backgroundColor': 'var(--color-surface-info-primary)',
            'border': '1px solid var(--color-stroke-info-primary)',
        },
        'success': {
            'color': 'var(--color-text-success)',
            'backgroundColor': 'var(--color-surface-success-primary)',
            'border': '1px solid var(--color-stroke-success-primary)',
        },
        'error': {
            'color': 'var(--color-text-error)',
            'backgroundColor': 'var(--color-surface-error-primary)',
            'border': '1px solid var(--color-stroke-error-primary)',
        },
    }
    style = {
        **style_map.get(type_, style_map['info']),
        'padding': 'var(--spacing-8)',
        'borderRadius': 'var(--border-radius-small)',
        'fontSize': 'var(--font-size-small)'
    }
    return html.Div(text, style=style)
