import dash_bootstrap_components as dbc
from dash import html
from utils.create_card import create_card

def create_stats_card(title, value, subtitle=None, icon=None, color="primary", id=None, trend=None):
    """
    Creates a statistics card with value, optional subtitle, icon and trend indicator
    
    Parameters:
    -----------
    title : str
        Title of the stats card
    value : str
        Main value to display
    subtitle : str, optional
        Explanatory text below the value
    icon : str, optional
        Font Awesome icon class (e.g., "fas fa-users")
    color : str, optional
        Card accent color: primary, secondary, tertiary, success, warning, danger
    id : str, optional
        Component ID
    trend : dict, optional
        Dictionary with:
        - value: percentage value (e.g., "+12.5%")
        - direction: "up" or "down"
        - color: optional color name
        
    Returns:
    --------
    dbc.Card
        Statistics card component
    """
    # Prepare the trend indicator if provided
    trend_component = None
    if trend:
        trend_direction = trend.get("direction", "up")
        trend_color = trend.get("color", "success" if trend_direction == "up" else "danger")
        trend_icon = "fa-arrow-up" if trend_direction == "up" else "fa-arrow-down"
        
        # Custom color class instead of Bootstrap's text-{color}
        custom_class = "d-flex align-items-center"
        
        # Use CSS variables for text color
        text_color = {
            "success": "var(--color-text-success)",
            "warning": "var(--color-text-warning)",
            "danger": "var(--color-text-error)",
            "primary": "var(--color-accent-primary)",
            "secondary": "var(--color-accent-secondary)",
            "tertiary": "var(--color-accent-tertiary)",
            "info": "var(--color-viz-blue)"
        }.get(trend_color, "var(--color-text-success)" if trend_direction == "up" else "var(--color-text-error)")
        
        trend_style = {
            "font-size": "0.9rem", 
            "color": text_color
        }
        
        trend_component = html.Div(
            [
                html.I(className=f"fas {trend_icon} me-1"),
                html.Span(trend.get("value", "0%")),
            ],
            className=custom_class,
            style=trend_style
        )
    
    # Prepare the icon if provided
    icon_component = None
    if icon:
        # Custom color styles for the icon background
        bg_color = {
            "primary": "var(--color-accent-primary)",
            "secondary": "var(--color-accent-secondary)",
            "tertiary": "var(--color-accent-tertiary)",
            "success": "var(--color-surface-success-strong)",
            "warning": "var(--color-surface-warning-strong)",
            "danger": "var(--color-surface-error-strong)",
            "info": "var(--color-viz-blue)"
        }.get(color, "var(--color-accent-primary)")
        
        icon_component = html.Div(
            html.I(className=icon),
            style={
                "width": "48px", 
                "height": "48px", 
                "border-radius": "50%",
                "display": "flex",
                "align-items": "center",
                "justify-content": "center",
                "font-size": "1.5rem",
                "background-color": bg_color,
                "color": "var(--color-text-default)"
            }
        )
    
    # Card body content
    card_content = [
        # Title row
        html.Div(
            [
                html.H6(title, className="card-title text-muted mb-0"),
                icon_component if icon_component else None,
            ],
            className="d-flex justify-content-between align-items-center"
        ),
        
        # Value row
        html.Div(
            [
                html.H3(value, className="my-2", style={"font-weight": "600"}),
                trend_component if trend_component else None,
            ],
            className="d-flex justify-content-between align-items-center"
        ),
    ]
    
    # Add subtitle if provided
    if subtitle:
        card_content.append(
            html.P(subtitle, className="text-muted mb-0", style={"font-size": "0.9rem"})
        )
    
    # Card styles specific to stats cards
    card_style = {
        "height": "100%",
        "borderLeft": f"4px solid var(--color-accent-{color})"
    }
    
    # Use the generic create_card function
    return create_card(
        title="",  # No header for stats cards
        content=card_content,
        id=id,
        color=color,
        style=card_style,
        class_name="stats-card"
    )
