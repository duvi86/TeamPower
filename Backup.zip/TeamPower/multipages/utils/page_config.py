"""
Page configuration utilities for creating standardized pages
This module provides configuration templates and helpers for different page types.
"""

def create_simple_crud_page_config(
    page_title,
    path,
    navbar_tab,
    form_component,
    table_component,
    form_title=None,
    table_title=None,
    **kwargs
):
    """
    Create configuration for a simple CRUD page (form + table)
    
    Args:
        page_title (str): Title of the page
        path (str): URL path for the page
        navbar_tab (str): Active navbar tab name
        form_component (function): Function that creates the form
        table_component (function): Function that creates the table
        form_title (str, optional): Title for form card (defaults to "Add New {item}")
        table_title (str, optional): Title for table card (defaults to "{item} History")
        **kwargs: Additional configuration options
    
    Returns:
        dict: Page configuration
    """
    
    # Extract item name from page title for default titles
    item_name = page_title.replace('AI ', '').replace('Transactions', 'Transaction').replace('Projects', 'Project')
    
    if not form_title:
        form_title = f"Add New {item_name}"
    if not table_title:
        table_title = f"{item_name} History" if 'Transaction' in item_name else f"{item_name} Portfolio"
    
    config = {
        'page_title': page_title,
        'path': path,
        'page_id': path.replace('/', '').replace('-', '_') or 'default',  # Add unique page ID
        'navbar_tab': navbar_tab,
        'form_component': form_component,
        'table_component': table_component,
        'form_title': form_title,
        'table_title': table_title,
        'form_width': kwargs.get('form_width', '400px'),
        'min_table_width': kwargs.get('min_table_width', '800px'),
        'max_page_width': kwargs.get('max_page_width', '1600px'),
        'version': kwargs.get('version', '2.0.0')
    }
    
    return config

def create_tabbed_page_config(
    page_title,
    path,
    navbar_tab,
    tabs,
    **kwargs
):
    """
    Create configuration for a tabbed page with multiple form+table combinations
    
    Args:
        page_title (str): Title of the page
        path (str): URL path for the page
        navbar_tab (str): Active navbar tab name
        tabs (list): List of tab configurations, each containing:
            - id: Tab identifier
            - label: Tab display name
            - form_component: Function that creates the form
            - table_component: Function that creates the table
            - form_title: Title for form card
            - table_title: Title for table card
            - active: Whether this tab is active by default
        **kwargs: Additional configuration options
    
    Returns:
        dict: Page configuration
    """
    
    config = {
        'page_title': page_title,
        'path': path,
        'page_id': path.replace('/', '').replace('-', '_') or 'default',  # Add unique page ID
        'navbar_tab': navbar_tab,
        'tabs': tabs,
        'form_width': kwargs.get('form_width', '400px'),
        'min_table_width': kwargs.get('min_table_width', '800px'),
        'max_page_width': kwargs.get('max_page_width', '1600px'),
        'version': kwargs.get('version', '2.0.0')
    }
    
    return config

def create_dashboard_page_config(
    page_title,
    path,
    navbar_tab,
    dashboard_component,
    **kwargs
):
    """
    Create configuration for a dashboard-style page (single content area)
    
    Args:
        page_title (str): Title of the page
        path (str): URL path for the page
        navbar_tab (str): Active navbar tab name
        dashboard_component (function): Function that creates the dashboard content
        **kwargs: Additional configuration options
    
    Returns:
        dict: Page configuration
    """
    
    config = {
        'page_title': page_title,
        'path': path,
        'navbar_tab': navbar_tab,
        'dashboard_component': dashboard_component,
        'max_page_width': kwargs.get('max_page_width', '1600px'),
        'version': kwargs.get('version', '2.0.0')
    }
    
    return config

# Predefined configurations for common page types
def get_transactions_page_config():
    """Get configuration for transactions page"""
    from components.forms.transaction_form import create_transaction_form
    from components.tables.transactions_table import create_transactions_table
    
    return create_simple_crud_page_config(
        page_title='Config',
        path='/config',
        navbar_tab='Config',
        form_component=create_transaction_form,
        table_component=lambda: create_transactions_table([]),
        form_title='Add New Transaction',
        table_title='Transaction History'
    )

def get_projects_page_config():
    """Get configuration for projects page"""
    from components.forms.project_form import create_project_form
    from components.tables.projects_table import create_projects_table
    
    return create_simple_crud_page_config(
        page_title='AI Projects',
        path='/ai-projects', 
        navbar_tab='AI Projects',
        form_component=create_project_form,
        table_component=create_projects_table,
        form_title='Add New Project',
        table_title='Project Portfolio'
    )

def get_combined_transactions_projects_config():
    """Get configuration for combined transactions + projects tabbed page"""
    from components.forms.transaction_form import create_transaction_form
    from components.tables.transactions_table import create_transactions_table
    from components.forms.project_form import create_project_form
    from components.tables.projects_table import create_projects_table
    
    tabs = [
        {
            'id': 'transactions',
            'label': 'Transactions',
            'form_component': create_transaction_form,
            'table_component': lambda: create_transactions_table([]),
            'form_title': 'Add New Transaction',
            'table_title': 'Transaction History',
            'active': True
        },
        {
            'id': 'projects',
            'label': 'Projects',
            'form_component': create_project_form,
            'table_component': create_projects_table,
            'form_title': 'Add New Project',
            'table_title': 'Project Portfolio',
            'active': False
        }
    ]
    
    return create_tabbed_page_config(
        page_title='Transactions (Refactored)',
        path='/transactions-refactored',
        navbar_tab='Config',
        tabs=tabs
    )

# Validation function
def validate_page_config(config):
    """
    Validate a page configuration
    
    Args:
        config (dict): Page configuration to validate
    
    Returns:
        tuple: (is_valid, error_messages)
    """
    errors = []
    
    # Required fields
    required_fields = ['page_title', 'path', 'navbar_tab']
    for field in required_fields:
        if field not in config:
            errors.append(f"Missing required field: {field}")
    
    # Check for appropriate components based on page type
    if 'tabs' in config:
        # Tabbed page
        if not config.get('tabs'):
            errors.append("Tabbed page must have at least one tab")
        else:
            for i, tab in enumerate(config['tabs']):
                if 'form_component' not in tab and 'table_component' not in tab:
                    errors.append(f"Tab {i} must have at least form_component or table_component")
    elif 'dashboard_component' in config:
        # Dashboard page - no additional validation needed
        pass
    else:
        # Simple CRUD page
        if 'form_component' not in config and 'table_component' not in config:
            errors.append("Simple page must have at least form_component or table_component")
    
    return len(errors) == 0, errors
