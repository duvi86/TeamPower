from dash import Input, Output, State, callback, html
import sys
sys.path.append('/Users/md395378/TeamPowerGSK/TeamPower')
sys.path.append('/Users/md395378/TeamPowerGSK/TeamPower/multipages')
from pages.ai_financials import generate_dashboard_content
import plotly.express as px
import pandas as pd
sys.path.append('/Users/md395378/TeamPowerGSK/TeamPower')
from utils.db import get_transactions_df

@callback(
    Output("navbar-collapse", "is_open"),
    [Input("navbar-toggler", "n_clicks")],
    [State("navbar-collapse", "is_open")]
)
def toggle_navbar_collapse(n, is_open):
    if n:
        return not is_open
    return is_open

@callback(
    Output('dashboard-content', 'children'),
    [Input('year-selector', 'value')]
)
def update_dashboard_content(selected_year):
    """Update dashboard content when year selection changes"""
    if selected_year is None:
        # Use current year as default
        import pandas as pd
        selected_year = pd.Timestamp.now().year
    
    # Generate dashboard content for selected year
    return generate_dashboard_content(selected_year)

# Callback for year dropdown with transaction filters
@callback(
    Output('financial-bar-chart', 'figure'),
    [Input('year-selector', 'value')]
)
def update_financial_chart(selected_year):
    """Update financial bar chart with year selection"""
    if selected_year is None:
        selected_year = pd.Timestamp.now().year
    
    # Get transaction data for the selected year
    transactions_df = get_transactions_df()
    
    if transactions_df.empty:
        # Create empty figure
        figure = px.bar(title=f"No transaction data available for {selected_year}")
        return figure
    
    # Ensure Date column is datetime
    transactions_df['Date'] = pd.to_datetime(transactions_df['Date'])
    
    # Filter by year
    year_data = transactions_df[transactions_df['Date'].dt.year == selected_year]
    
    if year_data.empty:
        # Create empty figure for the selected year
        figure = px.bar(title=f"No transaction data available for {selected_year}")
        return figure
    
    # Group by category and sum amounts
    category_totals = year_data.groupby('Category')['Amount'].sum().reset_index()
    
    # Create bar chart
    figure = px.bar(category_totals, 
                   x='Category', 
                   y='Amount',
                   title=f'Transaction Categories - {selected_year}',
                   labels={'Amount': 'Total Amount ($)', 'Category': 'Transaction Category'})
    
    figure.update_layout(
        showlegend=False,
        height=400,
        margin=dict(t=50, b=50, l=50, r=50)
    )
    
    return figure

# All transaction management callbacks have been removed for the simplified form-only page
# They can be re-added when full transaction management functionality is needed
