"""
Centralized Chart Configuration Management
Provides default configurations and themes for all chart components
Uses GSK Design System with CSS variable references
"""

# CSS Variable to Hex Color Mapping (fallbacks for Plotly)
# These provide fallback colors when CSS variables can't be used directly
CSS_VAR_FALLBACKS = {
    'var(--color-accent-primary)': '#FF6900',
    'var(--color-accent-secondary)': '#21837E',
    'var(--color-accent-tertiary)': '#6A6A6A',
    'var(--color-success-strong)': '#448422',
    'var(--color-warning-strong)': '#FFC709',
    'var(--color-error-strong)': '#C83629',
    'var(--color-info-strong)': '#1F75CB',
    'var(--color-text-default)': '#151515',
    'var(--color-text-subtle)': '#464646',
    'var(--color-text-muted)': '#6A6A6A',
    'var(--color-background-primary)': '#FFFFFF',
    'var(--color-background-secondary)': '#F8F8F8',
    'var(--color-border-default)': '#D8D7D5',
    'var(--chart-color-1)': '#FF6900',
    'var(--chart-color-2)': '#21837E',
    'var(--chart-color-3)': '#1F75CB',
    'var(--chart-color-4)': '#448422',
    'var(--chart-color-5)': '#FFC709',
    'var(--chart-color-6)': '#C83629',
    'var(--chart-color-7)': '#6A6A6A',
    'var(--chart-color-8)': '#9B59B6',
}

def resolve_css_var(css_var):
    """
    Resolve CSS variable to actual color value for Plotly compatibility
    
    Args:
        css_var: CSS variable string (e.g., 'var(--color-primary)')
    
    Returns:
        Hex color code or original value if not a CSS variable
    """
    if isinstance(css_var, str) and css_var.startswith('var('):
        return CSS_VAR_FALLBACKS.get(css_var, css_var)
    return css_var

def resolve_color_sequence(color_sequence):
    """
    Resolve a sequence of CSS variables to actual colors for Plotly
    
    Args:
        color_sequence: List of color values (may include CSS variables)
    
    Returns:
        List of resolved color values
    """
    return [resolve_css_var(color) for color in color_sequence]

# GSK Design System Color Palette - Using CSS Variables
GSK_COLORS = {
    # Primary Brand Colors - Reference CSS variables
    'primary': 'var(--color-accent-primary)',           # GSK Orange
    'secondary': 'var(--color-accent-secondary)',       # GSK Teal
    'accent': 'var(--color-accent-tertiary)',          # GSK Grey
    
    # Status Colors - Reference CSS variables
    'success': 'var(--color-success-strong)',          # GSK Success Strong
    'warning': 'var(--color-warning-strong)',          # GSK Warning Strong
    'error': 'var(--color-error-strong)',             # GSK Error Strong
    'info': 'var(--color-info-strong)',               # GSK Info Strong
    
    # Neutral Colors - Reference CSS variables
    'text_primary': 'var(--color-text-default)',       # GSK Text Default
    'text_secondary': 'var(--color-text-subtle)',      # GSK Text Subtle
    'text_muted': 'var(--color-text-muted)',          # GSK Text Muted
    'background': 'var(--color-background-primary)',   # GSK Background Primary
    'surface': 'var(--color-background-secondary)',    # GSK Background Secondary
    'border': 'var(--color-border-default)',          # GSK Border Default
    
    # Data Visualization Palette - Use CSS chart variables
    'viz_primary': 'var(--chart-color-1)',            # Orange
    'viz_secondary': 'var(--chart-color-2)',          # Teal
    'viz_tertiary': 'var(--chart-color-3)',           # Blue
    'viz_quaternary': 'var(--chart-color-4)',         # Green
    'viz_quinary': 'var(--chart-color-5)',            # Yellow
    'viz_senary': 'var(--chart-color-6)',             # Red
    'viz_septenary': 'var(--chart-color-7)',          # Grey
    'viz_octonary': 'var(--chart-color-8)',           # Purple
}

# Chart Color Sequences - Using CSS chart variables
GSK_COLOR_SEQUENCES = {
    'primary': [
        'var(--chart-color-1)',     # Orange
        'var(--chart-color-2)',     # Teal
        'var(--chart-color-3)',     # Blue
        'var(--chart-color-4)',     # Green
        'var(--chart-color-5)',     # Yellow
        'var(--chart-color-6)',     # Red
        'var(--chart-color-7)',     # Grey
        'var(--chart-color-8)'      # Purple
    ],
    'status': [
        'var(--color-success-strong)',
        'var(--color-warning-strong)',
        'var(--color-error-strong)',
        'var(--color-info-strong)'
    ],
    'monochrome': [
        'var(--color-text-default)', 
        'var(--color-text-subtle)', 
        'var(--color-text-muted)', 
        'var(--color-border-strong)',
        'var(--color-border-default)', 
        'var(--color-border-subtle)', 
        'var(--color-background-tertiary)', 
        'var(--color-background-secondary)'
    ]
}

# Typography Configuration - Reference CSS custom properties
GSK_TYPOGRAPHY = {
    'font_family': 'var(--font-family-base)',        # GSK Precision
    'font_family_bold': 'var(--font-family-bold)',   # GSK Precision Bold
    'font_size_small': 'var(--font-size-sm)',        # 10px
    'font_size_regular': 'var(--font-size-base)',    # 12px
    'font_size_medium': 'var(--font-size-md)',       # 14px
    'font_size_large': 'var(--font-size-lg)',        # 16px
    'font_size_title': 'var(--font-size-xl)',        # 18px
    'font_size_heading': 'var(--font-size-2xl)',     # 20px
}

# Base Chart Configuration Templates - Using GSK Design System references
BASE_CHART_CONFIG = {
    'common': {
        'font_family': GSK_TYPOGRAPHY['font_family'],
        'font_size': 12,  # Fallback for Plotly - CSS vars don't work in Plotly directly
        'title_font_family': GSK_TYPOGRAPHY['font_family_bold'],
        'title_font_size': 18,  # Fallback for Plotly
        'title_color': GSK_COLORS['text_primary'],
        'background_color': 'rgba(0,0,0,0)',  # Transparent to use CSS background
        'paper_color': 'rgba(0,0,0,0)',       # Transparent to use CSS background
        'grid_color': GSK_COLORS['border'],
        'axis_color': GSK_COLORS['text_secondary'],
        'axis_title_size': 14,  # Fallback for Plotly
    },
    
    'margins': {
        'default': {'t': 80, 'b': 60, 'l': 60, 'r': 20},
        'compact': {'t': 60, 'b': 40, 'l': 40, 'r': 20},
        'expanded': {'t': 120, 'b': 80, 'l': 80, 'r': 40},
        'legend_top': {'t': 140, 'b': 60, 'l': 60, 'r': 20},
    },
    
    'legend': {
        'orientation': 'h',
        'x': 0.5,
        'xanchor': 'center',
        'y': 0.98,
        'yanchor': 'top',
        'bgcolor': 'rgba(255,255,255,0.9)',  # Semi-transparent white
        'bordercolor': GSK_COLORS['border'],
        'borderwidth': 1,
        'font': {'size': 12}  # Fallback for Plotly
    },
    
    'hover': {
        'bgcolor': GSK_COLORS['background'],
        'bordercolor': GSK_COLORS['border'],
        'font': {'size': 12},  # Fallback for Plotly
    }
}

# Chart-Specific Default Configurations
CHART_DEFAULTS = {
    'line_chart': {
        **BASE_CHART_CONFIG['common'],
        'height': 400,
        'margin': BASE_CHART_CONFIG['margins']['default'],
        'show_legend': True,
        'legend_orientation': 'h',  # Add missing legend_orientation
        'legend_y': 0.98,           # Add missing legend_y
        'legend_yanchor': 'top',    # Add missing legend_yanchor
        'show_markers': True,
        'line_width': 2,
        'marker_size': 6,
        'line_color': GSK_COLORS['border'],  # Add missing line_color for axis lines
        'color_sequence': GSK_COLOR_SEQUENCES['primary'],
        'hover_template': '<b>%{fullData.name}</b><br>%{x}: %{y}<extra></extra>',
        'x_title': 'X Axis',
        'y_title': 'Y Axis',
    },
    
    'bar_chart': {
        **BASE_CHART_CONFIG['common'],
        'height': 400,
        'margin': BASE_CHART_CONFIG['margins']['default'],
        'show_legend': False,
        'orientation': 'v',
        'bar_mode': 'group',  # Add missing bar_mode
        'color': GSK_COLORS['viz_primary'],  # Reference CSS variable
        'color_sequence': GSK_COLOR_SEQUENCES['primary'],
        'bar_gap': 0.2,
        'show_values_on_bars': False,
        'hover_template': '<b>%{x}</b><br>Value: %{y}<extra></extra>',
        'x_title': 'Categories',
        'y_title': 'Values',
    },
    
    'stacked_bar_chart': {
        **BASE_CHART_CONFIG['common'],
        'height': 400,
        'margin': BASE_CHART_CONFIG['margins']['legend_top'],
        'show_legend': True,
        'legend_orientation': 'h',
        'legend_y': 0.98,
        'legend_yanchor': 'top',
        'orientation': 'v',
        'color_sequence': GSK_COLOR_SEQUENCES['primary'],
        'bar_gap': 0.1,
        'hover_template': '<b>%{fullData.name}</b><br>%{x}: %{y}<extra></extra>',
        'x_title': 'Categories',
        'y_title': 'Values',
    },
    
    'sunburst_chart': {
        **BASE_CHART_CONFIG['common'],
        'height': 500,
        'margin': BASE_CHART_CONFIG['margins']['compact'],
        'color_sequence': GSK_COLOR_SEQUENCES['primary'],
        'maxdepth': 3,
        'line_color': 'white',
        'line_width': 2,
        'hover_template': '<b>%{label}</b><br>Count: %{value}<extra></extra>',
    },
    
    'gauge_chart': {
        **BASE_CHART_CONFIG['common'],
        'height': 300,
        'margin': BASE_CHART_CONFIG['margins']['compact'],
        'min_value': 0,
        'max_value': 1,
        'threshold_colors': {
            'low': GSK_COLORS['error'],      # CSS variable reference
            'medium': GSK_COLORS['warning'], # CSS variable reference
            'high': GSK_COLORS['success']    # CSS variable reference
        },
        'gauge_color': GSK_COLORS['surface'],     # CSS variable reference
        'needle_color': GSK_COLORS['text_primary'], # CSS variable reference
        'text_color': GSK_COLORS['text_primary'],   # CSS variable reference
    }
}

# Theme Configurations
CHART_THEMES = {
    'default': {
        'colors': GSK_COLOR_SEQUENCES['primary'],
        'background': GSK_COLORS['background'],
        'text_color': GSK_COLORS['text_primary'],
        'grid_color': GSK_COLORS['border'],
    },
    
    'dark': {
        'colors': GSK_COLOR_SEQUENCES['primary'],
        'background': '#1a1a1a',
        'text_color': '#ffffff',
        'grid_color': '#404040',
    },
    
    'high_contrast': {
        'colors': ['#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF'],
        'background': '#FFFFFF',
        'text_color': '#000000',
        'grid_color': '#808080',
    },
    
    'print': {
        'colors': GSK_COLOR_SEQUENCES['monochrome'],
        'background': '#FFFFFF',
        'text_color': '#000000',
        'grid_color': '#CCCCCC',
    }
}

# Utility Functions
def get_chart_config(chart_type, custom_config=None, theme='default'):
    """
    Get complete configuration for a chart type with CSS variable resolution
    
    Args:
        chart_type: Type of chart ('line_chart', 'bar_chart', etc.)
        custom_config: Custom configuration overrides
        theme: Theme name ('default', 'dark', 'high_contrast', 'print')
    
    Returns:
        Complete configuration dictionary with resolved CSS variables for Plotly
    """
    if chart_type not in CHART_DEFAULTS:
        raise ValueError(f"Unknown chart type: {chart_type}")
    
    # Start with chart defaults
    config = CHART_DEFAULTS[chart_type].copy()
    
    # Apply theme
    if theme in CHART_THEMES:
        theme_config = CHART_THEMES[theme]
        config.update({
            'color_sequence': theme_config['colors'],
            'background_color': theme_config['background'],
            'paper_color': theme_config['background'],
            'title_color': theme_config['text_color'],
            'axis_color': theme_config['text_color'],
            'grid_color': theme_config['grid_color'],
        })
    
    # Apply custom overrides
    if custom_config:
        config.update(custom_config)
    
    # Resolve CSS variables for Plotly compatibility
    config = _resolve_config_colors(config)
    
    return config

def _resolve_config_colors(config):
    """
    Recursively resolve CSS variables in configuration
    
    Args:
        config: Configuration dictionary
    
    Returns:
        Configuration with resolved CSS variables
    """
    resolved_config = {}
    
    for key, value in config.items():
        if isinstance(value, str) and value.startswith('var('):
            resolved_config[key] = resolve_css_var(value)
        elif isinstance(value, list):
            resolved_config[key] = resolve_color_sequence(value)
        elif isinstance(value, dict):
            resolved_config[key] = _resolve_config_colors(value)
        else:
            resolved_config[key] = value
    
    return resolved_config

def get_color_sequence(sequence_name='primary', count=None):
    """
    Get a color sequence for charts
    
    Args:
        sequence_name: Name of color sequence
        count: Number of colors needed (will cycle if more than available)
    
    Returns:
        List of color codes
    """
    if sequence_name not in GSK_COLOR_SEQUENCES:
        sequence_name = 'primary'
    
    colors = GSK_COLOR_SEQUENCES[sequence_name]
    
    if count is None:
        return colors
    
    if count <= len(colors):
        return colors[:count]
    else:
        # Cycle through colors if more needed
        return [colors[i % len(colors)] for i in range(count)]

def get_status_color(status):
    """Get appropriate color for status values using CSS variables"""
    status_map = {
        'active': GSK_COLORS['success'],
        'success': GSK_COLORS['success'],
        'good': GSK_COLORS['success'],
        'on_leave': GSK_COLORS['warning'],
        'warning': GSK_COLORS['warning'],
        'pending': GSK_COLORS['warning'],
        'inactive': GSK_COLORS['error'],
        'error': GSK_COLORS['error'],
        'failed': GSK_COLORS['error'],
        'info': GSK_COLORS['info'],
        'default': GSK_COLORS['accent'],
    }
    
    return status_map.get(status.lower(), GSK_COLORS['accent'])
