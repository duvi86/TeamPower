"""
Centralized Layout Management System
Provides reusable layout templates and grid systems
"""

import dash_bootstrap_components as dbc
from dash import html

# Standard Layout Templates
LAYOUT_TEMPLATES = {
    'single_column': {
        'columns': [12],
        'responsive': {'lg': [12], 'md': [12], 'sm': [12]}
    },
    
    'two_column_equal': {
        'columns': [6, 6],
        'responsive': {'lg': [6, 6], 'md': [12, 12], 'sm': [12, 12]}
    },
    
    'two_column_sidebar': {
        'columns': [8, 4],
        'responsive': {'lg': [8, 4], 'md': [12, 12], 'sm': [12, 12]}
    },
    
    'three_column_equal': {
        'columns': [4, 4, 4],
        'responsive': {'lg': [4, 4, 4], 'md': [6, 6, 12], 'sm': [12, 12, 12]}
    },
    
    'dashboard_grid': {
        'columns': [3, 3, 3, 3],
        'responsive': {'xl': [3, 3, 3, 3], 'lg': [6, 6, 6, 6], 'md': [12, 12, 12, 12], 'sm': [12, 12, 12, 12]}
    },
    
    'hero_section': {
        'columns': [12],
        'responsive': {'lg': [12], 'md': [12], 'sm': [12]},
        'style': {'min-height': '60vh', 'display': 'flex', 'align-items': 'center'}
    }
}

# Container Classes
CONTAINER_CLASSES = {
    'page': 'page-container',
    'section': 'section-spacing',
    'content': 'centered-content',
    'card': 'custom-card-body',
    'full_width': 'container-fluid',
    'constrained': 'container',
    'narrow': 'container-sm'
}

# Spacing Utilities
SPACING = {
    'none': 0,
    'xs': 1,
    'sm': 2,
    'md': 3,
    'lg': 4,
    'xl': 5
}

def create_responsive_layout(template_name, content_items, spacing='md', container_class='page'):
    """
    Create a responsive layout using predefined templates
    
    Args:
        template_name: Name of layout template
        content_items: List of content elements for each column
        spacing: Spacing between elements ('xs', 'sm', 'md', 'lg', 'xl')
        container_class: Container wrapper class
    
    Returns:
        Dash layout component
    """
    if template_name not in LAYOUT_TEMPLATES:
        raise ValueError(f"Unknown layout template: {template_name}")
    
    template = LAYOUT_TEMPLATES[template_name]
    responsive = template['responsive']
    
    # Ensure we have content for each column
    if len(content_items) > len(template['columns']):
        raise ValueError(f"Too many content items for template {template_name}")
    
    # Pad content_items if fewer than columns
    while len(content_items) < len(template['columns']):
        content_items.append(html.Div())
    
    # Create columns
    columns = []
    for i, content in enumerate(content_items):
        col_props = {
            'children': content,
            'width': template['columns'][i],
            'className': f'mb-{SPACING[spacing]}'
        }
        
        # Add responsive breakpoints
        for breakpoint, widths in responsive.items():
            if i < len(widths):
                col_props[breakpoint] = widths[i]
        
        columns.append(dbc.Col(**col_props))
    
    # Apply custom style if specified
    row_props = {'children': columns}
    if 'style' in template:
        row_props['style'] = template['style']
    
    layout = html.Div([
        dbc.Row(**row_props)
    ], className=CONTAINER_CLASSES.get(container_class, container_class))
    
    return layout

def create_dashboard_grid(cards, columns_per_row=4, spacing='md'):
    """
    Create a responsive dashboard grid layout
    
    Args:
        cards: List of card components
        columns_per_row: Number of columns per row
        spacing: Spacing between cards
    
    Returns:
        Dash layout with cards in responsive grid
    """
    # Calculate responsive column widths
    col_width_xl = 12 // columns_per_row
    col_width_lg = 12 // min(columns_per_row, 3)
    col_width_md = 12 // min(columns_per_row, 2)
    col_width_sm = 12
    
    rows = []
    for i in range(0, len(cards), columns_per_row):
        row_cards = cards[i:i + columns_per_row]
        
        columns = []
        for card in row_cards:
            columns.append(
                dbc.Col(
                    card,
                    width=col_width_sm,
                    sm=col_width_sm,
                    md=col_width_md,
                    lg=col_width_lg,
                    xl=col_width_xl,
                    className=f'mb-{SPACING[spacing]}'
                )
            )
        
        rows.append(dbc.Row(columns, className=f'g-{SPACING[spacing]}'))
    
    return html.Div(rows)

def create_hero_section(title, subtitle=None, actions=None, background_class='bg-light'):
    """
    Create a hero section with title, subtitle, and optional actions
    
    Args:
        title: Main title text
        subtitle: Optional subtitle text
        actions: Optional list of action buttons/components
        background_class: CSS class for background styling
    
    Returns:
        Hero section layout
    """
    content = [
        html.H1(title, className='display-4 fw-bold text-center mb-3'),
    ]
    
    if subtitle:
        content.append(
            html.P(subtitle, className='lead text-center mb-4')
        )
    
    if actions:
        content.append(
            html.Div(
                actions,
                className='d-flex justify-content-center gap-3 flex-wrap'
            )
        )
    
    return html.Div([
        html.Div(
            content,
            className='d-flex flex-column justify-content-center align-items-center h-100'
        )
    ], className=f'{background_class} py-5', style={'min-height': '60vh'})

def create_section_header(title, subtitle=None, actions=None, divider=True):
    """
    Create a standardized section header
    
    Args:
        title: Section title
        subtitle: Optional subtitle/description
        actions: Optional action buttons
        divider: Whether to include a divider line
    
    Returns:
        Section header layout
    """
    header_content = []
    
    # Title row
    title_row = html.Div([
        html.H2(title, className='mb-0 d-inline-block'),
        html.Div(actions or [], className='d-inline-block ms-auto') if actions else None
    ], className='d-flex align-items-center justify-content-between mb-2')
    
    header_content.append(title_row)
    
    if subtitle:
        header_content.append(
            html.P(subtitle, className='text-muted mb-3')
        )
    
    if divider:
        header_content.append(
            html.Hr(className='custom-divider mb-4')
        )
    
    return html.Div(header_content, className='section-header')

def create_tabs_layout(tabs_config, default_tab=None, tab_style='default'):
    """
    Create a standardized tabs layout
    
    Args:
        tabs_config: List of dicts with 'label', 'tab_id', and optional 'disabled'
        default_tab: Default active tab ID
        tab_style: Tab styling ('default', 'pills', 'underline')
    
    Returns:
        Tabs component and content div
    """
    tabs = []
    for config in tabs_config:
        tab_props = {
            'label': config['label'],
            'tab_id': config['tab_id']
        }
        if config.get('disabled'):
            tab_props['disabled'] = True
        
        tabs.append(dbc.Tab(**tab_props))
    
    # Set default active tab
    active_tab = default_tab or tabs_config[0]['tab_id']
    
    # Tab styling classes
    tab_classes = {
        'default': 'mb-4',
        'pills': 'nav-pills mb-4',
        'underline': 'nav-underline mb-4'
    }
    
    tabs_component = dbc.Tabs(
        tabs,
        id='section-tabs',
        active_tab=active_tab,
        className=tab_classes.get(tab_style, 'mb-4')
    )
    
    content_div = html.Div(id='tab-content')
    
    return tabs_component, content_div

def create_metric_card(title, value, subtitle=None, trend=None, color='primary'):
    """
    Create a standardized metric card
    
    Args:
        title: Card title
        value: Main metric value
        subtitle: Optional subtitle/description
        trend: Optional trend indicator (dict with 'value', 'direction', 'color')
        color: Color theme for the card
    
    Returns:
        Metric card component
    """
    card_content = [
        html.H6(title, className='card-subtitle mb-2 text-muted')
    ]
    
    # Main value with optional trend
    value_row = [
        html.H2(str(value), className=f'card-title mb-0 text-{color}')
    ]
    
    if trend:
        trend_icon = '↑' if trend['direction'] == 'up' else '↓' if trend['direction'] == 'down' else '→'
        trend_class = f"text-{trend.get('color', 'muted')} ms-2 small"
        value_row.append(
            html.Span([
                html.I(className=f'fas fa-arrow-{trend["direction"]} me-1'),
                str(trend['value'])
            ], className=trend_class)
        )
    
    card_content.append(html.Div(value_row, className='d-flex align-items-center'))
    
    if subtitle:
        card_content.append(
            html.P(subtitle, className='card-text small text-muted mt-2')
        )
    
    return dbc.Card([
        dbc.CardBody(card_content)
    ], className='shadow-sm border-0 h-100')

def create_info_panel(title, content, panel_type='info', dismissible=False):
    """
    Create an information panel/alert
    
    Args:
        title: Panel title
        content: Panel content (text or components)
        panel_type: Panel type ('info', 'warning', 'success', 'error')
        dismissible: Whether panel can be dismissed
    
    Returns:
        Alert/panel component
    """
    color_map = {
        'info': 'info',
        'warning': 'warning',
        'success': 'success',
        'error': 'danger'
    }
    
    icon_map = {
        'info': 'fa-info-circle',
        'warning': 'fa-exclamation-triangle',
        'success': 'fa-check-circle',
        'error': 'fa-times-circle'
    }
    
    panel_content = [
        html.Div([
            html.I(className=f'fas {icon_map[panel_type]} me-2'),
            html.Strong(title)
        ], className='d-flex align-items-center mb-2')
    ]
    
    if isinstance(content, str):
        panel_content.append(html.P(content, className='mb-0'))
    else:
        panel_content.append(content)
    
    return dbc.Alert(
        panel_content,
        color=color_map[panel_type],
        dismissable=dismissible,
        className='border-0 shadow-sm'
    )
