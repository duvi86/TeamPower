from multipages.utils.callback_utils import (
    make_clear_duplicate_button_text_callback, make_clear_duplicate_form_callback, make_export_csv_callback, make_search_callback
)
"""
Transaction tab callbacks using generic factories from callback_utils.py
"""
from dash import callback, Input, Output, State, html, no_update
from db_management.db import add_transaction, update_transaction, delete_transaction, get_transaction_by_id, get_transactions
from multipages.utils.callback_utils import make_row_selection_callback, make_add_update_callback, make_delete_modal_callback, make_delete_confirm_callback

TRANSACTION_FORM_FIELD_IDS = [
    'transaction-date',
    'transaction-description',
    'transaction-amount',
    'transaction-cost-center-project',
    'transaction-cost-center-sow',
    'transaction-sow-number',
    'transaction-po-number',
    'transaction-category',
    'transaction-type',
    'transaction-project-bottom',
]

def transaction_delete_info(selected_rows, table_data):
    if selected_rows and table_data:
        idx = selected_rows[0]
        transaction = table_data[idx]
        info = html.Div([
            html.P(f"Date: {transaction.get('date', 'Unknown')}", style={"fontWeight": "bold"}),
            html.P(f"Description: {transaction.get('description', '')}"),
            html.P(f"Amount: {transaction.get('amount', '')}"),
            html.P(f"Project: {transaction.get('project', '')}")
        ])
        return info, transaction.get('id')
    return [], None

# Delete modal callback
make_delete_modal_callback(
    delete_btn_id='delete-form-btn',
    modal_id='transactions-table-delete-modal',
    cancel_btn_id='transactions-table-cancel-delete',
    confirm_btn_id='transactions-table-confirm-delete',
    table_id='transactions-table-datatable',
    store_id='selected-transaction-store',
    info_output_id='transactions-table-delete-info',
    info_func=transaction_delete_info,
)

# Delete confirm callback
make_delete_confirm_callback(
    confirm_btn_id='transactions-table-confirm-delete',
    store_id='selected-transaction-store',
    db_delete_func=delete_transaction,
    table_id='transactions-table-datatable',
    get_table_data_func=get_transactions,
    info_output_id='transactions-table-delete-info',
    message_output_id='transaction-message',
)

# Add/Update callback
make_add_update_callback(
    form_field_ids=TRANSACTION_FORM_FIELD_IDS,
    add_btn_id='add-transaction-btn',
    store_id='selected-transaction-store',
    db_add_func=add_transaction,
    db_update_func=update_transaction,
    table_id='transactions-table-datatable',
    id_field_name='id',
    add_label='Add Transaction',
    update_label='Update Transaction',
    required_fields=['date', 'amount', 'project_id'],
    get_table_data_func=get_transactions,
    message_func=None,
    field_map={
        'transaction-date': 'date',
        'transaction-description': 'description',
        'transaction-amount': 'amount',
        'transaction-cost-center-project': 'cost_center_project',
        'transaction-cost-center-sow': 'cost_center_sow',
        'transaction-sow-number': 'sow_number',
        'transaction-po-number': 'po',
        'transaction-category': 'category',
        'transaction-type': 'type',
        'transaction-project-bottom': 'project_id',
    },
    date_fields=['date'],
    message_output_id='transaction-message',
)

make_clear_duplicate_button_text_callback(
    clear_btn_id='clear-form-btn',
    store_id='selected-transaction-store',
    label_clear='Clear',
    label_duplicate='Duplicate'
)

make_clear_duplicate_form_callback(
    clear_btn_id='clear-form-btn',
    form_field_ids=TRANSACTION_FORM_FIELD_IDS,
    store_id='selected-transaction-store',
    add_btn_id='add-transaction-btn',
    delete_btn_wrapper_id='delete-btn-wrapper',
    message_output_id='transaction-message',
    add_label='Add Transaction',
    duplicate_message="Form data preserved for new transaction",
    clear_message="Form cleared",
    date_fields=['date']
)

make_row_selection_callback(
    table_id='transactions-table-datatable',
    form_field_ids=TRANSACTION_FORM_FIELD_IDS,
    store_id='selected-transaction-store',
    db_get_by_id_func=get_transaction_by_id,
    add_btn_id='add-transaction-btn',
    delete_btn_wrapper_id='delete-btn-wrapper',
    date_fields=['date'],
    id_field_name='id',
    add_label='Add Transaction',
    update_label='Update Transaction',
    form_field_map={
        'transaction-date': 'date',
        'transaction-description': 'description',
        'transaction-amount': 'amount',
        'transaction-cost-center-project': 'cost_center_project',
        'transaction-cost-center-sow': 'cost_center_sow',
        'transaction-sow-number': 'sow_number',
        'transaction-po-number': 'po',
        'transaction-category': 'category',
        'transaction-type': 'type',
        'transaction-project-bottom': 'project_id',
    },
    message_output_id='transaction-message'
)

make_export_csv_callback(
    export_btn_id='transactions-table-export-csv',
    table_id='transactions-table-datatable',
    download_id='transactions-table-download-csv',
    filename='transactions_export.csv'
)

make_search_callback(
    search_input_id='transactions-table-search',
    table_id='transactions-table-datatable',
    get_data_func=get_transactions,
    search_fields=['date', 'description', 'amount', 'project']
)
