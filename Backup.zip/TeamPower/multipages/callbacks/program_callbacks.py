from multipages.utils.callback_utils import (
    make_clear_duplicate_button_text_callback, make_clear_duplicate_form_callback, make_export_csv_callback, make_search_callback
)
"""
Program tab callbacks using generic factories from callback_utils.py
"""
from dash import callback, Input, Output, State, html, no_update
from db_management.program_db import add_program, update_program, delete_program, get_program_by_id
from components.tables.programs_table import get_programs_data
from multipages.utils.callback_utils import make_row_selection_callback, make_add_update_callback, make_delete_modal_callback, make_delete_confirm_callback

PROGRAM_FORM_FIELD_IDS = [
    'programs-table-name',
    'programs-table-description',
    'programs-table-start-date',
    'programs-table-end-date',
    'programs-table-status',
    'programs-table-owner',
]

def program_delete_info(selected_rows, table_data):
    if selected_rows and table_data:
        idx = selected_rows[0]
        program = table_data[idx]
        owner_display = program.get('owner') or program.get('owner_name') or program.get('owner_id', '')
        info = html.Div([
            html.P(f"Program Name: {program.get('name', 'Unknown')}", style={"fontWeight": "bold"}),
            html.P(f"Description: {program.get('description', '')}"),
            html.P(f"Status: {program.get('status', '')}"),
            html.P(f"Owner: {owner_display}")
        ])
        return info, program.get('id')
    return [], None

# Delete modal callback
make_delete_modal_callback(
    delete_btn_id='delete-programs-table-btn',
    modal_id='programs-table-delete-modal',
    cancel_btn_id='programs-table-cancel-delete',
    confirm_btn_id='programs-table-confirm-delete',
    table_id='programs-table-datatable',
    store_id='selected-programs-table-store',
    info_output_id='programs-table-delete-info',
    info_func=program_delete_info,
)

# Delete confirm callback
make_delete_confirm_callback(
    confirm_btn_id='programs-table-confirm-delete',
    store_id='selected-programs-table-store',
    db_delete_func=delete_program,
    table_id='programs-table-datatable',
    get_table_data_func=get_programs_data,
    info_output_id='programs-table-delete-info',
    message_output_id='programs-table-message',
)

# Add/Update callback
make_add_update_callback(
    form_field_ids=[
        'programs-table-name',
        'programs-table-description',
        'programs-table-start-date',
        'programs-table-end-date',
        'programs-table-status',
        'programs-table-owner',
    ],
    add_btn_id='add-programs-table-btn',
    store_id='selected-programs-table-store',
    db_add_func=add_program,
    db_update_func=update_program,
    table_id='programs-table-datatable',
    id_field_name='id',
    add_label='Add Program',
    update_label='Update Program',
    required_fields=['name', 'status'],
    get_table_data_func=get_programs_data,
    message_func=None,
    field_map={
        'programs-table-name': 'name',
        'programs-table-description': 'description',
        'programs-table-start-date': 'start_date',
        'programs-table-end-date': 'end_date',
        'programs-table-status': 'status',
        'programs-table-owner': 'owner_id',
    },
    date_fields=['start_date', 'end_date'],
    message_output_id='programs-table-message',
)

make_clear_duplicate_button_text_callback(
    clear_btn_id='clear-programs-table-form-btn',
    store_id='selected-programs-table-store',
    label_clear='Clear',
    label_duplicate='Duplicate'
)

make_clear_duplicate_form_callback(
    clear_btn_id='clear-programs-table-form-btn',
    form_field_ids=PROGRAM_FORM_FIELD_IDS,
    store_id='selected-programs-table-store',
    add_btn_id='add-programs-table-btn',
    delete_btn_wrapper_id='delete-programs-table-btn-wrapper',
    message_output_id='programs-table-message',
    add_label='Add Program',
    duplicate_message="Form data preserved for new program",
    clear_message="Form cleared",
    date_fields=['start-date', 'end-date']
)

make_row_selection_callback(
    table_id='programs-table-datatable',
    form_field_ids=PROGRAM_FORM_FIELD_IDS,
    store_id='selected-programs-table-store',
    db_get_by_id_func=get_program_by_id,
    add_btn_id='add-programs-table-btn',
    delete_btn_wrapper_id='delete-programs-table-btn-wrapper',
    date_fields=['start_date', 'end_date'],
    id_field_name='id',
    add_label='Add Program',
    update_label='Update Program',
    form_field_map={
        'programs-table-name': 'name',
        'programs-table-description': 'description',
        'programs-table-start-date': 'start_date',
        'programs-table-end-date': 'end_date',
        'programs-table-status': 'status',
        'programs-table-owner': 'owner_id',
    },
    message_output_id='programs-table-message'
)

make_export_csv_callback(
    export_btn_id='programs-table-export-csv',
    table_id='programs-table-datatable',
    download_id='programs-table-download-csv',
    filename='programs_export.csv'
)

make_search_callback(
    search_input_id='programs-table-search',
    table_id='programs-table-datatable',
    get_data_func=get_programs_data,
    search_fields=['name', 'description', 'status', 'owner']
)



# # Custom row selection callback to map owner_id to owner for the form
# from dash import callback, Input, Output, State, no_update
# from datetime import datetime, date

# @callback(
#     [Output('programs-table-name', 'value', allow_duplicate=True),
#      Output('programs-table-description', 'value', allow_duplicate=True),
#      Output('programs-table-start-date', 'value', allow_duplicate=True),
#      Output('programs-table-end-date', 'value', allow_duplicate=True),
#      Output('programs-table-status', 'value', allow_duplicate=True),
#      Output('programs-table-owner', 'value', allow_duplicate=True),
#      Output('selected-programs-table-store', 'data', allow_duplicate=True),
#      Output('delete-programs-table-btn-wrapper', 'style', allow_duplicate=True),
#      Output('add-programs-table-btn', 'children', allow_duplicate=True),
#      Output('programs-table-datatable', 'selected_rows', allow_duplicate=True)],
#     [Input('programs-table-datatable', 'active_cell')],
#     [State('programs-table-datatable', 'data'), State('selected-programs-table-store', 'data')],
#     prevent_initial_call=True
# )
# def programs_table_row_selected(active_cell, table_data, current_selected_id):
#     if not active_cell:
#         return ["" for _ in range(6)] + [None, {"opacity": "0", "pointerEvents": "none"}, "Add Program", []]
#     row_index = active_cell["row"]
#     selected_row = table_data[row_index]
#     record_id = selected_row.get('id')
#     if record_id == current_selected_id:
#         return ["" for _ in range(6)] + [None, {"opacity": "0", "pointerEvents": "none"}, "Add Program", []]
#     record_data = get_program_by_id(record_id)
#     if record_data:
#         # Map owner_id to owner for the form dropdown
#         owner_value = record_data.get('owner_id', '')
#         # Convert date strings to date objects if needed
#         def parse_date(val):
#             if isinstance(val, str) and val:
#                 try:
#                     return datetime.strptime(val, "%Y-%m-%d").date()
#                 except Exception:
#                     return None
#             return val
#         return [
#             record_data.get('name', ''),
#             record_data.get('description', ''),
#             parse_date(record_data.get('start_date', '')),
#             parse_date(record_data.get('end_date', '')),
#             record_data.get('status', ''),
#             owner_value,
#             record_id,
#             {"opacity": "1", "pointerEvents": "auto"},
#             "Update Program",
#             [row_index]
#         ]
#     return ["" for _ in range(6)] + [None, {"opacity": "0", "pointerEvents": "none"}, "Add Program", []]

