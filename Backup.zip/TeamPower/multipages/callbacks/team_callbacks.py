from dash import callback, Input, Output, State, html, no_update
import dash_bootstrap_components as dbc
from datetime import datetime, date
from db_management.team_member_db import add_team_member, update_team_member, delete_team_member, get_team_member_by_id
from components.tables.team_table import get_team_members_data
from multipages.utils.callback_utils import make_row_selection_callback, make_add_update_callback, make_delete_modal_callback, make_delete_confirm_callback
from multipages.utils.callback_utils import (
    make_clear_duplicate_button_text_callback, make_clear_duplicate_form_callback, make_export_csv_callback, make_search_callback
)

TEAM_FORM_FIELD_IDS = [
    'team-full-name',
    'team-email',
    'team-role',
    'team-department',
    'team-manager',
    'team-start-date',
    'team-end-date',
    'team-status',
]

def team_delete_info(selected_rows, table_data):
    if selected_rows and table_data:
        member = table_data[selected_rows[0]]
        info = html.Div([
            html.P(f"Name: {member.get('full_name', 'Unknown')}", style={"fontWeight": "bold"}),
            html.P(f"Email: {member.get('email', '')}"),
            html.P(f"Role: {member.get('role', '')}"),
            html.P(f"Department: {member.get('department', '')}")
        ])
        return info, member
    return [], None

make_delete_modal_callback(
    delete_btn_id='delete-team-member-btn',
    modal_id='team-table-delete-modal',
    cancel_btn_id='team-table-cancel-delete',
    confirm_btn_id='team-table-confirm-delete',
    table_id='team-table-datatable',
    store_id='team-table-delete-store',
    info_output_id='team-table-delete-info',
    info_func=team_delete_info,
)

make_delete_confirm_callback(
    confirm_btn_id='team-table-confirm-delete',
    store_id='team-table-delete-store',
    db_delete_func=delete_team_member,
    table_id='team-table-datatable',
    get_table_data_func=get_team_members_data,
    info_output_id='team-table-delete-info',
    message_output_id='team-member-message',
)


make_add_update_callback(
    form_field_ids=[
        'team-full-name',
        'team-email',
        'team-role',
        'team-department',
        'team-manager',
        'team-start-date',
        'team-end-date',
        'team-status',
    ],
    add_btn_id='add-team-member-btn',
    store_id='selected-team-member-store',
    db_add_func=add_team_member,
    db_update_func=update_team_member,
    table_id='team-table-datatable',
    id_field_name='id',
    add_label='Add Team Member',
    update_label='Update Team Member',
    required_fields=['name', 'email', 'role', 'department', 'status'],
    get_table_data_func=get_team_members_data,
    field_map={
        'team-manager': 'manager_id',
        'team-start-date': 'start_date',
        'team-end-date': 'end_date',
    },
    date_fields=['start_date', 'end_date'],
)

make_clear_duplicate_button_text_callback(
    clear_btn_id='clear-team-form-btn',
    store_id='selected-team-member-store',
    label_clear='Clear',
    label_duplicate='Duplicate'
)

make_clear_duplicate_form_callback(
    clear_btn_id='clear-team-form-btn',
    form_field_ids=TEAM_FORM_FIELD_IDS,
    store_id='selected-team-member-store',
    add_btn_id='add-team-member-btn',
    delete_btn_wrapper_id='delete-team-member-btn-wrapper',
    message_output_id='team-member-message',
    add_label='Add Team Member',
    duplicate_message="Form data preserved for new team member",
    clear_message="Form cleared",
    date_fields=['start-date', 'end-date']
)

make_row_selection_callback(
    table_id='team-table-datatable',
    form_field_ids=TEAM_FORM_FIELD_IDS,
    store_id='selected-team-member-store',
    db_get_by_id_func=get_team_member_by_id,
    add_btn_id='add-team-member-btn',
    delete_btn_wrapper_id='delete-team-member-btn-wrapper',
    date_fields=['start_date', 'end_date'],
    id_field_name='id',
    add_label='Add Team Member',
    update_label='Update Team Member',
    form_field_map={
        'team-full-name': 'name',
        'team-email': 'email',
        'team-role': 'role',
        'team-department': 'department',
        'team-manager': 'manager_id',
        'team-start-date': 'start_date',
        'team-end-date': 'end_date',
        'team-status': 'status',
    }
)

make_export_csv_callback(
    export_btn_id='team-table-export-csv',
    table_id='team-table-datatable',
    download_id='team-table-download-csv',
    filename='team_members_export.csv'
)

make_search_callback(
    search_input_id='team-table-search',
    table_id='team-table-datatable',
    get_data_func=get_team_members_data,
    search_fields=['full_name', 'email', 'role', 'department', 'status']
)
