from multipages.utils.callback_utils import (
    make_clear_duplicate_button_text_callback, make_clear_duplicate_form_callback, make_export_csv_callback, make_search_callback
)
"""
Project tab callbacks using generic factories from callback_utils.py
"""
from dash import callback, Input, Output, State, html, no_update
from db_management.project_db import add_project, update_project, delete_project, get_project_by_id
from components.tables.projects_table import get_projects_data
from multipages.utils.callback_utils import make_row_selection_callback, make_add_update_callback, make_delete_modal_callback, make_delete_confirm_callback

PROJECT_FORM_FIELD_IDS = [
    'projects-table-title',
    'projects-table-description',
    'projects-table-potential-value',
    'projects-table-start-date',
    'projects-table-end-date',
    'projects-table-program',
    'projects-table-owner',
    'projects-table-maturity',
    'projects-table-status',
]

def project_delete_info(selected_rows, table_data):
    if selected_rows and table_data:
        idx = selected_rows[0]
        project = table_data[idx]
        owner_display = project.get('owner') or project.get('owner_name') or project.get('owner_id', '')
        info = html.Div([
            html.P(f"Project Title: {project.get('title', 'Unknown')}", style={"fontWeight": "bold"}),
            html.P(f"Description: {project.get('description', '')}"),
            html.P(f"Status: {project.get('status', '')}"),
            html.P(f"Owner: {owner_display}")
        ])
        return info, project.get('id')
    return [], None

# Delete modal callback
make_delete_modal_callback(
    delete_btn_id='projects-table-delete-btn',
    modal_id='projects-table-delete-modal',
    cancel_btn_id='projects-table-cancel-delete',
    confirm_btn_id='projects-table-confirm-delete',
    table_id='projects-table-datatable',
    store_id='projects-table-selected-store',
    info_output_id='projects-table-delete-info',
    info_func=project_delete_info,
)

# Delete confirm callback
make_delete_confirm_callback(
    confirm_btn_id='projects-table-confirm-delete',
    store_id='projects-table-selected-store',
    db_delete_func=delete_project,
    table_id='projects-table-datatable',
    get_table_data_func=get_projects_data,
    info_output_id='projects-table-delete-info',
    message_output_id='projects-table-message',
)

# Add/Update callback
make_add_update_callback(
    form_field_ids=PROJECT_FORM_FIELD_IDS,
    add_btn_id='projects-table-add-btn',
    store_id='projects-table-selected-store',
    db_add_func=add_project,
    db_update_func=update_project,
    table_id='projects-table-datatable',
    id_field_name='id',
    add_label='Add Project',
    update_label='Update Project',
    required_fields=['name', 'status'],
    get_table_data_func=get_projects_data,
    message_func=None,
    field_map={
        'projects-table-title': 'name',
        'projects-table-description': 'description',
        'projects-table-potential-value': 'potential_value',
        'projects-table-start-date': 'start_date',
        'projects-table-end-date': 'end_date',
        'projects-table-program': 'program_id',
        'projects-table-owner': 'owner_id',
        'projects-table-maturity': 'maturity',
        'projects-table-status': 'status',
    },
    date_fields=['start_date', 'end_date'],
    message_output_id='projects-table-message',
)

make_clear_duplicate_button_text_callback(
    clear_btn_id='projects-table-clear-form-btn',
    store_id='projects-table-selected-store',
    label_clear='Clear',
    label_duplicate='Duplicate'
)

make_clear_duplicate_form_callback(
    clear_btn_id='projects-table-clear-form-btn',
    form_field_ids=PROJECT_FORM_FIELD_IDS,
    store_id='projects-table-selected-store',
    add_btn_id='projects-table-add-btn',
    delete_btn_wrapper_id='projects-table-delete-btn-wrapper',
    message_output_id='projects-table-message',
    add_label='Add Project',
    duplicate_message="Form data preserved for new project",
    clear_message="Form cleared",
    date_fields=['start-date', 'end-date']
)

make_row_selection_callback(
    table_id='projects-table-datatable',
    form_field_ids=PROJECT_FORM_FIELD_IDS,
    store_id='projects-table-selected-store',
    db_get_by_id_func=get_project_by_id,
    add_btn_id='projects-table-add-btn',
    delete_btn_wrapper_id='projects-table-delete-btn-wrapper',
    date_fields=['start_date', 'end_date'],
    id_field_name='id',
    add_label='Add Project',
    update_label='Update Project',
    form_field_map={
        'projects-table-title': 'name',
        'projects-table-description': 'description',
        'projects-table-potential-value': 'potential_value',
        'projects-table-start-date': 'start_date',
        'projects-table-end-date': 'end_date',
        'projects-table-program': 'program_id',
        'projects-table-owner': 'owner_id',
        'projects-table-maturity': 'maturity',
        'projects-table-status': 'status',
    },
    message_output_id='projects-table-message'
)

make_export_csv_callback(
    export_btn_id='projects-table-export-csv',
    table_id='projects-table-datatable',
    download_id='projects-table-download-csv',
    filename='projects_export.csv'
)

make_search_callback(
    search_input_id='projects-table-search',
    table_id='projects-table-datatable',
    get_data_func=get_projects_data,
    search_fields=['title', 'description', 'status', 'owner']
)
