from multipages.utils.callback_utils import (
    make_clear_duplicate_button_text_callback, make_clear_duplicate_form_callback, make_export_csv_callback, make_search_callback
)
from dash import html
from db_management.db import (
    add_value_tracking_record, update_value_tracking_record, delete_value_tracking_record, get_value_tracking_record_by_id, get_value_tracking_records
)
from multipages.utils.callback_utils import (
    make_row_selection_callback, make_add_update_callback, make_delete_modal_callback, make_delete_confirm_callback
)

VALUE_TRACKER_FORM_FIELD_IDS = [
    'value-tracker-description',
    'value-tracker-amount',
    'value-tracker-start-date',
    'value-tracker-end-date',
    'value-tracker-project',
    'value-tracker-business-sponsor',
]

def value_tracker_delete_info(selected_rows, table_data):
    if selected_rows and table_data:
        idx = selected_rows[0]
        value = table_data[idx]
        info = html.Div([
            html.P(f"Description: {value.get('description', 'Unknown')}", style={"fontWeight": "bold"}),
            html.P(f"Amount: {value.get('amount', '')}"),
            html.P(f"Start Date: {value.get('start_date', '')}"),
            html.P(f"End Date: {value.get('end_date', '')}"),
            html.P(f"Project: {value.get('project_id', '')}"),
            html.P(f"Business Sponsor: {value.get('business_sponsor', '')}")
        ])
        return info, value.get('id')
    return [], None

# Delete modal callback
make_delete_modal_callback(
    delete_btn_id='value-tracker-delete-btn',
    modal_id='value-tracker-table-delete-modal',
    cancel_btn_id='value-tracker-table-cancel-delete',
    confirm_btn_id='value-tracker-table-confirm-delete',
    table_id='value-tracker-table-datatable',
    store_id='value-tracker-selected-store',
    info_output_id='value-tracker-table-delete-info',
    info_func=value_tracker_delete_info,
)

# Delete confirm callback
make_delete_confirm_callback(
    confirm_btn_id='value-tracker-table-confirm-delete',
    store_id='value-tracker-selected-store',
    db_delete_func=delete_value_tracking_record,
    table_id='value-tracker-table-datatable',
    get_table_data_func=get_value_tracking_records,
    info_output_id='value-tracker-table-delete-info',
    message_output_id='value-tracker-message',
)

# Add/Update callback
make_add_update_callback(
    form_field_ids=VALUE_TRACKER_FORM_FIELD_IDS,
    add_btn_id='value-tracker-add-btn',
    store_id='value-tracker-selected-store',
    db_add_func=add_value_tracking_record,
    db_update_func=update_value_tracking_record,
    table_id='value-tracker-table-datatable',
    id_field_name='id',
    add_label='Add Value',
    update_label='Update Value',
    required_fields=['description', 'amount', 'start_date', 'end_date', 'project_id', 'business_sponsor'],
    get_table_data_func=get_value_tracking_records,
    message_func=None,
    field_map={
        'value-tracker-description': 'description',
        'value-tracker-amount': 'amount',
        'value-tracker-start-date': 'start_date',
        'value-tracker-end-date': 'end_date',
        'value-tracker-project': 'project_id',
        'value-tracker-business-sponsor': 'business_sponsor',
    },
    date_fields=['start_date', 'end_date'],
    message_output_id='value-tracker-message',
)

make_clear_duplicate_button_text_callback(
    clear_btn_id='value-tracker-clear-form-btn',
    store_id='value-tracker-selected-store',
    label_clear='Clear',
    label_duplicate='Duplicate'
)

make_clear_duplicate_form_callback(
    clear_btn_id='value-tracker-clear-form-btn',
    form_field_ids=VALUE_TRACKER_FORM_FIELD_IDS,
    store_id='value-tracker-selected-store',
    add_btn_id='value-tracker-add-btn',
    delete_btn_wrapper_id='value-tracker-delete-btn-wrapper',
    message_output_id='value-tracker-message',
    add_label='Add Value',
    duplicate_message="Form data preserved for new value",
    clear_message="Form cleared",
    date_fields=['date']
)

make_row_selection_callback(
    table_id='value-tracker-table-datatable',
    form_field_ids=VALUE_TRACKER_FORM_FIELD_IDS,
    store_id='value-tracker-selected-store',
    db_get_by_id_func=get_value_tracking_record_by_id,
    add_btn_id='value-tracker-add-btn',
    delete_btn_wrapper_id='value-tracker-delete-btn-wrapper',
    date_fields=['start_date', 'end_date'],
    id_field_name='id',
    add_label='Add Value',
    update_label='Update Value',
    form_field_map={
        'value-tracker-description': 'description',
        'value-tracker-amount': 'amount',
        'value-tracker-start-date': 'start_date',
        'value-tracker-end-date': 'end_date',
        'value-tracker-project': 'project_id',
        'value-tracker-business-sponsor': 'business_sponsor',
    },
    message_output_id='value-tracker-message'
)

make_export_csv_callback(
    export_btn_id='value-tracker-export-csv',
    table_id='value-tracker-table-datatable',
    download_id='value-tracker-download-csv',
    filename='value_tracker_export.csv'
)

make_search_callback(
    search_input_id='value-tracker-search',
    table_id='value-tracker-table-datatable',
    get_data_func=get_value_tracking_records,
    search_fields=['description', 'amount', 'start_date', 'end_date', 'project_id', 'business_sponsor']
)
