# TeamPower GSK Dashboard

> **A modern, comprehensive dashboard application for GSK team management, analytics, and decision-making**

TeamPower GSK Dashboard is a web-based analytics platform built specifically for GSK teams to visualize data, track performance metrics, and make informed decisions. The application combines powerful data visualization capabilities with GSK's design standards to deliver a professional, user-friendly experience.

## 🎯 Why TeamPower GSK Dashboard?

### **For Business Users**
- 📊 **Instant Insights**: Get immediate visibility into key performance metrics
- 🎨 **Professional Presentation**: GSK-branded visualizations ready for executive presentations
- 📱 **Access Anywhere**: Responsive design works on desktop, tablet, and mobile
- ⚡ **Real-time Data**: Live updates ensure you're always working with current information

### **For IT Teams**
- 🔧 **Low Maintenance**: Built on proven, stable technologies
- 🚀 **Quick Deployment**: Single Python application with minimal dependencies
- 🔒 **Secure**: Local deployment options with full data control
- 📈 **Scalable**: Modular architecture supports growth and customization

### **For Developers**
- 🧩 **Modular Design**: Reusable components and utilities
- 📚 **Well Documented**: Clear code structure and comprehensive documentation
- 🎨 **Design System**: Consistent GSK branding across all components
- 🔄 **Extensible**: Easy to add new pages, charts, and features

## ✨ Key Features

### **Dashboard Capabilities**
- **Multi-page Navigation**: Seamless transition between different analytical views
- **Interactive Visualizations**: Click, hover, and zoom interactions on all charts
- **Real-time Updates**: Live data refresh capabilities for dynamic dashboards
- **Export Functions**: Save charts and data for reports and presentations

### **Chart Types & Analytics**
- **Line Charts**: Trend analysis and time-series visualization
- **Bar Charts**: Comparative analysis and categorical data display
- **Gauge Charts**: KPI monitoring and performance tracking
- **Sunburst Diagrams**: Hierarchical data exploration
- **Stacked Charts**: Multi-dimensional data comparison

### **GSK Design Integration**
- **Brand Compliance**: Automatic application of GSK colors and typography
- **Professional Styling**: Executive-ready visualizations out of the box
- **Responsive Layout**: Optimized for all screen sizes and devices
- **Accessibility**: High contrast options and screen reader support

## 🏗️ Architecture Overview

### **Application Architecture**
```
┌─────────────────────────────────────────┐
│             Frontend Layer              │
│  (Dash + Plotly + Bootstrap)           │
├─────────────────────────────────────────┤
│           Component Layer               │
│     (Reusable Charts & Utilities)      │
├─────────────────────────────────────────┤
│            Data Layer                   │
│    (Pandas + SQLite + Processing)      │
├─────────────────────────────────────────┤
│           Storage Layer                 │
│      (Local Files + Database)          │
└─────────────────────────────────────────┘
```

### **Design Principles**
- **Separation of Concerns**: Clear separation between UI, logic, and data
- **Reusability**: Modular components that can be used across pages
- **Maintainability**: Clean code structure with comprehensive documentation
- **Performance**: Optimized data processing and caching strategies
- **Security**: Local deployment with controlled data access

### **Technology Stack**

| Layer | Technology | Purpose |
|-------|------------|---------|
| **Frontend** | Dash + Plotly | Interactive web interface and visualizations |
| **Styling** | Bootstrap 5 + Custom CSS | Responsive design and GSK branding |
| **Backend** | Flask (via Dash) | Web server and application routing |
| **Data Processing** | Pandas + NumPy | Data manipulation and analysis |
| **Database** | SQLite | Local data storage and management |
| **Deployment** | Python + Virtual Environment | Isolated application environment |

## 📊 Available Pages & Features

### **Overview Dashboard**
- **Purpose**: Central hub for key organizational metrics
- **Features**: Executive summary cards, trend analysis, performance indicators
- **Target Users**: Managers, executives, team leads

### **Configuration Management**
- **Purpose**: System settings and user preferences
- **Features**: Theme selection, data source configuration, user management
- **Target Users**: System administrators, power users

### **AI Financials**
- **Purpose**: Financial analytics with AI-driven insights
- **Features**: Revenue tracking, budget analysis, predictive modeling
- **Target Users**: Finance teams, business analysts

### **AI Governance**
- **Purpose**: Compliance tracking and governance metrics
- **Features**: Risk assessment, audit trails, compliance dashboards
- **Target Users**: Compliance officers, risk managers

### **Transactions**
- **Purpose**: Transaction management and analysis
- **Features**: Transaction logs, analysis tools, reporting
- **Target Users**: Operations teams, analysts

### **Team Hierarchy**
- **Purpose**: Organizational structure visualization
- **Features**: Org charts, team metrics, hierarchy analysis
- **Target Users**: HR teams, managers, executives

## � Quick Start Guide

### **Prerequisites**
- Python 3.8+ (recommended: Python 3.11)
- pip package manager
- Git (for cloning the repository)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### **Installation Steps**

1. **Clone and Setup**:
   ```bash
   git clone <repository-url>
   cd TeamPowerGSK
   
   # Create isolated Python environment
   python -m venv .venv
   
   # Activate environment
   source .venv/bin/activate  # macOS/Linux
   # or
   .venv\Scripts\activate     # Windows
   ```

2. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Launch Application**:
   ```bash
   cd TeamPower/multipages
   python app.py
   ```

4. **Access Dashboard**:
   Open your browser and navigate to: **http://localhost:8122**

### **First-Time Setup**
1. **Verify Installation**: Check that all pages load without errors
2. **Review Sample Data**: Explore the demo data and visualizations
3. **Configure Settings**: Access the Configuration page to customize preferences
4. **Test Functionality**: Try interactive features like chart zoom and hover

### **Troubleshooting**
```bash
# Verify Python version
python --version

# Check installed packages
pip list

# Test imports
python -c "import dash, plotly, pandas; print('All packages working!')"

# Check port availability
lsof -i :8122  # macOS/Linux
netstat -an | findstr :8122  # Windows
```

## 🎨 Design System & User Experience

### **GSK Brand Integration**
The application strictly adheres to GSK's design principles and brand guidelines:

- **Color Palette**:
  - Primary: GSK Orange (#FF6900) - Call-to-action elements
  - Secondary: GSK Teal (#21837E) - Data visualization and accents
  - Neutral: Professional grays for text and backgrounds
  - Status: Success, warning, and error states with appropriate colors

- **Typography**:
  - Primary Font: GSK Precision (brand-specific)
  - Fallback: System fonts for optimal performance
  - Hierarchy: Consistent heading sizes and spacing

- **Layout Principles**:
  - Clean, minimalist design
  - Consistent spacing using 8px grid system
  - Logical information hierarchy
  - Professional appearance suitable for executive presentations

### **User Experience Features**
- **Intuitive Navigation**: Clear menu structure with visual indicators
- **Responsive Design**: Seamless experience across all device sizes
- **Interactive Elements**: Hover states, tooltips, and feedback
- **Loading States**: Progress indicators for data-heavy operations
- **Error Handling**: User-friendly error messages and recovery options
- **Accessibility**: WCAG compliance with keyboard navigation and screen reader support

### **Performance Optimization**
- **Fast Load Times**: Optimized asset loading and caching
- **Smooth Interactions**: Efficient data processing and rendering
- **Memory Management**: Proper cleanup of resources and components
- **Scalable Architecture**: Handles increasing data volumes gracefully

## 📁 Project Structure & Organization

```
TeamPowerGSK/
├── 📄 README.md                     # Main documentation
├── 📄 requirements.txt              # Python dependencies
├── 📄 .gitignore                    # Git ignore rules
├── 🗂️ TeamPower/                    # Main application directory
│   ├── 🗂️ multipages/               # Multi-page Dash application
│   │   ├── 🐍 app.py                # Application entry point
│   │   ├── 🐍 callbacks.py          # Interactive callbacks
│   │   ├── 🎨 assets/               # Static assets (CSS, JS, images)
│   │   │   ├── bootstrap-overrides.css
│   │   │   ├── styles.css
│   │   │   └── GSK_Logo_Full_Colour_RGB.svg
│   │   ├── 🧩 components/           # Reusable UI components
│   │   │   ├── analytics/
│   │   │   ├── forms/
│   │   │   ├── tables/
│   │   │   └── legacy/
│   │   ├── 📄 pages/                # Individual page modules
│   │   │   ├── overview.py
│   │   │   ├── configuration.py
│   │   │   ├── ai_financials.py
│   │   │   ├── ai_governance.py
│   │   │   ├── transactions.py
│   │   │   └── team_hierarchy.py
│   │   ├── 🔧 utils/                # Chart creation utilities
│   │   │   ├── create_line_chart.py
│   │   │   ├── create_bar_chart.py
│   │   │   ├── create_gauge_chart.py
│   │   │   ├── create_sunburst_chart.py
│   │   │   └── create_stacked_bar_chart.py
│   │   ├── ⚙️ config/               # Configuration files
│   │   │   └── chart_config.py
│   │   └── 🎛️ dashboard/            # Dashboard-specific modules
│   │       ├── analytics.py
│   │       ├── metrics.py
│   │       └── table.py
│   └── 🗄️ db_management/            # Database utilities
│       ├── database_manager.py
│       ├── project_db.py
│       ├── users.py
│       └── time_management.py
└── 📊 *.db                         # SQLite database files
```

### **Module Descriptions**

| Module | Purpose | Key Features |
|--------|---------|--------------|
| **app.py** | Application bootstrap | Page registration, routing, layout |
| **callbacks.py** | Interactive logic | User interactions, data updates |
| **assets/** | Static resources | GSK branding, custom styles |
| **components/** | UI building blocks | Reusable interface elements |
| **pages/** | Application views | Individual page implementations |
| **utils/** | Chart utilities | Standardized visualization functions |
| **config/** | Configuration | Chart styling, application settings |
| **db_management/** | Data layer | Database operations, data models |

## 🔧 Development Guide

### **Adding New Pages**

1. **Create Page Module**:
   ```python
   # In TeamPower/multipages/pages/new_page.py
   import dash
   from dash import html, dcc
   
   # Register the page
   dash.register_page(__name__, path="/new-page", name="New Page")
   
   def layout():
       return html.Div([
           html.H1("New Page"),
           # Your page content here
       ])
   ```

2. **Import in App**:
   ```python
   # In app.py
   from pages import overview, configuration, new_page  # Add your page
   ```

### **Creating Charts**

Use the standardized utility functions for consistent styling:

```python
from utils.create_line_chart import create_line_chart
from utils.create_bar_chart import create_bar_chart
from utils.create_gauge_chart import create_performance_gauge

# Line chart example
chart_data = {
    'x': ['Jan', 'Feb', 'Mar', 'Apr'],
    'y': [100, 120, 130, 110],
    'labels': ['Revenue']
}
chart_config = {
    'title': 'Monthly Revenue Trend',
    'height': 400,
    'x_title': 'Month',
    'y_title': 'Revenue ($)',
    'show_markers': True
}
chart = create_line_chart(chart_data, chart_config)

# Bar chart example
bar_data = {
    'categories': ['Q1', 'Q2', 'Q3', 'Q4'],
    'values': [850, 920, 880, 950]
}
bar_config = {
    'title': 'Quarterly Performance',
    'height': 350,
    'color': '#21837E',  # GSK Teal
    'show_values_on_bars': True
}
bar_chart = create_bar_chart(bar_data, bar_config)

# Gauge chart example
gauge_chart = create_performance_gauge(0.85, 'Team Efficiency')
```

### **Styling Guidelines**

- **Colors**: Use CSS variables defined in `assets/styles.css`
- **Spacing**: Follow 8px grid system (8px, 16px, 24px, 32px)
- **Typography**: Use Bootstrap typography classes with GSK font stack
- **Components**: Leverage Dash Bootstrap Components for consistency

### **Code Standards**

- **Python Style**: Follow PEP 8 guidelines
- **Documentation**: Add docstrings to all functions and classes
- **Naming**: Use descriptive, snake_case for variables and functions
- **Comments**: Explain complex logic and business rules
- **Error Handling**: Implement proper exception handling

### **Testing Your Changes**

```bash
# Basic functionality test
python -c "from TeamPower.multipages import app; print('App loads successfully')"

# Chart utility tests
python -c "
from TeamPower.multipages.utils.create_line_chart import create_line_chart
data = {'x': [1,2,3], 'y': [10,20,15], 'labels': ['Test']}
config = {'title': 'Test Chart', 'height': 300}
chart = create_line_chart(data, config)
print('Chart creation successful')
"

# Run the application
cd TeamPower/multipages && python app.py
```

## 🚦 Best Practices

### **Data Handling**
- **Validation**: Always validate data inputs and handle edge cases
- **Performance**: Use efficient pandas operations for large datasets
- **Caching**: Implement caching for expensive computations
- **Memory**: Clean up large dataframes after use

### **UI/UX Guidelines**
- **Responsive**: Test on multiple screen sizes and devices
- **Accessibility**: Include proper ARIA labels and keyboard navigation
- **Loading**: Show loading indicators for operations > 1 second
- **Feedback**: Provide clear user feedback for all actions

### **Security Considerations**
- **Input Sanitization**: Validate all user inputs
- **Error Messages**: Don't expose sensitive system information
- **Dependencies**: Keep packages updated for security patches
- **Data Privacy**: Follow GSK data handling policies

## 🔄 Deployment & Maintenance

### **Local Development**
```bash
# Development mode with hot reload
export FLASK_ENV=development
python app.py
```

### **Production Deployment**
```bash
# Production mode
export FLASK_ENV=production
gunicorn -w 4 -b 0.0.0.0:8000 app:server
```

### **Maintenance Tasks**
- **Regular Updates**: Keep dependencies current
- **Monitoring**: Log application performance and errors
- **Backups**: Regular database and configuration backups
- **Documentation**: Keep documentation updated with changes

## 📈 Performance Monitoring

### **Key Metrics to Track**
- Page load times
- Chart rendering performance
- Memory usage
- Database query performance
- User interaction response times

### **Optimization Strategies**
- Lazy loading for large datasets
- Efficient data filtering and aggregation
- Chart performance optimization
- Asset compression and caching

## 🤝 Contributing & Support

### **Contributing Guidelines**

1. **Fork & Branch**: Create feature branches for new development
2. **Code Standards**: Follow established patterns and style guidelines
3. **Testing**: Test all changes thoroughly before submitting
4. **Documentation**: Update documentation for new features
5. **Review**: Submit pull requests for code review

### **Reporting Issues**
- Use clear, descriptive titles
- Include steps to reproduce
- Provide system information (OS, Python version, browser)
- Include relevant error messages and logs

### **Getting Help**
- Check documentation and README files first
- Search existing issues for similar problems
- Contact the GSK development team for support
- Join internal development discussions

## � License & Legal

This application is developed for internal GSK use and contains proprietary code and design elements. All rights reserved by GlaxoSmithKline.

## 🎉 Acknowledgments

- **GSK Design Team**: For brand guidelines and design standards
- **GSK IT Team**: For infrastructure and deployment support
- **Development Team**: For creating and maintaining the application
- **Open Source Community**: For the excellent tools and libraries used

---

## 🚀 Ready to Get Started?

1. **Clone the repository** and follow the installation guide
2. **Explore the demo data** to understand the application capabilities
3. **Review the development guide** to start customizing for your needs
4. **Join the GSK developer community** for support and collaboration

**Built with ❤️ for GSK Teams - Empowering Data-Driven Decisions**

---

*Last updated: August 2025 | Version: 2.0 | Maintained by GSK Development Team*
````