# TeamPower GSK Dashboard - Software Design Document

> **Detailed software design, patterns, and implementation guidelines**

## 🎯 Design Philosophy

The TeamPower GSK Dashboard is built on the following core design principles:

### **1. User-Centric Design**
- **Intuitive Interface**: Easy navigation for users of all technical levels
- **Responsive Experience**: Consistent functionality across all devices
- **Professional Aesthetics**: GSK brand compliance for business presentations
- **Accessibility**: WCAG 2.1 compliance for inclusive access

### **2. Modular Architecture**
- **Component Reusability**: Shared components across multiple pages
- **Separation of Concerns**: Clear boundaries between UI, logic, and data
- **Pluggable Design**: Easy to add new features and pages
- **Testable Components**: Isolated units for comprehensive testing

### **3. Performance-First**
- **Efficient Data Processing**: Optimized pandas operations and caching
- **Fast Rendering**: Plotly WebGL acceleration for large datasets
- **Memory Management**: Proper cleanup and resource management
- **Scalable Architecture**: Handles growing data volumes gracefully

### **4. Maintainable Codebase**
- **Clear Documentation**: Comprehensive comments and docstrings
- **Consistent Patterns**: Standardized approaches across all modules
- **Error Handling**: Robust exception management and user feedback
- **Code Quality**: Automated testing and code quality checks

## 🏗️ Design Patterns

### **1. Model-View-Controller (MVC) Pattern**

```
Model (Data Layer)
├── Database Operations
├── Data Processing
└── Business Logic

View (Presentation Layer)
├── Dash Components
├── Chart Visualizations
└── User Interface

Controller (Application Layer)
├── Callback Functions
├── User Interactions
└── State Management
```

**Implementation Example:**
```python
# Model - Data operations
class DataManager:
    def fetch_financial_data(self, period):
        """Fetch and process financial data"""
        return processed_data

# View - UI components
def create_financial_dashboard():
    """Create financial dashboard layout"""
    return html.Div([...])

# Controller - Callbacks
@app.callback(
    Output('financial-chart', 'figure'),
    Input('period-selector', 'value')
)
def update_financial_chart(selected_period):
    """Update chart based on user selection"""
    data = DataManager().fetch_financial_data(selected_period)
    return create_chart(data)
```

### **2. Factory Pattern for Chart Creation**

```python
class ChartFactory:
    """Factory for creating different chart types"""
    
    @staticmethod
    def create_chart(chart_type, data, config):
        """Create chart based on type"""
        creators = {
            'line': LineChartCreator,
            'bar': BarChartCreator,
            'gauge': GaugeChartCreator,
            'sunburst': SunburstChartCreator
        }
        
        creator = creators.get(chart_type)
        if not creator:
            raise ValueError(f"Unknown chart type: {chart_type}")
        
        return creator.create(data, config)

class ChartCreator:
    """Base class for chart creators"""
    
    @abstractmethod
    def create(self, data, config):
        """Create chart with given data and configuration"""
        pass
    
    def apply_gsk_styling(self, figure):
        """Apply consistent GSK styling"""
        figure.update_layout(
            font_family="GSK Precision, Arial, sans-serif",
            plot_bgcolor='white',
            paper_bgcolor='white'
        )
        return figure
```

### **3. Observer Pattern for State Management**

```python
class StateManager:
    """Manage application state with observer pattern"""
    
    def __init__(self):
        self._observers = []
        self._state = {}
    
    def subscribe(self, observer):
        """Subscribe to state changes"""
        self._observers.append(observer)
    
    def notify(self, event, data):
        """Notify all observers of state change"""
        for observer in self._observers:
            observer.update(event, data)
    
    def set_state(self, key, value):
        """Update state and notify observers"""
        old_value = self._state.get(key)
        self._state[key] = value
        
        if old_value != value:
            self.notify('state_change', {'key': key, 'value': value})
```

### **4. Strategy Pattern for Data Processing**

```python
class DataProcessingStrategy:
    """Base strategy for data processing"""
    
    @abstractmethod
    def process(self, raw_data):
        """Process raw data"""
        pass

class FinancialDataProcessor(DataProcessingStrategy):
    """Strategy for processing financial data"""
    
    def process(self, raw_data):
        # Financial-specific processing
        return processed_data

class AnalyticsDataProcessor(DataProcessingStrategy):
    """Strategy for processing analytics data"""
    
    def process(self, raw_data):
        # Analytics-specific processing
        return processed_data

class DataProcessor:
    """Context class for data processing"""
    
    def __init__(self, strategy: DataProcessingStrategy):
        self._strategy = strategy
    
    def process_data(self, raw_data):
        """Process data using current strategy"""
        return self._strategy.process(raw_data)
```

## 🧩 Component Design

### **Chart Component Architecture**

```python
from dataclasses import dataclass
from typing import Dict, Any, Optional
import plotly.graph_objects as go
from dash import dcc

@dataclass
class ChartConfig:
    """Configuration for chart creation"""
    title: str
    height: int = 400
    width: Optional[int] = None
    color_scheme: str = 'gsk_primary'
    show_legend: bool = True
    responsive: bool = True
    export_enabled: bool = True

@dataclass
class ChartData:
    """Data structure for chart input"""
    x: list
    y: list
    labels: Optional[list] = None
    colors: Optional[list] = None
    metadata: Optional[Dict[str, Any]] = None

class BaseChart:
    """Base class for all chart components"""
    
    def __init__(self, data: ChartData, config: ChartConfig):
        self.data = data
        self.config = config
        self._figure = None
    
    def create_figure(self) -> go.Figure:
        """Create Plotly figure - to be implemented by subclasses"""
        raise NotImplementedError
    
    def apply_styling(self, figure: go.Figure) -> go.Figure:
        """Apply GSK styling to figure"""
        figure.update_layout(
            title={
                'text': self.config.title,
                'font': {'family': 'GSK Precision', 'size': 20},
                'x': 0.5,
                'xanchor': 'center'
            },
            font_family="GSK Precision, Arial, sans-serif",
            font_color="#333333",
            plot_bgcolor='white',
            paper_bgcolor='white',
            height=self.config.height,
            showlegend=self.config.show_legend
        )
        return figure
    
    def to_dash_component(self) -> dcc.Graph:
        """Convert to Dash graph component"""
        if self._figure is None:
            self._figure = self.create_figure()
            self._figure = self.apply_styling(self._figure)
        
        return dcc.Graph(
            figure=self._figure,
            responsive=self.config.responsive,
            config={
                'displayModeBar': self.config.export_enabled,
                'toImageButtonOptions': {
                    'format': 'png',
                    'filename': f'{self.config.title}_chart',
                    'height': self.config.height,
                    'width': self.config.width or 800,
                    'scale': 2
                }
            }
        )

class LineChart(BaseChart):
    """Line chart implementation"""
    
    def create_figure(self) -> go.Figure:
        """Create line chart figure"""
        figure = go.Figure()
        
        # Add traces for each data series
        for i, label in enumerate(self.data.labels or ['Series']):
            figure.add_trace(go.Scatter(
                x=self.data.x,
                y=self.data.y if not isinstance(self.data.y[0], list) else self.data.y[i],
                mode='lines+markers',
                name=label,
                line=dict(width=3),
                marker=dict(size=6)
            ))
        
        return figure
```

### **Page Component Architecture**

```python
from abc import ABC, abstractmethod
import dash
from dash import html, dcc, Input, Output, State

class BasePage(ABC):
    """Base class for all page components"""
    
    def __init__(self, path: str, name: str, title: str):
        self.path = path
        self.name = name
        self.title = title
        self.register_page()
        self.register_callbacks()
    
    def register_page(self):
        """Register page with Dash"""
        dash.register_page(
            __name__, 
            path=self.path, 
            name=self.name, 
            title=self.title
        )
    
    @abstractmethod
    def create_layout(self) -> html.Div:
        """Create page layout - to be implemented by subclasses"""
        pass
    
    @abstractmethod
    def register_callbacks(self):
        """Register page-specific callbacks"""
        pass
    
    def create_header(self) -> html.Div:
        """Create standard page header"""
        return html.Div([
            html.H1(self.title, className="page-title"),
            html.Hr(className="title-divider")
        ], className="page-header")
    
    def create_footer(self) -> html.Div:
        """Create standard page footer"""
        return html.Div([
            html.P("© 2025 GlaxoSmithKline", className="copyright")
        ], className="page-footer")

# Layout function for Dash
def layout():
    """Return the layout for this page"""
    page = FinancialPage("/financials", "Financials", "Financial Analytics")
    return page.create_layout()

class FinancialPage(BasePage):
    """Financial analytics page implementation"""
    
    def create_layout(self) -> html.Div:
        """Create financial page layout"""
        return html.Div([
            self.create_header(),
            html.Div([
                self.create_filters(),
                self.create_charts(),
                self.create_data_table()
            ], className="page-content"),
            self.create_footer()
        ], className="page-container")
    
    def create_filters(self) -> html.Div:
        """Create filter controls"""
        return html.Div([
            dcc.DatePickerRange(
                id='financial-date-range',
                display_format='YYYY-MM-DD'
            ),
            dcc.Dropdown(
                id='business-unit-filter',
                options=[
                    {'label': 'All Units', 'value': 'all'},
                    {'label': 'Research', 'value': 'research'},
                    {'label': 'Commercial', 'value': 'commercial'}
                ],
                value='all'
            )
        ], className="filter-panel")
    
    def register_callbacks(self):
        """Register financial page callbacks"""
        @dash.callback(
            Output('revenue-chart', 'figure'),
            [Input('financial-date-range', 'start_date'),
             Input('financial-date-range', 'end_date'),
             Input('business-unit-filter', 'value')]
        )
        def update_revenue_chart(start_date, end_date, business_unit):
            # Chart update logic
            return updated_figure
```

## 🔧 Data Layer Design

### **Database Access Layer**

```python
from contextlib import contextmanager
import sqlite3
import pandas as pd
from typing import Dict, List, Any, Optional

class DatabaseConnection:
    """Database connection management"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
        finally:
            conn.close()
    
    def execute_query(self, query: str, params: Optional[tuple] = None) -> pd.DataFrame:
        """Execute query and return DataFrame"""
        with self.get_connection() as conn:
            return pd.read_sql_query(query, conn, params=params)
    
    def execute_non_query(self, query: str, params: Optional[tuple] = None) -> int:
        """Execute non-query and return affected rows"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params or ())
            conn.commit()
            return cursor.rowcount

class DataRepository:
    """Repository pattern for data access"""
    
    def __init__(self, db_connection: DatabaseConnection):
        self.db = db_connection
    
    def get_financial_data(self, start_date: str, end_date: str, 
                          business_unit: Optional[str] = None) -> pd.DataFrame:
        """Get financial data for specified period"""
        query = """
        SELECT date, revenue, expenses, profit
        FROM financial_data 
        WHERE date BETWEEN ? AND ?
        """
        params = (start_date, end_date)
        
        if business_unit and business_unit != 'all':
            query += " AND business_unit = ?"
            params += (business_unit,)
        
        return self.db.execute_query(query, params)
    
    def get_team_hierarchy(self) -> pd.DataFrame:
        """Get team hierarchy data"""
        query = """
        SELECT e.name as employee, m.name as manager, 
               e.department, e.position, e.level
        FROM employees e
        LEFT JOIN employees m ON e.manager_id = m.id
        ORDER BY e.level, e.department, e.name
        """
        return self.db.execute_query(query)
```

### **Data Processing Layer**

```python
from abc import ABC, abstractmethod
import pandas as pd
import numpy as np
from typing import Dict, Any

class DataProcessor(ABC):
    """Abstract base class for data processors"""
    
    @abstractmethod
    def process(self, raw_data: pd.DataFrame) -> Dict[str, Any]:
        """Process raw data and return chart-ready format"""
        pass
    
    def validate_data(self, data: pd.DataFrame) -> bool:
        """Validate input data"""
        return not data.empty and len(data.columns) > 0
    
    def handle_missing_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """Handle missing data points"""
        # Forward fill for time series data
        if 'date' in data.columns:
            data = data.sort_values('date')
            data = data.fillna(method='ffill')
        
        # Fill remaining NaN with appropriate defaults
        numeric_columns = data.select_dtypes(include=[np.number]).columns
        data[numeric_columns] = data[numeric_columns].fillna(0)
        
        return data

class FinancialDataProcessor(DataProcessor):
    """Processor for financial data"""
    
    def process(self, raw_data: pd.DataFrame) -> Dict[str, Any]:
        """Process financial data for visualization"""
        if not self.validate_data(raw_data):
            raise ValueError("Invalid financial data")
        
        data = self.handle_missing_data(raw_data)
        
        # Calculate derived metrics
        data['profit_margin'] = (data['profit'] / data['revenue']) * 100
        data['growth_rate'] = data['revenue'].pct_change() * 100
        
        # Prepare chart data
        return {
            'x': data['date'].dt.strftime('%Y-%m').tolist(),
            'revenue': data['revenue'].tolist(),
            'expenses': data['expenses'].tolist(),
            'profit': data['profit'].tolist(),
            'profit_margin': data['profit_margin'].tolist(),
            'growth_rate': data['growth_rate'].fillna(0).tolist()
        }

class TeamDataProcessor(DataProcessor):
    """Processor for team hierarchy data"""
    
    def process(self, raw_data: pd.DataFrame) -> Dict[str, Any]:
        """Process team data for visualization"""
        if not self.validate_data(raw_data):
            raise ValueError("Invalid team data")
        
        # Build hierarchy structure
        hierarchy = self._build_hierarchy_tree(raw_data)
        
        # Calculate department metrics
        dept_counts = raw_data.groupby('department').size()
        level_distribution = raw_data.groupby('level').size()
        
        return {
            'hierarchy_tree': hierarchy,
            'department_counts': dept_counts.to_dict(),
            'level_distribution': level_distribution.to_dict(),
            'total_employees': len(raw_data)
        }
    
    def _build_hierarchy_tree(self, data: pd.DataFrame) -> Dict:
        """Build hierarchical tree structure"""
        # Implementation for building tree structure
        pass
```

## 🎨 UI/UX Design Patterns

### **Responsive Design System**

```css
/* GSK Design System Variables */
:root {
    --gsk-orange: #FF6900;
    --gsk-teal: #21837E;
    --gsk-gray-100: #f8f9fa;
    --gsk-gray-900: #212529;
    
    --font-family-primary: 'GSK Precision', Arial, sans-serif;
    --font-size-base: 16px;
    --line-height-base: 1.5;
    
    --spacing-xs: 4px;
    --spacing-sm: 8px;
    --spacing-md: 16px;
    --spacing-lg: 24px;
    --spacing-xl: 32px;
    
    --border-radius: 4px;
    --box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

/* Responsive Grid System */
.chart-grid {
    display: grid;
    gap: var(--spacing-lg);
    grid-template-columns: 1fr;
}

@media (min-width: 768px) {
    .chart-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (min-width: 1200px) {
    .chart-grid {
        grid-template-columns: repeat(3, 1fr);
    }
}

/* Component Styling */
.chart-container {
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    padding: var(--spacing-lg);
    margin-bottom: var(--spacing-lg);
}

.page-header {
    border-bottom: 2px solid var(--gsk-orange);
    padding-bottom: var(--spacing-md);
    margin-bottom: var(--spacing-xl);
}

.filter-panel {
    background: var(--gsk-gray-100);
    border-radius: var(--border-radius);
    padding: var(--spacing-lg);
    margin-bottom: var(--spacing-lg);
}
```

### **Interactive State Management**

```python
class InteractionManager:
    """Manage user interactions and state"""
    
    def __init__(self):
        self.state = {
            'selected_filters': {},
            'chart_states': {},
            'user_preferences': {}
        }
        self.callbacks = []
    
    def register_interaction(self, component_id: str, property_name: str, 
                           callback_func: callable):
        """Register interaction callback"""
        self.callbacks.append({
            'component': component_id,
            'property': property_name,
            'callback': callback_func
        })
    
    def handle_interaction(self, component_id: str, property_name: str, value: Any):
        """Handle user interaction"""
        # Update state
        if component_id not in self.state['chart_states']:
            self.state['chart_states'][component_id] = {}
        
        self.state['chart_states'][component_id][property_name] = value
        
        # Execute relevant callbacks
        for callback_info in self.callbacks:
            if (callback_info['component'] == component_id and 
                callback_info['property'] == property_name):
                callback_info['callback'](value)
```

## 🧪 Testing Design

### **Unit Testing Strategy**

```python
import unittest
from unittest.mock import Mock, patch, MagicMock
import pandas as pd

class TestChartCreation(unittest.TestCase):
    """Test chart creation components"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.sample_data = ChartData(
            x=[1, 2, 3, 4],
            y=[10, 20, 15, 25],
            labels=['Test Series']
        )
        self.sample_config = ChartConfig(
            title='Test Chart',
            height=400
        )
    
    def test_line_chart_creation(self):
        """Test line chart creation with valid data"""
        chart = LineChart(self.sample_data, self.sample_config)
        component = chart.to_dash_component()
        
        self.assertIsNotNone(component)
        self.assertEqual(component.figure.layout.title.text, 'Test Chart')
        self.assertEqual(len(component.figure.data), 1)
    
    def test_invalid_data_handling(self):
        """Test handling of invalid data"""
        invalid_data = ChartData(x=[], y=[], labels=[])
        
        with self.assertRaises(ValueError):
            chart = LineChart(invalid_data, self.sample_config)
    
    @patch('chart_components.go.Figure')
    def test_chart_styling_application(self, mock_figure):
        """Test that GSK styling is applied correctly"""
        mock_fig = MagicMock()
        mock_figure.return_value = mock_fig
        
        chart = LineChart(self.sample_data, self.sample_config)
        chart.to_dash_component()
        
        # Verify styling was applied
        mock_fig.update_layout.assert_called()
        call_args = mock_fig.update_layout.call_args[1]
        self.assertIn('font_family', call_args)
        self.assertEqual(call_args['plot_bgcolor'], 'white')

class TestDataProcessing(unittest.TestCase):
    """Test data processing components"""
    
    def setUp(self):
        """Set up test data"""
        self.financial_data = pd.DataFrame({
            'date': pd.date_range('2024-01-01', periods=12, freq='M'),
            'revenue': [100, 120, 110, 140, 130, 150, 
                       145, 160, 175, 170, 185, 200],
            'expenses': [80, 90, 85, 100, 95, 110, 
                        105, 115, 125, 120, 130, 140],
            'profit': [20, 30, 25, 40, 35, 40, 
                      40, 45, 50, 50, 55, 60]
        })
    
    def test_financial_data_processing(self):
        """Test financial data processor"""
        processor = FinancialDataProcessor()
        result = processor.process(self.financial_data)
        
        self.assertIn('profit_margin', result)
        self.assertIn('growth_rate', result)
        self.assertEqual(len(result['revenue']), 12)
    
    def test_missing_data_handling(self):
        """Test handling of missing data"""
        data_with_nulls = self.financial_data.copy()
        data_with_nulls.loc[5, 'revenue'] = None
        
        processor = FinancialDataProcessor()
        result = processor.process(data_with_nulls)
        
        # Should not contain NaN values
        self.assertNotIn(None, result['revenue'])
        self.assertTrue(all(isinstance(x, (int, float)) for x in result['revenue']))
```

### **Integration Testing**

```python
class TestPageIntegration(unittest.TestCase):
    """Test page-level integration"""
    
    def setUp(self):
        """Set up test app"""
        self.app = create_test_app()
        self.client = self.app.test_client()
    
    def test_financial_page_loading(self):
        """Test financial page loads correctly"""
        response = self.client.get('/financials')
        self.assertEqual(response.status_code, 200)
        self.assertIn('Financial Analytics', response.data.decode())
    
    def test_chart_callback_execution(self):
        """Test chart callback execution"""
        with self.app.test_request_context():
            # Simulate callback trigger
            result = update_revenue_chart('2024-01-01', '2024-12-31', 'all')
            self.assertIsNotNone(result)
            self.assertIn('data', result)
```

## 📊 Performance Design

### **Optimization Strategies**

```python
from functools import lru_cache
import time
from typing import Dict, Any

class PerformanceManager:
    """Manage application performance"""
    
    def __init__(self):
        self.cache = {}
        self.cache_timestamps = {}
        self.performance_metrics = {}
    
    @lru_cache(maxsize=128)
    def cached_expensive_operation(self, data_hash: str, params: str) -> Any:
        """Cache expensive operations with LRU cache"""
        # Expensive computation here
        pass
    
    def time_based_cache(self, key: str, func: callable, 
                        max_age: int = 300) -> Any:
        """Time-based caching for data operations"""
        current_time = time.time()
        
        if key in self.cache_timestamps:
            if current_time - self.cache_timestamps[key] < max_age:
                return self.cache[key]
        
        # Execute function and cache result
        result = func()
        self.cache[key] = result
        self.cache_timestamps[key] = current_time
        
        return result
    
    def monitor_performance(self, operation_name: str):
        """Decorator for monitoring operation performance"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time
                    self._record_performance(operation_name, duration, 'success')
                    return result
                except Exception as e:
                    duration = time.time() - start_time
                    self._record_performance(operation_name, duration, 'error')
                    raise
            return wrapper
        return decorator
    
    def _record_performance(self, operation: str, duration: float, status: str):
        """Record performance metrics"""
        if operation not in self.performance_metrics:
            self.performance_metrics[operation] = []
        
        self.performance_metrics[operation].append({
            'duration': duration,
            'status': status,
            'timestamp': time.time()
        })
```

## 🔒 Security Design

### **Security Implementation**

```python
import hashlib
import secrets
from typing import Optional

class SecurityManager:
    """Handle application security"""
    
    def __init__(self):
        self.secret_key = secrets.token_hex(32)
        self.failed_attempts = {}
    
    def validate_input(self, user_input: str, input_type: str) -> bool:
        """Validate user input to prevent injection attacks"""
        validators = {
            'date': self._validate_date,
            'numeric': self._validate_numeric,
            'text': self._validate_text,
            'sql': self._validate_sql_input
        }
        
        validator = validators.get(input_type)
        if not validator:
            return False
        
        return validator(user_input)
    
    def _validate_sql_input(self, input_value: str) -> bool:
        """Validate SQL input to prevent injection"""
        dangerous_patterns = [
            'union', 'select', 'drop', 'delete', 'insert', 
            'update', 'exec', 'script', '--', ';'
        ]
        
        input_lower = input_value.lower()
        return not any(pattern in input_lower for pattern in dangerous_patterns)
    
    def sanitize_output(self, output: str) -> str:
        """Sanitize output to prevent XSS"""
        replacements = {
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            '&': '&amp;'
        }
        
        for char, replacement in replacements.items():
            output = output.replace(char, replacement)
        
        return output
    
    def rate_limit_check(self, user_id: str, max_attempts: int = 100, 
                        window_minutes: int = 60) -> bool:
        """Check if user is within rate limits"""
        current_time = time.time()
        window_start = current_time - (window_minutes * 60)
        
        if user_id not in self.failed_attempts:
            self.failed_attempts[user_id] = []
        
        # Remove old attempts outside the window
        self.failed_attempts[user_id] = [
            attempt for attempt in self.failed_attempts[user_id]
            if attempt > window_start
        ]
        
        return len(self.failed_attempts[user_id]) < max_attempts
```

---

**This software design document provides the blueprint for building robust, maintainable, and secure dashboard applications following industry best practices and GSK standards.**

*Software Design Document Version 2.0 | Last Updated: August 2025*
