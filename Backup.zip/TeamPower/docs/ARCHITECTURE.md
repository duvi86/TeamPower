# TeamPower GSK Dashboard - Technical Architecture

> **Comprehensive technical documentation for developers, architects, and system administrators**

## 🏗️ System Architecture Overview

### **High-Level Architecture**

```
┌─────────────────────────────────────────────────────────────┐
│                    Presentation Layer                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Dash UI   │  │  Bootstrap  │  │   GSK Components    │  │
│  │   Engine    │  │   Styling   │  │   & Branding        │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│                   Application Layer                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │    Page     │  │ Components  │  │     Callbacks       │  │
│  │  Modules    │  │ & Utilities │  │   & Interactions    │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│                    Business Layer                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │    Chart    │  │    Data     │  │     Analytics       │  │
│  │  Creation   │  │ Processing  │  │   & Algorithms      │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│                     Data Layer                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   SQLite    │  │   Pandas    │  │    File System      │  │
│  │  Database   │  │ DataFrames  │  │    Storage          │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### **Technology Stack Deep Dive**

| Component | Technology | Version | Purpose | Notes |
|-----------|------------|---------|---------|-------|
| **Web Framework** | Dash | 2.17+ | Interactive web apps | Built on Flask and React |
| **Visualization** | Plotly | 5.17+ | Interactive charts | WebGL acceleration |
| **UI Components** | Dash Bootstrap | 1.5+ | Responsive layouts | Bootstrap 5 integration |
| **Data Processing** | Pandas | 2.0+ | Data manipulation | High-performance analytics |
| **Numerical Computing** | NumPy | 1.24+ | Mathematical operations | Vectorized computations |
| **Database** | SQLite | 3.40+ | Local data storage | Embedded, serverless |
| **Styling** | Bootstrap | 5.3+ | CSS framework | Mobile-first design |
| **Icons** | Font Awesome | 6.0+ | Icon library | Comprehensive icon set |

## 🔧 Application Architecture

### **Multi-Page Architecture Pattern**

The application follows Dash's multi-page architecture with the following benefits:
- **Separation of Concerns**: Each page handles specific functionality
- **Code Organization**: Modular structure for maintainability
- **Performance**: Only load necessary components per page
- **Scalability**: Easy to add new pages and features

### **Component Hierarchy**

```
app.py (Root Application)
├── pages/ (Page Modules)
│   ├── overview.py
│   ├── configuration.py
│   ├── ai_financials.py
│   ├── ai_governance.py
│   ├── transactions.py
│   └── team_hierarchy.py
├── components/ (Reusable Components)
│   ├── analytics/
│   ├── forms/
│   ├── tables/
│   └── legacy/
├── utils/ (Chart Utilities)
│   ├── create_line_chart.py
│   ├── create_bar_chart.py
│   ├── create_gauge_chart.py
│   ├── create_sunburst_chart.py
│   └── create_stacked_bar_chart.py
├── config/ (Configuration)
│   └── chart_config.py
└── callbacks.py (Interaction Logic)
```

### **Data Flow Architecture**

```
User Interaction → Dash Callback → Data Processing → Chart Generation → UI Update
      ↓                ↓               ↓               ↓              ↓
  Click/Select → Python Function → Pandas Analysis → Plotly Chart → DOM Update
```

## 📊 Chart System Architecture

### **Chart Creation Pipeline**

1. **Data Input**: Raw data from database or API
2. **Data Processing**: Pandas transformation and analysis
3. **Configuration**: Chart styling and layout settings
4. **Chart Generation**: Plotly figure creation
5. **Component Integration**: Dash component wrapping
6. **UI Rendering**: Browser display and interaction

### **Standardized Chart Components**

Each chart type follows a consistent pattern:

```python
def create_chart_type(data, config):
    """
    Standard chart creation function
    
    Args:
        data (dict): Chart data with keys: x, y, labels, etc.
        config (dict): Chart configuration options
        
    Returns:
        dcc.Graph: Dash graph component
    """
    # 1. Validate input data
    # 2. Apply default configuration
    # 3. Create Plotly figure
    # 4. Apply GSK styling
    # 5. Return Dash component
```

### **GSK Design System Integration**

```python
# Color Palette
GSK_COLORS = {
    'primary': '#FF6900',      # GSK Orange
    'secondary': '#21837E',    # GSK Teal
    'success': '#28a745',      # Success green
    'warning': '#ffc107',      # Warning yellow
    'danger': '#dc3545',       # Error red
    'info': '#17a2b8',         # Info blue
    'light': '#f8f9fa',        # Light gray
    'dark': '#343a40'          # Dark gray
}

# Typography
GSK_FONTS = {
    'family': 'GSK Precision, Arial, sans-serif',
    'size': 14,
    'color': '#333333'
}

# Layout Standards
GSK_LAYOUT = {
    'margin': {'t': 60, 'b': 60, 'l': 80, 'r': 80},
    'height': 400,
    'paper_bgcolor': 'white',
    'plot_bgcolor': 'white'
}
```

## 🗄️ Database Architecture

### **SQLite Database Design**

The application uses SQLite for local data storage with the following structure:

```sql
-- User Management
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE,
    email TEXT,
    role TEXT,
    created_at TIMESTAMP,
    last_login TIMESTAMP
);

-- Project Management
CREATE TABLE projects (
    id INTEGER PRIMARY KEY,
    name TEXT,
    description TEXT,
    status TEXT,
    start_date DATE,
    end_date DATE,
    budget DECIMAL,
    team_lead_id INTEGER,
    FOREIGN KEY (team_lead_id) REFERENCES users(id)
);

-- Transactions
CREATE TABLE transactions (
    id INTEGER PRIMARY KEY,
    project_id INTEGER,
    amount DECIMAL,
    category TEXT,
    transaction_date DATE,
    description TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(id)
);

-- Team Hierarchy
CREATE TABLE team_hierarchy (
    id INTEGER PRIMARY KEY,
    employee_id INTEGER,
    manager_id INTEGER,
    department TEXT,
    position TEXT,
    level INTEGER,
    FOREIGN KEY (employee_id) REFERENCES users(id),
    FOREIGN KEY (manager_id) REFERENCES users(id)
);
```

### **Data Access Layer**

```python
class DatabaseManager:
    """Centralized database operations"""
    
    def __init__(self, db_path):
        self.db_path = db_path
        self.connection = None
    
    def connect(self):
        """Establish database connection"""
        pass
    
    def execute_query(self, query, params=None):
        """Execute SQL query with parameters"""
        pass
    
    def fetch_data(self, table, filters=None):
        """Fetch data with optional filtering"""
        pass
    
    def close(self):
        """Close database connection"""
        pass
```

## 🎨 Frontend Architecture

### **Component-Based Design**

The frontend follows a component-based architecture:

```
Layout Components
├── Navigation (Navbar)
├── Page Container
│   ├── Header Section
│   ├── Content Section
│   │   ├── Filter Panel
│   │   ├── Chart Grid
│   │   └── Data Table
│   └── Footer Section
└── Modal Dialogs
```

### **Responsive Design Strategy**

```css
/* Mobile First Approach */
.chart-container {
    width: 100%;
    padding: 16px;
}

/* Tablet */
@media (min-width: 768px) {
    .chart-container {
        width: 50%;
        padding: 24px;
    }
}

/* Desktop */
@media (min-width: 1200px) {
    .chart-container {
        width: 33.33%;
        padding: 32px;
    }
}
```

### **State Management**

Dash handles state through:
- **Component Properties**: Current values and configurations
- **Callback Functions**: State transformation logic
- **Client-Side Callbacks**: Browser-side state management
- **Storage Components**: Persistent user preferences

## 🔄 Performance Architecture

### **Optimization Strategies**

1. **Data Processing**:
   - Efficient pandas operations
   - Query optimization for large datasets
   - Caching of computed results
   - Lazy loading for heavy operations

2. **Chart Rendering**:
   - Plotly WebGL for large datasets
   - Chart resampling for performance
   - Progressive loading for complex visualizations
   - Memory management for chart updates

3. **Frontend Performance**:
   - Component virtualization
   - Efficient callback design
   - Asset optimization and compression
   - Browser caching strategies

### **Caching Strategy**

```python
from functools import lru_cache
import time

@lru_cache(maxsize=128)
def expensive_computation(data_hash, params):
    """Cache expensive computations"""
    # Perform heavy data processing
    return result

# Time-based cache invalidation
cache_timestamp = {}

def get_cached_data(key, max_age=300):
    """Get data with time-based cache invalidation"""
    current_time = time.time()
    if key in cache_timestamp:
        if current_time - cache_timestamp[key] < max_age:
            return cached_data[key]
    
    # Refresh cache
    data = fetch_fresh_data(key)
    cached_data[key] = data
    cache_timestamp[key] = current_time
    return data
```

## 🔒 Security Architecture

### **Security Layers**

1. **Application Security**:
   - Input validation and sanitization
   - SQL injection prevention
   - XSS protection
   - CSRF token implementation

2. **Data Security**:
   - Local database encryption
   - Secure data transmission
   - Access control and permissions
   - Data anonymization for demos

3. **Infrastructure Security**:
   - Secure deployment configuration
   - Environment variable management
   - Logging and monitoring
   - Regular security updates

### **Authentication & Authorization**

```python
class SecurityManager:
    """Handle authentication and authorization"""
    
    def authenticate_user(self, credentials):
        """Verify user credentials"""
        pass
    
    def authorize_access(self, user, resource):
        """Check user permissions for resource"""
        pass
    
    def log_security_event(self, event_type, user, details):
        """Log security-related events"""
        pass
```

## 🚀 Deployment Architecture

### **Development Environment**

```bash
# Local development setup
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd TeamPower/multipages
python app.py
```

### **Production Deployment Options**

1. **Single Server Deployment**:
   ```bash
   # Using Gunicorn
   gunicorn -w 4 -b 0.0.0.0:8000 app:server
   
   # Using uWSGI
   uwsgi --http :8000 --wsgi-file app.py --callable server
   ```

2. **Container Deployment**:
   ```dockerfile
   FROM python:3.11-slim
   WORKDIR /app
   COPY requirements.txt .
   RUN pip install -r requirements.txt
   COPY . .
   EXPOSE 8000
   CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:8000", "app:server"]
   ```

3. **Cloud Deployment**:
   - **AWS**: Elastic Beanstalk, ECS, or Lambda
   - **Azure**: App Service or Container Instances
   - **GCP**: App Engine or Cloud Run

### **Configuration Management**

```python
import os
from dataclasses import dataclass

@dataclass
class Config:
    """Application configuration"""
    DEBUG: bool = os.getenv('DEBUG', 'False').lower() == 'true'
    DATABASE_URL: str = os.getenv('DATABASE_URL', 'sqlite:///teampower.db')
    SECRET_KEY: str = os.getenv('SECRET_KEY', 'dev-key')
    PORT: int = int(os.getenv('PORT', 8122))
    HOST: str = os.getenv('HOST', '127.0.0.1')
```

## 📊 Monitoring & Observability

### **Application Monitoring**

```python
import logging
import time
from functools import wraps

# Performance monitoring decorator
def monitor_performance(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            duration = time.time() - start_time
            logging.info(f"{func.__name__} completed in {duration:.2f}s")
            return result
        except Exception as e:
            duration = time.time() - start_time
            logging.error(f"{func.__name__} failed after {duration:.2f}s: {e}")
            raise
    return wrapper

# Usage example
@monitor_performance
def create_complex_chart(data, config):
    # Chart creation logic
    pass
```

### **Health Checks**

```python
def health_check():
    """Application health check endpoint"""
    checks = {
        'database': check_database_connection(),
        'memory': check_memory_usage(),
        'disk': check_disk_space(),
        'dependencies': check_critical_dependencies()
    }
    
    overall_status = all(checks.values())
    return {
        'status': 'healthy' if overall_status else 'unhealthy',
        'checks': checks,
        'timestamp': time.time()
    }
```

## 🔧 Development Workflow

### **Code Organization Best Practices**

1. **Modular Structure**: Keep related functionality together
2. **Clear Interfaces**: Define clear APIs between modules
3. **Documentation**: Comprehensive docstrings and comments
4. **Testing**: Unit tests for critical functions
5. **Version Control**: Meaningful commit messages and branching

### **Development Tools**

```bash
# Code formatting
black TeamPower/
isort TeamPower/

# Code linting
flake8 TeamPower/
pylint TeamPower/

# Type checking
mypy TeamPower/

# Security scanning
bandit -r TeamPower/
```

### **Testing Strategy**

```python
import unittest
from unittest.mock import patch, MagicMock

class TestChartCreation(unittest.TestCase):
    """Test chart creation utilities"""
    
    def setUp(self):
        self.sample_data = {
            'x': [1, 2, 3, 4],
            'y': [10, 20, 15, 25],
            'labels': ['Series 1']
        }
        self.sample_config = {
            'title': 'Test Chart',
            'height': 400
        }
    
    def test_line_chart_creation(self):
        """Test line chart creation with valid data"""
        from utils.create_line_chart import create_line_chart
        
        chart = create_line_chart(self.sample_data, self.sample_config)
        self.assertIsNotNone(chart)
        self.assertEqual(chart.figure.layout.title.text, 'Test Chart')
    
    @patch('utils.create_line_chart.go.Figure')
    def test_chart_error_handling(self, mock_figure):
        """Test error handling in chart creation"""
        mock_figure.side_effect = Exception("Chart creation failed")
        
        with self.assertRaises(Exception):
            create_line_chart(self.sample_data, self.sample_config)
```

---

**This technical architecture document provides the foundation for understanding, maintaining, and extending the TeamPower GSK Dashboard application.**

*Technical Architecture Version 2.0 | Last Updated: August 2025*
