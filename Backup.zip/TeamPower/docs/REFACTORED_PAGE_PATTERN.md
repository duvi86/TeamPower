# Reusable Page Pattern Documentation

This documentation explains how to use the refactored page pattern to create consistent, maintainable pages throughout the application.

## Overview

The refactored pattern provides a generic, reusable system for creating pages with consistent structure and behavior. It supports:

- **Simple CRUD pages** (form + table)
- **Tabbed pages** (multiple form + table combinations)
- **Dashboard pages** (single content area)
- **Configuration-driven approach** (minimal code, maximum reusability)

## Architecture

### Core Components

1. **`utils/create_generic_page.py`** - Main page template engine
2. **`utils/page_config.py`** - Configuration utilities and presets
3. **Page files** - Minimal files that use the template

### Benefits

✅ **Consistent UI/UX** - All pages follow the same layout patterns  
✅ **Reduced Code Duplication** - Reuse layout logic across pages  
✅ **Easy Maintenance** - Changes to layout affect all pages  
✅ **Type Safety** - Configuration validation prevents errors  
✅ **Rapid Development** - New pages require minimal code  

## Usage Examples

### 1. Simple CRUD Page

```python
from utils.create_generic_page import create_generic_page_layout
from utils.page_config import create_simple_crud_page_config
from components.forms.my_form import create_my_form
from components.tables.my_table import create_my_table

# Configure the page
page_config = create_simple_crud_page_config(
    page_title='My Items',
    path='/my-items',
    navbar_tab='My Items',
    form_component=create_my_form,
    table_component=create_my_table,
    form_title='Add New Item',
    table_title='Item List'
)

# Create layout
layout = create_generic_page_layout(page_config)
```

### 2. Tabbed Page

```python
from utils.create_generic_page import create_generic_page_layout, create_tab_callback_factory
from utils.page_config import create_tabbed_page_config

tabs = [
    {
        'id': 'tab1',
        'label': 'Tab 1',
        'form_component': create_form1,
        'table_component': create_table1,
        'form_title': 'Add Item Type 1',
        'table_title': 'Type 1 Items',
        'active': True
    },
    {
        'id': 'tab2', 
        'label': 'Tab 2',
        'form_component': create_form2,
        'table_component': create_table2,
        'form_title': 'Add Item Type 2',
        'table_title': 'Type 2 Items'
    }
]

page_config = create_tabbed_page_config(
    page_title='Multi-Item Manager',
    path='/multi-items',
    navbar_tab='Multi Items',
    tabs=tabs
)

layout = create_generic_page_layout(page_config)
create_tab_callback_factory(page_config)  # Enables tab switching
```

### 3. Using Predefined Configurations

```python
from utils.page_config import get_transactions_page_config, get_projects_page_config
from utils.create_generic_page import create_generic_page_layout

# Use predefined configuration
page_config = get_transactions_page_config()
layout = create_generic_page_layout(page_config)
```

## Configuration Options

### Page Configuration Dictionary

```python
{
    'page_title': str,           # Page title (e.g., 'AI Transactions')
    'path': str,                 # URL path (e.g., '/ai-transactions')
    'navbar_tab': str,           # Active navbar tab name
    'form_title': str,           # Form card title (e.g., 'Add New Transaction')
    'table_title': str,          # Table card title (e.g., 'Transaction History')
    'form_component': function,  # Function that returns form component
    'table_component': function, # Function that returns table component
    'tabs': list,               # Optional: List of tab configurations
    'form_width': str,          # Optional: Form width (default: '400px')
    'min_table_width': str,     # Optional: Min table width (default: '800px')
    'max_page_width': str,      # Optional: Max page width (default: '1600px')
    'version': str              # Optional: Version string (default: '2.0.0')
}
```

### Tab Configuration

```python
{
    'id': str,                  # Unique tab identifier
    'label': str,               # Tab display name
    'form_component': function, # Function that creates form
    'table_component': function,# Function that creates table
    'form_title': str,          # Form card title
    'table_title': str,         # Table card title
    'active': bool              # Whether tab is active by default
}
```

## Migration Guide

### Before (Original Pattern)

```python
# transactions.py - 150+ lines of layout code
from dash import html, register_page, callback
from utils.create_navbar import create_navbar
from utils.create_card import create_card
# ... lots of layout code ...

def transactions_page():
    return html.Div([
        # Lots of repeated layout logic
        html.Div([
            html.Div([
                create_card(
                    title="Add New Transaction",
                    content=create_transaction_form()
                )
            ], style={'flex': '0 0 400px', ...}),
            # ... more layout code
        ])
    ])

layout = html.Div([
    create_navbar(...),
    # ... lots of wrapper code
])
```

### After (Refactored Pattern)

```python
# transactions.py - 15 lines total
from utils.create_generic_page import create_generic_page_layout
from utils.page_config import get_transactions_page_config

page_config = get_transactions_page_config()
layout = create_generic_page_layout(page_config)
```

## Creating New Page Types

### 1. Create Form Component
```python
# components/forms/my_item_form.py
def create_my_item_form(selected=False):
    # Return form component
    pass
```

### 2. Create Table Component
```python
# components/tables/my_item_table.py
def create_my_item_table(data=None):
    # Return table component
    pass
```

### 3. Create Page Configuration
```python
# utils/page_config.py
def get_my_item_page_config():
    return create_simple_crud_page_config(
        page_title='My Items',
        path='/my-items',
        navbar_tab='My Items',
        form_component=create_my_item_form,
        table_component=create_my_item_table
    )
```

### 4. Create Page File
```python
# pages/my_items.py
from utils.create_generic_page import create_generic_page_layout
from utils.page_config import get_my_item_page_config

register_page(__name__, path="/my-items", title="My Items", name="My Items")
layout = create_generic_page_layout(get_my_item_page_config())
```

## Best Practices

### ✅ Do's

- **Use predefined configurations** when possible
- **Keep page files minimal** - just configuration and layout creation
- **Follow naming conventions** for consistency
- **Validate configurations** before deployment
- **Document custom configurations** for team members

### ❌ Don'ts

- **Don't duplicate layout code** - use the generic template
- **Don't hardcode styles** - use configuration options
- **Don't mix layout and business logic** - keep concerns separated
- **Don't skip validation** - always validate page configs

## Advanced Features

### Custom Styling
```python
page_config = {
    'form_width': '500px',      # Wider form
    'min_table_width': '1000px', # Wider table
    'max_page_width': '1800px'   # Wider overall layout
}
```

### Conditional Components
```python
def conditional_form():
    if some_condition:
        return create_advanced_form()
    else:
        return create_simple_form()

page_config = {
    'form_component': conditional_form,
    # ... other config
}
```

### Dynamic Tab Configuration
```python
def get_dynamic_tabs():
    tabs = [base_tab]
    if user_has_permission('advanced'):
        tabs.append(advanced_tab)
    return tabs

page_config = create_tabbed_page_config(
    tabs=get_dynamic_tabs(),
    # ... other config
)
```

## Troubleshooting

### Common Issues

1. **Tab callbacks not working**: Make sure to call `create_tab_callback_factory(page_config)`
2. **Components not loading**: Check that component functions are properly imported
3. **Layout issues**: Verify CSS and style configurations
4. **Validation errors**: Use `validate_page_config()` to check configuration

### Debugging Tips

- Check browser console for JavaScript errors
- Verify all required callbacks are registered
- Test with minimal configuration first
- Use configuration validation tools
