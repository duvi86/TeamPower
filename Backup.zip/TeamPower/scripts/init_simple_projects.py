"""Simple database initialization for projects"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from db_management.project_db import init_project_tables, add_project

def init_simple_projects():
    """Initialize project tables and add sample data"""
    print("Initializing project database...")
    
    # Initialize tables first
    init_project_tables()
    
    # Sample projects data
    sample_projects = [
        {
            'name': 'AI-Powered Analytics Platform',
            'description': 'Building machine learning capabilities for predictive analytics and business intelligence',
            'start_date': '2024-01-15',
            'end_date': '2024-12-31',
            'status': 'Active',
            'maturity': 'PoV',
            'budget': 3500000.0,
            'potential_value': 3500000.0,
            'realized_value': 450000.0,
            'refresh_date': '2024-08-20'
        },
        {
            'name': 'Digital Transformation Initiative',
            'description': 'Modernizing legacy systems and implementing cloud-based solutions across the organization',
            'start_date': '2024-01-01',
            'end_date': '2025-06-30',
            'status': 'Active',
            'maturity': 'Scaling',
            'budget': 5000000.0,
            'potential_value': 5000000.0,
            'realized_value': 1200000.0,
            'refresh_date': '2024-08-15'
        },
        {
            'name': 'Customer Experience Optimization',
            'description': 'Improving customer journey and satisfaction metrics through enhanced digital touchpoints',
            'start_date': '2024-02-01',
            'end_date': '2024-09-30',
            'status': 'Planning',
            'maturity': 'Design',
            'budget': 1500000.0,
            'potential_value': 1500000.0,
            'realized_value': 125000.0,
            'refresh_date': '2024-08-10'
        },
        {
            'name': 'Mobile App Development',
            'description': 'Creating a comprehensive mobile application for customer engagement and self-service',
            'start_date': '2024-03-01',
            'end_date': '2024-11-30',
            'status': 'Active',
            'maturity': 'PoC',
            'budget': 2200000.0,
            'potential_value': 2200000.0,
            'realized_value': 750000.0,
            'refresh_date': '2024-08-25'
        },
        {
            'name': 'Process Automation Suite',
            'description': 'Automating manual business processes to improve efficiency and reduce operational costs',
            'start_date': '2024-01-10',
            'end_date': '2024-08-31',
            'status': 'Completed',
            'maturity': 'Live',
            'budget': 800000.0,
            'potential_value': 800000.0,
            'realized_value': 300000.0,
            'refresh_date': '2024-08-30'
        }
    ]
    
    # Add sample projects
    for project_data in sample_projects:
        try:
            add_project(**project_data)
            print(f"✅ Added project: {project_data['name']}")
        except Exception as e:
            print(f"ℹ️ Project may already exist: {project_data['name']} ({e})")
    
    print("Project database initialization completed!")

if __name__ == "__main__":
    init_simple_projects()
