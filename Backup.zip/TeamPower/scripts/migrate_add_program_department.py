#!/usr/bin/env python3
"""
Migration script to add department column to programs table
and populate it based on the program owner's department
"""

import sys
import os
import sqlite3
from pathlib import Path

# Add parent directory to path to import database utilities
sys.path.append(str(Path(__file__).resolve().parents[1]))
from db_management.db_path_utils import get_db_path

def migrate_add_program_department():
    """
    Add department column to programs table and populate with owner's department
    """
    db_path = get_db_path()
    print(f"Migrating database: {db_path}")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if department column already exists
        cursor.execute("PRAGMA table_info(programs)")
        columns = cursor.fetchall()
        has_department = any(col[1] == 'department' for col in columns)
        
        if has_department:
            print("✅ Department column already exists in programs table")
            return
        
        print("📋 Adding department column to programs table...")
        
        # Add department column
        cursor.execute("""
            ALTER TABLE programs 
            ADD COLUMN department TEXT
        """)
        
        print("✅ Department column added successfully")
        
        # Populate department based on owner's department
        print("📋 Populating department data based on program owners...")
        
        cursor.execute("""
            UPDATE programs 
            SET department = (
                SELECT team_members.department 
                FROM team_members 
                WHERE team_members.id = programs.owner_id
            )
            WHERE programs.owner_id IS NOT NULL
        """)
        
        rows_updated = cursor.rowcount
        print(f"✅ Updated {rows_updated} program records with department data")
        
        # Show the updated data
        cursor.execute("""
            SELECT p.name, p.department, tm.name as owner_name, tm.department as owner_dept
            FROM programs p
            LEFT JOIN team_members tm ON p.owner_id = tm.id
        """)
        
        results = cursor.fetchall()
        print("\n📊 Program departments after migration:")
        for row in results:
            prog_name, prog_dept, owner_name, owner_dept = row
            print(f"  • {prog_name}: {prog_dept} (Owner: {owner_name} from {owner_dept})")
        
        # Commit changes
        conn.commit()
        print("\n🎉 Migration completed successfully!")
        
    except Exception as e:
        print(f"❌ Migration failed: {e}")
        if 'conn' in locals():
            conn.rollback()
        raise
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    migrate_add_program_department()
