#!/usr/bin/env python3
"""
TeamPower Database Management Script
====================================

Single entry point for all database operations:
- Initialize database schema
- Clear existing data
- Populate with sample data
- Verify data integrity
- Generate reports

Usage:
    python manage_database.py --help
    python manage_database.py --init          # Initialize empty database
    python manage_database.py --clear         # Clear all data
    python manage_database.py --populate      # Populate with sample data
    python manage_database.py --full-reset    # Clear + Populate
    python manage_database.py --verify        # Verify data integrity
    python manage_database.py --report        # Generate data report
"""

import sys
import os
import argparse
import random
from datetime import datetime, timedelta
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from db_management.database_manager import DatabaseManager as DBManager
from db_management.project_db import (
    add_team_member, add_project, add_program, 
    get_team_members, get_projects, get_programs
)
from db_management.db import (
    add_transaction, get_transactions, get_transactions_df,
    get_dashboard_kpis, init_db
)

# Database path
DB_PATH = Path(__file__).parent.parent / 'team_power.db'

class TeamPowerDatabaseManager:
    """Comprehensive database management class"""
    
    def __init__(self):
        self.db_path = DB_PATH
        self.db = DBManager(self.db_path)
    
    def initialize_database(self):
        """Initialize database with proper schema"""
        print("🔧 Initializing database schema...")
        init_db()
        print("✅ Database schema initialized")
    
    def clear_database(self):
        """Clear all data from database"""
        print("🧹 Clearing database...")
        try:
            self.db.execute('DELETE FROM transactions')
            self.db.execute('DELETE FROM team_members')
            self.db.execute('DELETE FROM projects') 
            self.db.execute('DELETE FROM programs')
            self.db.execute('DELETE FROM objectives')
            self.db.execute('DELETE FROM key_results')
            print("✅ Database cleared successfully")
        except Exception as e:
            print(f"⚠️  Warning: {e}")
    
    def populate_team_members(self):
        """Populate team members with realistic data"""
        print("👥 Adding team members...")
        
        team_data = [
            # Leadership Team
            ("Michael Chen", "CEO", "Active", "Executive", "michael.chen@gsk.com", "2020-01-15"),
            ("Sarah Johnson", "CTO", "Active", "Technology", "sarah.johnson@gsk.com", "2020-03-20"),
            ("David Wilson", "VP Data Science", "Active", "Data Science", "david.wilson@gsk.com", "2021-06-10"),
            ("Emily Davis", "VP AI Platform", "Active", "AI Platform", "emily.davis@gsk.com", "2021-02-28"),
            
            # Data Science Team
            ("John Smith", "Senior Data Scientist", "Active", "Data Science", "john.smith@gsk.com", "2022-01-15"),
            ("Lisa Brown", "ML Engineer", "Active", "Data Science", "lisa.brown@gsk.com", "2022-11-01"),
            ("Mike Chen", "Data Analyst", "Active", "Data Science", "mike.chen@gsk.com", "2023-06-10"),
            ("Jennifer Lee", "Research Scientist", "Active", "Data Science", "jennifer.lee@gsk.com", "2023-07-01"),
            ("Maria Garcia", "Business Analyst", "On Leave", "Data Science", "maria.garcia@gsk.com", "2023-05-20"),
            
            # AI Platform Team  
            ("Robert Taylor", "Senior ML Engineer", "Active", "AI Platform", "robert.taylor@gsk.com", "2022-01-05"),
            ("Tom Anderson", "Platform Engineer", "Active", "AI Platform", "tom.anderson@gsk.com", "2022-08-15"),
            ("Jessica Wang", "DevOps Engineer", "Active", "AI Platform", "jessica.wang@gsk.com", "2023-03-12"),
            ("Alex Kumar", "Solutions Architect", "Active", "AI Platform", "alex.kumar@gsk.com", "2023-04-18"),
            
            # Support Functions
            ("Rachel Green", "Project Manager", "Active", "PMO", "rachel.green@gsk.com", "2022-09-01"),
            ("Kevin Liu", "Technical Writer", "Active", "Documentation", "kevin.liu@gsk.com", "2023-01-10"),
            ("Sophia Martinez", "UX Designer", "Active", "Design", "sophia.martinez@gsk.com", "2023-02-14"),
            
            # Former Team Members (for attrition tracking)
            ("James Wilson", "Data Scientist", "Inactive", "Data Science", "james.wilson@gsk.com", "2021-03-01"),
            ("Laura Thompson", "ML Engineer", "Inactive", "AI Platform", "laura.thompson@gsk.com", "2021-08-15"),
            ("Mark Johnson", "Platform Engineer", "Inactive", "AI Platform", "mark.johnson@gsk.com", "2022-05-20"),
            ("Anna Rodriguez", "Business Analyst", "Inactive", "Data Science", "anna.rodriguez@gsk.com", "2022-11-30"),
        ]
        
        for name, position, status, department, email, hire_date in team_data:
            try:
                add_team_member(name, position, status, department, email, hire_date)
            except Exception as e:
                print(f"⚠️  Warning adding {name}: {e}")
        
        print(f"✅ Added {len(team_data)} team members")
    
    def populate_programs(self):
        """Populate programs with realistic data"""
        print("📋 Adding programs...")
        
        program_data = [
            # Major Strategic Programs
            ("AI Drug Discovery Platform", "Advanced AI platform for drug discovery and development", "2023-01-01", "2025-12-31", "Active", 8000000),
            ("Enterprise Data Modernization", "Modernize data infrastructure and analytics capabilities", "2023-02-01", "2024-12-31", "Active", 5000000),
            ("MLOps Platform Development", "Develop enterprise MLOps platform for model deployment", "2023-03-01", "2024-09-30", "Active", 3000000),
            ("Clinical Analytics Suite", "Advanced analytics for clinical trial optimization", "2024-01-01", "2025-06-30", "Planning", 6000000),
            ("Digital Health Innovation", "Digital health solutions and patient engagement", "2023-06-01", "2025-03-31", "Active", 4500000),
            
            # Completed Programs
            ("Legacy System Migration", "Migrate legacy systems to cloud infrastructure", "2022-01-01", "2023-12-31", "Completed", 2000000),
            ("Data Governance Initiative", "Establish data governance and compliance framework", "2022-06-01", "2023-11-30", "Completed", 1500000),
        ]
        
        for name, description, start_date, end_date, status, budget in program_data:
            try:
                add_program(name, description, start_date, end_date, status, budget)
            except Exception as e:
                print(f"⚠️  Warning adding program {name}: {e}")
        
        print(f"✅ Added {len(program_data)} programs")
    
    def populate_projects(self):
        """Populate projects with realistic data"""
        print("🎯 Adding projects...")
        
        project_data = [
            # AI Drug Discovery Projects
            ("Molecular Property Prediction", "ML models for predicting molecular properties", "2023-02-01", "2024-08-31", "Active", 1200000),
            ("Compound Optimization Engine", "AI-driven compound optimization algorithms", "2023-04-01", "2024-12-31", "Active", 1800000),
            ("Drug-Target Interaction Prediction", "Predict drug-target interactions using deep learning", "2023-06-01", "2025-02-28", "Active", 1500000),
            
            # Data Modernization Projects  
            ("Data Lake Implementation", "Implement enterprise data lake on AWS", "2023-03-01", "2024-06-30", "Active", 1800000),
            ("Real-time Analytics Platform", "Build real-time analytics and monitoring platform", "2023-05-01", "2024-04-30", "Active", 900000),
            ("Data Quality Framework", "Implement data quality monitoring and validation", "2023-07-01", "2024-05-31", "Active", 600000),
            
            # MLOps Projects
            ("Model Deployment Pipeline", "Automated ML model deployment and monitoring", "2023-04-01", "2024-03-31", "Active", 800000),
            ("Feature Store Development", "Centralized feature store for ML models", "2023-06-01", "2024-07-31", "Active", 700000),
            ("ML Model Monitoring", "Comprehensive ML model performance monitoring", "2023-08-01", "2024-06-30", "Active", 500000),
            
            # Clinical Analytics Projects (Planning)
            ("Clinical Trial Optimization", "Optimize clinical trial design and execution", "2024-02-01", "2025-01-31", "Planning", 1500000),
            ("Patient Stratification Models", "AI models for patient stratification", "2024-03-01", "2025-04-30", "Planning", 1200000),
            ("Biomarker Discovery Platform", "Platform for biomarker discovery and validation", "2024-04-01", "2025-08-31", "Planning", 1800000),
            
            # Digital Health Projects
            ("Patient Engagement App", "Mobile app for patient engagement and monitoring", "2023-07-01", "2024-12-31", "Active", 1000000),
            ("Telemedicine Integration", "Integrate telemedicine capabilities", "2023-09-01", "2025-01-31", "Active", 800000),
            ("Health Data Analytics", "Analytics platform for health data insights", "2023-10-01", "2025-02-28", "Active", 1100000),
            
            # Completed Projects
            ("Cloud Migration Phase 1", "Migrate core systems to cloud", "2022-06-01", "2023-05-31", "Completed", 1200000),
            ("Data Warehouse Modernization", "Modernize enterprise data warehouse", "2022-08-01", "2023-07-31", "Completed", 900000),
            ("Identity Management System", "Implement enterprise identity management", "2022-10-01", "2023-09-30", "Completed", 600000),
        ]
        
        for name, description, start_date, end_date, status, budget in project_data:
            try:
                add_project(name, description, start_date, end_date, status, budget)
            except Exception as e:
                print(f"⚠️  Warning adding project {name}: {e}")
        
        print(f"✅ Added {len(project_data)} projects")
    
    def populate_transactions(self):
        """Populate financial transactions with realistic data"""
        print("💰 Adding financial transactions...")
        
        projects = [
            "Molecular Property Prediction", "Data Lake Implementation", "Model Deployment Pipeline",
            "Clinical Trial Optimization", "Patient Engagement App", "Real-time Analytics Platform",
            "Compound Optimization Engine", "Feature Store Development", "Cloud Migration Phase 1",
            "Data Quality Framework", "ML Model Monitoring", "Health Data Analytics"
        ]
        
        categories = [
            "Software Licenses", "Cloud Infrastructure", "Consulting Services", 
            "Hardware", "Training", "Personnel", "Research", "Development Tools",
            "Security", "Compliance", "Data Storage", "Compute Resources"
        ]
        
        vendors = [
            "AWS", "Microsoft", "Google Cloud", "Databricks", "Snowflake",
            "Palantir", "Accenture", "Deloitte", "IBM", "NVIDIA",
            "Dell", "Oracle", "SAP", "Salesforce", "ServiceNow"
        ]
        
        transaction_count = 0
        
        # Generate transactions for 2023-2025
        for year in [2023, 2024, 2025]:
            for month in range(1, 13):
                # More transactions in recent months
                monthly_transactions = random.randint(15, 25) if year >= 2024 else random.randint(8, 15)
                
                for _ in range(monthly_transactions):
                    day = random.randint(1, 28)
                    date = f"{year}-{month:02d}-{day:02d}"
                    
                    project = random.choice(projects)
                    category = random.choice(categories)
                    vendor = random.choice(vendors)
                    
                    # Realistic amount based on category
                    if category in ["Cloud Infrastructure", "Software Licenses"]:
                        amount = random.randint(5000, 50000)
                    elif category in ["Consulting Services", "Personnel"]:
                        amount = random.randint(10000, 100000)
                    elif category in ["Hardware", "Research"]:
                        amount = random.randint(2000, 75000)
                    else:
                        amount = random.randint(1000, 25000)
                    
                    description = f"{category} for {project} - {vendor}"
                    ccp = f"CCP-{project[:3].upper()}-{year}"
                    ccs = f"SOW-{random.randint(1000, 9999)}"
                    sow = f"SOW{year}{month:02d}{random.randint(10, 99)}"
                    po = f"PO{year}{random.randint(100000, 999999)}"
                    trans_type = random.choice(["Budget", "Planned", "Consumed"])
                    
                    try:
                        add_transaction(date, description, ccp, ccs, sow, po, amount, category, trans_type)
                        transaction_count += 1
                    except Exception as e:
                        print(f"⚠️  Warning adding transaction: {e}")
        
        print(f"✅ Added {transaction_count} financial transactions")
    
    def verify_data_integrity(self):
        """Verify database data integrity"""
        print("🔍 Verifying data integrity...")
        
        issues = []
        
        # Check basic counts
        team_count = len(get_team_members())
        program_count = len(get_programs()) 
        project_count = len(get_projects())
        transaction_count = len(get_transactions())
        
        print(f"📊 Data counts:")
        print(f"   Team members: {team_count}")
        print(f"   Programs: {program_count}")
        print(f"   Projects: {project_count}")
        print(f"   Transactions: {transaction_count}")
        
        # Verify minimum data requirements
        if team_count < 5:
            issues.append(f"Low team member count: {team_count}")
        if program_count < 3:
            issues.append(f"Low program count: {program_count}")
        if project_count < 5:
            issues.append(f"Low project count: {project_count}")
        if transaction_count < 50:
            issues.append(f"Low transaction count: {transaction_count}")
        
        # Test key dashboard functions
        try:
            df = get_transactions_df()
            if df.empty:
                issues.append("Empty transactions dataframe")
            else:
                print(f"   Transaction DF shape: {df.shape}")
        except Exception as e:
            issues.append(f"Transaction DF error: {e}")
        
        try:
            kpis = get_dashboard_kpis()
            if not kpis:
                issues.append("No KPIs returned")
            else:
                print(f"   KPIs available: {len(kpis)}")
        except Exception as e:
            issues.append(f"KPI error: {e}")
        
        if issues:
            print("❌ Data integrity issues found:")
            for issue in issues:
                print(f"   - {issue}")
            return False
        else:
            print("✅ Data integrity verification passed")
            return True
    
    def generate_report(self):
        """Generate comprehensive data report"""
        print("📊 Generating database report...")
        print("="*50)
        
        # Team composition
        team_members = get_team_members()
        if team_members:
            departments = {}
            statuses = {}
            for member in team_members:
                dept = member.get('department', 'Unknown')
                status = member.get('status', 'Unknown')
                departments[dept] = departments.get(dept, 0) + 1
                statuses[status] = statuses.get(status, 0) + 1
            
            print("👥 Team Composition:")
            print("   By Department:")
            for dept, count in sorted(departments.items()):
                print(f"     {dept}: {count}")
            print("   By Status:")
            for status, count in sorted(statuses.items()):
                print(f"     {status}: {count}")
            print()
        
        # Program summary
        programs = get_programs()
        if programs:
            print("📋 Program Summary:")
            total_budget = sum(p.get('budget', 0) for p in programs)
            statuses = {}
            for program in programs:
                status = program.get('status', 'Unknown')
                statuses[status] = statuses.get(status, 0) + 1
            
            print(f"   Total Programs: {len(programs)}")
            print(f"   Total Budget: ${total_budget:,.0f}")
            print("   By Status:")
            for status, count in sorted(statuses.items()):
                print(f"     {status}: {count}")
            print()
        
        # Project summary  
        projects = get_projects()
        if projects:
            print("🎯 Project Summary:")
            total_budget = sum(p.get('budget', 0) for p in projects)
            statuses = {}
            for project in projects:
                status = project.get('status', 'Unknown')
                statuses[status] = statuses.get(status, 0) + 1
            
            print(f"   Total Projects: {len(projects)}")
            print(f"   Total Budget: ${total_budget:,.0f}")
            print("   By Status:")
            for status, count in sorted(statuses.items()):
                print(f"     {status}: {count}")
            print()
        
        # Transaction summary
        try:
            df = get_transactions_df()
            if not df.empty:
                print("💰 Transaction Summary:")
                print(f"   Total Transactions: {len(df)}")
                print(f"   Total Amount: ${df['Amount'].sum():,.0f}")
                print(f"   Date Range: {df['Date'].min()} to {df['Date'].max()}")
                print("   By Category:")
                for category, amount in df.groupby('Category')['Amount'].sum().head(5).items():
                    print(f"     {category}: ${amount:,.0f}")
                print()
        except Exception as e:
            print(f"⚠️  Transaction summary error: {e}")
        
        # KPI summary
        try:
            kpis = get_dashboard_kpis()
            if kpis:
                print("📈 Key Performance Indicators:")
                for key, value in kpis.items():
                    if isinstance(value, (int, float)):
                        if 'rate' in key.lower() or 'percentage' in key.lower():
                            print(f"   {key.replace('_', ' ').title()}: {value:.1f}%")
                        else:
                            print(f"   {key.replace('_', ' ').title()}: {value}")
                    else:
                        print(f"   {key.replace('_', ' ').title()}: {value}")
        except Exception as e:
            print(f"⚠️  KPI summary error: {e}")
        
        print("="*50)

def main():
    """Main command line interface"""
    parser = argparse.ArgumentParser(
        description="TeamPower Database Management Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python manage_database.py --full-reset    # Complete database reset
  python manage_database.py --populate      # Add sample data only
  python manage_database.py --verify        # Check data integrity
  python manage_database.py --report        # Generate report
        """
    )
    
    parser.add_argument('--init', action='store_true', 
                       help='Initialize database schema')
    parser.add_argument('--clear', action='store_true',
                       help='Clear all database data')
    parser.add_argument('--populate', action='store_true',
                       help='Populate database with sample data')
    parser.add_argument('--full-reset', action='store_true',
                       help='Clear database and populate with fresh data')
    parser.add_argument('--verify', action='store_true',
                       help='Verify data integrity')
    parser.add_argument('--report', action='store_true',
                       help='Generate comprehensive data report')
    
    args = parser.parse_args()
    
    # If no arguments provided, show help
    if not any(vars(args).values()):
        parser.print_help()
        return
    
    db_manager = TeamPowerDatabaseManager()
    
    try:
        if args.init:
            db_manager.initialize_database()
        
        if args.clear or args.full_reset:
            db_manager.clear_database()
        
        if args.populate or args.full_reset:
            print("🚀 Starting comprehensive database population...")
            db_manager.populate_team_members()
            db_manager.populate_programs() 
            db_manager.populate_projects()
            db_manager.populate_transactions()
            print("✅ Database population completed!")
        
        if args.verify or args.full_reset:
            db_manager.verify_data_integrity()
        
        if args.report:
            db_manager.generate_report()
            
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
