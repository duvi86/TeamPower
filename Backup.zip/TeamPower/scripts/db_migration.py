"""Database migration utilities to handle schema updates"""

from db_management.database_manager import DatabaseManager
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / 'team_power.db'
db = DatabaseManager(DB_PATH)

def migrate_projects_table():
    """Migrate existing projects table to add new columns"""
    try:
        # Check if the table exists and what columns it has
        columns_query = "PRAGMA table_info(projects)"
        existing_columns = db.fetchall(columns_query)
        existing_column_names = [col[1] for col in existing_columns] if existing_columns else []
        
        # Define new columns to add
        new_columns = [
            ('ongoing', 'BOOLEAN DEFAULT 0'),
            ('currency', 'TEXT DEFAULT "USD"'),
            ('program_id', 'INTEGER'),
            ('spadm_id', 'INTEGER')
        ]
        
        # Add missing columns
        for column_name, column_def in new_columns:
            if column_name not in existing_column_names:
                try:
                    alter_query = f"ALTER TABLE projects ADD COLUMN {column_name} {column_def}"
                    db.execute(alter_query, commit=True)
                    print(f"Added column {column_name} to projects table")
                except Exception as e:
                    print(f"Could not add column {column_name}: {e}")
        
        print("Projects table migration completed")
        return True
        
    except Exception as e:
        print(f"Error during projects table migration: {e}")
        return False

def check_and_migrate():
    """Check if migration is needed and run it"""
    try:
        # Check if projects table exists
        table_check = db.fetchone("SELECT name FROM sqlite_master WHERE type='table' AND name='projects'")
        if table_check:
            print("Projects table exists, checking for migration...")
            return migrate_projects_table()
        else:
            print("Projects table doesn't exist, will be created with new schema")
            return True
    except Exception as e:
        print(f"Error checking migration status: {e}")
        return False

if __name__ == "__main__":
    check_and_migrate()
