#!/usr/bin/env python3
"""
Populate sample data for the dashboard
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from utils.project_db import (
    add_program, add_project, add_team_member, add_objective, add_key_result
)
from utils.db import add_transaction
from datetime import datetime, date, timedelta
import random

def populate_programs():
    """Add sample programs"""
    programs = [
        {
            'name': 'Digital Transformation Initiative',
            'description': 'Company-wide digital transformation program',
            'start_date': '2025-01-01',
            'end_date': '2026-12-31',
            'status': 'Active',
            'budget': 2500000.0
        },
        {
            'name': 'AI & Machine Learning Program',
            'description': 'Implementing AI solutions across departments',
            'start_date': '2025-03-01',
            'end_date': '2025-11-30',
            'status': 'Active',
            'budget': 1800000.0
        },
        {
            'name': 'Customer Experience Enhancement',
            'description': 'Improving customer touchpoints and satisfaction',
            'start_date': '2025-02-15',
            'end_date': '2025-09-30',
            'status': 'Active',
            'budget': 950000.0
        },
        {
            'name': 'Infrastructure Modernization',
            'description': 'Upgrading IT infrastructure and systems',
            'start_date': '2024-06-01',
            'end_date': '2025-05-31',
            'status': 'Active',
            'budget': 3200000.0
        }
    ]
    
    for program in programs:
        try:
            add_program(**program)
        except Exception as e:

def populate_team_members():
    """Add sample team members"""
    departments = ['Engineering', 'Data Science', 'Product', 'Marketing', 'Operations', 'Finance']
    roles = ['Manager', 'Senior Developer', 'Developer', 'Analyst', 'Specialist', 'Director']
    
    team_members = [
        {'name': 'Alice Johnson', 'email': 'alice.johnson@company.com', 'role': 'Director', 'department': 'Engineering', 'status': 'Active'},
        {'name': 'Bob Smith', 'email': 'bob.smith@company.com', 'role': 'Manager', 'department': 'Data Science', 'status': 'Active'},
        {'name': 'Carol Davis', 'email': 'carol.davis@company.com', 'role': 'Senior Developer', 'department': 'Engineering', 'status': 'Active'},
        {'name': 'David Wilson', 'email': 'david.wilson@company.com', 'role': 'Analyst', 'department': 'Finance', 'status': 'Active'},
        {'name': 'Emily Brown', 'email': 'emily.brown@company.com', 'role': 'Manager', 'department': 'Product', 'status': 'Active'},
        {'name': 'Frank Miller', 'email': 'frank.miller@company.com', 'role': 'Developer', 'department': 'Engineering', 'status': 'Active'},
        {'name': 'Grace Lee', 'email': 'grace.lee@company.com', 'role': 'Specialist', 'department': 'Marketing', 'status': 'Active'},
        {'name': 'Henry Chen', 'email': 'henry.chen@company.com', 'role': 'Senior Developer', 'department': 'Engineering', 'status': 'Active'},
        {'name': 'Iris Garcia', 'email': 'iris.garcia@company.com', 'role': 'Analyst', 'department': 'Data Science', 'status': 'Active'},
        {'name': 'Jack Taylor', 'email': 'jack.taylor@company.com', 'role': 'Manager', 'department': 'Operations', 'status': 'Active'},
        {'name': 'Karen White', 'email': 'karen.white@company.com', 'role': 'Developer', 'department': 'Engineering', 'status': 'On Leave'},
        {'name': 'Leo Martinez', 'email': 'leo.martinez@company.com', 'role': 'Specialist', 'department': 'Product', 'status': 'Active'},
        {'name': 'Maria Rodriguez', 'email': 'maria.rodriguez@company.com', 'role': 'Senior Developer', 'department': 'Data Science', 'status': 'Active'},
        {'name': 'Nathan Cooper', 'email': 'nathan.cooper@company.com', 'role': 'Analyst', 'department': 'Finance', 'status': 'Active'},
        {'name': 'Olivia Parker', 'email': 'olivia.parker@company.com', 'role': 'Manager', 'department': 'Marketing', 'status': 'Active'},
        {'name': 'Paul Anderson', 'email': 'paul.anderson@company.com', 'role': 'Developer', 'department': 'Engineering', 'status': 'Inactive'},
        {'name': 'Quinn Thompson', 'email': 'quinn.thompson@company.com', 'role': 'Specialist', 'department': 'Operations', 'status': 'Active'},
        {'name': 'Rachel Green', 'email': 'rachel.green@company.com', 'role': 'Senior Developer', 'department': 'Product', 'status': 'Active'},
        {'name': 'Sam Mitchell', 'email': 'sam.mitchell@company.com', 'role': 'Analyst', 'department': 'Data Science', 'status': 'Active'},
        {'name': 'Tina Lewis', 'email': 'tina.lewis@company.com', 'role': 'Manager', 'department': 'Engineering', 'status': 'Active'}
    ]
    
    for member in team_members:
        try:
            add_team_member(**member)
        except Exception as e:

def populate_projects():
    """Add sample projects"""
    projects = [
        {
            'name': 'Customer Portal Redesign',
            'description': 'Redesign customer-facing portal with modern UX/UI',
            'start_date': '2025-01-15',
            'end_date': '2025-06-30',
            'status': 'Active',
            'budget': 450000.0,
            'maturity': 'PoC',
            'potential_value': 800000.0,
            'realized_value': 120000.0
        },
        {
            'name': 'Data Analytics Platform',
            'description': 'Build comprehensive data analytics and reporting platform',
            'start_date': '2025-02-01',
            'end_date': '2025-08-31',
            'status': 'Active',
            'budget': 680000.0,
            'maturity': 'Scoping',
            'potential_value': 1200000.0,
            'realized_value': 0.0
        },
        {
            'name': 'Mobile App Development',
            'description': 'Native mobile app for iOS and Android',
            'start_date': '2025-03-01',
            'end_date': '2025-12-15',
            'status': 'Active',
            'budget': 750000.0,
            'maturity': 'PoV',
            'potential_value': 1500000.0,
            'realized_value': 250000.0
        },
        {
            'name': 'Legacy System Migration',
            'description': 'Migrate legacy systems to cloud-based solutions',
            'start_date': '2024-09-01',
            'end_date': '2025-04-30',
            'status': 'Active',
            'budget': 920000.0,
            'maturity': 'Scaling',
            'potential_value': 600000.0,
            'realized_value': 480000.0
        },
        {
            'name': 'Security Enhancement Project',
            'description': 'Implement advanced security measures and compliance',
            'start_date': '2025-01-01',
            'end_date': '2025-07-31',
            'status': 'Active',
            'budget': 320000.0,
            'maturity': 'PoC',
            'potential_value': 500000.0,
            'realized_value': 75000.0
        },
        {
            'name': 'Marketing Automation',
            'description': 'Automated marketing campaigns and lead nurturing',
            'start_date': '2024-11-01',
            'end_date': '2025-03-31',
            'status': 'Completed',
            'budget': 280000.0,
            'maturity': 'Live',
            'potential_value': 400000.0,
            'realized_value': 420000.0
        },
        {
            'name': 'Employee Training Platform',
            'description': 'Online training and certification platform',
            'start_date': '2024-08-01',
            'end_date': '2024-12-31',
            'status': 'Completed',
            'budget': 180000.0,
            'maturity': 'Live',
            'potential_value': 300000.0,
            'realized_value': 285000.0
        },
        {
            'name': 'Supply Chain Optimization',
            'description': 'AI-driven supply chain and inventory optimization',
            'start_date': '2025-04-01',
            'end_date': '2025-10-31',
            'status': 'Planning',
            'budget': 540000.0,
            'maturity': 'Seed',
            'potential_value': 900000.0,
            'realized_value': 0.0
        },
        {
            'name': 'Quality Assurance Automation',
            'description': 'Automated testing and quality assurance processes',
            'start_date': '2025-02-15',
            'end_date': '2025-05-31',
            'status': 'On Hold',
            'budget': 220000.0,
            'maturity': 'Scoping',
            'potential_value': 350000.0,
            'realized_value': 0.0
        },
        {
            'name': 'API Gateway Implementation',
            'description': 'Centralized API management and security gateway',
            'start_date': '2024-10-01',
            'end_date': '2025-02-28',
            'status': 'Completed',
            'budget': 380000.0,
            'maturity': 'Live',
            'potential_value': 450000.0,
            'realized_value': 465000.0
        }
    ]
    
    for project in projects:
        try:
            add_project(**project)
            print(f"Added project: {project['name']}")
        except Exception as e:
            print(f"Error adding project {project['name']}: {e}")

def populate_transactions():
    """Add sample financial transactions for multiple years"""
    categories = ['Budget', 'Planned', 'Consumed']
    types = ['OPEX', 'CAPEX']
    
    # Generate transactions for multiple years to populate dropdown
    years_to_populate = [2023, 2024, 2025]
    
    for year in years_to_populate:
        # Generate transactions for each year
        if year == 2025:
            # For current year, go up to current date
            start_date = datetime(year, 1, 1)
            end_date = datetime(year, 8, 26)
        else:
            # For past years, full year
            start_date = datetime(year, 1, 1)
            end_date = datetime(year, 12, 31)
        
        current_date = start_date
        transactions_count = 0
        
        while current_date <= end_date and transactions_count < 30:  # Limit to 30 per year
            # Generate 1-2 transactions per iteration
            num_transactions = random.randint(1, 2)
            
            for _ in range(num_transactions):
                try:
                    # Use correct parameter names for add_transaction function
                    add_transaction(
                        date=current_date.strftime('%Y-%m-%d'),
                        ccp=f"CC-{random.randint(1000, 9999)}",
                        ccs=f"SOW-{random.randint(100, 999)}",
                        sow=f"SOW-{year}-{random.randint(10, 99):02d}",
                        po=f"PO-{random.randint(10000, 99999)}",
                        amount=round(random.uniform(5000, 150000), 2),
                        category=random.choice(categories),
                        type_=random.choice(types)
                    )
                    transactions_count += 1
                    if transactions_count >= 30:
                        break
                except Exception as e:
                    print(f"Error adding transaction for {year}: {e}")
            
            current_date += timedelta(days=random.randint(7, 30))  # Jump weeks/months
        
        print(f"Added {transactions_count} transactions for {year}")
    
    print(f"Completed transaction population for years: {years_to_populate}")

def main():
    """Populate all sample data"""
    populate_programs()
    populate_team_members()
    populate_projects()
    populate_transactions()
    

if __name__ == "__main__":
    main()
