#!/usr/bin/env python3
"""
Migration script to add project_id column to transactions table
This enables proper linking between transactions and projects
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from db_management.database_manager import DatabaseManager
from db_management.db_path_utils import get_db_path

def add_project_id_column():
    """Add project_id column to transactions table for proper linking"""
    try:
        # Use the correct database path
        db_path = get_db_path()
        print(f"Using database: {db_path}")
        
        db = DatabaseManager(db_path)
        
        # Check if project_id column exists
        cursor = db._connect().cursor()
        cursor.execute("PRAGMA table_info(transactions)")
        columns = [column[1] for column in cursor.fetchall()]
        cursor.close()
        
        if 'project_id' not in columns:
            print("Adding project_id column to transactions table...")
            
            # Add project_id column
            db.execute("ALTER TABLE transactions ADD COLUMN project_id INTEGER", commit=True)
            
            # Create index for better performance
            db.execute("CREATE INDEX IF NOT EXISTS idx_transactions_project_id ON transactions(project_id)", commit=True)
            
            print("✅ Successfully added project_id column to transactions table")
        else:
            print("ℹ️  project_id column already exists in transactions table")
        
        return True
        
    except Exception as e:
        print(f"❌ Error adding project_id column: {e}")
        return False

if __name__ == "__main__":
    print("Running migration: Add project_id to transactions table")
    success = add_project_id_column()
    if success:
        print("Migration completed successfully!")
    else:
        print("Migration failed!")
        sys.exit(1)
