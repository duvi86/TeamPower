"""
Migration script to drop the 'realized_value' column from the 'projects' table.
This is safe for SQLite. For other DBs, adjust as needed.
"""
import sqlite3
import os

def migrate_drop_realized_value_column(db_path):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    # 1. Get current schema
    c.execute("PRAGMA table_info(projects)")
    columns = [col[1] for col in c.fetchall()]
    if 'realized_value' not in columns:
        print("Column 'realized_value' does not exist. No migration needed.")
        conn.close()
        return
    # 2. Rename old table
    c.execute("ALTER TABLE projects RENAME TO projects_old")
    # 3. Create new table without realized_value, matching actual schema
    c.execute('''
        CREATE TABLE projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            start_date DATE,
            end_date DATE,
            status TEXT,
            maturity TEXT,
            budget REAL,
            owner_id INTEGER,
            created_at DATE,
            updated_at DATE,
            potential_value REAL,
            refresh_date DATE
        )
    ''')
    # 4. Copy data (exclude realized_value)
    c.execute('''
        INSERT INTO projects (id, name, description, start_date, end_date, status, maturity, budget, owner_id, created_at, updated_at, potential_value, refresh_date)
        SELECT id, name, description, start_date, end_date, status, maturity, budget, owner_id, created_at, updated_at, potential_value, refresh_date
        FROM projects_old
    ''')
    # 5. Drop old table
    c.execute("DROP TABLE projects_old")
    conn.commit()
    conn.close()
    print("Migration complete: 'realized_value' column dropped from 'projects'.")

if __name__ == "__main__":
    db_path = os.path.join(os.path.dirname(__file__), "..", "team_power.db")
    migrate_drop_realized_value_column(db_path)
