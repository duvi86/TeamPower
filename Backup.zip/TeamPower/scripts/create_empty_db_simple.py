#!/usr/bin/env python3
"""
Simple Database Creation Script for TeamPower Application

This script provides a streamlined way to create an empty database for the TeamPower
application with minimal configuration and no advanced features.

Key Features:
- Single function call to create database
- No backup or verification options
- Fixed database location
- Minimal console output
- Quick setup for development

Usage:
    python create_empty_db_simple.py

Target Database:
    /Users/md395378/TeamPowerGSK/team_power.db

Tables Created:
    - projects: Core project tracking and management
    - programs: High-level program organization  
    - program_projects: Junction table for program-project relationships
    - team_members: Employee information and organizational hierarchy
    - project_teams: Team member assignments to projects
    - objectives: OKR (Objectives and Key Results) objectives
    - key_results: Measurable outcomes for objectives
    - okr_supporting_team: Additional team members supporting objectives
    - kr_supporting_team: Additional team members supporting key results
    - transactions: Financial transactions and budget tracking
    - value_tracking: Business value realization tracking

Important Notes:
    - This script overwrites existing databases without backup
    - No verification or error handling beyond basic exceptions
    - For production use, consider using recreate_empty_database.py instead
    - Database location is hardcoded - modify create_empty_database() call to change

Dependencies:
    - sqlite3 (standard library)
    - Database management modules from db_management/ folder

Related Scripts:
    - recreate_empty_database.py: Full-featured database creation with backup/verification
    - scripts/create_fresh_db.py: Alternative database creation approach
    
Author: TeamPower Development Team
Date: September 2024
"""

import sys
import os
import sqlite3

# Add the parent directory to the path so we can import from db_management
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def create_empty_database(db_path):
    """
    Simple function to create an empty database with all required tables.
    
    This is a lightweight version that creates the database structure
    without the advanced features of the comprehensive recreation script.
    
    Args:
        db_path (str): Path where the database should be created
    """
    # Remove existing database if it exists
    if os.path.exists(db_path):
        os.remove(db_path)
    
    # Create new database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create all tables (simplified schema without extensive comments)
    tables = {
        'projects': '''
            CREATE TABLE projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT,
                start_date DATE,
                end_date DATE,
                status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                maturity TEXT CHECK(maturity IN ('Seed', 'Scoping', 'PoC', 'PoV', 'Scaling', 'Live')) DEFAULT 'Seed',
                budget REAL DEFAULT 0.0,
                owner_id INTEGER,
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                potential_value REAL DEFAULT 0.0,
                realized_value REAL DEFAULT 0.0,
                refresh_date DATE
            )
        ''',
        'programs': '''
            CREATE TABLE programs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT,
                start_date DATE,
                end_date DATE,
                status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                budget REAL DEFAULT 0.0,
                owner_id INTEGER,
                department TEXT,
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now'))
            )
        ''',
        'program_projects': '''
            CREATE TABLE program_projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                program_id INTEGER NOT NULL,
                project_id INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (program_id) REFERENCES programs(id),
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        ''',
        'team_members': '''
            CREATE TABLE team_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                role TEXT NOT NULL,
                department TEXT,
                manager_id INTEGER,
                start_date DATE,
                end_date DATE,
                status TEXT CHECK(status IN ('Active', 'Inactive', 'On Leave')) DEFAULT 'Active',
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (manager_id) REFERENCES team_members(id)
            )
        ''',
        'project_teams': '''
            CREATE TABLE project_teams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                team_member_id INTEGER NOT NULL,
                role_in_project TEXT DEFAULT 'Team Member',
                allocation_percentage REAL DEFAULT 100.0,
                start_date DATE,
                end_date DATE,
                created_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (team_member_id) REFERENCES team_members(id)
            )
        ''',
        'objectives': '''
            CREATE TABLE objectives (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                program_id INTEGER,
                owner_id INTEGER NOT NULL,
                main_responsible_id INTEGER,
                quarter TEXT,
                year INTEGER,
                status TEXT CHECK(status IN ('Planning', 'Active', 'At Risk', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                progress REAL DEFAULT 0.0,
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (program_id) REFERENCES programs(id),
                FOREIGN KEY (owner_id) REFERENCES team_members(id),
                FOREIGN KEY (main_responsible_id) REFERENCES team_members(id)
            )
        ''',
        'key_results': '''
            CREATE TABLE key_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                objective_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                target_value REAL,
                current_value REAL DEFAULT 0.0,
                unit TEXT,
                status TEXT CHECK(status IN ('Planning', 'Active', 'At Risk', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                progress REAL DEFAULT 0.0,
                due_date DATE,
                owner_id INTEGER,
                main_responsible_id INTEGER,
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (objective_id) REFERENCES objectives(id),
                FOREIGN KEY (owner_id) REFERENCES team_members(id),
                FOREIGN KEY (main_responsible_id) REFERENCES team_members(id)
            )
        ''',
        'okr_supporting_team': '''
            CREATE TABLE okr_supporting_team (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                objective_id INTEGER NOT NULL,
                team_member_id INTEGER NOT NULL,
                role TEXT DEFAULT 'Support',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (objective_id) REFERENCES objectives(id),
                FOREIGN KEY (team_member_id) REFERENCES team_members(id)
            )
        ''',
        'kr_supporting_team': '''
            CREATE TABLE kr_supporting_team (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_result_id INTEGER NOT NULL,
                team_member_id INTEGER NOT NULL,
                role TEXT DEFAULT 'Support',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (key_result_id) REFERENCES key_results(id),
                FOREIGN KEY (team_member_id) REFERENCES team_members(id)
            )
        ''',
        'transactions': '''
            CREATE TABLE transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                description TEXT,
                cost_center_project TEXT,
                cost_center_sow TEXT,
                sow_number TEXT,
                po TEXT,
                amount REAL,
                category TEXT,
                type TEXT,
                project_id INTEGER,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        ''',
        'value_tracking': '''
            CREATE TABLE value_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                description TEXT NOT NULL,
                amount REAL NOT NULL,
                start_date TEXT,
                end_date TEXT,
                project_id INTEGER,
                business_sponsor TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        '''
    }
    
    # Create tables
    for table_name, sql in tables.items():
        cursor.execute(sql)
    
    # Create basic indexes
    indexes = [
        "CREATE INDEX idx_transactions_project_id ON transactions(project_id)",
        "CREATE INDEX idx_program_projects_program_id ON program_projects(program_id)",
        "CREATE INDEX idx_program_projects_project_id ON program_projects(project_id)",
        "CREATE INDEX idx_project_teams_project_id ON project_teams(project_id)",
        "CREATE INDEX idx_project_teams_member_id ON project_teams(team_member_id)",
        "CREATE INDEX idx_value_tracking_project_id ON value_tracking(project_id)"
    ]
    
    for index_sql in indexes:
        cursor.execute(index_sql)
    
    # Commit and close
    conn.commit()
    conn.close()
    
    print(f"Database created successfully at: {db_path}")

def main():
    """
    Main function to create an empty database with minimal configuration.
    
    This function provides a simple interface to create a new empty database
    for the TeamPower application. It uses hardcoded paths and settings for
    quick development setup.
    
    Process:
        1. Display startup message
        2. Call database creation function
        3. Handle any errors gracefully
        4. Display completion status
        
    Database Location:
        /Users/md395378/TeamPowerGSK/team_power.db
        
    Error Handling:
        - Catches and displays any creation errors
        - Exits with status code 1 on failure
        - Exits with status code 0 on success
        
    Output:
        Simple console messages about creation status
        
    Note:
        This function uses the database_manager.create_empty_database()
        function which handles all table creation and schema setup.
        
    Example Output:
        Creating empty database...
        Database created successfully at: /Users/md395378/TeamPowerGSK/team_power.db
    """
    try:
        print("Creating empty database...")
        
        # Create empty database at fixed location
        create_empty_database('/Users/md395378/TeamPowerGSK/team_power.db')
        
        print("✅ Database created successfully!")
        
    except Exception as e:
        print(f"❌ Error creating database: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    """
    Script entry point for command-line execution.
    
    When this script is run directly (not imported), it executes the main()
    function to create the database. This allows the script to be used as:
    
        python create_empty_db_simple.py
        
    or executed directly if made executable:
    
        chmod +x create_empty_db_simple.py
        ./create_empty_db_simple.py
        
    The script will exit with appropriate status codes:
        - 0: Success (database created)
        - 1: Error (database creation failed)
    """
    main()