# TeamPower Database Management

## Overview

The `manage_database.py` script is the **single entry point** for all TeamPower database operations. It provides a comprehensive command-line interface to initialize, populate, verify, and manage the TeamPower database.

## Features

- 🔧 **Database Initialization**: Set up proper database schema
- 🧹 **Data Management**: Clear existing data safely
- 📊 **Sample Data Population**: Populate with realistic sample data
- 🔍 **Data Integrity Verification**: Verify data consistency and completeness
- 📈 **Comprehensive Reporting**: Generate detailed database reports
- ⚡ **One-Command Reset**: Complete database reset with fresh data

## Usage

### Basic Commands

```bash
# Show help and available options
python scripts/manage_database.py --help

# Initialize empty database schema
python scripts/manage_database.py --init

# Clear all existing data
python scripts/manage_database.py --clear

# Populate with sample data
python scripts/manage_database.py --populate

# Complete reset: clear + populate + verify
python scripts/manage_database.py --full-reset

# Verify data integrity
python scripts/manage_database.py --verify

# Generate comprehensive report
python scripts/manage_database.py --report
```

### Common Workflows

```bash
# 🚀 Quick Start - Complete database setup
python scripts/manage_database.py --full-reset

# 📊 Check current database status
python scripts/manage_database.py --report

# 🔍 Verify data after changes
python scripts/manage_database.py --verify
```

## Sample Data

The script populates the database with comprehensive, realistic sample data:

### Team Members (20+ people)
- **Leadership Team**: CEO, CTO, VPs across different departments
- **Data Science Team**: Data Scientists, ML Engineers, Analysts, Researchers
- **AI Platform Team**: Platform Engineers, DevOps, Solutions Architects
- **Support Functions**: Project Managers, Technical Writers, UX Designers
- **Former Members**: For realistic attrition tracking

### Programs (7 major programs)
- **AI Drug Discovery Platform** ($8M budget, Active)
- **Enterprise Data Modernization** ($5M budget, Active)
- **MLOps Platform Development** ($3M budget, Active)
- **Clinical Analytics Suite** ($6M budget, Planning)
- **Digital Health Innovation** ($4.5M budget, Active)
- **Legacy System Migration** ($2M budget, Completed)
- **Data Governance Initiative** ($1.5M budget, Completed)

### Projects (18 projects)
- **Drug Discovery**: Molecular prediction, compound optimization, drug-target interaction
- **Data Platform**: Data lake, real-time analytics, data quality framework
- **MLOps**: Model deployment, feature store, monitoring
- **Clinical**: Trial optimization, patient stratification, biomarker discovery
- **Digital Health**: Patient engagement, telemedicine, health analytics
- **Infrastructure**: Cloud migration, data warehouse, identity management

### Financial Transactions (600+ transactions)
- **Realistic Categories**: Software licenses, cloud infrastructure, consulting, hardware, training, personnel
- **Time Range**: 2023-2025 with varying monthly volumes
- **Vendors**: AWS, Microsoft, Google Cloud, Databricks, Snowflake, consulting firms
- **Amounts**: Realistic ranges based on category type

## Database Schema

The script manages the following core tables:

- **`team_members`**: Employee information, status, departments
- **`programs`**: Strategic programs with budgets and timelines
- **`projects`**: Individual projects linked to programs
- **`transactions`**: Financial transactions with detailed categorization
- **`objectives`**: OKR objectives (when applicable)
- **`key_results`**: OKR key results (when applicable)

## Data Integrity Checks

The verification process checks:

- ✅ **Minimum Data Requirements**: Ensures sufficient data for dashboard functionality
- ✅ **Database Functions**: Tests key dashboard functions (`get_transactions_df`, `get_dashboard_kpis`)
- ✅ **Data Consistency**: Validates data relationships and formats
- ✅ **KPI Calculation**: Ensures all KPIs can be calculated properly

## Reporting Features

The comprehensive report includes:

- 👥 **Team Composition**: Breakdown by department and status
- 📋 **Program Summary**: Total count, budget, status distribution
- 🎯 **Project Summary**: Total count, budget, status distribution  
- 💰 **Transaction Summary**: Total amount, date range, category breakdown
- 📈 **KPI Summary**: All key performance indicators

## Error Handling

The script includes robust error handling:

- **Graceful Warnings**: Continues operation despite individual record failures
- **Transaction Rollback**: Ensures database consistency
- **Detailed Error Messages**: Helps diagnose issues
- **Data Validation**: Checks data integrity before proceeding

## Integration

This tool integrates seamlessly with the TeamPower dashboard:

- **Dashboard Functions**: Populates data for all dashboard KPIs and charts
- **Real-time Analytics**: Ensures sufficient data for time-series analysis
- **Filter Operations**: Provides data across all categories and date ranges
- **Performance Testing**: Enables testing with realistic data volumes

## Best Practices

### Development Workflow
```bash
# 1. Start with fresh data
python scripts/manage_database.py --full-reset

# 2. Verify everything works
python scripts/manage_database.py --verify

# 3. Check data distribution
python scripts/manage_database.py --report

# 4. Test dashboard functionality
python multipages/app.py
```

### Production Deployment
```bash
# 1. Initialize schema only
python scripts/manage_database.py --init

# 2. Import real data (custom scripts)
# Your data import process here

# 3. Verify data integrity
python scripts/manage_database.py --verify
```

## Troubleshooting

### Common Issues

**"No data available" errors in dashboard**
```bash
python scripts/manage_database.py --populate
```

**Database schema errors**
```bash
python scripts/manage_database.py --init
```

**Data consistency issues**
```bash
python scripts/manage_database.py --verify
```

**Need fresh start**
```bash
python scripts/manage_database.py --full-reset
```

### Verification Steps

1. **Check file exists**: `ls -la team_power.db`
2. **Run verification**: `python scripts/manage_database.py --verify`
3. **Generate report**: `python scripts/manage_database.py --report`
4. **Test dashboard**: Start the app and check for errors

## File Structure

```
TeamPower/
├── scripts/
│   └── manage_database.py          # Single entry point for DB management
├── db_management/
│   ├── database_manager.py         # Core database operations
│   ├── db.py                       # Transaction and KPI functions
│   └── project_db.py               # Project/program/team functions
└── team_power.db                   # SQLite database file
```

---

**Note**: This script replaces all individual populate scripts and provides a unified, reliable way to manage the TeamPower database. Use `--full-reset` for quick setup and `--report` to monitor database health.
