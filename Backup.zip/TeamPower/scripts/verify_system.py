#!/usr/bin/env python3
"""
TeamPower GSK Dashboard - System Verification Script
Verifies the complete application setup and functionality
"""

import sys
import os
import importlib
import subprocess
from pathlib import Path

def print_header(title):
    """Print formatted section header"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")

def print_success(message):
    """Print success message"""
    print(f"✅ {message}")

def print_error(message):
    """Print error message"""
    print(f"❌ {message}")

def print_info(message):
    """Print info message"""
    print(f"ℹ️  {message}")

def check_python_version():
    """Check Python version compatibility"""
    print_header("PYTHON VERSION CHECK")
    
    version = sys.version_info
    print_info(f"Python version: {version.major}.{version.minor}.{version.micro}")
    
    if version.major == 3 and version.minor >= 8:
        print_success("Python version is compatible")
        return True
    else:
        print_error("Python 3.8+ required")
        return False

def check_dependencies():
    """Check if all required dependencies are installed"""
    print_header("DEPENDENCY CHECK")
    
    required_packages = [
        'dash',
        'dash_bootstrap_components',
        'pandas',
        'numpy',
        'plotly',
        'flask',
        'bcrypt'
    ]
    
    all_installed = True
    
    for package in required_packages:
        try:
            module = importlib.import_module(package)
            version = getattr(module, '__version__', 'Unknown')
            print_success(f"{package}: {version}")
        except ImportError:
            print_error(f"{package}: Not installed")
            all_installed = False
    
    return all_installed

def check_project_structure():
    """Check project directory structure"""
    print_header("PROJECT STRUCTURE CHECK")
    
    required_paths = [
        'TeamPower',
        'TeamPower/multipages',
        'TeamPower/multipages/app.py',
        'TeamPower/multipages/callbacks.py',
        'TeamPower/multipages/pages',
        'TeamPower/multipages/utils',
        'TeamPower/multipages/components',
        'TeamPower/multipages/assets',
        'TeamPower/multipages/config',
        'TeamPower/db_management',
        'requirements.txt',
        'README.md',
        'USER_GUIDE.md',
        'ARCHITECTURE.md',
        'SOFTWARE_DESIGN.md'
    ]
    
    all_present = True
    
    for path in required_paths:
        if os.path.exists(path):
            print_success(f"{path}")
        else:
            print_error(f"{path}: Missing")
            all_present = False
    
    return all_present

def check_chart_utilities():
    """Check chart utility functions"""
    print_header("CHART UTILITIES CHECK")
    
    sys.path.append('TeamPower/multipages')
    sys.path.append('TeamPower')
    
    chart_modules = [
        'utils.create_line_chart',
        'utils.create_bar_chart',
        'utils.create_gauge_chart',
        'utils.create_sunburst_chart',
        'utils.create_stacked_bar_chart'
    ]
    
    all_working = True
    
    for module_name in chart_modules:
        try:
            module = importlib.import_module(module_name)
            print_success(f"{module_name}: Available")
        except ImportError as e:
            print_error(f"{module_name}: Import failed - {e}")
            all_working = False
    
    return all_working

def check_database_system():
    """Check database system functionality"""
    print_header("DATABASE SYSTEM CHECK")
    
    try:
        sys.path.append('TeamPower')
        from db_management.database_manager import DatabaseManager
        print_success("DatabaseManager: Available")
        
        # Check if database files exist
        db_files = [f for f in os.listdir('TeamPower') if f.endswith('.db')]
        if db_files:
            print_success(f"Database files found: {', '.join(db_files)}")
        else:
            print_info("No database files found (will be created on first run)")
        
        return True
    except ImportError as e:
        print_error(f"Database system: Import failed - {e}")
        return False

def test_basic_functionality():
    """Test basic application functionality"""
    print_header("BASIC FUNCTIONALITY TEST")
    
    try:
        # Test chart creation
        sys.path.append('TeamPower/multipages')
        sys.path.append('TeamPower')
        
        import pandas as pd
        import numpy as np
        from utils.create_line_chart import create_line_chart, prepare_metrics_data
        from utils.create_bar_chart import create_bar_chart
        
        # Create test data
        test_data = {
            'x': ['Jan', 'Feb', 'Mar', 'Apr'],
            'y': [100, 120, 110, 130],
            'labels': ['Test Metric']
        }
        
        test_config = {
            'title': 'Test Chart',
            'height': 400,
            'x_title': 'Month',
            'y_title': 'Value'
        }
        
        # Test line chart
        line_chart = create_line_chart(test_data, test_config)
        print_success("Line chart creation: Working")
        
        # Test bar chart
        bar_data = {
            'categories': ['A', 'B', 'C', 'D'],
            'values': [10, 20, 15, 25]
        }
        bar_config = {
            'title': 'Test Bar Chart',
            'height': 300
        }
        bar_chart = create_bar_chart(bar_data, bar_config)
        print_success("Bar chart creation: Working")
        
        return True
        
    except Exception as e:
        print_error(f"Functionality test failed: {e}")
        return False

def check_app_startup():
    """Check if the app can start without errors"""
    print_header("APPLICATION STARTUP CHECK")
    
    try:
        sys.path.append('TeamPower/multipages')
        
        # Try to import the main app module
        import app
        print_success("App module: Imports successfully")
        
        # Check if pages can be imported
        from pages import overview, configuration, ai_financials
        print_success("Page modules: Import successfully")
        
        return True
        
    except Exception as e:
        print_error(f"App startup check failed: {e}")
        return False

def generate_summary_report(results):
    """Generate summary report"""
    print_header("VERIFICATION SUMMARY")
    
    total_checks = len(results)
    passed_checks = sum(results.values())
    
    print(f"Total checks: {total_checks}")
    print(f"Passed: {passed_checks}")
    print(f"Failed: {total_checks - passed_checks}")
    print(f"Success rate: {(passed_checks/total_checks)*100:.1f}%")
    
    print("\nDetailed Results:")
    for check_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {check_name}: {status}")
    
    if passed_checks == total_checks:
        print_success("\n🎉 ALL CHECKS PASSED - Application is ready to use!")
        print_info("To start the application:")
        print_info("  1. cd TeamPower/multipages")
        print_info("  2. python app.py")
        print_info("  3. Open http://localhost:8122 in your browser")
    else:
        print_error(f"\n❌ {total_checks - passed_checks} checks failed - Please review the issues above")

def main():
    """Main verification function"""
    print_header("TEAMPOWER GSK DASHBOARD - SYSTEM VERIFICATION")
    print_info("Verifying complete application setup and functionality...")
    
    # Run all checks
    results = {
        'Python Version': check_python_version(),
        'Dependencies': check_dependencies(),
        'Project Structure': check_project_structure(),
        'Chart Utilities': check_chart_utilities(),
        'Database System': check_database_system(),
        'Basic Functionality': test_basic_functionality(),
        'App Startup': check_app_startup()
    }
    
    # Generate summary
    generate_summary_report(results)
    
    # Return exit code
    return 0 if all(results.values()) else 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
