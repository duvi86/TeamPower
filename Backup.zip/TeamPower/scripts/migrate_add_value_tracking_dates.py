
import os
import sys
import sqlite3
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from db_management.db_path_utils import get_db_path

def column_exists(cursor, table, column):
    cursor.execute(f"PRAGMA table_info({table})")
    return any(row[1] == column for row in cursor.fetchall())

def migrate():
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    # Add start_date
    if not column_exists(cursor, 'value_tracking', 'start_date'):
        cursor.execute("ALTER TABLE value_tracking ADD COLUMN start_date TEXT")
    # Add end_date
    if not column_exists(cursor, 'value_tracking', 'end_date'):
        cursor.execute("ALTER TABLE value_tracking ADD COLUMN end_date TEXT")
    # Add business_sponsor
    if not column_exists(cursor, 'value_tracking', 'business_sponsor'):
        cursor.execute("ALTER TABLE value_tracking ADD COLUMN business_sponsor TEXT")
    # Add project_id
    if not column_exists(cursor, 'value_tracking', 'project_id'):
        cursor.execute("ALTER TABLE value_tracking ADD COLUMN project_id INTEGER")
    # Add created_at
    if not column_exists(cursor, 'value_tracking', 'created_at'):
        cursor.execute("ALTER TABLE value_tracking ADD COLUMN created_at TEXT")
    # Add updated_at
    if not column_exists(cursor, 'value_tracking', 'updated_at'):
        cursor.execute("ALTER TABLE value_tracking ADD COLUMN updated_at TEXT")
    conn.commit()
    conn.close()
    print("Migration complete.")

if __name__ == "__main__":
    migrate()
