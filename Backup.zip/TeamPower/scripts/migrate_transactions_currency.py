#!/usr/bin/env python3
"""
Migration script to add currency support to transactions table
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from db_management.database_manager import DatabaseManager
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / 'team_power.db'
db = DatabaseManager(DB_PATH)

def migrate_transactions_currency():
    """Add currency column to transactions table"""
    try:
        # Check if the table exists and what columns it has
        columns_query = "PRAGMA table_info(transactions)"
        existing_columns = db.fetchall(columns_query)
        existing_column_names = [col[1] for col in existing_columns] if existing_columns else []
        
        print(f"Existing columns in transactions table: {existing_column_names}")
        
        # Check if currency column already exists
        if 'currency' not in existing_column_names:
            try:
                # Add currency column with USD as default
                alter_query = "ALTER TABLE transactions ADD COLUMN currency TEXT DEFAULT 'USD'"
                db.execute(alter_query, commit=True)
                print("Added currency column to transactions table")
                
                # Update all existing transactions to USD
                update_query = "UPDATE transactions SET currency = 'USD' WHERE currency IS NULL"
                db.execute(update_query, commit=True)
                print("Updated all existing transactions to USD currency")
                
                return True
            except Exception as e:
                print(f"Could not add currency column: {e}")
                return False
        else:
            print("Currency column already exists in transactions table")
            return True
        
    except Exception as e:
        print(f"Error during transactions currency migration: {e}")
        return False

def verify_migration():
    """Verify that the migration was successful"""
    try:
        # Check columns
        columns_query = "PRAGMA table_info(transactions)"
        columns = db.fetchall(columns_query)
        column_names = [col[1] for col in columns]
        
        print(f"Final columns in transactions table: {column_names}")
        
        if 'currency' in column_names:
            # Check sample data
            sample_query = "SELECT id, description, amount, currency FROM transactions LIMIT 3"
            samples = db.fetchall(sample_query)
            print("Sample transactions with currency:")
            for sample in samples:
                print(f"  ID: {sample[0]}, Description: {sample[1][:30]}..., Amount: {sample[2]}, Currency: {sample[3]}")
            return True
        else:
            print("ERROR: Currency column not found after migration")
            return False
            
    except Exception as e:
        print(f"Error verifying migration: {e}")
        return False

if __name__ == "__main__":
    print("Starting transactions currency migration...")
    
    if migrate_transactions_currency():
        print("Migration completed successfully")
        if verify_migration():
            print("Migration verification passed")
        else:
            print("Migration verification failed")
    else:
        print("Migration failed")
