#!/usr/bin/env python3
"""
Database migration script to change transaction types from "Planned" to "X-charged"

Migration:
- Planned -> X-charged
"""
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from db_management.database_manager import DatabaseManager
from db_management.db_path_utils import get_db_path

def migrate_planned_to_xcharged():
    """
    Migrate transaction types from "Planned" to "X-charged"
    """
    
    # Get database connection
    db_path = get_db_path()
    db = DatabaseManager(db_path)
    
    print("Starting transaction type migration: Planned -> X-charged...")
    
    try:
        # Get current count of "Planned" transactions
        current_count = db.fetchone(
            'SELECT COUNT(*) FROM transactions WHERE type = ?', 
            ('Planned',)
        )[0]
        
        print(f"Found {current_count} transactions with type 'Planned'")
        
        if current_count > 0:
            # Update Planned to X-charged
            print("Updating 'Planned' -> 'X-charged'...")
            
            result = db.execute(
                'UPDATE transactions SET type = ? WHERE type = ?',
                ('X-charged', 'Planned'),
                commit=True
            )
            
            # Verify migration
            new_count = db.fetchone(
                'SELECT COUNT(*) FROM transactions WHERE type = ?', 
                ('X-charged',)
            )[0]
            
            remaining_planned = db.fetchone(
                'SELECT COUNT(*) FROM transactions WHERE type = ?', 
                ('Planned',)
            )[0]
            
            print(f"Migration completed!")
            print(f"  Transactions with 'X-charged': {new_count}")
            print(f"  Remaining 'Planned' transactions: {remaining_planned}")
            
            if remaining_planned == 0:
                print("✓ All 'Planned' transactions successfully migrated to 'X-charged'")
            else:
                print(f"⚠ Warning: {remaining_planned} transactions still have type 'Planned'")
        else:
            print("No 'Planned' transactions found - migration not needed")
        
        # Show final transaction type distribution
        print("\nFinal transaction type distribution:")
        types = ['Budget', 'X-charged', 'Consumed']
        for transaction_type in types:
            count = db.fetchone(
                'SELECT COUNT(*) FROM transactions WHERE type = ?', 
                (transaction_type,)
            )[0]
            print(f"  {transaction_type}: {count} transactions")
            
    except Exception as e:
        print(f"Error during migration: {e}")
        raise e

def rollback_xcharged_to_planned():
    """
    Rollback transaction types from "X-charged" to "Planned"
    """
    
    # Get database connection
    db_path = get_db_path()
    db = DatabaseManager(db_path)
    
    print("Starting transaction type rollback: X-charged -> Planned...")
    
    try:
        # Get current count of "X-charged" transactions
        current_count = db.fetchone(
            'SELECT COUNT(*) FROM transactions WHERE type = ?', 
            ('X-charged',)
        )[0]
        
        print(f"Found {current_count} transactions with type 'X-charged'")
        
        if current_count > 0:
            # Update X-charged back to Planned
            print("Rolling back 'X-charged' -> 'Planned'...")
            
            result = db.execute(
                'UPDATE transactions SET type = ? WHERE type = ?',
                ('Planned', 'X-charged'),
                commit=True
            )
            
            # Verify rollback
            new_count = db.fetchone(
                'SELECT COUNT(*) FROM transactions WHERE type = ?', 
                ('Planned',)
            )[0]
            
            remaining_xcharged = db.fetchone(
                'SELECT COUNT(*) FROM transactions WHERE type = ?', 
                ('X-charged',)
            )[0]
            
            print(f"Rollback completed!")
            print(f"  Transactions with 'Planned': {new_count}")
            print(f"  Remaining 'X-charged' transactions: {remaining_xcharged}")
            
            if remaining_xcharged == 0:
                print("✓ All 'X-charged' transactions successfully rolled back to 'Planned'")
            else:
                print(f"⚠ Warning: {remaining_xcharged} transactions still have type 'X-charged'")
        else:
            print("No 'X-charged' transactions found - rollback not needed")
        
        # Show final transaction type distribution
        print("\nFinal transaction type distribution:")
        types = ['Budget', 'Planned', 'Consumed']
        for transaction_type in types:
            count = db.fetchone(
                'SELECT COUNT(*) FROM transactions WHERE type = ?', 
                (transaction_type,)
            )[0]
            print(f"  {transaction_type}: {count} transactions")
            
    except Exception as e:
        print(f"Error during rollback: {e}")
        raise e

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Migrate transaction types: Planned <-> X-charged')
    parser.add_argument('--rollback', action='store_true', 
                       help='Rollback from X-charged to Planned')
    
    args = parser.parse_args()
    
    if args.rollback:
        rollback_xcharged_to_planned()
    else:
        migrate_planned_to_xcharged()
