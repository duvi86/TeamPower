import sqlite3
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'db_management'))
from db_path_utils import get_db_path

def migrate_add_end_date():
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    # Check if 'end_date' column exists
    cur.execute("PRAGMA table_info(team_members)")
    columns = [row[1] for row in cur.fetchall()]
    if 'end_date' not in columns:
        print("Adding 'end_date' column to team_members table...")
        cur.execute("ALTER TABLE team_members ADD COLUMN end_date DATE")
        conn.commit()
        print("Migration complete.")
    else:
        print("'end_date' column already exists.")
    conn.close()

if __name__ == "__main__":
    migrate_add_end_date()
