#!/usr/bin/env python3
"""
Verify that all required dependencies are installed and working
"""

import sys
import importlib

def check_package(package_name, display_name=None):
    """Check if a package can be imported"""
    if display_name is None:
        display_name = package_name
    
    try:
        importlib.import_module(package_name)
        print(f"✅ {display_name}")
        return True
    except ImportError:
        print(f"❌ {display_name} - Not installed")
        return False

def main():
    print("🔍 Verifying TeamPower Dependencies")
    print("=" * 40)
    
    required_packages = [
        ("dash", "Dash"),
        ("dash_bootstrap_components", "Dash Bootstrap Components"),
        ("pandas", "Pandas"),
        ("numpy", "NumPy"),
        ("plotly", "Plotly"),
        ("flask", "Flask"),
        ("bcrypt", "BCrypt"),
    ]
    
    all_good = True
    for package, name in required_packages:
        if not check_package(package, name):
            all_good = False
    
    print()
    if all_good:
        print("🎉 All dependencies are installed!")
        print("Ready to run: python TeamPower/multipages/app.py")
    else:
        print("⚠️  Some dependencies are missing.")
        print("Run: pip install -r requirements.txt")
    
    return 0 if all_good else 1

if __name__ == "__main__":
    sys.exit(main())