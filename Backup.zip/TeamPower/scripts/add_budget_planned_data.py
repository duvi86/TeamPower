"""
Script to add missing Budget and Planned transactions for KPI display
"""

from db_management.db import add_transaction
from datetime import datetime

def add_budget_planned_data():
    """Add Budget and Planned transactions for years 2023-2025"""
    
    # Data for each year
    years_data = {
        2023: {
            'budget_capex': 2000000.0,
            'budget_opex': 1400000.0,
            'planned_capex': 1800000.0,
            'planned_opex': 1300000.0,
        },
        2024: {
            'budget_capex': 2300000.0,
            'budget_opex': 1600000.0,
            'planned_capex': 2100000.0,
            'planned_opex': 1500000.0,
        },
        2025: {
            'budget_capex': 2500000.0,
            'budget_opex': 1800000.0,
            'planned_capex': 2200000.0,
            'planned_opex': 1600000.0,
        }
    }
    
    # Add Budget and Planned entries for each year
    for year, data in years_data.items():
        print(f"Adding Budget and Planned data for {year}...")
        
        # Budget entries
        add_transaction(
            date=f"{year}-01-01",
            description=f"Annual CAPEX Budget Allocation {year}",
            ccp="BUDGET-CAPEX",
            ccs="ANNUAL-BUDGET",
            sow=f"BUDGET-SOW-{year}-001",
            po=f"BUDGET-PO-{year}-001",
            amount=data['budget_capex'],
            category="Budget",
            type_="CAPEX"
        )
        
        add_transaction(
            date=f"{year}-01-01",
            description=f"Annual OPEX Budget Allocation {year}",
            ccp="BUDGET-OPEX",
            ccs="ANNUAL-BUDGET",
            sow=f"BUDGET-SOW-{year}-002",
            po=f"BUDGET-PO-{year}-002",
            amount=data['budget_opex'],
            category="Budget",
            type_="OPEX"
        )
        
        # Planned entries
        add_transaction(
            date=f"{year}-01-15",
            description=f"Planned CAPEX Spending {year}",
            ccp="PLANNED-CAPEX",
            ccs="ANNUAL-PLAN",
            sow=f"PLAN-SOW-{year}-001",
            po=f"PLAN-PO-{year}-001",
            amount=data['planned_capex'],
            category="Planned",
            type_="CAPEX"
        )
        
        add_transaction(
            date=f"{year}-01-15",
            description=f"Planned OPEX Spending {year}",
            ccp="PLANNED-OPEX",
            ccs="ANNUAL-PLAN",
            sow=f"PLAN-SOW-{year}-002",
            po=f"PLAN-PO-{year}-002",
            amount=data['planned_opex'],
            category="Planned",
            type_="OPEX"
        )
        
        print(f"  Added Budget CAPEX: £{data['budget_capex']:,.2f}")
        print(f"  Added Budget OPEX: £{data['budget_opex']:,.2f}")
        print(f"  Added Planned CAPEX: £{data['planned_capex']:,.2f}")
        print(f"  Added Planned OPEX: £{data['planned_opex']:,.2f}")

if __name__ == "__main__":
    add_budget_planned_data()
    print("\nCompleted adding Budget and Planned data!")
