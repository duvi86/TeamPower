#!/usr/bin/env python3
"""
Populate the OKR database with sample data for testing and demonstration
"""

import sqlite3
from datetime import datetime, timedelta
import random

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect('team_power.db')
    conn.row_factory = sqlite3.Row
    return conn

def populate_objectives():
    """Add sample objectives"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Sample objectives for different team leads
    objectives = [
        {
            'title': 'Increase Customer Satisfaction Score',
            'description': 'Improve our overall customer satisfaction score from 4.2 to 4.7 out of 5.0 by implementing customer feedback loops and enhancing support processes.',
            'program_id': 1,  # Assuming program exists
            'owner_id': 5,    # Emma Wilson - VP Sales
            'main_responsible_id': 14,  # Robert Davis - Sales Manager
            'quarter': 'Q3',
            'year': 2025,
            'status': 'Active'
        },
        {
            'title': 'Accelerate Product Development Cycle',
            'description': 'Reduce product development cycle time from 6 months to 4 months while maintaining quality standards.',
            'program_id': 2,
            'owner_id': 2,    # Michael Chen - CTO
            'main_responsible_id': 3,   # Lisa Rodriguez - VP Engineering
            'quarter': 'Q3',
            'year': 2025,
            'status': 'Active'
        },
        {
            'title': 'Expand Market Reach',
            'description': 'Increase market penetration in the European market by 25% through strategic partnerships and localized marketing campaigns.',
            'program_id': 3,
            'owner_id': 4,    # David Kim - VP Marketing
            'main_responsible_id': 11,  # Sophie Turner - Marketing Manager
            'quarter': 'Q4',
            'year': 2025,
            'status': 'Planning'
        },
        {
            'title': 'Improve System Reliability',
            'description': 'Achieve 99.9% uptime across all critical systems and reduce mean time to recovery to under 15 minutes.',
            'program_id': 2,
            'owner_id': 3,    # Lisa Rodriguez - VP Engineering
            'main_responsible_id': 8,   # Ryan O\'Connor - DevOps Engineer
            'quarter': 'Q3',
            'year': 2025,
            'status': 'Active'
        },
        {
            'title': 'Launch Mobile Application',
            'description': 'Successfully launch our mobile application with core features available on both iOS and Android platforms.',
            'program_id': 2,
            'owner_id': 3,    # Lisa Rodriguez - VP Engineering
            'main_responsible_id': 10,  # James Brown - Frontend Developer
            'quarter': 'Q4',
            'year': 2025,
            'status': 'Planning'
        },
        {
            'title': 'Revenue Growth Initiative',
            'description': 'Achieve 40% YoY revenue growth through new customer acquisition and existing customer expansion.',
            'program_id': 1,
            'owner_id': 1,    # Sarah Johnson - CEO
            'main_responsible_id': 5,   # Emma Wilson - VP Sales
            'quarter': 'Q4',
            'year': 2025,
            'status': 'Active'
        },
        {
            'title': 'Team Development Program',
            'description': 'Implement comprehensive team development program with quarterly skill assessments and training plans.',
            'program_id': 1,
            'owner_id': 1,    # Sarah Johnson - CEO
            'main_responsible_id': 2,   # Michael Chen - CTO
            'quarter': 'Q3',
            'year': 2025,
            'status': 'Active'
        },
        {
            'title': 'Quality Assurance Enhancement',
            'description': 'Reduce production bugs by 60% and implement automated testing coverage of 90%+ across all features.',
            'program_id': 2,
            'owner_id': 3,    # Lisa Rodriguez - VP Engineering
            'main_responsible_id': 9,   # Priya Patel - QA Engineer
            'quarter': 'Q3',
            'year': 2025,
            'status': 'Active'
        }
    ]
    
    for obj in objectives:
        cursor.execute('''
            INSERT OR REPLACE INTO objectives 
            (title, description, program_id, owner_id, main_responsible_id, quarter, year, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            obj['title'], obj['description'], obj['program_id'], obj['owner_id'],
            obj['main_responsible_id'], obj['quarter'], obj['year'], obj['status'],
            datetime.now().isoformat(), datetime.now().isoformat()
        ))
    
    conn.commit()
    conn.close()
        # print(f"✅ Added {len(objectives)} objectives")

def populate_key_results():
    """Add sample key results"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get all objective IDs
    cursor.execute('SELECT id FROM objectives')
    objective_ids = [row[0] for row in cursor.fetchall()]
    
    key_results = []
    
    # Key results for Customer Satisfaction (assuming objective id 1 or 2)
    if len(objective_ids) >= 1:
        key_results.extend([
            {
                'objective_id': objective_ids[0],
                'title': 'Implement Customer Feedback System',
                'description': 'Deploy automated customer feedback collection system across all touchpoints',
                'target_value': 100,
                'current_value': 75,
                'unit': 'Percentage',
                'due_date': '2025-09-30',
                'owner_id': 14,  # Robert Davis
                'responsible_id': 14,
                'supporting_team': 'Sales Team'
            },
            {
                'objective_id': objective_ids[0],
                'title': 'Reduce Response Time',
                'description': 'Achieve average customer support response time under 2 hours',
                'target_value': 2,
                'current_value': 3.5,
                'unit': 'Hours',
                'due_date': '2025-09-15',
                'owner_id': 14,  # Robert Davis
                'responsible_id': 16,  # Mark Williams
                'supporting_team': 'Customer Support'
            },
            {
                'objective_id': objective_ids[0],
                'title': 'Customer Satisfaction Score',
                'description': 'Achieve target satisfaction score of 4.7/5.0',
                'target_value': 4.7,
                'current_value': 4.4,
                'unit': 'Score',
                'due_date': '2025-09-30',
                'owner_id': 5,   # Emma Wilson
                'responsible_id': 14, # Robert Davis
                'supporting_team': 'Sales & Support'
            }
        ])
    
    # Key results for Product Development (assuming objective id 2 or 3)
    if len(objective_ids) >= 2:
        key_results.extend([
            {
                'objective_id': objective_ids[1],
                'title': 'Implement Agile Workflows',
                'description': 'Deploy agile development workflows across all engineering teams',
                'target_value': 100,
                'current_value': 80,
                'unit': 'Percentage',
                'due_date': '2025-08-31',
                'owner_id': 3,   # Lisa Rodriguez
                'responsible_id': 3,
                'supporting_team': 'Engineering Team'
            },
            {
                'objective_id': objective_ids[1],
                'title': 'Automated Testing Coverage',
                'description': 'Achieve 95% automated testing coverage across all features',
                'target_value': 95,
                'current_value': 78,
                'unit': 'Percentage',
                'due_date': '2025-09-15',
                'owner_id': 3,   # Lisa Rodriguez
                'responsible_id': 9,  # Priya Patel
                'supporting_team': 'QA Team'
            },
            {
                'objective_id': objective_ids[1],
                'title': 'Development Cycle Time',
                'description': 'Reduce average development cycle from 6 months to 4 months',
                'target_value': 4,
                'current_value': 5.2,
                'unit': 'Months',
                'due_date': '2025-10-31',
                'owner_id': 2,   # Michael Chen
                'responsible_id': 3,  # Lisa Rodriguez
                'supporting_team': 'Full Engineering'
            }
        ])
    
    # Key results for Market Expansion
    if len(objective_ids) >= 3:
        key_results.extend([
            {
                'objective_id': objective_ids[2],
                'title': 'European Market Penetration',
                'description': 'Achieve 25% market penetration in target European countries',
                'target_value': 25,
                'current_value': 8,
                'unit': 'Percentage',
                'due_date': '2025-12-31',
                'owner_id': 4,   # David Kim
                'responsible_id': 11, # Sophie Turner
                'supporting_team': 'Marketing Team'
            },
            {
                'objective_id': objective_ids[2],
                'title': 'Strategic Partnerships',
                'description': 'Establish partnerships with 10 strategic European partners',
                'target_value': 10,
                'current_value': 3,
                'unit': 'Partners',
                'due_date': '2025-11-30',
                'owner_id': 4,   # David Kim
                'responsible_id': 11, # Sophie Turner
                'supporting_team': 'Business Development'
            }
        ])
    
    # Key results for System Reliability
    if len(objective_ids) >= 4:
        key_results.extend([
            {
                'objective_id': objective_ids[3],
                'title': 'System Uptime',
                'description': 'Maintain 99.9% uptime across all critical systems',
                'target_value': 99.9,
                'current_value': 99.5,
                'unit': 'Percentage',
                'due_date': '2025-09-30',
                'owner_id': 8,   # Ryan O'Connor
                'responsible_id': 8,
                'supporting_team': 'DevOps Team'
            },
            {
                'objective_id': objective_ids[3],
                'title': 'Mean Time to Recovery',
                'description': 'Reduce MTTR to under 15 minutes for critical issues',
                'target_value': 15,
                'current_value': 22,
                'unit': 'Minutes',
                'due_date': '2025-09-15',
                'owner_id': 8,   # Ryan O'Connor
                'responsible_id': 8,
                'supporting_team': 'DevOps Team'
            }
        ])
    
    # Key results for Mobile App
    if len(objective_ids) >= 5:
        key_results.extend([
            {
                'objective_id': objective_ids[4],
                'title': 'iOS App Development',
                'description': 'Complete iOS application with core features',
                'target_value': 100,
                'current_value': 65,
                'unit': 'Percentage',
                'due_date': '2025-11-15',
                'owner_id': 10,  # James Brown
                'responsible_id': 10,
                'supporting_team': 'Mobile Team'
            },
            {
                'objective_id': objective_ids[4],
                'title': 'Android App Development',
                'description': 'Complete Android application with core features',
                'target_value': 100,
                'current_value': 60,
                'unit': 'Percentage',
                'due_date': '2025-11-15',
                'owner_id': 10,  # James Brown
                'responsible_id': 7,  # Jessica Martinez
                'supporting_team': 'Mobile Team'
            }
        ])
    
    # Insert all key results
    for kr in key_results:
        cursor.execute('''
            INSERT OR REPLACE INTO key_results
            (objective_id, title, description, target_value, current_value, unit, due_date, 
             owner_id, main_responsible_id, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            kr['objective_id'], kr['title'], kr['description'], kr['target_value'],
            kr['current_value'], kr['unit'], kr['due_date'], kr['owner_id'],
            kr['responsible_id'], 'Active', 
            datetime.now().isoformat(), datetime.now().isoformat()
        ))
    
    conn.commit()
    conn.close()
        # print(f"✅ Added {len(key_results)} key results")

def populate_supporting_teams():
    """Add sample supporting team members"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get all key result IDs
    cursor.execute('SELECT id FROM key_results')
    kr_ids = [row[0] for row in cursor.fetchall()]
    
    # Sample supporting team assignments
    supporting_assignments = []
    
    for kr_id in kr_ids:
        # Randomly assign 1-3 team members to each key result
        num_supporters = random.randint(1, 3)
        available_members = [6, 7, 8, 9, 10, 11, 12, 13, 15, 16]  # Various team member IDs
        selected_members = random.sample(available_members, min(num_supporters, len(available_members)))
        
        roles = ['Contributor', 'Reviewer', 'Coordinator', 'Specialist', 'Analyst']
        
        for member_id in selected_members:
            supporting_assignments.append({
                'key_result_id': kr_id,
                'team_member_id': member_id,
                'role': random.choice(roles)
            })
    
    # Insert supporting team assignments
    for assignment in supporting_assignments:
        cursor.execute('''
            INSERT OR REPLACE INTO kr_supporting_team
            (key_result_id, team_member_id, role, created_at)
            VALUES (?, ?, ?, ?)
        ''', (
            assignment['key_result_id'],
            assignment['team_member_id'],
            assignment['role'],
            datetime.now().isoformat()
        ))
    
    conn.commit()
    conn.close()
        # print(f"✅ Added {len(supporting_assignments)} supporting team assignments")


def update_objective_progress():
    """Update objective progress based on key results"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get all objectives with their key results
    cursor.execute('''
        SELECT o.id, 
               AVG(CASE 
                   WHEN kr.current_value >= kr.target_value THEN 100.0
                   ELSE (kr.current_value * 100.0 / kr.target_value)
               END) as avg_progress
        FROM objectives o
        LEFT JOIN key_results kr ON o.id = kr.objective_id
        GROUP BY o.id
        HAVING COUNT(kr.id) > 0
    ''')
    
    results = cursor.fetchall()
    
    for obj_id, avg_progress in results:
        # Update objective progress
        cursor.execute('''
            UPDATE objectives 
            SET progress = ?, 
                status = CASE 
                    WHEN ? >= 100 THEN 'Completed'
                    WHEN ? >= 25 THEN 'Active'
                    ELSE 'Planning'
                END,
                updated_at = ?
            WHERE id = ?
        ''', (avg_progress, avg_progress, avg_progress, datetime.now().isoformat(), obj_id))
    
    conn.commit()
    conn.close()
        # print(f"✅ Updated progress for {len(results)} objectives")

def main():
    """Main function to populate OKR data"""
        # print("🚀 Starting OKR data population...")
    
    try:
        # Clear existing data (optional - comment out if you want to keep existing data)
        # conn = get_db_connection()
        # cursor = conn.cursor()
        # cursor.execute('DELETE FROM key_results WHERE objective_id > 1')  # Keep first objective
        # cursor.execute('DELETE FROM objectives WHERE id > 1')  # Keep first objective
        # conn.commit()
        # conn.close()
        # print("🧹 Cleared existing data")
        
        # Populate new data
        populate_objectives()
        populate_key_results()
        populate_supporting_teams()
        update_objective_progress()
        
            # print("✨ OKR data population completed successfully!")
            # print("\nℹ️  You can now:")
            # print("   - View analytics with populated data")
            # print("   - Test the 'OKRs by Lead' feature with different team leads")
            # print("   - See progress tracking and visualizations")
        
    except Exception as e:
            # print(f"❌ Error populating data: {e}")
        raise

if __name__ == "__main__":
    main()
