"""Script to populate the database with sample data for projects, programs, team members, and transactions"""

import sys
import os
# Add the parent directory to the Python path so we can import from db_management
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db_management.project_db import *
from db_management.db import add_transaction, init_db  # Import transaction functions and database initialization
from datetime import datetime, timedelta
import random

def populate_sample_data():
    
    # Sample team members (simplified structure)
    
    # Enhanced team members with historical data and varying attrition by year
    # We'll create team members with different join/leave dates to simulate realistic attrition trends
    
    base_team_members = [
        # C-Level Leadership (no managers)
        ("Michael Chen", "michael.chen@company.com", "CEO", "Executive", "2015-01-01", "Active", None),
        ("Lisa Rodriguez", "lisa.rodriguez@company.com", "CTO", "Technology", "2017-02-01", "Active", "Michael Chen"),
        ("David Kim", "david.kim@company.com", "VP Product", "Product", "2018-04-01", "Active", "Michael Chen"),
        ("Emma Wilson", "emma.wilson@company.com", "VP Sales", "Sales", "2019-05-01", "Active", "Michael Chen"),
        ("Robert Taylor", "robert.taylor@company.com", "VP Marketing", "Marketing", "2019-03-01", "Active", "Michael Chen"),
        ("Jennifer Adams", "jennifer.adams@company.com", "VP Operations", "Operations", "2020-01-01", "Active", "Michael Chen"),
        
        # Technology Leadership (report to CTO)
        ("Sarah Johnson", "sarah.johnson@company.com", "Director of Engineering", "Technology", "2018-03-01", "Active", "Lisa Rodriguez"),
        ("Alex Thompson", "alex.thompson@company.com", "Director of Infrastructure", "Technology", "2019-01-15", "Active", "Lisa Rodriguez"),
        ("Priya Patel", "priya.patel@company.com", "Director of QA", "Technology", "2019-08-01", "Active", "Lisa Rodriguez"),
        
        # Engineering Teams (report to Director of Engineering)
        ("John Smith", "john.smith@company.com", "Senior Engineering Manager", "Technology", "2020-01-15", "Active", "Sarah Johnson"),
        ("Mike Davis", "mike.davis@company.com", "Engineering Manager", "Technology", "2020-06-15", "Active", "Sarah Johnson"),
        ("Emma Brown", "emma.brown@company.com", "Senior Technical Lead", "Technology", "2019-11-15", "Active", "John Smith"),
        ("Jessica Martinez", "jessica.martinez@company.com", "Technical Lead", "Technology", "2021-03-01", "Active", "John Smith"),
        ("Ryan O'Connor", "ryan.oconnor@company.com", "Senior Software Engineer", "Technology", "2021-06-15", "Active", "Emma Brown"),
        ("Daniel Garcia", "daniel.garcia@company.com", "Senior Software Engineer", "Technology", "2022-01-15", "Active", "Emma Brown"),
        ("Sophie Chen", "sophie.chen@company.com", "Software Engineer", "Technology", "2022-06-01", "Active", "Jessica Martinez"),
        ("Marcus Johnson", "marcus.johnson@company.com", "Software Engineer", "Technology", "2023-02-15", "Active", "Jessica Martinez"),
        ("Amy Liu", "amy.liu@company.com", "Junior Software Engineer", "Technology", "2024-07-01", "Active", "Ryan O'Connor"),
        ("Carlos Rodriguez", "carlos.rodriguez@company.com", "Junior Software Engineer", "Technology", "2024-09-01", "Active", "Daniel Garcia"),
        
        # DevOps Team (report to Director of Infrastructure)
        ("Tom Wilson", "tom.wilson@company.com", "DevOps Manager", "Technology", "2020-04-01", "Active", "Alex Thompson"),
        ("Rachel Green", "rachel.green@company.com", "Senior DevOps Engineer", "Technology", "2021-08-15", "Active", "Tom Wilson"),
        ("Kevin Park", "kevin.park@company.com", "DevOps Engineer", "Technology", "2022-11-01", "Active", "Tom Wilson"),
        ("Maria Santos", "maria.santos@company.com", "Cloud Engineer", "Technology", "2023-03-15", "Active", "Rachel Green"),
        
        # QA Team (report to Director of QA)
        ("Linda Martinez", "linda.martinez@company.com", "QA Manager", "Technology", "2020-07-01", "Active", "Priya Patel"),
        ("James Foster", "james.foster@company.com", "Senior QA Engineer", "Technology", "2021-05-15", "Active", "Linda Martinez"),
        ("Anna Taylor", "anna.taylor@company.com", "QA Engineer", "Technology", "2022-09-01", "Active", "Linda Martinez"),
        ("David Lee", "david.lee@company.com", "Automation Engineer", "Technology", "2023-01-15", "Active", "James Foster"),
        
        # Product Organization (report to VP Product)
        ("Lisa Chen", "lisa.chen@company.com", "Director of Product Management", "Product", "2019-09-01", "Active", "David Kim"),
        ("Amy Taylor", "amy.taylor@company.com", "Senior Product Manager", "Product", "2021-08-15", "Active", "Lisa Chen"),
        ("Daniel Brown", "daniel.brown@company.com", "Product Manager", "Product", "2022-06-15", "Active", "Lisa Chen"),
        ("Rachel White", "rachel.white@company.com", "Associate Product Manager", "Product", "2024-03-01", "Active", "Amy Taylor"),
        
        # Design Team (report to Director of Product Management)
        ("Michael Torres", "michael.torres@company.com", "Design Manager", "Design", "2020-10-01", "Active", "Lisa Chen"),
        ("Sarah Kim", "sarah.kim@company.com", "Senior UX Designer", "Design", "2021-04-01", "Active", "Michael Torres"),
        ("Jason Wang", "jason.wang@company.com", "UI Designer", "Design", "2022-12-01", "Active", "Michael Torres"),
        ("Zoe Anderson", "zoe.anderson@company.com", "UX Researcher", "Design", "2023-08-15", "Active", "Sarah Kim"),
        
        # Sales Organization (report to VP Sales)
        ("Richard Davis", "richard.davis@company.com", "Director of Sales", "Sales", "2020-02-01", "Active", "Emma Wilson"),
        ("Michelle Chang", "michelle.chang@company.com", "Sales Manager - Enterprise", "Sales", "2021-01-15", "Active", "Richard Davis"),
        ("Brandon Smith", "brandon.smith@company.com", "Sales Manager - SMB", "Sales", "2021-06-01", "Active", "Richard Davis"),
        ("Kelly Johnson", "kelly.johnson@company.com", "Senior Account Executive", "Sales", "2022-03-15", "Active", "Michelle Chang"),
        ("Tyler Brown", "tyler.brown@company.com", "Account Executive", "Sales", "2022-09-01", "Active", "Michelle Chang"),
        ("Nicole Wilson", "nicole.wilson@company.com", "Sales Development Rep", "Sales", "2023-05-01", "Active", "Brandon Smith"),
        ("Chris Garcia", "chris.garcia@company.com", "Sales Development Rep", "Sales", "2024-02-15", "Active", "Brandon Smith"),
        
        # Marketing Organization (report to VP Marketing)
        ("Amanda Foster", "amanda.foster@company.com", "Director of Marketing", "Marketing", "2020-08-01", "Active", "Robert Taylor"),
        ("Steven Liu", "steven.liu@company.com", "Marketing Manager - Digital", "Marketing", "2021-11-01", "Active", "Amanda Foster"),
        ("Grace Park", "grace.park@company.com", "Marketing Manager - Content", "Marketing", "2022-04-15", "Active", "Amanda Foster"),
        ("Nathan Young", "nathan.young@company.com", "Digital Marketing Specialist", "Marketing", "2023-01-15", "Active", "Steven Liu"),
        ("Olivia Martinez", "olivia.martinez@company.com", "Content Creator", "Marketing", "2023-07-01", "Active", "Grace Park"),
        ("Alex Wright", "alex.wright@company.com", "Marketing Coordinator", "Marketing", "2024-01-15", "Active", "Grace Park"),
        
        # Operations (report to VP Operations)
        ("Patricia Johnson", "patricia.johnson@company.com", "Director of Operations", "Operations", "2020-11-01", "Active", "Jennifer Adams"),
        ("Mark Thompson", "mark.thompson@company.com", "Operations Manager", "Operations", "2021-09-15", "Active", "Patricia Johnson"),
        ("Laura Kim", "laura.kim@company.com", "HR Manager", "HR", "2022-02-01", "Active", "Patricia Johnson"),
        ("Brian Chen", "brian.chen@company.com", "Finance Manager", "Finance", "2022-05-15", "Active", "Patricia Johnson"),
        ("Diana Rodriguez", "diana.rodriguez@company.com", "Facilities Coordinator", "Operations", "2023-04-01", "Active", "Mark Thompson"),
        ("Kevin Martinez", "kevin.martinez@company.com", "HR Specialist", "HR", "2023-10-15", "Active", "Laura Kim"),
        
        # Recent Hires (2024-2025)
        ("Isabella Garcia", "isabella.garcia@company.com", "Junior Product Manager", "Product", "2024-11-01", "Active", "Daniel Brown"),
        ("Ethan Davis", "ethan.davis@company.com", "Junior Developer", "Technology", "2025-01-15", "Active", "Sophie Chen"),
        ("Maya Patel", "maya.patel@company.com", "Marketing Intern", "Marketing", "2025-06-01", "Active", "Nathan Young"),
        
        # People on Leave
        ("Anna Rodriguez", "anna.rodriguez@company.com", "Senior Designer", "Design", "2021-01-15", "On Leave", "Sarah Kim"),  # Maternity leave 2025
        ("Samuel Lee", "samuel.lee@company.com", "DevOps Engineer", "Technology", "2022-03-01", "On Leave", "Kevin Park"),  # Sabbatical 2025
        
        # Historical Departures - 2023 (higher attrition year)
        ("Mark Stevens", "mark.stevens@company.com", "Former Senior Developer", "Technology", "2019-03-01", "Inactive", "Emma Brown"),  # Left 2023
        ("Jennifer Walsh", "jennifer.walsh@company.com", "Former Marketing Lead", "Marketing", "2020-01-15", "Inactive", "Amanda Foster"),  # Left 2023
        ("Carlos Mendoza", "carlos.mendoza@company.com", "Former Sales Rep", "Sales", "2021-02-01", "Inactive", "Brandon Smith"),  # Left 2023
        ("Rebecca Davis", "rebecca.davis@company.com", "Former Product Manager", "Product", "2020-07-01", "Inactive", "Lisa Chen"),  # Left 2023
        ("Anthony Wilson", "anthony.wilson@company.com", "Former QA Lead", "Technology", "2019-05-15", "Inactive", "Priya Patel"),  # Left 2023
        
        # Historical Departures - 2024 (moderate attrition)
        ("Sophie Turner", "sophie.turner@company.com", "Former Operations Manager", "Operations", "2020-05-01", "Inactive", "Patricia Johnson"),  # Left 2024
        ("James Wilson", "james.wilson@company.com", "Former Backend Developer", "Technology", "2021-01-15", "Inactive", "Mike Davis"),  # Left 2024
        ("Monica Rodriguez", "monica.rodriguez@company.com", "Former Sales Manager", "Sales", "2020-09-01", "Inactive", "Richard Davis"),  # Left 2024
        
        # 2025 current status (some on leave, one departure)
        ("Tom Anderson", "tom.anderson@company.com", "Senior Developer", "Technology", "2022-09-01", "On Leave", "Sarah Johnson"),  # Medical leave 2025
        ("Maria Garcia", "maria.garcia@company.com", "Former Product Manager", "Product", "2023-06-01", "Inactive", "Michael Chen"),  # Left in 2025
        
        # Recent hires (2024-2025)
        ("Kevin Park", "kevin.park@company.com", "Junior Developer", "Technology", "2024-01-15", "Active", "Alex Thompson"),
        ("Sarah Kim", "sarah.kim@company.com", "DevOps Specialist", "Technology", "2024-09-01", "Active", "Ryan O'Connor"),
        ("Chris Taylor", "chris.taylor@company.com", "Business Analyst", "Business", "2025-01-15", "Active", "Lisa Chen"),
        ("Lisa Wang", "lisa.wang@company.com", "Frontend Developer", "Technology", "2025-03-01", "Active", "Jessica Martinez"),
        ("Mike Johnson", "mike.johnson@company.com", "QA Lead", "Technology", "2025-05-01", "Active", "Priya Patel")
    ]
    
    # First pass: add all team members without manager relationships
    member_id_map = {}
    for name, email, role, department, start_date, status, manager_name in base_team_members:
        try:
            member_id = add_team_member(name, email, role, department, start_date=start_date, status=status)
            member_id_map[name] = member_id
        except Exception as e:
            if "UNIQUE constraint failed" in str(e):
                print(f"Skipping duplicate team member: {name}")
                # Try to get existing member ID
                from db_management.project_db import get_team_members
                existing_members = get_team_members()
                for member in existing_members:
                    if member.get('email') == email:
                        member_id_map[name] = member.get('id')
                        break
            else:
                raise e
    
    # Second pass: update manager relationships
    for name, email, role, department, start_date, status, manager_name in base_team_members:
        if manager_name and manager_name in member_id_map:
            member_id = member_id_map[name]
            manager_id = member_id_map[manager_name]
            update_team_member(member_id, name, email, role, department, manager_id, None, start_date, status)
    
    # Sample programs
    
    programs = [
        ("Digital Transformation Initiative", "Modernizing company infrastructure and processes", "2024-01-01", "2025-12-31", "Active", 1000000.0),
        ("Customer Experience Enhancement", "Improving customer satisfaction and engagement", "2024-01-15", "2024-12-31", "Active", 750000.0),
        ("Operational Excellence Program", "Streamlining operations and reducing costs", "2024-02-01", "2025-06-30", "Planning", 500000.0),
        ("Market Expansion Strategy", "Expanding into new markets and regions", "2024-03-01", "2025-09-30", "Planning", 1200000.0)
    ]
    
    for program in programs:
        add_program(*program)
    
    # Sample projects with realistic potential and realized values
    
    projects = [
        # Active projects with progress
        ("Cloud Migration", "Migrate applications to cloud infrastructure", "2024-01-01", "2024-06-30", "Active", 250000.0, "Scaling", 1, 500000.0, 320000.0),
        ("Mobile App Development", "Develop new mobile application", "2024-02-01", "2024-08-31", "Active", 180000.0, "PoV", 1, 750000.0, 180000.0),
        ("Customer Portal", "Build customer self-service portal", "2024-01-15", "2024-07-15", "Active", 150000.0, "PoV", 2, 400000.0, 280000.0),
        ("CRM System Upgrade", "Upgrade existing CRM system", "2024-02-15", "2024-09-15", "Active", 100000.0, "Scoping", 2, 300000.0, 85000.0),
        
        # Planning projects with future potential
        ("Process Automation", "Automate manual business processes", "2024-03-01", "2024-10-31", "Planning", 130000.0, "Seed", 3, 600000.0, 0.0),
        ("Data Analytics Platform", "Build comprehensive analytics platform", "2024-03-15", "2024-11-30", "Planning", 200000.0, "Seed", 3, 800000.0, 0.0),
        ("Market Research Study", "Conduct comprehensive market analysis", "2024-04-01", "2024-08-31", "Planning", 75000.0, "Seed", 4, 200000.0, 0.0),
        ("Brand Refresh Initiative", "Update brand identity and marketing materials", "2024-04-15", "2024-10-15", "Planning", 90000.0, "Seed", 4, 350000.0, 0.0),
        
        # Completed projects (realized values)
        ("Legacy System Migration", "Migrate legacy systems to modern platform", "2023-01-01", "2023-12-31", "Completed", 300000.0, "Live", 1, 650000.0, 650000.0),
        ("Security Audit Implementation", "Implement security recommendations", "2023-06-01", "2023-11-30", "Completed", 120000.0, "Live", 3, 250000.0, 250000.0)
    ]
    
    for project in projects:
        # Unpack with the correct signature: name, description, start_date, end_date, status, budget, maturity, program_id, potential_value, realized_value
        add_project(project[0], project[1], project[2], project[3], project[4], project[5], project[6], project[7], project[8], project[9])
    
    # Sample transactions with descriptions - including Budget, Planned, Consumed data for AI Financials
    # Add historical data for 2023, 2024, and current year (2025)
    
    current_year = datetime.now().year
    
    # Historical data for multiple years
    years_data = {
        2023: {
            'budget_capex': 2000000.0,
            'budget_opex': 1400000.0,
            'planned_capex': 1800000.0,
            'planned_opex': 1300000.0,
            'consumed_capex': 1650000.0,
            'consumed_opex': 1150000.0
        },
        2024: {
            'budget_capex': 2300000.0,
            'budget_opex': 1600000.0,
            'planned_capex': 2100000.0,
            'planned_opex': 1500000.0,
            'consumed_capex': 1950000.0,
            'consumed_opex': 1420000.0
        },
        2025: {
            'budget_capex': 2500000.0,
            'budget_opex': 1800000.0,
            'planned_capex': 2200000.0,
            'planned_opex': 1600000.0,
            'consumed_capex': 245000.0,  # Year in progress
            'consumed_opex': 245000.0    # Year in progress
        }
    }
    
    # Add Budget and Planned entries for each year
    for year, data in years_data.items():
        # Budget entries
        add_transaction(
            date=f"{year}-01-01",
            description=f"Annual CAPEX Budget Allocation {year}",
            ccp="BUDGET-CAPEX",
            ccs="ANNUAL-BUDGET",
            sow=f"BUDGET-SOW-{year}-001",
            po=f"BUDGET-PO-{year}-001",
            amount=data['budget_capex'],
            category="CAPEX",
            type_="Budget"
        )
        
        add_transaction(
            date=f"{year}-01-01",
            description=f"Annual OPEX Budget Allocation {year}",
            ccp="BUDGET-OPEX",
            ccs="ANNUAL-BUDGET",
            sow=f"BUDGET-SOW-{year}-002",
            po=f"BUDGET-PO-{year}-002",
            amount=data['budget_opex'],
            category="OPEX",
            type_="Budget"
        )
        
        # Planned entries
        add_transaction(
            date=f"{year}-01-15",
            description=f"Planned CAPEX Spending {year}",
            ccp="PLANNED-CAPEX",
            ccs="ANNUAL-PLAN",
            sow=f"PLAN-SOW-{year}-001",
            po=f"PLAN-PO-{year}-001",
            amount=data['planned_capex'],
            category="CAPEX",
            type_="Planned"
        )
        
        add_transaction(
            date=f"{year}-01-15",
            description=f"Planned OPEX Spending {year}",
            ccp="PLANNED-OPEX",
            ccs="ANNUAL-PLAN",
            sow=f"PLAN-SOW-{year}-002",
            po=f"PLAN-PO-{year}-002",
            amount=data['planned_opex'],
            category="OPEX",
            type_="Planned"
        )
    
    # Add detailed consumed transactions for each year
    consumed_transaction_templates = [
        ("Software License Purchase", "CAPEX"),
        ("Cloud Infrastructure Monthly", "OPEX"),
        ("Consulting Services", "OPEX"),
        ("Hardware Equipment", "CAPEX"),
        ("Training and Development", "OPEX"),
        ("Office Supplies", "OPEX"),
        ("Travel and Expenses", "OPEX"),
        ("Contractor Payment", "OPEX"),
        ("Equipment Rental", "OPEX"),
        ("Marketing Campaign", "OPEX"),
        ("Legal Services", "OPEX"),
        ("Security Audit", "OPEX"),
        ("Database License", "CAPEX"),
        ("Design Services", "OPEX"),
        ("Server Maintenance", "OPEX")
    ]
    
    # Add consumed transactions for each year
    for year, data in years_data.items():
        # Calculate how to distribute the total consumed amount across transactions
        capex_per_transaction = data['consumed_capex'] / len([t for t in consumed_transaction_templates if t[1] == "CAPEX"])
        opex_per_transaction = data['consumed_opex'] / len([t for t in consumed_transaction_templates if t[1] == "OPEX"])
        
        for i, (description, expense_type) in enumerate(consumed_transaction_templates):
            # Create dates throughout the year
            if year == current_year:
                # For current year, use dates up to current date
                max_month = min(datetime.now().month, 12)
                transaction_date = datetime(year, random.randint(1, max_month), random.randint(1, 28))
            else:
                # For past years, use full year
                transaction_date = datetime(year, random.randint(1, 12), random.randint(1, 28))
            
            # Use the calculated amount per transaction type
            amount = capex_per_transaction if expense_type == "CAPEX" else opex_per_transaction
            
            po_number = f"PO-{year}-{2000 + i:04d}"
            sow_number = f"SOW-{year}-{300 + i:03d}"
            
            add_transaction(
                date=transaction_date.strftime("%Y-%m-%d"),
                description=f"{description} ({year})",
                ccp=f"CONSUMED-{expense_type}",
                ccs=f"ACTUAL-{expense_type}",
                sow=sow_number,
                po=po_number,
                amount=amount,
                category=expense_type,
                type_="Consumed"
            )
    

if __name__ == "__main__":
    # Initialize the database first
    init_project_tables()  # Initialize project tables
    init_db()  # Initialize transaction table
    
    # Populate with sample data
    populate_sample_data()
