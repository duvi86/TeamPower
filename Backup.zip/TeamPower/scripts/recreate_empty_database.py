#!/usr/bin/env python3
"""
TeamPower Database Recreation Script (Full-Featured)
====================================================

This script recreates the root TeamPower database (team_power.db) with empty tables.
It provides a complete database recreation solution with safety features and optional sample data.

FEATURES:
---------
✅ Automatic backup of existing database (timestamped)
✅ Complete table recreation with proper foreign keys and constraints
✅ Index creation for optimal performance
✅ Database verification after creation
✅ Optional sample data for immediate testing
✅ Command line options for customization
✅ Comprehensive error handling and logging

USAGE:
------
Basic usage (empty database):
    python3 recreate_empty_database.py

With sample data for testing:
    python3 recreate_empty_database.py --with-sample-data

Custom database path:
    python3 recreate_empty_database.py --db-path /path/to/database.db

SAFETY:
-------
- Existing database is automatically backed up before recreation
- No data is lost - the original database is renamed with timestamp
- Verification is performed after creation to ensure integrity

TABLES CREATED:
---------------
1. projects - Project information (budget computed from transactions)
2. programs - Program management and organization
3. program_projects - Junction table linking programs to projects
4. team_members - Team member information and hierarchy
5. project_teams - Project team assignments and roles
6. objectives - OKR objectives and goals
7. key_results - OKR key results and metrics
8. okr_supporting_team - OKR support team assignments
9. kr_supporting_team - Key result support assignments
10. transactions - Financial transactions (including Budget type for project budget computation)
11. value_tracking - Value tracking and business impact records

DEPENDENCIES:
-------------
- sqlite3 (built-in Python module)
- os, sys, datetime (built-in Python modules)

AUTHOR: TeamPower Development Team
DATE: September 2025
VERSION: 1.0
"""

import sqlite3
import os
import sys
from datetime import datetime

def create_empty_database(db_path='/Users/md395378/TeamPowerGSK/team_power.db'):
    """
    Create a fresh empty database with all required tables for TeamPower application.
    
    This function performs the following operations:
    1. Backs up existing database (if present) with timestamp
    2. Creates new database with complete schema
    3. Sets up all tables with proper constraints and relationships
    4. Creates performance indexes
    5. Verifies database integrity
    
    Args:
        db_path (str): Full path to the database file to create
                      Default: '/Users/md395378/TeamPowerGSK/team_power.db'
    
    Returns:
        None
        
    Raises:
        sqlite3.Error: If database creation or table creation fails
        OSError: If file system operations (backup, creation) fail
        
    Note:
        - If database exists, it will be backed up as {db_path}_backup_{timestamp}
        - All tables include proper foreign key constraints for data integrity
        - Indexes are created for optimal query performance
    """
    
    # Backup existing database if it exists
    if os.path.exists(db_path):
        backup_path = f"{db_path}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        print(f"Backing up existing database to: {backup_path}")
        os.rename(db_path, backup_path)
    
    print(f"Creating new empty database at: {db_path}")
    
    # Create new database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create all tables with comprehensive documentation
    tables = {
        'projects': '''
            -- Projects table: Core project information and tracking
            -- Note: budget field exists but will be computed from transactions for new projects
            CREATE TABLE projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,           -- Project name (must be unique)
                description TEXT,                    -- Detailed project description
                start_date DATE,                     -- Project start date
                end_date DATE,                       -- Project end date
                status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                maturity TEXT CHECK(maturity IN ('Seed', 'Scoping', 'PoC', 'PoV', 'Scaling', 'Live')) DEFAULT 'Seed',
                budget REAL DEFAULT 0.0,             -- Legacy budget field (computed from transactions for new projects)
                owner_id INTEGER,                    -- References team_members.id
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                potential_value REAL DEFAULT 0.0,   -- Expected business value
                realized_value REAL DEFAULT 0.0,    -- Actual business value achieved
                refresh_date DATE                    -- Last data refresh date
            )
        ''',
        
        'programs': '''
            -- Programs table: High-level program organization and management
            CREATE TABLE programs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,           -- Program name (must be unique)
                description TEXT,                    -- Program description and objectives
                start_date DATE,                     -- Program start date
                end_date DATE,                       -- Program end date
                status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                budget REAL DEFAULT 0.0,             -- Program budget allocation
                owner_id INTEGER,                    -- References team_members.id (program owner)
                department TEXT,                     -- Department responsible for program
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now'))
            )
        ''',
        
        'program_projects': '''
            -- Junction table: Many-to-many relationship between programs and projects
            -- Allows projects to be part of multiple programs and programs to have multiple projects
            CREATE TABLE program_projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                program_id INTEGER NOT NULL,         -- References programs.id
                project_id INTEGER NOT NULL,        -- References projects.id
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (program_id) REFERENCES programs(id),
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        ''',
        
        'team_members': '''
            -- Team members table: Employee information and organizational hierarchy
            CREATE TABLE team_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,                  -- Full name of team member
                email TEXT UNIQUE,                   -- Email address (must be unique)
                role TEXT NOT NULL,                  -- Job role/title
                department TEXT,                     -- Department/division
                manager_id INTEGER,                  -- References team_members.id (hierarchical relationship)
                start_date DATE,                     -- Employment start date
                end_date DATE,                       -- Employment end date (NULL for active employees)
                status TEXT CHECK(status IN ('Active', 'Inactive', 'On Leave')) DEFAULT 'Active',
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (manager_id) REFERENCES team_members(id)
            )
        ''',
        
        'project_teams': '''
            -- Project teams table: Team member assignments to specific projects
            -- Tracks role, allocation, and timeline for each assignment
            CREATE TABLE project_teams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,        -- References projects.id
                team_member_id INTEGER NOT NULL,    -- References team_members.id
                role_in_project TEXT DEFAULT 'Team Member',  -- Role within the project
                allocation_percentage REAL DEFAULT 100.0,    -- Percentage of time allocated (0-100)
                start_date DATE,                     -- Assignment start date
                end_date DATE,                       -- Assignment end date
                created_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (team_member_id) REFERENCES team_members(id)
            )
        ''',
        
        'objectives': '''
            -- Objectives table: OKR (Objectives and Key Results) objectives
            -- High-level goals that can be tracked and measured
            CREATE TABLE objectives (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,                 -- Objective title/name
                description TEXT,                    -- Detailed objective description
                program_id INTEGER,                  -- References programs.id (optional program linkage)
                owner_id INTEGER NOT NULL,          -- References team_members.id (objective owner)
                main_responsible_id INTEGER,        -- References team_members.id (main person responsible)
                quarter TEXT,                        -- Target quarter (e.g., "Q1", "Q2")
                year INTEGER,                        -- Target year
                status TEXT CHECK(status IN ('Planning', 'Active', 'At Risk', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                progress REAL DEFAULT 0.0,          -- Progress percentage (0-100)
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (program_id) REFERENCES programs(id),
                FOREIGN KEY (owner_id) REFERENCES team_members(id),
                FOREIGN KEY (main_responsible_id) REFERENCES team_members(id)
            )
        ''',
        
        'key_results': '''
            -- Key Results table: Measurable outcomes for objectives
            -- Specific, measurable results that indicate objective completion
            CREATE TABLE key_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                objective_id INTEGER NOT NULL,      -- References objectives.id
                title TEXT NOT NULL,                -- Key result title
                description TEXT,                   -- Detailed description
                target_value REAL,                  -- Target value to achieve
                current_value REAL DEFAULT 0.0,    -- Current achieved value
                unit TEXT,                          -- Unit of measurement (e.g., "%", "$", "count")
                status TEXT CHECK(status IN ('Planning', 'Active', 'At Risk', 'Completed', 'Cancelled')) DEFAULT 'Planning',
                progress REAL DEFAULT 0.0,          -- Progress percentage (0-100)
                due_date DATE,                       -- Target completion date
                owner_id INTEGER,                    -- References team_members.id (KR owner)
                main_responsible_id INTEGER,        -- References team_members.id (main person responsible)
                created_at DATE DEFAULT (DATE('now')),
                updated_at DATE DEFAULT (DATE('now')),
                FOREIGN KEY (objective_id) REFERENCES objectives(id),
                FOREIGN KEY (owner_id) REFERENCES team_members(id),
                FOREIGN KEY (main_responsible_id) REFERENCES team_members(id)
            )
        ''',
        
        'okr_supporting_team': '''
            -- OKR Supporting Team table: Additional team members supporting objectives
            -- Tracks team members who provide support for objectives beyond owner/responsible
            CREATE TABLE okr_supporting_team (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                objective_id INTEGER NOT NULL,      -- References objectives.id
                team_member_id INTEGER NOT NULL,    -- References team_members.id
                role TEXT DEFAULT 'Support',        -- Support role (e.g., "Advisor", "Contributor")
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (objective_id) REFERENCES objectives(id),
                FOREIGN KEY (team_member_id) REFERENCES team_members(id)
            )
        ''',
        
        'kr_supporting_team': '''
            -- Key Result Supporting Team table: Additional team members supporting key results
            -- Tracks team members who provide support for key results beyond owner/responsible
            CREATE TABLE kr_supporting_team (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_result_id INTEGER NOT NULL,     -- References key_results.id
                team_member_id INTEGER NOT NULL,    -- References team_members.id
                role TEXT DEFAULT 'Support',        -- Support role (e.g., "Advisor", "Contributor")
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (key_result_id) REFERENCES key_results(id),
                FOREIGN KEY (team_member_id) REFERENCES team_members(id)
            )
        ''',
        
        'transactions': '''
            -- Transactions table: Financial transactions and budget tracking
            -- Critical: This table is used to compute project budgets when type='Budget'
            CREATE TABLE transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,                           -- Transaction date
                description TEXT,                    -- Transaction description
                cost_center_project TEXT,            -- Cost center project code
                cost_center_sow TEXT,               -- Statement of Work cost center
                sow_number TEXT,                     -- SOW reference number
                po TEXT,                             -- Purchase Order number
                amount REAL,                         -- Transaction amount
                category TEXT,                       -- Transaction category
                type TEXT,                           -- Transaction type (IMPORTANT: 'Budget' type used for project budget computation)
                project_id INTEGER,                  -- References projects.id (links transaction to project)
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        ''',
        
        'value_tracking': '''
            -- Value Tracking table: Business value realization tracking
            -- Tracks actual business value delivered by projects over time
            CREATE TABLE value_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                description TEXT NOT NULL,          -- Description of value delivered
                amount REAL NOT NULL,               -- Monetary value amount
                start_date TEXT,                    -- Value realization start date
                end_date TEXT,                      -- Value realization end date
                project_id INTEGER,                 -- References projects.id
                business_sponsor TEXT,              -- Business sponsor name
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            )
        '''
    }
    
    # Create tables
    for table_name, sql in tables.items():
        print(f"Creating table: {table_name}")
        cursor.execute(sql)
    
    # Create indexes
    indexes = [
        "CREATE INDEX idx_transactions_project_id ON transactions(project_id)",
        "CREATE INDEX idx_program_projects_program_id ON program_projects(program_id)",
        "CREATE INDEX idx_program_projects_project_id ON program_projects(project_id)",
        "CREATE INDEX idx_project_teams_project_id ON project_teams(project_id)",
        "CREATE INDEX idx_project_teams_member_id ON project_teams(team_member_id)",
        "CREATE INDEX idx_value_tracking_project_id ON value_tracking(project_id)"
    ]
    
    for index_sql in indexes:
        print(f"Creating index: {index_sql.split()[2]}")
        cursor.execute(index_sql)
    
    # Commit changes
    conn.commit()
    conn.close()
    
    print(f"\n✅ Empty database created successfully at: {db_path}")
    print("\nTables created:")
    for table_name in tables.keys():
        print(f"  - {table_name}")
    
    # Verify the database
    verify_database(db_path)

def verify_database(db_path):
    """
    Verify database integrity and table structure after creation.
    
    This function performs comprehensive validation of the newly created database
    to ensure all tables exist with correct schemas and basic operations work.
    
    Args:
        db_path (str): Path to the database file to verify
        
    Returns:
        None: Prints verification results to console
        
    Verification Process:
        1. Connect to database
        2. Check all expected tables exist
        3. Count records in each table
        4. Verify basic queries work
        5. Report status for each table
        
    Expected Tables:
        - projects: Core project information and tracking
        - programs: High-level program organization  
        - program_projects: Junction table for program-project relationships
        - team_members: Employee information and hierarchy
        - project_teams: Team assignments to projects
        - objectives: OKR objectives
        - key_results: Measurable outcomes for objectives
        - okr_supporting_team: Additional objective support team
        - kr_supporting_team: Additional key result support team
        - transactions: Financial transactions (critical for budget computation)
        - value_tracking: Business value realization tracking
        
    Output Format:
        Found X tables:
          - table_name: Y records
        ✅ Database verification complete
        
    Note:
        This function is automatically called by create_empty_database()
        and provides immediate feedback on database creation success.
        For new databases, all tables should show 0 records.
    """
    print(f"\n🔍 Verifying database structure...")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get all tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = cursor.fetchall()
    
    print(f"Found {len(tables)} tables:")
    for table in tables:
        if table[0] != 'sqlite_sequence':  # Skip internal table
            cursor.execute(f"SELECT COUNT(*) FROM {table[0]}")
            count = cursor.fetchone()[0]
            print(f"  - {table[0]}: {count} records")
    
    conn.close()
    print("✅ Database verification complete")

def create_sample_data(db_path='/Users/md395378/TeamPowerGSK/team_power.db'):
    """
    Add minimal sample data for testing and demonstration purposes.
    
    This function populates the empty database with a basic set of sample data
    to verify functionality and provide examples for development/testing.
    
    Args:
        db_path (str): Path to the database file to populate
                      Defaults to '/Users/md395378/TeamPowerGSK/team_power.db'
    
    Returns:
        None: Prints creation status to console
        
    Sample Data Created:
        Team Members (3):
            - John Smith (Tech Lead, Engineering) - No manager
            - Sarah Johnson (Program Manager, IT) - No manager  
            - Mike Chen (Developer, Engineering) - Reports to John Smith
            
        Programs (1):
            - Digital Innovation Program (Active, owned by Sarah Johnson)
            
        Projects (1):
            - AI Analytics Platform (Active, PoC maturity, owned by John Smith)
            - Linked to Digital Innovation Program
            - Potential value: $1,500,000
            
        Transactions (1):
            - Budget allocation of $250,000 for AI Analytics Platform
            - Type='Budget' (used for budget computation)
            - Date: 2024-09-01
            
        Relationships:
            - Project linked to program via program_projects junction table
            - Transaction linked to project for budget calculation
            - Team member hierarchy (Mike reports to John)
    
    Usage Examples:
        # Add sample data to default database
        create_sample_data()
        
        # Add sample data to specific database
        create_sample_data('/path/to/custom.db')
        
    Important Notes:
        - Sample transaction demonstrates budget computation system
        - Hierarchy shows manager-employee relationships
        - Junction table usage for program-project relationships
        - All IDs are auto-generated and start from 1
        
    Verification:
        After running, you can verify with:
        - Projects page should show AI Analytics Platform with $250,000 budget
        - Programs page should show Digital Innovation Program
        - Team hierarchy should show Mike reporting to John
    """
    print(f"\n📝 Adding minimal sample data...")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Add sample team members (demonstrating hierarchy)
    team_members = [
        ("John Smith", "john.smith@company.com", "Tech Lead", "Engineering", None, "2024-01-01", "Active"),
        ("Sarah Johnson", "sarah.johnson@company.com", "Program Manager", "IT", None, "2024-01-15", "Active"),
        ("Mike Chen", "mike.chen@company.com", "Developer", "Engineering", 1, "2024-02-01", "Active")
    ]
    
    cursor.executemany(
        "INSERT INTO team_members (name, email, role, department, manager_id, start_date, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
        team_members
    )
    
    # Add sample program
    cursor.execute(
        "INSERT INTO programs (name, description, status, owner_id) VALUES (?, ?, ?, ?)",
        ("Digital Innovation Program", "Main digital transformation initiative", "Active", 2)
    )
    
    # Add sample project (note: budget will be computed from transactions)
    cursor.execute(
        "INSERT INTO projects (name, description, status, maturity, potential_value, owner_id) VALUES (?, ?, ?, ?, ?, ?)",
        ("AI Analytics Platform", "Machine learning analytics system", "Active", "PoC", 1500000.0, 1)
    )
    
    # Link project to program (demonstrates junction table usage)
    cursor.execute(
        "INSERT INTO program_projects (program_id, project_id) VALUES (?, ?)",
        (1, 1)
    )
    
    # Add sample transaction (Budget type - critical for budget computation)
    cursor.execute(
        "INSERT INTO transactions (date, description, amount, category, type, project_id) VALUES (?, ?, ?, ?, ?, ?)",
        ("2024-09-01", "Initial project budget allocation", 250000.0, "Budget", "Budget", 1)
    )
    
    conn.commit()
    conn.close()
    
    print("✅ Sample data created successfully")
    print("\nSample data summary:")
    print("  - 3 team members (with hierarchy)")
    print("  - 1 program (Digital Innovation)")
    print("  - 1 project (AI Analytics Platform)")
    print("  - 1 budget transaction ($250,000)")
    print("  - Program-project relationship established")
    print("\nNote: Project budget will be computed as $250,000 from the Budget transaction")
    
    print("✅ Sample data added successfully")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Recreate empty team_power database')
    parser.add_argument('--with-sample-data', action='store_true', help='Include minimal sample data')
    parser.add_argument('--db-path', default='/Users/md395378/TeamPowerGSK/team_power.db', help='Database path')
    
    args = parser.parse_args()
    
    print("🚀 TeamPower Database Recreation Script")
    print("=" * 50)
    
    create_empty_database(args.db_path)
    
    if args.with_sample_data:
        create_sample_data(args.db_path)
    
    print(f"\n🎉 Database recreation complete!")
    print(f"Database location: {args.db_path}")
    print("\nTo run the script:")
    print("  python3 recreate_empty_database.py")
    print("  python3 recreate_empty_database.py --with-sample-data")
