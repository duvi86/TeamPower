from dash import html

def create_kpi_card(title, value, card_class=None, value_class=None, id=None):
    """
    Generic KPI card for dashboard metrics.
    """
    return html.Div([
        html.H4(title, className='dashboard-card-title'),
        html.H3(value, className='dashboard-card-value' + (f' {value_class}' if value_class else ''))
    ], className='dashboard-card' + (f' {card_class}' if card_class else ''), id=id)


def create_kpi_row(cards):
    """
    Row of KPI cards for dashboard.
    """
    return html.Div(cards, className='dashboard-cards-row')
