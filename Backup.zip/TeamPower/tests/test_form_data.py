#!/usr/bin/env python3
"""
Test script to verify form data is coming from database
"""

import sys
import os
sys.path.append('TeamPower/multipages')

from utils.form_data_options import (
    get_team_members_options, 
    get_program_options,
    get_project_status_options,
    get_project_maturity_options,
    get_program_status_options
)

def test_form_data():
    print("Testing Form Data Options from Database...")
    print("=" * 50)
    
    # Test team members options
    print("\n1. Team Members Options:")
    team_members = get_team_members_options()
    print(f"   Found {len(team_members)} team members:")
    for member in team_members[:5]:  # Show first 5
        print(f"   - {member['label']} (ID: {member['value']})")
    if len(team_members) > 5:
        print(f"   ... and {len(team_members) - 5} more")
    
    # Test program options
    print("\n2. Program Options:")
    programs = get_program_options()
    print(f"   Found {len(programs)} programs:")
    for program in programs[:5]:  # Show first 5
        print(f"   - {program['label']} (ID: {program['value']})")
    if len(programs) > 5:
        print(f"   ... and {len(programs) - 5} more")
    
    # Test project status options
    print("\n3. Project Status Options:")
    statuses = get_project_status_options()
    print(f"   Found {len(statuses)} status options:")
    for status in statuses:
        print(f"   - {status['label']}")
    
    # Test project maturity options
    print("\n4. Project Maturity Options:")
    maturities = get_project_maturity_options()
    print(f"   Found {len(maturities)} maturity options:")
    for maturity in maturities:
        print(f"   - {maturity['label']}")
    
    # Test program status options
    print("\n5. Program Status Options:")
    prog_statuses = get_program_status_options()
    print(f"   Found {len(prog_statuses)} program status options:")
    for status in prog_statuses:
        print(f"   - {status['label']}")
    
    print("\n" + "=" * 50)
    print("✅ All form data options are working correctly!")

if __name__ == "__main__":
    test_form_data()
