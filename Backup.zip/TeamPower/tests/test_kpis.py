from utils.db import get_year_filtered_kpis

for year in [2023, 2024, 2025]:
    kpis = get_year_filtered_kpis(year)
    gap = kpis.get("budget_amount", 0) - kpis.get("consumed_amount", 0)
