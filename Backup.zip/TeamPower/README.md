# TeamPower GSK Dashboard

> **A modern, comprehensive dashboard application for GSK team management, analytics, and decision-making**

TeamPower GSK Dashboard is a web-based analytics platform built for GSK teams to visualize data, track performance metrics, and make informed decisions. The application combines powerful data visualization capabilities with GSK's design standards to deliver a professional, user-friendly experience.

## 📁 Project Structure & Organization

```
TeamPower/
├── components/
├── database/                  # (legacy or future use)
├── db/                        # Database files (e.g., team_power.db)
├── db_management/             # Database utilities and logic
├── documentation/             # All documentation markdown files
├── multipages/                # Main Dash app and modules
│   ├── app.py
│   ├── callbacks.py
│   ├── assets/
│   ├── components/
│   ├── config/
│   ├── dashboard/
│   ├── pages/
│   ├── services/
│   └── utils/
├── requirements.txt
├── scripts/                   # Data population and migration scripts
├── tests/                     # All test files
```

- All documentation is now in `documentation/`.
- All scripts are in `scripts/`.
- All database files are in `db/`.
- All tests are in `tests/`.
- The main Dash app and modules are under `multipages/`.

## For more details, see the documentation in the `documentation/` folder.

---

## 🎯 Why TeamPower GSK Dashboard?

### **For Business Users**
- 📊 **Instant Insights**: Get immediate visibility into key performance metrics
- 🎨 **Professional Presentation**: GSK-branded visualizations ready for executive presentations
- 📱 **Access Anywhere**: Responsive design works on desktop, tablet, and mobile
- ⚡ **Real-time Data**: Live updates ensure you're always working with current information

### **For IT Teams**
- 🔧 **Low Maintenance**: Built on proven, stable technologies
- 🚀 **Quick Deployment**: Single Python application with minimal dependencies
- 🔒 **Secure**: Local deployment options with full data control
- 📈 **Scalable**: Modular architecture supports growth and customization

### **For Developers**
- 🧩 **Modular Design**: Reusable components and utilities
- 📚 **Well Documented**: Clear code structure and comprehensive documentation
- 🎨 **Design System**: Consistent GSK branding across all components
- 🔄 **Extensible**: Easy to add new pages, charts, and features

## ✨ Key Features

### **Dashboard Capabilities**
- **Multi-page Navigation**: Seamless transition between different analytical views
- **Interactive Visualizations**: Click, hover, and zoom interactions on all charts
- **Real-time Updates**: Live data refresh capabilities for dynamic dashboards
- **Export Functions**: Save charts and data for reports and presentations

### **Chart Types & Analytics**
- **Line Charts**: Trend analysis and time-series visualization
- **Bar Charts**: Comparative analysis and categorical data display
- **Gauge Charts**: KPI monitoring and performance tracking
- **Sunburst Diagrams**: Hierarchical data exploration
- **Stacked Charts**: Multi-dimensional data comparison

### **GSK Design Integration**
- **Brand Compliance**: Automatic application of GSK colors and typography
- **Professional Styling**: Executive-ready visualizations out of the box
- **Responsive Layout**: Optimized for all screen sizes and devices
- **Accessibility**: High contrast options and screen reader support

## 🏗️ Architecture Overview

### **Application Architecture**
```
┌─────────────────────────────────────────┐
│             Frontend Layer              │
│  (Dash + Plotly + Bootstrap)           │
├─────────────────────────────────────────┤
│           Component Layer               │
│     (Reusable Charts & Utilities)      │
├─────────────────────────────────────────┤
│            Data Layer                   │
│    (Pandas + SQLite + Processing)      │
├─────────────────────────────────────────┤
│           Storage Layer                 │
│      (Local Files + Database)          │
└─────────────────────────────────────────┘
```

### **Design Principles**
- **Separation of Concerns**: Clear separation between UI, logic, and data
- **Reusability**: Modular components that can be used across pages
- **Maintainability**: Clean code structure with comprehensive documentation
- **Performance**: Optimized data processing and caching strategies
- **Security**: Local deployment with controlled data access

### **Technology Stack**

| Layer | Technology | Purpose |
|-------|------------|---------|
| **Frontend** | Dash + Plotly | Interactive web interface and visualizations |
| **Styling** | Bootstrap 5 + Custom CSS | Responsive design and GSK branding |
| **Backend** | Flask (via Dash) | Web server and application routing |
| **Data Processing** | Pandas + NumPy | Data manipulation and analysis |
| **Database** | SQLite | Local data storage and management |
| **Deployment** | Python + Virtual Environment | Isolated application environment |

## 📊 Available Pages & Features

### **Overview Dashboard**
- **Purpose**: Central hub for key organizational metrics
- **Features**: Executive summary cards, trend analysis, performance indicators
- **Target Users**: Managers, executives, team leads

### **Configuration Management**
- **Purpose**: System settings and user preferences
- **Features**: Theme selection, data source configuration, user management
- **Target Users**: System administrators, power users

### **AI Financials**
- **Purpose**: Financial analytics with AI-driven insights
- **Features**: Revenue tracking, budget analysis, predictive modeling
- **Target Users**: Finance teams, business analysts

### **AI Governance**
- **Purpose**: Compliance tracking and governance metrics
- **Features**: Risk assessment, audit trails, compliance dashboards
- **Target Users**: Compliance officers, risk managers

### **Transactions**
- **Purpose**: Transaction management and analysis
- **Features**: Transaction logs, analysis tools, reporting
- **Target Users**: Operations teams, analysts

### **Team Hierarchy**
- **Purpose**: Organizational structure visualization
- **Features**: Org charts, team metrics, hierarchy analysis
- **Target Users**: HR teams, managers, executives

## � Quick Start Guide

### **Prerequisites**
- Python 3.8+ (recommended: Python 3.11)
- pip package manager
- Git (for cloning the repository)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### **Installation Steps**

1. **Clone and Setup**:
   ```bash
   git clone <repository-url>
   cd TeamPowerGSK
   
   # Create isolated Python environment
   python -m venv .venv
   
   # Activate environment
   source .venv/bin/activate  # macOS/Linux
   # or
   .venv\Scripts\activate     # Windows
   ```

2. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Launch Application**:
   ```bash
   cd TeamPower/multipages
   python app.py
   ```

4. **Access Dashboard**:
   Open your browser and navigate to: **http://localhost:8122**

### **First-Time Setup**
1. **Verify Installation**: Check that all pages load without errors
2. **Review Sample Data**: Explore the demo data and visualizations
3. **Configure Settings**: Access the Configuration page to customize preferences
4. **Test Functionality**: Try interactive features like chart zoom and hover

### **Troubleshooting**
```bash
# Verify Python version
python --version

# Check installed packages
pip list

# Test imports
python -c "import dash, plotly, pandas; print('All packages working!')"

# Check port availability
lsof -i :8122  # macOS/Linux
netstat -an | findstr :8122  # Windows
```

## 🎨 Design System & User Experience

### **GSK Brand Integration**
The application strictly adheres to GSK's design principles and brand guidelines:

- **Color Palette**:
  - Primary: GSK Orange (#FF6900) - Call-to-action elements
  - Secondary: GSK Teal (#21837E) - Data visualization and accents
  - Neutral: Professional grays for text and backgrounds
  - Status: Success, warning, and error states with appropriate colors

- **Typography**:
  - Primary Font: GSK Precision (brand-specific)
  - Fallback: System fonts for optimal performance
  - Hierarchy: Consistent heading sizes and spacing

- **Layout Principles**:
  - Clean, minimalist design
  - Consistent spacing using 8px grid system
  - Logical information hierarchy
  - Professional appearance suitable for executive presentations

### **User Experience Features**
- **Intuitive Navigation**: Clear menu structure with visual indicators
- **Responsive Design**: Seamless experience across all device sizes
- **Interactive Elements**: Hover states, tooltips, and feedback
- **Loading States**: Progress indicators for data-heavy operations
- **Error Handling**: User-friendly error messages and recovery options
- **Accessibility**: WCAG compliance with keyboard navigation and screen reader support

### **Performance Optimization**
- **Fast Load Times**: Optimized asset loading and caching
- **Smooth Interactions**: Efficient data processing and rendering
- **Memory Management**: Proper cleanup of resources and components
- **Scalable Architecture**: Handles increasing data volumes gracefully

## 📁 Project Structure & Organization

```
TeamPower/
├── components/
├── database/                  # (legacy or future use)
├── db/                        # Database files (e.g., team_power.db)
├── db_management/             # Database utilities and logic
├── documentation/             # All documentation markdown files
├── multipages/                # Main Dash app and modules
│   ├── app.py
│   ├── callbacks.py
│   ├── assets/
│   ├── components/
│   ├── config/
│   ├── dashboard/
│   ├── pages/
│   ├── services/
│   └── utils/
├── requirements.txt
├── scripts/                   # Data population and migration scripts
├── tests/                     # All test files
```

- All documentation is now in `documentation/`.
- All scripts are in `scripts/`.
- All database files are in `db/`.
- All tests are in `tests/`.
- The main Dash app and modules are under `multipages/`.

## For more details, see the documentation in the `documentation/` folder.

---

## 🎯 Why TeamPower GSK Dashboard?

### **For Business Users**
- 📊 **Instant Insights**: Get immediate visibility into key performance metrics
- 🎨 **Professional Presentation**: GSK-branded visualizations ready for executive presentations
- 📱 **Access Anywhere**: Responsive design works on desktop, tablet, and mobile
- ⚡ **Real-time Data**: Live updates ensure you're always working with current information

### **For IT Teams**
- 🔧 **Low Maintenance**: Built on proven, stable technologies
- 🚀 **Quick Deployment**: Single Python application with minimal dependencies
- 🔒 **Secure**: Local deployment options with full data control
- 📈 **Scalable**: Modular architecture supports growth and customization

### **For Developers**
- 🧩 **Modular Design**: Reusable components and utilities
- 📚 **Well Documented**: Clear code structure and comprehensive documentation
- 🎨 **Design System**: Consistent GSK branding across all components
- 🔄 **Extensible**: Easy to add new pages, charts, and features

## ✨ Key Features

### **Dashboard Capabilities**
- **Multi-page Navigation**: Seamless transition between different analytical views
- **Interactive Visualizations**: Click, hover, and zoom interactions on all charts
- **Real-time Updates**: Live data refresh capabilities for dynamic dashboards
- **Export Functions**: Save charts and data for reports and presentations

### **Chart Types & Analytics**
- **Line Charts**: Trend analysis and time-series visualization
- **Bar Charts**: Comparative analysis and categorical data display
- **Gauge Charts**: KPI monitoring and performance tracking
- **Sunburst Diagrams**: Hierarchical data exploration
- **Stacked Charts**: Multi-dimensional data comparison

### **GSK Design Integration**
- **Brand Compliance**: Automatic application of GSK colors and typography
- **Professional Styling**: Executive-ready visualizations out of the box
- **Responsive Layout**: Optimized for all screen sizes and devices
- **Accessibility**: High contrast options and screen reader support

## 🏗️ Architecture Overview

### **Application Architecture**
```
┌─────────────────────────────────────────┐
│             Frontend Layer              │
│  (Dash + Plotly + Bootstrap)           │
├─────────────────────────────────────────┤
│           Component Layer               │
│     (Reusable Charts & Utilities)      │
├─────────────────────────────────────────┤
│            Data Layer                   │
│    (Pandas + SQLite + Processing)      │
├─────────────────────────────────────────┤
│           Storage Layer                 │
│      (Local Files + Database)          │
└─────────────────────────────────────────┘
```

### **Design Principles**
- **Separation of Concerns**: Clear separation between UI, logic, and data
- **Reusability**: Modular components that can be used across pages
- **Maintainability**: Clean code structure with comprehensive documentation
- **Performance**: Optimized data processing and caching strategies
- **Security**: Local deployment with controlled data access

### **Technology Stack**

| Layer | Technology | Purpose |
|-------|------------|---------|
| **Frontend** | Dash + Plotly | Interactive web interface and visualizations |
| **Styling** | Bootstrap 5 + Custom CSS | Responsive design and GSK branding |
| **Backend** | Flask (via Dash) | Web server and application routing |
| **Data Processing** | Pandas + NumPy | Data manipulation and analysis |
| **Database** | SQLite | Local data storage and management |
| **Deployment** | Python + Virtual Environment | Isolated application environment |

## 📊 Available Pages & Features

### **Overview Dashboard**
- **Purpose**: Central hub for key organizational metrics
- **Features**: Executive summary cards, trend analysis, performance indicators
- **Target Users**: Managers, executives, team leads

### **Configuration Management**
- **Purpose**: System settings and user preferences
- **Features**: Theme selection, data source configuration, user management
- **Target Users**: System administrators, power users

### **AI Financials**
- **Purpose**: Financial analytics with AI-driven insights
- **Features**: Revenue tracking, budget analysis, predictive modeling
- **Target Users**: Finance teams, business analysts

### **AI Governance**
- **Purpose**: Compliance tracking and governance metrics
- **Features**: Risk assessment, audit trails, compliance dashboards
- **Target Users**: Compliance officers, risk managers

### **Transactions**
- **Purpose**: Transaction management and analysis
- **Features**: Transaction logs, analysis tools, reporting
- **Target Users**: Operations teams, analysts

### **Team Hierarchy**
- **Purpose**: Organizational structure visualization
- **Features**: Org charts, team metrics, hierarchy analysis
- **Target Users**: HR teams, managers, executives

## � Quick Start Guide

### **Prerequisites**
- Python 3.8+ (recommended: Python 3.11)
- pip package manager
- Git (for cloning the repository)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### **Installation Steps**

1. **Clone and Setup**:
   ```bash
   git clone <repository-url>
   cd TeamPowerGSK
   
   # Create isolated Python environment
   python -m venv .venv
   
   # Activate environment
   source .venv/bin/activate  # macOS/Linux
   # or
   .venv\Scripts\activate     # Windows
   ```

2. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Launch Application**:
   ```bash
   cd TeamPower/multipages
   python app.py
   ```

4. **Access Dashboard**:
   Open your browser and navigate to: **http://localhost:8122**

### **First-Time Setup**
1. **Verify Installation**: Check that all pages load without errors
2. **Review Sample Data**: Explore the demo data and visualizations
3. **Configure Settings**: Access the Configuration page to customize preferences
4. **Test Functionality**: Try interactive features like chart zoom and hover

### **Troubleshooting**
```bash
# Verify Python version
python --version

# Check installed packages
pip list

# Test imports
python -c "import dash, plotly, pandas; print('All packages working!')"

# Check port availability
lsof -i :8122  # macOS/Linux
netstat -an | findstr :8122  # Windows
```

## 🎨 Design System & User Experience

### **GSK Brand Integration**
The application strictly adheres to GSK's design principles and brand guidelines:

- **Color Palette**:
  - Primary: GSK Orange (#FF6900) - Call-to-action elements
  - Secondary: GSK Teal (#21837E) - Data visualization and accents
  - Neutral: Professional grays for text and backgrounds
  - Status: Success, warning, and error states with appropriate colors

- **Typography**:
  - Primary Font: GSK Precision (brand-specific)
  - Fallback: System fonts for optimal performance
  - Hierarchy: Consistent heading sizes and spacing

- **Layout Principles**:
  - Clean, minimalist design
  - Consistent spacing using 8px grid system
  - Logical information hierarchy
  - Professional appearance suitable for executive presentations

### **User Experience Features**
- **Intuitive Navigation**: Clear menu structure with visual indicators
- **Responsive Design**: Seamless experience across all device sizes
- **Interactive Elements**: Hover states, tooltips, and feedback
- **Loading States**: Progress indicators for data-heavy operations
- **Error Handling**: User-friendly error messages and recovery options
- **Accessibility**: WCAG compliance with keyboard navigation and screen reader support

### **Performance Optimization**
- **Fast Load Times**: Optimized asset loading and caching
- **Smooth Interactions**: Efficient data processing and rendering
- **Memory Management**: Proper cleanup of resources and components
- **Scalable Architecture**: Handles increasing data volumes gracefully

## 📁 Project Structure & Organization

```
TeamPower/
├── components/
├── database/                  # (legacy or future use)
├── db/                        # Database files (e.g., team_power.db)
├── db_management/             # Database utilities and logic
├── documentation/             # All documentation markdown files
├── multipages/                # Main Dash app and modules
│   ├── app.py
│   ├── callbacks.py
│   ├── assets/
│   ├── components/
│   ├── config/
│   ├── dashboard/
│   ├── pages/
│   ├── services/
│   └── utils/
├── requirements.txt
├── scripts/                   # Data population and migration scripts
├── tests/                     # All test files
```

- All documentation is now in `documentation/`.
- All scripts are in `scripts/`.
- All database files are in `db/`.
- All tests are in `tests/`.
- The main Dash app and modules are under `multipages/`.

## For more details, see the documentation in the `documentation/` folder.

---

## 🎯 Why TeamPower GSK Dashboard?

### **For Business Users**
- 📊 **Instant Insights**: Get immediate visibility into key performance metrics
- 🎨 **Professional Presentation**: GSK-branded visualizations ready for executive presentations
- 📱 **Access Anywhere**: Responsive design works on desktop, tablet, and mobile
- ⚡ **Real-time Data**: Live updates ensure you're always working with current information

### **For IT Teams**
- 🔧 **Low Maintenance**: Built on proven, stable technologies
- 🚀 **Quick Deployment**: Single Python application with minimal dependencies
- 🔒 **Secure**: Local deployment options with full data control
- 📈 **Scalable**: Modular architecture supports growth and customization

### **For Developers**
- 🧩 **Modular Design**: Reusable components and utilities
- 📚 **Well Documented**: Clear code structure and comprehensive documentation
- 🎨 **Design System**: Consistent GSK branding across all components
- 🔄 **Extensible**: Easy to add new pages, charts, and features

## ✨ Key Features

### **Dashboard Capabilities**
- **Multi-page Navigation**: Seamless transition between different analytical views
- **Interactive Visualizations**: Click, hover, and zoom interactions on all charts
- **Real-time Updates**: Live data refresh capabilities for dynamic dashboards
- **Export Functions**: Save charts and data for reports and presentations

### **Chart Types & Analytics**
- **Line Charts**: Trend analysis and time-series visualization
- **Bar Charts**: Comparative analysis and categorical data display
- **Gauge Charts**: KPI monitoring and performance tracking
- **Sunburst Diagrams**: Hierarchical data exploration
- **Stacked Charts**: Multi-dimensional data comparison

### **GSK Design Integration**
- **Brand Compliance**: Automatic application of GSK colors and typography
- **Professional Styling**: Executive-ready visualizations out of the box
- **Responsive Layout**: Optimized for all screen sizes and devices
- **Accessibility**: High contrast options and screen reader support

## 🏗️ Architecture Overview

### **Application Architecture**
```
┌─────────────────────────────────────────┐
│             Frontend Layer              │
│  (Dash + Plotly + Bootstrap)           │
├─────────────────────────────────────────┤
│           Component Layer               │
│     (Reusable Charts & Utilities)      │
├─────────────────────────────────────────┤
│            Data Layer                   │
│    (Pandas + SQLite + Processing)      │
├─────────────────────────────────────────┤
│           Storage Layer                 │
│      (Local Files + Database)          │
└─────────────────────────────────────────┘
```

### **Design Principles**
- **Separation of Concerns**: Clear separation between UI, logic, and data
- **Reusability**: Modular components that can be used across pages
- **Maintainability**: Clean code structure with comprehensive documentation
- **Performance**: Optimized data processing and caching strategies
- **Security**: Local deployment with controlled data access

### **Technology Stack**

| Layer | Technology | Purpose |
|-------|------------|---------|
| **Frontend** | Dash + Plotly | Interactive web interface and visualizations |
| **Styling** | Bootstrap 5 + Custom CSS | Responsive design and GSK branding |
| **Backend** | Flask (via Dash) | Web server and application routing |
| **Data Processing** | Pandas + NumPy | Data manipulation and analysis |
| **Database** | SQLite | Local data storage and management |
| **Deployment** | Python + Virtual Environment | Isolated application environment |

## 📊 Available Pages & Features

### **Overview Dashboard**
- **Purpose**: Central hub for key organizational metrics
- **Features**: Executive summary cards, trend analysis, performance indicators
- **Target Users**: Managers, executives, team leads

### **Configuration Management**
- **Purpose**: System settings and user preferences
- **Features**: Theme selection, data source configuration, user management
- **Target Users**: System administrators, power users

### **AI Financials**
- **Purpose**: Financial analytics with AI-driven insights
- **Features**: Revenue tracking, budget analysis, predictive modeling
- **Target Users**: Finance teams, business analysts

### **AI Governance**
- **Purpose**: Compliance tracking and governance metrics
- **Features**: Risk assessment, audit trails, compliance dashboards
- **Target Users**: Compliance officers, risk managers

### **Transactions**
- **Purpose**: Transaction management and analysis
- **Features**: Transaction logs, analysis tools, reporting
- **Target Users**: Operations teams, analysts

### **Team Hierarchy**
- **Purpose**: Organizational structure visualization
- **Features**: Org charts, team metrics, hierarchy analysis
- **Target Users**: HR teams, managers, executives

## � Quick Start Guide

### **Prerequisites**
- Python 3.8+ (recommended: Python 3.11)
- pip package manager
- Git (for cloning the repository)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### **Installation Steps**

1. **Clone and Setup**:
   ```bash
   git clone <repository-url>
   cd TeamPowerGSK
   
   # Create isolated Python environment
   python -m venv .venv
   
   # Activate environment
   source .venv/bin/activate  # macOS/Linux
   # or
   .venv\Scripts\activate     # Windows
   ```

2. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Launch Application**:
   ```bash
   cd TeamPower/multipages
   python app.py
   ```

4. **Access Dashboard**:
   Open your browser and navigate to: **http://localhost:8122**

### **First-Time Setup**
1. **Verify Installation**: Check that all pages load without errors
2. **Review Sample Data**: Explore the demo data and visualizations
3. **Configure Settings**: Access the Configuration page to customize preferences
4. **Test Functionality**: Try interactive features like chart zoom and hover

### **Troubleshooting**
```bash
# Verify Python version
python --version

# Check installed packages
pip list

# Test imports
python -c "import dash, plotly, pandas; print('All packages working!')"

# Check port availability
lsof -i :8122  # macOS/Linux
netstat -an | findstr :8122  # Windows
```

## 🎨 Design System & User Experience

### **GSK Brand Integration**
The application strictly adheres to GSK's design principles and brand guidelines:

- **Color Palette**:
  - Primary: GSK Orange (#FF6900) - Call-to-action elements
  - Secondary: GSK Teal (#21837E) - Data visualization and accents
  - Neutral: Professional grays for text and backgrounds
  - Status: Success, warning, and error states with appropriate colors

- **Typography**:
  - Primary Font: GSK Precision (brand-specific)
  - Fallback: System fonts for optimal performance
  - Hierarchy: Consistent heading sizes and spacing

- **Layout Principles**:
  - Clean, minimalist design
  - Consistent spacing using 8px grid system
  - Logical information hierarchy
  - Professional appearance suitable for executive presentations

### **User Experience Features**
- **Intuitive Navigation**: Clear menu structure with visual indicators
- **Responsive Design**: Seamless experience across all device sizes
- **Interactive Elements**: Hover states, tooltips, and feedback
- **Loading States**: Progress indicators for data-heavy operations
- **Error Handling**: User-friendly error messages and recovery options
- **Accessibility**: WCAG compliance with keyboard navigation and screen reader support

### **Performance Optimization**
- **Fast Load Times**: Optimized asset loading and caching
- **Smooth Interactions**: Efficient data processing and rendering
- **Memory Management**: Proper cleanup of resources and components
- **Scalable Architecture**: Handles increasing data volumes gracefully

## 📁 Project Structure & Organization

```
TeamPower/
├── components/
├── database/                  # (legacy or future use)
├── db/                        # Database files (e.g., team_power.db)
├── db_management/             # Database utilities and logic
├── documentation/             # All documentation markdown files
├── multipages/                # Main Dash app and modules
│   ├── app.py
│   ├── callbacks.py
│   ├── assets/
│   ├── components/
│   ├── config/
│   ├── dashboard/
│   ├── pages/
│   ├── services/
│   └── utils/
├── requirements.txt
├── scripts/                   # Data population and migration scripts
├── tests/                     # All test files
```

- All documentation is now in `documentation/`.
- All scripts are in `scripts/`.
- All database files are in `db/`.
- All tests are in `tests/`.
- The main Dash app and modules are under `multipages/`.

## For more details, see the documentation in the `documentation/` folder.

---

## 🚀 Ready to Get Started?

1. **Clone the repository** and follow the installation guide
2. **Explore the demo data** to understand the application capabilities
3. **Review the development guide** to start customizing for your needs
4. **Join the GSK developer community** for support and collaboration

**Built with ❤️ for GSK Teams - Empowering Data-Driven Decisions**

---

*Last updated: August 2025 | Version: 2.0 | Maintained by GSK Development Team*