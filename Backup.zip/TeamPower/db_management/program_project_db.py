from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_program_project_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        program_id INTEGER NOT NULL,
        project_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    '''
    db.init_table('program_projects', schema)

def add_program_project(program_id, project_id):
    db.insert('program_projects', {'program_id': program_id, 'project_id': project_id})

def delete_program_project_by_project(project_id):
    db.delete('program_projects', 'project_id=?', (project_id,))

def get_program_projects():
    query = '''
        SELECT id, program_id, project_id, created_at FROM program_projects
    '''
    rows = db.fetchall(query)
    return [
        {'id': row[0], 'program_id': row[1], 'project_id': row[2], 'created_at': row[3]}
        for row in rows
    ]

# Call this in your app init
init_program_project_table()
