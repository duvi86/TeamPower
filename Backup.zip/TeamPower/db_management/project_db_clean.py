"""Database utilities for Projects Management only"""
from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_project_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        start_date DATE,
        end_date DATE,
        status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
        maturity TEXT CHECK(maturity IN ('Seed', 'Scoping', 'PoC', 'PoV', 'Scaling', 'Live')) DEFAULT 'Seed',
        budget REAL DEFAULT 0.0,
        owner_id INTEGER,
        program_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        potential_value REAL DEFAULT 0.0,
        refresh_date DATE
    '''
    db.init_table('projects', schema)

def add_project(name, description, start_date, end_date, status='Planning', budget=0.0, maturity='Seed', program_id=None, potential_value=0.0, refresh_date=None, owner_id=None):
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'maturity': maturity,
        'program_id': program_id,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id
    }
    db.insert('projects', data)

def get_projects():
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, 
               p.maturity, p.created_at, p.updated_at, p.owner_id, p.program_id, 
               p.potential_value, p.refresh_date,
               owner.name as owner_name, prog.name as program_name
        FROM projects p
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        LEFT JOIN programs prog ON p.program_id = prog.id
        ORDER BY p.created_at DESC
    '''
    rows = db.fetchall(query)
    projects = []
    for row in rows:
        projects.append({
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'maturity': row[7],
            'created_at': row[8],
            'updated_at': row[9],
            'owner_id': row[10],
            'program_id': row[11],
            'potential_value': row[12],
            'refresh_date': row[13],
            'owner_name': row[14],
            'program_name': row[15]
        })
    return projects

def update_project(project_id, name, description, start_date, end_date, status, budget, maturity, program_id=None, potential_value=0.0, refresh_date=None, owner_id=None):
    from datetime import datetime
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'maturity': maturity,
        'program_id': program_id,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id,
        'updated_at': datetime.now()
    }
    db.update('projects', data, 'id=?', (project_id,))

def delete_project(project_id):
    db.delete('projects', 'id=?', (project_id,))

def get_project_by_id(project_id):
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, 
               p.maturity, p.created_at, p.updated_at, p.owner_id, p.program_id, 
               p.potential_value, p.refresh_date,
               owner.name as owner_name, prog.name as program_name
        FROM projects p
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        LEFT JOIN programs prog ON p.program_id = prog.id
        WHERE p.id = ?
    '''
    row = db.fetchone(query, (project_id,))
    if row:
        return {
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'maturity': row[7],
            'created_at': row[8],
            'updated_at': row[9],
            'owner_id': row[10],
            'program_id': row[11],
            'potential_value': row[12],
            'refresh_date': row[13],
            'owner_name': row[14],
            'program_name': row[15]
        }
    return None

# Call this in your app init
init_project_table()
