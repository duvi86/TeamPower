# --- New function: get_value_tracking_for_year ---
import datetime
def get_value_tracking_for_year(year):
    """
    Return value tracking records where start_date or end_date is in the given year.
    """
    records = get_value_tracking_records()
    filtered = []
    for rec in records:
        start = rec.get('start_date')
        end = rec.get('end_date')
        start_year = None
        end_year = None
        try:
            if start:
                start_year = datetime.datetime.strptime(start, '%Y-%m-%d').year
        except Exception:
            pass
        try:
            if end:
                end_year = datetime.datetime.strptime(end, '%Y-%m-%d').year
        except Exception:
            pass
        if (start_year == year) or (end_year == year):
            filtered.append(rec)
    return filtered
from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_value_tracking_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        description TEXT,
        amount REAL,
        start_date TEXT,
        end_date TEXT,
        project_id INTEGER,
        business_sponsor TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    '''
    db.init_table('value_tracking', schema)

def add_value_tracking_record(description, amount, start_date, end_date, project_id, business_sponsor):
    data = {
        'description': description,
        'amount': amount,
        'start_date': start_date,
        'end_date': end_date,
        'project_id': project_id,
        'business_sponsor': business_sponsor
    }
    db.insert('value_tracking', data)

def get_value_tracking_record_by_id(record_id):
    query = '''
        SELECT v.id, v.description, v.amount, v.start_date, v.end_date, v.project_id, v.business_sponsor, v.created_at, v.updated_at, p.name as project_name
        FROM value_tracking v
        LEFT JOIN projects p ON v.project_id = p.id
        WHERE v.id = ?
    '''
    row = db.fetchone(query, (record_id,))
    if row:
        return {
            'id': row[0],
            'description': row[1],
            'amount': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'project_id': row[5],
            'business_sponsor': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'project_name': row[9]
        }
    return None

def get_value_tracking_records():
    # Join with projects to get project name
    query = '''
        SELECT v.id, v.description, v.amount, v.start_date, v.end_date, v.project_id, v.business_sponsor, v.created_at, v.updated_at, p.name as project_name
        FROM value_tracking v
        LEFT JOIN projects p ON v.project_id = p.id
        ORDER BY v.start_date DESC
    '''
    rows = db.fetchall(query)
    records = []
    for row in rows:
        records.append({
            'id': row[0],
            'description': row[1],
            'amount': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'project_id': row[5],
            'business_sponsor': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'project_name': row[9]
        })
    return records

def update_value_tracking_record(record_id, description, amount, start_date, end_date, project_id, business_sponsor):
    data = {
        'description': description,
        'amount': amount,
        'start_date': start_date,
        'end_date': end_date,
        'project_id': project_id,
        'business_sponsor': business_sponsor,
        'updated_at': 'CURRENT_TIMESTAMP'
    }
    # Special handling for CURRENT_TIMESTAMP
    set_clause = ', '.join([f"{k}=?" if k != 'updated_at' else f"{k}=CURRENT_TIMESTAMP" for k in data.keys()])
    values = tuple([v for k, v in data.items() if k != 'updated_at']) + (record_id,)
    query = f"UPDATE value_tracking SET {set_clause} WHERE id=?"
    db.execute(query, values, commit=True)

def delete_value_tracking_record(record_id):
    db.delete('value_tracking', 'id=?', (record_id,))

# Call this in your app init
init_value_tracking_table()
