"""Database utilities for Projects, Programs, and Teams Management (generic, reusable)"""
from .database_manager import DatabaseManager
from .db_path_utils import get_db_path
from pathlib import Path
from datetime import datetime

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_project_table():
    # Projects table only
    project_schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        start_date DATE,
        end_date DATE,
        status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
        maturity TEXT CHECK(maturity IN ('Seed', 'Scoping', 'PoC', 'PoV', 'Scaling', 'Live')) DEFAULT 'Seed',
        budget REAL DEFAULT 0.0,
        owner_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        potential_value REAL DEFAULT 0.0,
        refresh_date DATE
    '''
    db.init_table('projects', project_schema)

# ============ PROJECT FUNCTIONS ============

def add_project(name, description, start_date, end_date, status='Planning', budget=0.0, maturity='Seed', program_id=None, potential_value=0.0, refresh_date=None, owner_id=None):
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'maturity': maturity,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id
    }
    db.insert('projects', data)
    # If a program is specified, create the association
    if program_id:
        project_id = db.fetchone('SELECT id FROM projects WHERE name=?', (name,))[0]
        from .program_project_db import add_program_project
        add_program_project(program_id, project_id)
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'maturity': maturity,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id
    }
    db.insert('projects', data)

def get_projects():
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, 
               p.maturity, p.created_at, p.updated_at, pr.id as program_id, pr.name as program_name, 
               p.potential_value, p.refresh_date, p.owner_id, 
               owner.name as owner_name
        FROM projects p
        LEFT JOIN program_projects pp ON p.id = pp.project_id
        LEFT JOIN programs pr ON pp.program_id = pr.id
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        ORDER BY p.created_at DESC
    '''
    rows = db.fetchall(query)
    projects = []
    for row in rows:
        projects.append({
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'maturity': row[7],
            'created_at': row[8],
            'updated_at': row[9],
            'program_id': row[10],
            'program_name': row[11],
            'potential_value': row[12],
            'refresh_date': row[13],
            'owner_id': row[14],
            'owner_name': row[15]
        })
    return projects

def update_project(project_id, name, description, start_date, end_date, status, budget, maturity, program_id=None, potential_value=0.0, refresh_date=None, owner_id=None):
    from datetime import datetime
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'maturity': maturity,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id,
        'updated_at': datetime.now()
    }
    db.update('projects', data, 'id=?', (project_id,))
    # Remove any existing program association
    from .program_project_db import delete_program_project_by_project
    delete_program_project_by_project(project_id)
    # If a program is specified, create the association
    if program_id:
        from .program_project_db import add_program_project
        add_program_project(program_id, project_id)
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'maturity': maturity,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id,
        'updated_at': datetime.now()
    }
    db.update('projects', data, 'id=?', (project_id,))

def delete_project(project_id):
    db.delete('projects', 'id=?', (project_id,))

def get_project_by_id(project_id):
    """Get a single project by ID"""
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, 
               p.maturity, p.created_at, p.updated_at, pr.id as program_id, pr.name as program_name, 
               p.potential_value, p.refresh_date, p.owner_id, 
               owner.name as owner_name
        FROM projects p
        LEFT JOIN program_projects pp ON p.id = pp.project_id
        LEFT JOIN programs pr ON pp.program_id = pr.id
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        WHERE p.id = ?
    '''
    row = db.fetchone(query, (project_id,))
    if row:
        return {
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'maturity': row[7],
            'created_at': row[8],
            'updated_at': row[9],
            'program_id': row[10],
            'program_name': row[11],
            'potential_value': row[12],
            'refresh_date': row[13],
            'owner_id': row[14],
            'owner_name': row[15]
        }
    return None

def add_program(name, description, start_date, end_date, status='Planning', budget=0.0, owner_id=None):
    # Get owner's department if owner_id is provided
    department = None
    if owner_id:
        owner_query = 'SELECT department FROM team_members WHERE id = ?'
        owner_result = db.fetchone(owner_query, (owner_id,))
        if owner_result:
            department = owner_result[0]
    
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'owner_id': owner_id,
        'department': department
    }
    db.insert('programs', data)

def get_programs():
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, 
               p.created_at, p.updated_at, p.owner_id, owner.name as owner_name, 
               p.department, owner.department as owner_department
        FROM programs p
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        ORDER BY p.created_at DESC
    '''
    rows = db.fetchall(query)
    programs = []
    for row in rows:
        programs.append({
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'owner_id': row[9],
            'owner_name': row[10],
            'department': row[11],
            'owner_department': row[12]
        })
    return programs

def update_program(program_id, name, description, start_date, end_date, status, budget, owner_id=None):
    # Get owner's department if owner_id is provided
    department = None
    if owner_id:
        owner_query = 'SELECT department FROM team_members WHERE id = ?'
        owner_result = db.fetchone(owner_query, (owner_id,))
        if owner_result:
            department = owner_result[0]
    
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'owner_id': owner_id,
        'department': department,
        'updated_at': datetime.now()
    }
    db.update('programs', data, 'id=?', (program_id,))

def delete_program(program_id):
    db.delete('programs', 'id=?', (program_id,))

def get_program_by_id(program_id):
    """Get a single program by ID"""
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, 
               p.created_at, p.updated_at, p.owner_id, owner.name as owner_name
        FROM programs p
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        WHERE p.id = ?
    '''
    row = db.fetchone(query, (program_id,))
    if row:
        return {
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'owner_id': row[9],
            'owner_name': row[10]
        }
    return None

# ============ PROGRAM-PROJECT MAPPING FUNCTIONS ============

def link_project_to_program(program_id, project_id):
    db.insert('program_projects', {'program_id': program_id, 'project_id': project_id})

def unlink_project_from_program(program_id, project_id):
    db.delete('program_projects', 'program_id=? AND project_id=?', (program_id, project_id))

def get_program_projects(program_id):
    query = '''
        SELECT p.id, p.name, p.description, p.status, p.start_date, p.end_date, p.budget, 
               p.maturity, p.potential_value, p.refresh_date
        FROM projects p
        JOIN program_projects pp ON p.id = pp.project_id
        WHERE pp.program_id = ?
        ORDER BY p.name
    '''
    rows = db.fetchall(query, (program_id,))
    projects = []
    for row in rows:
        projects.append({
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'maturity': row[7],
            'created_at': row[8],
            'updated_at': row[9],
            'program_id': row[10],
            'program_name': row[11],
            'potential_value': row[12],
            'refresh_date': row[13],
            'owner_id': row[14],
            'owner_name': row[15]
        })
    return projects

def add_team_member(name, email, role, department, manager_id=None, start_date=None, end_date=None, status='Active'):
    data = {
        'name': name,
        'email': email,
        'role': role,
        'department': department,
        'manager_id': manager_id,
        'start_date': start_date,
        'end_date': end_date,
        'status': status
    }
    db.insert('team_members', data)

def get_team_members():
    query = '''
        SELECT tm.id, tm.name, tm.email, tm.role, tm.department, tm.manager_id, 
               manager.name as manager_name, tm.start_date, tm.end_date, tm.status
        FROM team_members tm
        LEFT JOIN team_members manager ON tm.manager_id = manager.id
        ORDER BY tm.name
    '''
    rows = db.fetchall(query)
    team_members = []
    for row in rows:
        team_members.append({
            'id': row[0],
            'name': row[1],
            'email': row[2],
            'role': row[3],
            'department': row[4],
            'manager_id': row[5],
            'manager_name': row[6],
            'start_date': row[7],
            'end_date': row[8],
            'status': row[9]
        })
    return team_members

def get_team_members_with_details():
    """Get team members with detailed information including manager and project names"""
    query = '''
        SELECT tm.id, tm.name, tm.email, tm.role, tm.department, tm.start_date, tm.end_date, tm.status,
               manager.name as manager_name
        FROM team_members tm
        LEFT JOIN team_members manager ON tm.manager_id = manager.id
        ORDER BY tm.name
    '''
    rows = db.fetchall(query)
    team_members = []
    for row in rows:
        team_members.append({
            'id': row[0],
            'name': row[1],
            'email': row[2],
            'role': row[3],
            'department': row[4],
            'start_date': row[5],
            'end_date': row[6],
            'status': row[7],
            'manager_name': row[8]
        })
    return team_members

def get_team_member_by_id(member_id):
    """Get a specific team member by ID"""
    query = '''
        SELECT tm.id, tm.name, tm.email, tm.role, tm.department, tm.manager_id,
               tm.start_date, tm.end_date, tm.status, manager.name as manager_name
        FROM team_members tm
        LEFT JOIN team_members manager ON tm.manager_id = manager.id
        WHERE tm.id = ?
    '''
    row = db.fetchone(query, (member_id,))
    if row:
        return {
            'id': row[0],
            'name': row[1],
            'email': row[2],
            'role': row[3],
            'department': row[4],
            'manager_id': row[5],
            'start_date': row[6],
            'end_date': row[7],
            'status': row[8],
            'manager_name': row[9]
        }
    return None

def update_team_member(member_id, name, email, role, department, manager_id, start_date, end_date, status):
    data = {
        'name': name,
        'email': email,
        'role': role,
        'department': department,
        'manager_id': manager_id,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'updated_at': datetime.now()
    }
    db.update('team_members', data, 'id=?', (member_id,))

def delete_team_member(member_id):
    db.delete('team_members', 'id=?', (member_id,))

def get_team_hierarchy():
    query = '''
        SELECT DISTINCT m.id, m.name, m.role, m.department
        FROM team_members m
        JOIN team_members r ON m.id = r.manager_id
        WHERE m.status = 'Active'
        ORDER BY m.name
    '''
    managers = db.fetchall(query)
    hierarchy = []
    for manager in managers:
        manager_data = {
            'id': manager[0],
            'name': manager[1],
            'role': manager[2],
            'department': manager[3],
            'reportees': []
        }
        reportees_query = '''
            SELECT id, name, role, department, email, start_date, status
            FROM team_members
            WHERE manager_id = ? AND status = 'Active'
            ORDER BY name
        '''
        reportees = db.fetchall(reportees_query, (manager[0],))
        for reportee in reportees:
            manager_data['reportees'].append({
                'id': reportee[0],
                'name': reportee[1],
                'role': reportee[2],
                'department': reportee[3],
                'email': reportee[4],
                'start_date': reportee[5],
                'status': reportee[6]
            })
        hierarchy.append(manager_data)
    return hierarchy


def add_objective(title, description, program_id, owner_id, main_responsible_id=None, quarter=None, year=None, status='Planning'):
    data = {
        'title': title,
        'description': description,
        'program_id': program_id,
        'owner_id': owner_id,
        'main_responsible_id': main_responsible_id,
        'quarter': quarter,
        'year': year,
        'status': status
    }
    db.insert('objectives', data)
    objective_id = db.fetchone('SELECT id FROM objectives WHERE title=?', (title,))[0]
    return objective_id


def add_key_result(objective_id, title, description, target_value, unit, due_date=None, owner_id=None, main_responsible_id=None):
    data = {
        'objective_id': objective_id,
        'title': title,
        'description': description,
        'target_value': target_value,
        'unit': unit,
        'due_date': due_date,
        'owner_id': owner_id,
        'main_responsible_id': main_responsible_id
    }
    db.insert('key_results', data)
    return True


def add_supporting_team_member(objective_id, team_member_id, role='Support'):
    data = {
        'objective_id': objective_id,
        'team_member_id': team_member_id,
        'role': role
    }
    db.insert('okr_supporting_team', data)
    return True


def add_kr_supporting_team_member(key_result_id, team_member_id, role='Support'):
    data = {
        'key_result_id': key_result_id,
        'team_member_id': team_member_id,
        'role': role
    }
    db.insert('kr_supporting_team', data)
    return True


def get_kr_supporting_team(key_result_id):
    query = '''
        SELECT tm.id, tm.name, krs.role
        FROM kr_supporting_team krs
        JOIN team_members tm ON krs.team_member_id = tm.id
        WHERE krs.key_result_id = ?
        ORDER BY tm.name
    '''
    rows = db.fetchall(query, (key_result_id,))
    supporting_team = []
    for row in rows:
        supporting_team.append({
            'id': row[0],
            'name': row[1],
            'role': row[2]
        })
    return supporting_team


def get_objectives():
    query = '''
        SELECT o.id, o.title, o.description, o.program_id, p.name as program_name,
               o.owner_id, owner.name as owner_name,
               o.main_responsible_id, responsible.name as main_responsible_name,
               o.quarter, o.year, o.status, o.progress, o.created_at, o.updated_at
        FROM objectives o
        LEFT JOIN programs p ON o.program_id = p.id
        LEFT JOIN team_members owner ON o.owner_id = owner.id
        LEFT JOIN team_members responsible ON o.main_responsible_id = responsible.id
        ORDER BY o.created_at DESC
    '''
    rows = db.fetchall(query)
    objectives = []
    for row in rows:
        objectives.append({
            'id': row[0],
            'title': row[1],
            'description': row[2],
            'program_id': row[3],
            'program_name': row[4],
            'owner_id': row[5],
            'owner_name': row[6],
            'main_responsible_id': row[7],
            'main_responsible_name': row[8],
            'quarter': row[9],
            'year': row[10],
            'status': row[11],
            'progress': row[12],
            'created_at': row[13],
            'updated_at': row[14]
        })
    return objectives


def get_key_results_for_objective(objective_id):
    query = '''
        SELECT kr.id, kr.title, kr.description, kr.target_value, kr.current_value, kr.unit, 
               kr.status, kr.progress, kr.due_date, kr.created_at, kr.updated_at,
               owner.name as owner_name, responsible.name as main_responsible_name
        FROM key_results kr
        LEFT JOIN team_members owner ON kr.owner_id = owner.id
        LEFT JOIN team_members responsible ON kr.main_responsible_id = responsible.id
        WHERE kr.objective_id = ?
        ORDER BY kr.created_at ASC
    '''
    rows = db.fetchall(query, (objective_id,))
    key_results = []
    for row in rows:
        key_results.append({
            'id': row[0],
            'title': row[1],
            'description': row[2],
            'target_value': row[3],
            'current_value': row[4],
            'unit': row[5],
            'status': row[6],
            'progress': row[7],
            'due_date': row[8],
            'created_at': row[9],
            'updated_at': row[10],
            'owner_name': row[11],
            'main_responsible_name': row[12]
        })
    return key_results


def get_supporting_team_for_objective(objective_id):
    query = '''
        SELECT ost.id, tm.id, tm.name, tm.email, tm.role, ost.role as okr_role
        FROM okr_supporting_team ost
        JOIN team_members tm ON ost.team_member_id = tm.id
        WHERE ost.objective_id = ?
        ORDER BY tm.name
    '''
    rows = db.fetchall(query, (objective_id,))
    supporting_team = []
    for row in rows:
        supporting_team.append({
            'id': row[0],
            'team_member_id': row[1],
            'name': row[2],
            'email': row[3],
            'role': row[4],
            'okr_role': row[5]
        })
    return supporting_team


def update_key_result_progress(key_result_id, current_value):
    try:
        result = db.fetchone('SELECT target_value FROM key_results WHERE id = ?', (key_result_id,))
        if not result:
            return False
        target_value = result[0]
        progress = (current_value / target_value * 100) if target_value > 0 else 0
        progress = min(100, max(0, progress))
        data = {
            'current_value': current_value,
            'progress': progress,
            'updated_at': datetime.now()
        }
        db.update('key_results', data, 'id=?', (key_result_id,))
        return True
    except Exception as e:
        print(f"Error updating key result progress: {e}")
        return False


def delete_objective(objective_id):
    try:
        db.delete('objectives', 'id=?', (objective_id,))
        return True
    except Exception as e:
        print(f"Error deleting objective: {e}")
        return False


# ============ PROGRAM BUDGET CALCULATION FUNCTIONS ============

def get_program_budget(program_id, start_date=None, end_date=None):
    """
    Calculate program budget based on transactions linked to projects within the program
    Transaction → Project → Program linking
    """
    try:
        # Get program details if dates not provided
        if start_date is None or end_date is None:
            program = get_program_by_id(program_id)
            if program:
                start_date = program.get('start_date') if start_date is None else start_date
                end_date = program.get('end_date') if end_date is None else end_date
        
        # Query to get all transactions linked to projects in this program
        # Use the project_id field from transaction table
        query = """
        SELECT COALESCE(SUM(t.amount), 0) as total_budget
        FROM transactions t
        JOIN projects p ON t.project_id = p.id
        WHERE p.program_id = ?
        """
        
        params = [program_id]
        
        # Add date filters if available
        if start_date:
            query += " AND t.date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND t.date <= ?"
            params.append(end_date)
        
        rows = db.fetchall(query, tuple(params))
        budget = float(rows[0][0]) if rows and rows[0] and rows[0][0] is not None else 0.0
        
        return budget
        
    except Exception as e:
        print(f"Error calculating program budget: {e}")
        return 0.0

def get_programs_with_computed_budget():
    """Get all programs with computed budget from related transactions using proper project linking"""
    try:
        # Get all programs with their computed budgets using proper Transaction→Project→Program linking
        query = """
        SELECT 
            p.id,
            p.name,
            p.description,
            p.start_date,
            p.end_date,
            p.status,
            p.owner_id,
            tm.name as owner_name,
            COALESCE(budget_sum.total_budget, 0) as computed_budget
        FROM programs p
        LEFT JOIN team_members tm ON p.owner_id = tm.id
        LEFT JOIN (
            SELECT 
                p2.program_id,
                SUM(t.amount) as total_budget
            FROM transactions t
            JOIN projects p2 ON t.project_id = p2.id
            GROUP BY p2.program_id
        ) budget_sum ON p.id = budget_sum.program_id
        ORDER BY p.name
        """
        
        rows = db.fetchall(query)
        
        programs = []
        for row in rows:
            program = {
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'start_date': row[3],
                'end_date': row[4],
                'status': row[5],
                'owner_id': row[6],
                'owner': row[7] or '',  # owner name for display
                'budget': float(row[8])  # computed budget
            }
            programs.append(program)
        
        return programs
        
    except Exception as e:
        print(f"Error getting programs with computed budget: {e}")
        return []


def get_program_budget(program_id, start_date=None, end_date=None):
    """
    Calculate program budget based on transactions linked to projects within the program
    Transaction → Project → Program linking
    """
    try:
        from .db_path_utils import get_db_path
        import sqlite3
        
        conn = sqlite3.connect(get_db_path())
        cursor = conn.cursor()
        
        # Get program details if dates not provided
        if start_date is None or end_date is None:
            cursor.execute("SELECT start_date, end_date FROM programs WHERE id = ?", (program_id,))
            program_data = cursor.fetchone()
            if program_data:
                start_date = program_data[0] if start_date is None else start_date
                end_date = program_data[1] if end_date is None else end_date
        
        # Query to get all transactions linked to projects in this program
        query = """
        SELECT COALESCE(SUM(t.amount), 0) as total_budget
        FROM transactions t
        JOIN projects p ON t.project_id = p.id
        WHERE p.program_id = ?
        """
        
        params = [program_id]
        
        # Add date filters if available
        if start_date:
            query += " AND t.date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND t.date <= ?"
            params.append(end_date)
        
        cursor.execute(query, params)
        result = cursor.fetchone()
        budget = float(result[0]) if result and result[0] is not None else 0.0
        
        conn.close()
        return budget
        
    except Exception as e:
        print(f"Error calculating program budget: {e}")
        return 0.0

def get_programs_with_computed_budget():
    """Get all programs with computed budget from related transactions using proper project linking"""
    try:
        from .db_path_utils import get_db_path
        import sqlite3
        
        conn = sqlite3.connect(get_db_path())
        cursor = conn.cursor()
        
        # Get all programs with their computed budgets using proper Transaction→Project→Program linking
        query = """
        SELECT 
            p.id,
            p.name,
            p.description,
            p.start_date,
            p.end_date,
            p.status,
            p.owner_id,
            tm.name as owner_name,
            COALESCE(budget_sum.total_budget, 0) as computed_budget
        FROM programs p
        LEFT JOIN team_members tm ON p.owner_id = tm.id
        LEFT JOIN (
            SELECT 
                pp.program_id,
                SUM(t.amount) as total_budget
            FROM program_projects pp
            JOIN projects pr ON pr.id = pp.project_id
            JOIN transactions t ON t.project_id = pr.id
            WHERE t.type = 'Budget'
            GROUP BY pp.program_id
        ) budget_sum ON p.id = budget_sum.program_id
        ORDER BY p.name
        """
        
        cursor.execute(query)
        rows = cursor.fetchall()
        
        programs = []
        for row in rows:
            program = {
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'start_date': row[3],
                'end_date': row[4],
                'status': row[5],
                'owner_id': row[6],
                'owner': row[7] or '',  # owner name for display
                'budget': float(row[8])  # computed budget
            }
            programs.append(program)
        conn.close()
        return programs
        
    except Exception as e:
        print(f"Error getting programs with computed budget: {e}")
        return []


# Initialize tables when module is imported
init_project_table()
