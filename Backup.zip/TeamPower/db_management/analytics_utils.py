"""Analytics and KPI utility functions for cross-entity reporting"""
from .database_manager import DatabaseManager
from .db_path_utils import get_db_path
from .transaction_db import get_transactions_df
from .project_db import get_projects

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def get_dashboard_kpis():
    try:
        # Team statistics
        active_team_members = db.fetchone('SELECT COUNT(*) FROM team_members WHERE status = "Active"')[0] or 0
        total_programs = db.fetchone('SELECT COUNT(*) FROM programs')[0] or 0
        active_programs = db.fetchone('SELECT COUNT(*) FROM programs WHERE status = "Active"')[0] or 0
        total_projects = db.fetchone('SELECT COUNT(*) FROM projects')[0] or 0
        active_projects = db.fetchone('SELECT COUNT(*) FROM projects WHERE status = "Active"')[0] or 0
        completed_projects = db.fetchone('SELECT COUNT(*) FROM projects WHERE status = "Completed"')[0] or 0
        cancelled_projects = db.fetchone('SELECT COUNT(*) FROM projects WHERE status = "Cancelled"')[0] or 0
        planning_projects = db.fetchone('SELECT COUNT(*) FROM projects WHERE status = "Planning"')[0] or 0
        inactive_team_members = db.fetchone('SELECT COUNT(*) FROM team_members WHERE status = "Inactive"')[0] or 0
        total_team_members = db.fetchone('SELECT COUNT(*) FROM team_members')[0] or 0
        attrition_rate = (inactive_team_members / total_team_members * 100) if total_team_members > 0 else 0
        
        # Financial statistics from transactions
        budget_amount = db.fetchone('SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE type = "Budget"')[0] or 0
        planned_amount = db.fetchone('SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE type = "X-charged"')[0] or 0
        consumed_amount = db.fetchone('SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE type = "Consumed"')[0] or 0
        
        # Budget from programs and projects
        program_budgets = db.fetchone('SELECT COALESCE(SUM(budget), 0) FROM programs')[0] or 0
        project_budgets = db.fetchone('SELECT COALESCE(SUM(budget), 0) FROM projects')[0] or 0
        total_budget = program_budgets + project_budgets
        
        return {
            'active_team_members': active_team_members,
            'total_programs': total_programs,
            'active_programs': active_programs,
            'total_projects': total_projects,
            'active_projects': active_projects,
            'completed_projects': completed_projects,
            'cancelled_projects': cancelled_projects,
            'planning_projects': planning_projects,
            'attrition_rate': round(attrition_rate, 1),
            'inactive_team_members': inactive_team_members,
            'total_team_members': total_team_members,
            'budget_amount': round(budget_amount, 2),
            'planned_amount': round(planned_amount, 2),
            'consumed_amount': round(consumed_amount, 2),
            'total_budget': round(total_budget, 2)
        }
    except Exception:
        return {
            'active_team_members': 0,
            'total_programs': 0,
            'active_programs': 0,
            'total_projects': 0,
            'active_projects': 0,
            'completed_projects': 0,
            'cancelled_projects': 0,
            'planning_projects': 0,
            'attrition_rate': 0.0,
            'inactive_team_members': 0,
            'total_team_members': 0,
            'budget_amount': 0,
            'planned_amount': 0,
            'consumed_amount': 0,
            'total_budget': 0
        }

def get_year_filtered_kpis(selected_year):
    """
    Get KPIs filtered by selected year based on transaction data
    
    Parameters:
    -----------
    selected_year : int
        Year to filter the data by
        
    Returns:
    --------
    dict
        Dictionary containing year-filtered KPI metrics
    """
    try:
        import pandas as pd
        from datetime import datetime, timedelta
        # Get filtered transaction data for the year
        df = get_transactions_df()
        if df.empty:
            return get_default_kpis_for_year(selected_year)

        # Convert Date to datetime and filter by selected year
        df['Date'] = pd.to_datetime(df['Date'])
        df_filtered = df[df['Date'].dt.year == selected_year]

        if df_filtered.empty:
            return get_default_kpis_for_year(selected_year)

        # Calculate year-based financial KPIs using correct Type field
        total_amount = df_filtered['Amount'].sum()
        budget_amount = df_filtered[df_filtered['Type'] == 'Budget']['Amount'].sum()
        planned_amount = df_filtered[df_filtered['Type'] == 'X-charged']['Amount'].sum()
        consumed_amount = df_filtered[df_filtered['Type'] == 'Consumed']['Amount'].sum()

        opex_amount = df_filtered[df_filtered['Category'] == 'OPEX']['Amount'].sum()
        capex_amount = df_filtered[df_filtered['Category'] == 'CAPEX']['Amount'].sum()

        # Calculate transaction-based metrics
        total_transactions = len(df_filtered)
        unique_projects = len(df_filtered['Cost Center Project'].unique())
        unique_sows = len(df_filtered['SOW Number'].unique())

        # --- Rolling 12-month Attrition Rate Calculation ---
        # Numerator: Leavers (status 'Inactive' AND end_date in last 12 months)
        end_of_period = datetime(selected_year, 12, 31)
        start_of_period = end_of_period - timedelta(days=365)

        leavers = db.fetchone(
            """
            SELECT COUNT(*) FROM team_members
            WHERE status = 'Inactive' AND end_date IS NOT NULL AND end_date >= ? AND end_date <= ?
            """,
            (start_of_period.strftime("%Y-%m-%d"), end_of_period.strftime("%Y-%m-%d"))
        )[0]

        # Denominator: Average number of employees over the last 12 months
        counts = []
        for i in range(12):
            sample_date = (start_of_period + timedelta(days=30*i)).strftime("%Y-%m-%d")
            count = db.fetchone(
                """
                SELECT COUNT(*) FROM team_members
                WHERE start_date <= ? AND (end_date IS NULL OR end_date >= ?)
                """,
                (sample_date, sample_date)
            )[0]
            counts.append(count)
        avg_employees = sum(counts) / len(counts) if counts else 0

        attrition_rate = (leavers / avg_employees * 100) if avg_employees else 0

        return {
            # Financial metrics (year-filtered)
            'total_amount': round(total_amount, 2),
            'budget_amount': round(budget_amount, 2),
            'planned_amount': round(planned_amount, 2),
            'consumed_amount': round(consumed_amount, 2),
            'opex_amount': round(opex_amount, 2),
            'capex_amount': round(capex_amount, 2),
            # Transaction-based metrics (year-filtered)
            'total_transactions': total_transactions,
            'unique_projects': unique_projects,
            'unique_sows': unique_sows,
            'selected_year': selected_year,
            # Year-based organizational metrics
            'attrition_rate': round(attrition_rate, 1),
            'leavers': leavers,
            'base_population': float(f"{avg_employees:.1f}"),
            'active_team_members': counts[-1],
            # (Optionally add other project/program metrics as needed)
        }
    except Exception as e:
        print(f"Error getting year-filtered KPIs: {e}")
        return get_default_kpis_for_year(selected_year)

def get_default_kpis_for_year(selected_year):
    """Return default KPIs when no data available for selected year"""
    
    return {
        'total_amount': 0,
        'budget_amount': 0,
        'planned_amount': 0,
        'consumed_amount': 0,
        'opex_amount': 0,
        'capex_amount': 0,
        'total_transactions': 0,
        'unique_projects': 0,
        'unique_sows': 0,
        'selected_year': selected_year,
        'active_team_members': 0,
        'total_team_members': 0,
        'inactive_team_members': 0,
        'attrition_rate': 0.0,
        'total_programs': 0,
        'active_programs': 0,
        'total_projects': 0,
        'active_projects': 0,
        'completed_projects': 0
    }

def get_value_evolution_data(year):
    """Get value evolution data from database, year-dependent"""
    try:
        from datetime import datetime
        projects = get_projects()
        # Only include projects with update_date in the selected year
        filtered_projects = []
        for p in projects:
            update_date = p.get('update_date')
            if update_date:
                try:
                    update_year = datetime.strptime(update_date, "%Y-%m-%d").year
                except Exception:
                    continue
                if update_year == year:
                    filtered_projects.append(p)
        # Aggregate values per month
        months = [f"{year}-{month:02d}" for month in range(1, 13)]
        promised_values = [0] * 12
        realized_values = [0] * 12
        for p in filtered_projects:
            update_date = p.get('update_date')
            if update_date:
                try:
                    dt = datetime.strptime(update_date, "%Y-%m-%d")
                    month_idx = dt.month - 1
                except Exception:
                    continue
                promised_values[month_idx] += p.get('potential_value', 0) or 0
                realized_values[month_idx] += p.get('realized_value', 0) or 0
        return {
            'Month': months,
            'Value Promised': promised_values,
            'Value Realized': realized_values
        }
    except Exception as e:
        months = [f"{year}-{month:02d}" for month in range(1, 13)]
        return {
            'Month': months,
            'Value Promised': [0 for _ in range(12)],
            'Value Realized': [0 for _ in range(12)]
        }

def get_department_program_project_budgets():
    """
    Returns a list of dicts with department, program, project, and computed budget for sunburst chart.
    Each dict: {'department', 'program', 'project', 'budget'}
    """
    import sqlite3
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    query = """
    SELECT
        COALESCE(tm.department, 'Unknown') as department,
        pg.name as program,
        pr.name as project,
        COALESCE(SUM(t.amount), 0) as budget
    FROM programs pg
    LEFT JOIN team_members tm ON pg.owner_id = tm.id
    LEFT JOIN program_projects pp ON pp.program_id = pg.id
    LEFT JOIN projects pr ON pr.id = pp.project_id
    LEFT JOIN transactions t ON t.project_id = pr.id AND t.type = 'Budget'
    GROUP BY tm.department, pg.name, pr.name
    ORDER BY tm.department, pg.name, pr.name
    """
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    return [
        {
            'department': row[0],
            'program': row[1],
            'project': row[2],
            'budget': float(row[3])
        }
        for row in rows if row[1] is not None and row[2] is not None
    ]
