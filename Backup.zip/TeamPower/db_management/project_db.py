"""Database utilities for Projects Management only"""
from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_project_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        start_date DATE,
        end_date DATE,
        status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
        maturity TEXT CHECK(maturity IN ('Seed', 'Scoping', 'PoC', 'PoV', 'Scaling', 'Live')) DEFAULT 'Seed',
        owner_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        potential_value REAL DEFAULT 0.0,
        refresh_date DATE
    '''
    db.init_table('projects', schema)

def add_project(name, description, start_date, end_date, status='Planning', maturity='Seed', program_id=None, potential_value=0.0, refresh_date=None, owner_id=None):
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'maturity': maturity,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id
    }
    db.insert('projects', data)
    # If a program is specified, create the association
    if program_id:
        project_id = db.fetchone('SELECT id FROM projects WHERE name=?', (name,))[0]
        from .program_project_db import add_program_project
        add_program_project(program_id, project_id)

def get_projects():
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, 
               p.maturity, p.created_at, p.updated_at, pr.id as program_id, pr.name as program_name, 
               p.potential_value, p.refresh_date, p.owner_id, 
               owner.name as owner_name,
               COALESCE(budget_sum.total_budget, 0) as computed_budget
        FROM projects p
        LEFT JOIN program_projects pp ON p.id = pp.project_id
        LEFT JOIN programs pr ON pp.program_id = pr.id
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        LEFT JOIN (
            SELECT 
                project_id,
                SUM(amount) as total_budget
            FROM transactions 
            WHERE type = 'Budget'
            GROUP BY project_id
        ) budget_sum ON p.id = budget_sum.project_id
        ORDER BY p.created_at DESC
    '''
    rows = db.fetchall(query)
    projects = []
    for row in rows:
        projects.append({
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'maturity': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'program_id': row[9],
            'program_name': row[10],
            'potential_value': row[11],
            'refresh_date': row[12],
            'owner_id': row[13],
            'owner_name': row[14],
            'budget': float(row[15]) if row[15] else 0.0  # Computed from transactions
        })
    return projects

def update_project(project_id, name, description, start_date, end_date, status, maturity, program_id=None, potential_value=0.0, refresh_date=None, owner_id=None):
    from datetime import datetime
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'maturity': maturity,
        'potential_value': potential_value,
        'refresh_date': refresh_date,
        'owner_id': owner_id,
        'updated_at': datetime.now()
    }
    db.update('projects', data, 'id=?', (project_id,))
    # Remove any existing program association
    from .program_project_db import delete_program_project_by_project
    delete_program_project_by_project(project_id)
    # If a program is specified, create the association
    if program_id:
        from .program_project_db import add_program_project
        add_program_project(program_id, project_id)

def delete_project(project_id):
    db.delete('projects', 'id=?', (project_id,))

def get_project_by_id(project_id):
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status,
               p.maturity, p.created_at, p.updated_at, pr.id as program_id, pr.name as program_name, 
               p.potential_value, p.refresh_date, p.owner_id, 
               owner.name as owner_name,
               COALESCE(budget_sum.total_budget, 0) as computed_budget
        FROM projects p
        LEFT JOIN program_projects pp ON p.id = pp.project_id
        LEFT JOIN programs pr ON pp.program_id = pr.id
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        LEFT JOIN (
            SELECT 
                project_id,
                SUM(amount) as total_budget
            FROM transactions 
            WHERE type = 'Budget'
            GROUP BY project_id
        ) budget_sum ON p.id = budget_sum.project_id
        WHERE p.id = ?
    '''
    row = db.fetchone(query, (project_id,))
    if row:
        return {
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'maturity': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'program_id': row[9],
            'program_name': row[10],
            'potential_value': row[11],
            'refresh_date': row[12],
            'owner_id': row[13],
            'owner_name': row[14],
            'budget': float(row[15]) if row[15] else 0.0  # Computed from transactions
        }
    return None

# Call this in your app init
init_project_table()
