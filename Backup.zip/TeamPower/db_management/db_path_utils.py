import os
from pathlib import Path

def get_db_path():
    # Use environment variable if set, else default to project root
    return os.environ.get(
        'TEAM_POWER_DB_PATH',
        str(Path(__file__).resolve().parents[2] / 'team_power.db')
    )
