from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

# --- Utility for dashboard KPIs ---
def get_transactions_df():
    import pandas as pd
    try:
        data = get_transactions()
        if not data:
            # Return DataFrame with enforced column structure based on database schema
            return pd.DataFrame(columns=['ID', 'Date', 'Description', 'Cost Center Project', 'Cost Center SOW',
                                      'SOW Number', 'PO', 'Amount', 'Category', 'Type', 'Project ID', 'Project'])
        # Convert to DataFrame - data comes from get_transactions() which may include project name via JOIN
        df = pd.DataFrame(data)
        # Enforce the standard column structure based on database schema + project name
        expected_columns = ['ID', 'Date', 'Description', 'Cost Center Project', 'Cost Center SOW', 
                           'SOW Number', 'PO', 'Amount', 'Category', 'Type', 'Project ID', 'Project']
        if isinstance(data[0], dict):
            # Data is in dict format from get_transactions() 
            # Map database keys to display column names
            column_mapping = {
                'id': 'ID',
                'date': 'Date',
                'description': 'Description',
                'cost_center_project': 'Cost Center Project',
                'cost_center_sow': 'Cost Center SOW',
                'sow_number': 'SOW Number',
                'po': 'PO',
                'amount': 'Amount',
                'category': 'Category',
                'type': 'Type',
                'project_id': 'Project ID',
                'project': 'Project'  # project name from JOIN
            }
            # Create new DataFrame with standardized columns
            standardized_data = []
            for row in data:
                standardized_row = {}
                for db_key, display_key in column_mapping.items():
                    standardized_row[display_key] = row.get(db_key, '')
                standardized_data.append(standardized_row)
            df = pd.DataFrame(standardized_data)
        else:
            # Fallback: assign columns directly if data is in list format
            df.columns = expected_columns[:len(df.columns)]
        # Ensure we have all expected columns
        for col in expected_columns:
            if col not in df.columns:
                df[col] = ''
        # Reorder columns to match expected structure
        df = df[expected_columns]
        # Convert Amount to numeric
        df['Amount'] = pd.to_numeric(df['Amount'], errors='coerce')
        return df
    except Exception as e:
        print(f"Error getting transactions dataframe: {e}")
        # Return empty DataFrame with enforced column structure
        return pd.DataFrame(columns=['ID', 'Date', 'Description', 'Cost Center Project', 'Cost Center SOW',
                                   'SOW Number', 'PO', 'Amount', 'Category', 'Type', 'Project ID', 'Project'])


def init_transaction_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT,
        description TEXT,
        cost_center_project TEXT,
        cost_center_sow TEXT,
        sow_number TEXT,
        po TEXT,
        amount REAL,
        category TEXT,
        type TEXT,
        project_id INTEGER
    '''
    db.init_table('transactions', schema)

def add_transaction(date, description, cost_center_project, cost_center_sow, sow_number, po, amount, category, type, project_id=None):
    data = {
        'date': date,
        'description': description,
        'cost_center_project': cost_center_project,
        'cost_center_sow': cost_center_sow,
        'sow_number': sow_number,
        'po': po,
        'amount': amount,
        'category': category,
        'type': type,
        'project_id': project_id
    }
    db.insert('transactions', data)

def get_transaction_by_id(transaction_id):
    """Fetch a single transaction by its ID."""
    query = (
        "SELECT id, date, description, cost_center_project, cost_center_sow, "
        "sow_number, po, amount, category, type, project_id "
        "FROM transactions WHERE id = ?"
    )
    row = db.fetchone(query, (transaction_id,))
    if row:
        return {
            'id': row[0],
            'date': row[1],
            'description': row[2],
            'cost_center_project': row[3],
            'cost_center_sow': row[4],
            'sow_number': row[5],
            'po': row[6],
            'amount': row[7],
            'category': row[8],
            'type': row[9],
            'project_id': row[10],
        }
    return None

def get_transactions():
    # Get transactions with project names
    try:
        import sqlite3
        from .database_manager import DatabaseManager
        from .db_path_utils import get_db_path
        
        db_manager = DatabaseManager(get_db_path())
        
        # Query with JOIN to get project names
        query = """
        SELECT 
            t.id, t.date, t.description, t.cost_center_project, t.cost_center_sow,
            t.sow_number, t.po, t.amount, t.category, t.type, t.project_id,
            p.name as project_name
        FROM transactions t
        LEFT JOIN projects p ON t.project_id = p.id
        ORDER BY t.date DESC
        """
        
        rows = db_manager.fetchall(query)
        
        transactions = []
        for row in rows:
            transaction = {
                'id': row[0],
                'date': row[1],
                'description': row[2],
                'cost_center_project': row[3],
                'cost_center_sow': row[4],
                'sow_number': row[5],
                'po': row[6],
                'amount': row[7],
                'category': row[8],
                'type': row[9],
                'project_id': row[10],
                'project': row[11] or ''  # project name for display
            }
            
            # Format dates to show only YYYY-MM-DD (remove timestamp)
            if 'date' in transaction and transaction['date']:
                date_str = str(transaction['date'])
                if 'T' in date_str:
                    transaction['date'] = date_str.split('T')[0]
                elif ' ' in date_str and ':' in date_str:
                    transaction['date'] = date_str.split(' ')[0]
            
            transactions.append(transaction)
        
        return transactions
        
    except Exception as e:
        print(f"Error getting transactions with projects: {e}")
        # Fallback to basic select
        transactions = db.select('transactions')
        # Format dates to show only YYYY-MM-DD (remove timestamp)
        for transaction in transactions:
            if 'date' in transaction and transaction['date']:
                date_str = str(transaction['date'])
                # If date contains timestamp (T separator), keep only date part
                if 'T' in date_str:
                    transaction['date'] = date_str.split('T')[0]
                # If date is in full datetime format, extract just the date
                elif ' ' in date_str and ':' in date_str:
                    transaction['date'] = date_str.split(' ')[0]
        return transactions

def update_transaction(transaction_id, date, description, cost_center_project, cost_center_sow, sow_number, po, amount, category, type, project_id=None):
    data = {
        'date': date,
        'description': description,
        'cost_center_project': cost_center_project,
        'cost_center_sow': cost_center_sow,
        'sow_number': sow_number,
        'po': po,
        'amount': amount,
        'category': category,
        'type': type,
        'project_id': project_id
    }
    db.update('transactions', data, 'id=?', (transaction_id,))

def delete_transaction(transaction_id):
    db.delete('transactions', 'id=?', (transaction_id,))

# Call this in your app init
init_transaction_table()
