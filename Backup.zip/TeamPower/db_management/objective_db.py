from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_objectives_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        program_id INTEGER,
        owner_id INTEGER NOT NULL,
        main_responsible_id INTEGER,
        quarter TEXT,
        year INTEGER,
        status TEXT CHECK(status IN ('Planning', 'Active', 'At Risk', 'Completed', 'Cancelled')) DEFAULT 'Planning',
        progress REAL DEFAULT 0.0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    '''
    db.init_table('objectives', schema)

def add_objective(*args, **kwargs):
    pass

def get_objectives():
    # TODO: implement
    pass

def update_objective(*args, **kwargs):
    pass

def delete_objective(objective_id):
    db.delete('objectives', 'id=?', (objective_id,))

# Call this in your app init
init_objectives_table()
