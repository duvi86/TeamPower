import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import pandas as pd

class DatabaseManager:
    def __init__(self, db_path: Union[str, Path], db_type: str = "sqlite"):
        self.db_type = db_type
        self.db_path = str(db_path)
        if db_type == "sqlite":
            self._connect = self._sqlite_connect
        else:
            raise NotImplementedError(f"DB type {db_type} not supported yet.")

    def _sqlite_connect(self):
        return sqlite3.connect(self.db_path)

    def execute(self, query: str, params: Optional[tuple] = None, commit: bool = False) -> Any:
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(query, params or ())
            if commit:
                conn.commit()
            return cur
        finally:
            conn.close()

    def fetchall(self, query: str, params: Optional[tuple] = None) -> List[tuple]:
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(query, params or ())
            rows = cur.fetchall()
            return rows
        finally:
            conn.close()

    def fetchone(self, query: str, params: Optional[tuple] = None) -> Optional[tuple]:
        conn = self._connect()
        try:
            cur = conn.cursor()
            cur.execute(query, params or ())
            row = cur.fetchone()
            return row
        finally:
            conn.close()

    def insert(self, table: str, data: Dict[str, Any]) -> None:
        keys = ', '.join(data.keys())
        placeholders = ', '.join(['?'] * len(data))
        values = tuple(data.values())
        query = f"INSERT INTO {table} ({keys}) VALUES ({placeholders})"
        self.execute(query, values, commit=True)

    def update(self, table: str, data: Dict[str, Any], where: str, where_params: tuple) -> None:
        set_clause = ', '.join([f"{k}=?" for k in data.keys()])
        values = tuple(data.values()) + where_params
        query = f"UPDATE {table} SET {set_clause} WHERE {where}"
        self.execute(query, values, commit=True)

    def delete(self, table: str, where: str, where_params: tuple) -> None:
        query = f"DELETE FROM {table} WHERE {where}"
        self.execute(query, where_params, commit=True)

    def select(self, table: str, columns: Optional[List[str]] = None, where: Optional[str] = None, where_params: Optional[tuple] = None) -> List[Dict[str, Any]]:
        cols = ', '.join(columns) if columns else '*'
        query = f"SELECT {cols} FROM {table}"
        if where:
            query += f" WHERE {where}"
        rows = self.fetchall(query, where_params)
        if columns:
            return [dict(zip(columns, row)) for row in rows]
        else:
            # Get column names from table
            conn = self._connect()
            try:
                cur = conn.cursor()
                cur.execute(f"PRAGMA table_info({table})")
                colnames = [info[1] for info in cur.fetchall()]
            finally:
                conn.close()
            return [dict(zip(colnames, row)) for row in rows]

    def to_dataframe(self, table: str, columns: Optional[List[str]] = None, where: Optional[str] = None, where_params: Optional[tuple] = None) -> pd.DataFrame:
        data = self.select(table, columns, where, where_params)
        return pd.DataFrame(data)

    def init_table(self, table: str, schema: str) -> None:
        self.execute(f"CREATE TABLE IF NOT EXISTS {table} ({schema})", commit=True)

# Example usage:
# db = DatabaseManager("team_power.db")
# db.init_table("transactions", "id INTEGER PRIMARY KEY AUTOINCREMENT, ...")
# db.insert("transactions", {...})
# db.select("transactions")
