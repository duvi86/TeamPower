from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_program_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        start_date DATE,
        end_date DATE,
        status TEXT CHECK(status IN ('Planning', 'Active', 'On Hold', 'Completed', 'Cancelled')) DEFAULT 'Planning',
        budget REAL DEFAULT 0.0,
        owner_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    '''
    db.init_table('programs', schema)

def add_program(name, description, start_date, end_date, status='Planning', budget=0.0, owner_id=None):
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'owner_id': owner_id
    }
    db.insert('programs', data)

def get_programs():
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, \
               p.created_at, p.updated_at, p.owner_id, owner.name as owner_name
        FROM programs p
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        ORDER BY p.created_at DESC
    '''
    rows = db.fetchall(query)
    programs = []
    for row in rows:
        programs.append({
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'owner_id': row[9],
            'owner_name': row[10]
        })
    return programs

def update_program(program_id, name, description, start_date, end_date, status, budget, owner_id=None):
    from datetime import datetime
    data = {
        'name': name,
        'description': description,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
        'budget': budget,
        'owner_id': owner_id,
        'updated_at': datetime.now()
    }
    db.update('programs', data, 'id=?', (program_id,))

def delete_program(program_id):
    db.delete('programs', 'id=?', (program_id,))

def get_program_by_id(program_id):
    query = '''
        SELECT p.id, p.name, p.description, p.start_date, p.end_date, p.status, p.budget, \
               p.created_at, p.updated_at, p.owner_id, owner.name as owner_name
        FROM programs p
        LEFT JOIN team_members owner ON p.owner_id = owner.id
        WHERE p.id = ?
    '''
    row = db.fetchone(query, (program_id,))
    if row:
        return {
            'id': row[0],
            'name': row[1],
            'description': row[2],
            'start_date': row[3],
            'end_date': row[4],
            'status': row[5],
            'budget': row[6],
            'created_at': row[7],
            'updated_at': row[8],
            'owner_id': row[9],
            'owner_name': row[10]
        }
    return None

def get_programs_with_computed_budget():
    """Get all programs with computed budget from related transactions using proper project linking"""
    try:
        # Get all programs with their computed budgets using proper Transaction→Project→Program linking via junction table
        query = """
        SELECT 
            p.id,
            p.name,
            p.description,
            p.start_date,
            p.end_date,
            p.status,
            p.owner_id,
            tm.name as owner_name,
            COALESCE(budget_sum.total_budget, 0) as computed_budget
        FROM programs p
        LEFT JOIN team_members tm ON p.owner_id = tm.id
        LEFT JOIN (
            SELECT 
                pp.program_id,
                SUM(t.amount) as total_budget
            FROM transactions t
            JOIN projects proj ON t.project_id = proj.id
            JOIN program_projects pp ON proj.id = pp.project_id
            GROUP BY pp.program_id
        ) budget_sum ON p.id = budget_sum.program_id
        ORDER BY p.name
        """
        
        rows = db.fetchall(query)
        
        programs = []
        for row in rows:
            program = {
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'start_date': row[3],
                'end_date': row[4],
                'status': row[5],
                'owner_id': row[6],
                'owner': row[7] or '',  # owner name for display
                'budget': float(row[8])  # computed budget
            }
            programs.append(program)
        
        return programs
        
    except Exception as e:
        print(f"Error getting programs with computed budget: {e}")
        return []

# Call this in your app init
init_program_table()
