"""
Time management utilities for OKR lifecycle tracking and completion statistics
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import sqlite3


def calculate_time_to_completion(started_at: str, completed_at: Optional[str] = None) -> Optional[int]:
    """Calculate days from start to completion (or current date if not completed)"""
    if not started_at:
        return None
    
    start = datetime.fromisoformat(started_at)
    end = datetime.fromisoformat(completed_at) if completed_at else datetime.now()
    return (end - start).days


def calculate_activation_delay(activated_at: str, started_at: Optional[str] = None) -> Optional[int]:
    """Calculate days between activation and start"""
    if not activated_at or not started_at:
        return None
    
    activation = datetime.fromisoformat(activated_at)
    start = datetime.fromisoformat(started_at)
    return (start - activation).days


def get_time_statistics(db_path: str = 'team_power.db') -> Dict:
    """Get comprehensive time statistics for OKRs"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get completion statistics for key results
    cursor.execute('''
        SELECT 
            title,
            status,
            priority,
            activated_at,
            started_at,
            completed_at,
            estimated_completion_date,
            estimated_hours,
            actual_hours_spent,
            owner_id
        FROM key_results
        WHERE activated_at IS NOT NULL
    ''')
    
    key_results = cursor.fetchall()
    
    stats = {
        'total_okrs': len(key_results),
        'completed_okrs': 0,
        'in_progress_okrs': 0,
        'avg_completion_time': 0,
        'avg_activation_delay': 0,
        'efficiency_ratio': 0,  # actual vs estimated hours
        'by_priority': {
            'P1': {'count': 0, 'completed': 0, 'avg_time': 0}, 
            'P2': {'count': 0, 'completed': 0, 'avg_time': 0}, 
            'P3': {'count': 0, 'completed': 0, 'avg_time': 0}
        },
        'by_lead': {},
        'completion_timeline': []
    }
    
    total_completion_days = 0
    total_activation_delays = 0
    completed_count = 0
    delay_count = 0
    total_estimated_hours = 0
    total_actual_hours = 0
    
    for row in key_results:
        title, status, priority, activated_at, started_at, completed_at, est_completion, est_hours, actual_hours, owner_id = row
        
        # Calculate completion time
        if completed_at:
            completion_days = calculate_time_to_completion(started_at, completed_at)
            if completion_days is not None:
                total_completion_days += completion_days
                completed_count += 1
                stats['completed_okrs'] += 1
                
                stats['completion_timeline'].append({
                    'title': title,
                    'completion_days': completion_days,
                    'priority': priority,
                    'completed_at': completed_at
                })
        elif started_at:
            stats['in_progress_okrs'] += 1
        
        # Calculate activation delay
        activation_delay = calculate_activation_delay(activated_at, started_at)
        if activation_delay is not None:
            total_activation_delays += activation_delay
            delay_count += 1
        
        # Hours tracking
        if est_hours:
            total_estimated_hours += est_hours
        if actual_hours:
            total_actual_hours += actual_hours
        
        # By priority statistics
        if priority and priority not in stats['by_priority']:
            stats['by_priority'][priority] = {'count': 0, 'completed': 0, 'avg_time': 0}
        
        if priority:
            stats['by_priority'][priority]['count'] += 1
            if completed_at:
                stats['by_priority'][priority]['completed'] += 1
        
        # By lead statistics
        if owner_id and owner_id not in stats['by_lead']:
            stats['by_lead'][owner_id] = {'count': 0, 'completed': 0, 'total_hours': 0}
        
        if owner_id:
            stats['by_lead'][owner_id]['count'] += 1
            if completed_at:
                stats['by_lead'][owner_id]['completed'] += 1
            if actual_hours:
                stats['by_lead'][owner_id]['total_hours'] += actual_hours
    
    # Calculate averages
    if completed_count > 0:
        stats['avg_completion_time'] = round(total_completion_days / completed_count, 1)
    
    if delay_count > 0:
        stats['avg_activation_delay'] = round(total_activation_delays / delay_count, 1)
    
    if total_estimated_hours > 0:
        stats['efficiency_ratio'] = round(total_actual_hours / total_estimated_hours, 2)
    
    # Calculate priority-specific completion times
    for priority in stats['by_priority']:
        priority_completions = [item for item in stats['completion_timeline'] if item['priority'] == priority]
        if priority_completions:
            avg_time = sum(item['completion_days'] for item in priority_completions) / len(priority_completions)
            stats['by_priority'][priority]['avg_time'] = round(avg_time, 1)
    
    conn.close()
    return stats


def get_okr_timeline_data(db_path: str = 'team_power.db') -> List[Dict]:
    """Get timeline data for visualization"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            kr.title,
            kr.status,
            kr.priority,
            kr.activated_at,
            kr.started_at,
            kr.completed_at,
            kr.estimated_completion_date,
            tm.name as lead_name
        FROM key_results kr
        LEFT JOIN team_members tm ON kr.owner_id = tm.id
        WHERE kr.activated_at IS NOT NULL
        ORDER BY kr.activated_at DESC
    ''')
    
    timeline_data = []
    for row in cursor.fetchall():
        title, status, priority, activated_at, started_at, completed_at, est_completion, lead_name = row
        
        timeline_item = {
            'title': title,
            'status': status,
            'priority': priority,
            'lead_name': lead_name,
            'activated_at': activated_at,
            'started_at': started_at,
            'completed_at': completed_at,
            'estimated_completion_date': est_completion,
            'is_overdue': False,
            'days_active': 0
        }
        
        # Calculate days active
        if activated_at:
            start_date = datetime.fromisoformat(activated_at)
            end_date = datetime.fromisoformat(completed_at) if completed_at else datetime.now()
            timeline_item['days_active'] = (end_date - start_date).days
        
        # Check if overdue
        if est_completion and not completed_at:
            est_date = datetime.fromisoformat(est_completion)
            timeline_item['is_overdue'] = datetime.now() > est_date
        
        timeline_data.append(timeline_item)
    
    conn.close()
    return timeline_data


def update_okr_status(okr_id: int, new_status: str, db_path: str = 'team_power.db') -> bool:
    """Update OKR status and set appropriate timestamp"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        now = datetime.now().isoformat()
        
        # Determine which timestamp to update based on status
        timestamp_updates = {
            'Active': 'started_at',
            'Completed': 'completed_at',
            'Paused': 'paused_at',
            'Cancelled': 'cancelled_at'
        }
        
        if new_status in timestamp_updates:
            timestamp_field = timestamp_updates[new_status]
            cursor.execute(f'''
                UPDATE key_results 
                SET status = ?, {timestamp_field} = ?
                WHERE id = ?
            ''', (new_status, now, okr_id))
        else:
            cursor.execute('UPDATE key_results SET status = ? WHERE id = ?', (new_status, okr_id))
        
        conn.commit()
        return True
    except Exception as e:
        print(f"Error updating OKR status: {e}")
        return False
    finally:
        conn.close()


def get_performance_insights(db_path: str = 'team_power.db') -> Dict:
    """Generate performance insights and recommendations"""
    stats = get_time_statistics(db_path)
    insights = {
        'recommendations': [],
        'alerts': [],
        'trends': {}
    }
    
    # Completion rate analysis
    if stats['total_okrs'] > 0:
        completion_rate = stats['completed_okrs'] / stats['total_okrs']
        if completion_rate < 0.3:
            insights['alerts'].append("Low completion rate - consider reviewing OKR scope and priorities")
        elif completion_rate > 0.8:
            insights['recommendations'].append("Excellent completion rate - consider increasing OKR ambition")
    
    # Efficiency analysis
    if stats['efficiency_ratio'] > 1.5:
        insights['alerts'].append("Significant time overruns - improve estimation accuracy")
    elif stats['efficiency_ratio'] < 0.8:
        insights['recommendations'].append("Ahead of schedule - consider taking on additional objectives")
    
    # Priority analysis
    for priority, data in stats['by_priority'].items():
        if data['count'] > 0:
            priority_completion_rate = data['completed'] / data['count']
            if priority == 'P1' and priority_completion_rate < 0.5:
                insights['alerts'].append(f"Low P1 completion rate ({priority_completion_rate:.1%})")
    
    # Activation delay analysis
    if stats['avg_activation_delay'] > 7:
        insights['recommendations'].append("Reduce activation delay - OKRs are taking too long to start")
    
    return insights
