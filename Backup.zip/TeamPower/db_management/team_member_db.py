from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_team_member_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        role TEXT NOT NULL,
        department TEXT,
        manager_id INTEGER,
        start_date DATE,
        status TEXT CHECK(status IN ('Active', 'Inactive', 'On Leave')) DEFAULT 'Active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    '''
    db.init_table('team_members', schema)

def add_team_member(name, email, role, department=None, manager_id=None, start_date=None, status='Active'):
    data = {
        'name': name,
        'email': email,
        'role': role,
        'department': department,
        'manager_id': manager_id,
        'start_date': start_date,
        'status': status
    }
    db.insert('team_members', data)

def get_team_members():
    query = '''
        SELECT id, name, email, role, department, manager_id, start_date, status, created_at, updated_at
        FROM team_members
        ORDER BY created_at DESC
    '''
    rows = db.fetchall(query)
    members = []
    for row in rows:
        members.append({
            'id': row[0],
            'name': row[1],
            'email': row[2],
            'role': row[3],
            'department': row[4],
            'manager_id': row[5],
            'start_date': row[6],
            'status': row[7],
            'created_at': row[8],
            'updated_at': row[9]
        })
    return members

def update_team_member(member_id, name, email, role, department=None, manager_id=None, start_date=None, status='Active'):
    from datetime import datetime
    data = {
        'name': name,
        'email': email,
        'role': role,
        'department': department,
        'manager_id': manager_id,
        'start_date': start_date,
        'status': status,
        'updated_at': datetime.now()
    }
    db.update('team_members', data, 'id=?', (member_id,))

def delete_team_member(member_id):
    db.delete('team_members', 'id=?', (member_id,))

def get_team_member_by_id(member_id):
    query = '''
        SELECT id, name, email, role, department, manager_id, start_date, status, created_at, updated_at
        FROM team_members
        WHERE id = ?
    '''
    row = db.fetchone(query, (member_id,))
    if row:
        return {
            'id': row[0],
            'name': row[1],
            'email': row[2],
            'role': row[3],
            'department': row[4],
            'manager_id': row[5],
            'start_date': row[6],
            'status': row[7],
            'created_at': row[8],
            'updated_at': row[9]
        }
    return None

def get_team_members_with_details():
    """Get team members with detailed information including manager and project names"""
    query = '''
        SELECT tm.id, tm.name, tm.email, tm.role, tm.department, tm.start_date, tm.end_date, tm.status,
               manager.name as manager_name
        FROM team_members tm
        LEFT JOIN team_members manager ON tm.manager_id = manager.id
        ORDER BY tm.name
    '''
    rows = db.fetchall(query)
    team_members = []
    for row in rows:
        team_members.append({
            'id': row[0],
            'name': row[1],
            'email': row[2],
            'role': row[3],
            'department': row[4],
            'start_date': row[5],
            'end_date': row[6],
            'status': row[7],
            'manager_name': row[8]
        })
    return team_members

# Call this in your app init
init_team_member_table()
