from .database_manager import DatabaseManager
from .db_path_utils import get_db_path

DB_PATH = get_db_path()
db = DatabaseManager(DB_PATH)

def init_project_team_table():
    schema = '''
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        team_member_id INTEGER NOT NULL,
        role_in_project TEXT DEFAULT 'Team Member',
        allocation_percentage REAL DEFAULT 100.0,
        start_date DATE,
        end_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    '''
    db.init_table('project_teams', schema)

def add_project_team(project_id, team_member_id, role_in_project='Team Member', allocation_percentage=100.0, start_date=None, end_date=None):
    data = {
        'project_id': project_id,
        'team_member_id': team_member_id,
        'role_in_project': role_in_project,
        'allocation_percentage': allocation_percentage,
        'start_date': start_date,
        'end_date': end_date
    }
    db.insert('project_teams', data)

def get_project_teams():
    query = '''
        SELECT id, project_id, team_member_id, role_in_project, allocation_percentage, start_date, end_date, created_at
        FROM project_teams
    '''
    rows = db.fetchall(query)
    return [
        {
            'id': row[0],
            'project_id': row[1],
            'team_member_id': row[2],
            'role_in_project': row[3],
            'allocation_percentage': row[4],
            'start_date': row[5],
            'end_date': row[6],
            'created_at': row[7]
        }
        for row in rows
    ]

def delete_project_team_by_project(project_id):
    db.delete('project_teams', 'project_id=?', (project_id,))

# Call this in your app init
init_project_team_table()
