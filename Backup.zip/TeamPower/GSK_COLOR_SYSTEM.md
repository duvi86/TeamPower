# GSK Design System Colors for Visualizations

## Overview

The application now uses the official GSK Design System colors for all visualizations, ensuring brand consistency and accessibility.

## Color Implementation

### 1. GSK Visualization Color Palette

The following colors are now used for department visualizations:

- **Blue**: `#154EC2` (--color-viz-blue) - Technology, Finance
- **Teal**: `#21837E` (--color-viz-teal) - Vision, Data & Analytics, IT
- **Green**: `#66A73d` (--color-viz-green) - Product, Research, Manufacturing  
- **Purple**: `#ca305b` (--color-viz-purple) - Design, Quality, Clinical
- **Yellow**: `#f7C650` (--color-viz-yellow) - Sales, Commercial
- **Violet**: `#7540EE` (--color-viz-violet) - Executive, Strategy
- **Orange**: `#F36633` (--color-accent-primary) - Marketing, Innovation

### 2. Current Department Assignments

Based on the actual departments in the database:

- **Digital Twins**: `#154EC2` (GSK Blue) - Technology/Innovation focus
- **Vision**: `#21837E` (GSK Teal) - Vision/Strategy focus

### 3. Status Colors

For employee status visualizations:

- **Active**: `#448422` (GSK Success Strong)
- **On Leave**: `#FFC709` (GSK Warning Strong)
- **Inactive**: `#C83629` (GSK Error Strong)

## Updated Components

### 1. Organization Charts (Sunburst)
- Location: `multipages/utils/create_sunburst_chart.py`
- Uses GSK visualization colors for departments
- Uses GSK status colors for employee status

### 2. Team Distribution (Pie Chart)
- Location: `multipages/pages/ai_monitoring.py`
- Department colors follow GSK visualization palette
- Consistent with organizational chart colors

### 3. Department Status (Stacked Bar Chart)  
- Location: `multipages/utils/create_stacked_bar_chart.py`
- Uses GSK status colors for employee status categories

### 4. CSS Variables
- Location: `multipages/assets/styles.css`
- Added chart-specific CSS variables mapping to GSK colors
- Enables consistent color usage across components

## Utility Functions

### GSK Color Utilities (`multipages/utils/gsk_colors.py`)

```python
# Get department color mapping
get_department_color_mapping()

# Get status color mapping  
get_status_color_mapping()

# Get color sequence for specific departments
get_department_color_sequence(['Digital Twins', 'Vision'])

# Get GSK visualization color palette
get_gsk_color_palette(count=5)
```

## Benefits

1. **Brand Consistency**: All visualizations use official GSK Design System colors
2. **Accessibility**: GSK colors are designed for optimal contrast and accessibility
3. **Maintainability**: Centralized color management through utility functions
4. **Scalability**: Easy to add new departments with appropriate GSK colors
5. **CSS Integration**: Colors are mapped to CSS variables for consistent styling

## Testing

The color system has been tested with:
- Current departments: Digital Twins, Vision
- Organization charts with department hierarchy
- Team distribution pie charts
- Status-based visualizations

All visualizations now display with proper GSK Design System colors while maintaining visual clarity and brand consistency.
