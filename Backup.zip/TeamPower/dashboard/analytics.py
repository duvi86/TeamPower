import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from dash import html, dcc
from TeamPower.utils.create_graph_card import create_graph_card
from TeamPower.utils.create_dashboard_grid import create_dashboard_grid
from TeamPower.utils.create_dropdown import create_dropdown
from TeamPower.db_management.db import get_transactions_df

def create_monthly_analysis_chart(df_filtered, selected_year):
    """
    Create monthly analysis chart showing Budget, Planned, and Consumed
    """
    if df_filtered.empty:
        empty_figure = px.bar(title='No data available')
        empty_figure.update_layout(
            template='plotly_white',
            height=400,
            margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
        )
        return create_graph_card(
            id='monthly-analysis-chart',
            figure=empty_figure,
            title='Monthly Financial Analysis',
            height=500,
            actions=False
        )
    
    # Create year date range
    year_start = pd.Timestamp(f'{selected_year}-01-01')
    all_months = pd.date_range(start=year_start, end=pd.Timestamp(f'{selected_year}-12-01'), freq='MS')
    month_index = [d.strftime('%Y-%m') for d in all_months]
    month_labels = [d.strftime('%b') for d in all_months]
    
    # Group by month and transaction type (Budget, Planned, Consumed)
    monthly_data = df_filtered.groupby([df_filtered['Date'].dt.strftime('%Y-%m'), 'Type'])['Amount'].sum().unstack(fill_value=0)
    monthly_df = pd.DataFrame(index=month_index, columns=['Budget', 'Planned', 'Consumed'], dtype=float).fillna(0.0)
    
    if not monthly_data.empty:
        for col in monthly_data.columns:
            if col in monthly_df.columns:
                monthly_df[col] = monthly_data[col].reindex(month_index, fill_value=0.0)
    
    # Ensure all values are numeric and fill any remaining NaN with 0
    monthly_df = monthly_df.fillna(0.0)
    
    # Create the figure with explicit sizing
    monthly_figure = px.bar(
        monthly_df,
        x=month_labels,
        y=['Budget', 'Planned', 'Consumed'],
        title=f'Monthly Financial Analysis - {selected_year}',
        labels={'value': 'Amount ($)', 'x': 'Month', 'variable': 'Type'},
        barmode='group',
        color_discrete_map={'Budget': '#2E86AB', 'Planned': '#A23B72', 'Consumed': '#F18F01'}
    )
    monthly_figure.update_layout(
        template='plotly_white',
        title={'x': 0.5, 'xanchor': 'center'},
        xaxis={'tickangle': 0},
        yaxis={'tickformat': '$,.0f'},
        height=400,  # Fixed height for consistency
        margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
    )
    
    return create_graph_card(
        id='monthly-analysis-chart',
        figure=monthly_figure,
        title='Monthly Financial Analysis',
        height=500,  # Increased card height to accommodate chart
        actions=False  # Remove Twin Start/Stop buttons
    )

def budget_financial_analytics(selected_year=2025):
    """
    Create budget financial analytics with year-to-date and monthly plots
    Uses only CSS classes, no inline styling
    
    Parameters:
    -----------
    selected_year : int
        The year to filter the data by
        
    Returns:
    --------
    dash components
        Dashboard grid with financial plots
    """
    # Get filtered transaction data
    df = get_transactions_df()
    if df.empty:
        return html.Div("No transaction data available", className="text-center p-4")
    
    # Convert Date to datetime and filter by selected year
    df['Date'] = pd.to_datetime(df['Date'])
    df_filtered = df[df['Date'].dt.year == selected_year]
    
    if df_filtered.empty:
        return html.Div(f"No transaction data available for {selected_year}", className="text-center p-4")
    
    # Create year date range
    year_start = pd.Timestamp(f'{selected_year}-01-01')
    year_end = pd.Timestamp(f'{selected_year}-12-31')
    
    # Generate YTD data
    if not df_filtered.empty:
        # Create full year date range with all dates
        date_range = pd.date_range(start=year_start, end=year_end, freq='D')
        
        # Create cumulative sums for each category
        categories = ['Budget', 'Planned', 'Consumed']
        ytd_data = []
        
        for category in categories:
            cat_data = df_filtered[df_filtered['Type'] == category].copy()
            if not cat_data.empty:
                daily_sums = cat_data.groupby('Date')['Amount'].sum()
                cumsum = daily_sums.reindex(date_range, fill_value=0).cumsum()
                ytd_data.append(pd.DataFrame({category: cumsum}))
        
        ytd = pd.concat(ytd_data, axis=1).fillna(0.0) if ytd_data else pd.DataFrame()
    else:
        ytd = pd.DataFrame()
    
    # Create YTD line chart - no buttons, cleaner display
    if not ytd.empty:
        ytd_figure = px.line(
            ytd, 
            x=ytd.index, 
            y=ytd.columns,
            title=f'Cumulative Financial Progress - {selected_year}',
            labels={'value': 'Amount ($)', 'Date': 'Date', 'variable': 'Category'}
        )
        ytd_figure.update_layout(
            template='plotly_white',
            title={'x': 0.5, 'xanchor': 'center'},
            yaxis={'tickformat': '$,.0f'},
            xaxis={'title': 'Date'},
            height=400,  # Fixed height for consistency
            margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
        )
        
        ytd_chart = create_graph_card(
            id='ytd-financial-chart',
            figure=ytd_figure,
            title='Year-to-Date Overview',
            height=500,  # Increased card height
            actions=False  # Remove Twin Start/Stop buttons
        )
    else:
        ytd_figure = px.line(title='No YTD data available')
        ytd_figure.update_layout(
            template='plotly_white',
            height=400,
            margin={'t': 60, 'b': 40, 'l': 60, 'r': 20}
        )
        ytd_chart = create_graph_card(
            id='ytd-financial-chart',
            figure=ytd_figure,
            title='Year-to-Date Overview',
            height=500,
            actions=False
        )
    
    # Create monthly analysis with default category (will be updated by callback)
    monthly_section = create_monthly_analysis_chart(df_filtered, selected_year)
    
    # Create layout with two columns using CSS classes
    return html.Div([
        html.Div([
            # Left column - YTD Chart
            html.Div(ytd_chart, className='chart-column'),
            # Right column - Monthly Analysis with Dropdown
            html.Div(monthly_section, className='chart-column')
        ], className='charts-container')
    ], className='budget-analytics-section')

def analytics_charts(df):
    # Pie chart for status
    status_counts = df['status'].value_counts()
    status_pie = px.pie(
        values=status_counts.values,
        names=status_counts.index,
        title="Key Wins by Status",
        color_discrete_map={
            'Completed': '#28a745',
            'In Progress': '#ffc107',
            'Pending': '#6c757d',
            'On Hold': '#dc3545'
        }
    )
    status_pie.update_traces(textposition='inside', textinfo='percent+label')

    # Bar chart for value
    value_data = pd.DataFrame({
        'Type': ['Potential Value', 'Realized Value', 'Remaining Value'],
        'Value': [df['value_potential'].sum(), df['value_realized'].sum(), max(0, df['value_potential'].sum() - df['value_realized'].sum())],
        'Color': ['#007bff', '#28a745', '#ffc107']
    })
    value_bar = px.bar(
        value_data, x='Type', y='Value',
        title="Value Analysis",
        color='Color',
        color_discrete_map={c: c for c in value_data['Color']}
    )
    value_bar.update_layout(showlegend=False)

    # Wins per lead (owner)
    owner_chart = None
    if 'owner_name' in df.columns and not df['owner_name'].isna().all():
        owner_counts = df.groupby('owner_name').agg({'id': 'count', 'value_realized': 'sum'}).reset_index()
        owner_counts.columns = ['Owner', 'Total Wins', 'Value Realized']
        owner_bar = px.bar(
            owner_counts, x='Owner', y='Total Wins',
            title="Key Wins by Owner",
            color='Value Realized',
            color_continuous_scale='Viridis'
        )
        owner_chart = owner_bar

    # Use modular graph cards and dashboard grid
    items = [
        {
            'type': 'graph',
            'title': 'Key Wins by Status',
            'id': 'status-pie-card',
            'figure': status_pie,
            'width': 4
        },
        {
            'type': 'graph',
            'title': 'Value Analysis',
            'id': 'value-bar-card',
            'figure': value_bar,
            'width': 4
        }
    ]
    if owner_chart is not None:
        items.append({
            'type': 'graph',
            'title': 'Key Wins by Owner',
            'id': 'owner-bar-card',
            'figure': owner_chart,
            'width': 4
        })

    return create_dashboard_grid(items, grid_style={'marginBottom': '24px'})
